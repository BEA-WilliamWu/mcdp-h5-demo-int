package com.ofss.digx.cz.bea.app.notifications.example;

import com.ofss.digx.app.alerts.dto.eventgen.ActivityLog;

/** Example-only payload: no passwords, OTPs, account details or recipient addresses. */
public class BmNotificationActivityLogDTO extends ActivityLog {
    private static final long serialVersionUID = 1L;
    private String bmDemoUserId;
    private String bmDemoReference;
    private String bmDemoApprovedAt;

    public String getBmDemoUserId() { return bmDemoUserId; }
    public void setBmDemoUserId(String value) { bmDemoUserId = value; }
    public String getBmDemoReference() { return bmDemoReference; }
    public void setBmDemoReference(String value) { bmDemoReference = value; }
    public String getBmDemoApprovedAt() { return bmDemoApprovedAt; }
    public void setBmDemoApprovedAt(String value) { bmDemoApprovedAt = value; }
}
