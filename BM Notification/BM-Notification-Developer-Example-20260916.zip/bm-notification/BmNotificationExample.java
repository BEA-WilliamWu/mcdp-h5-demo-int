package com.ofss.digx.cz.bea.app.notifications.example;

import com.ofss.fc.app.context.SessionContext;
import com.ofss.fc.enumeration.ep.DestinationType;
import com.ofss.fc.enumeration.ep.SubscriberType;
import com.ofss.fc.service.response.TransactionStatus;
import com.ofss.fc.xface.ep.dto.NotificationDetail;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Reference example only; not a REST endpoint and not wired into the application.
 * Caller must resolve contacts on the server and provide an approved, COMMITTED
 * business outcome (normally from a durable notification ledger / outbox).
 * Publication is NOT delivery and this class alone does NOT provide deduplication.
 */
public final class BmNotificationExample {
    public static final String ACTIVITY_ID =
        "com.ofss.digx.cz.bea.app.notifications.example.BmNotificationExample.publish";
    public static final String EVENT_ID = "BM_EXAMPLE_APPROVED";

    @FunctionalInterface
    public interface EventPublisher {
        TransactionStatus publish(SessionContext context, String activity, String event,
                com.ofss.fc.datatype.Date at, BmNotificationActivityLogDTO payload)
                throws com.ofss.digx.infra.exceptions.Exception;
    }
    private final EventPublisher publisher;
    public BmNotificationExample(EventPublisher publisher) {
        if (publisher == null) throw new IllegalArgumentException("Missing event publisher");
        this.publisher = publisher;
    }

    public TransactionStatus publishEmail(SessionContext context, String ownerPartyId,
            String targetUserId, String businessReference, Instant approvedAt, String email)
            throws com.ofss.digx.infra.exceptions.Exception {
        String destination = required(email, "email");
        if (!destination.matches("[^\\s@;,<>]+@[^\\s@;,<>]+\\.[^\\s@;,<>]+"))
            throw new IllegalArgumentException("Expected one server-resolved email address");
        return publish(context, ownerPartyId, targetUserId, businessReference, approvedAt,
            DestinationType.EMAIL, destination);
    }

    /**
     * Legacy SMSDispatcher input: LOCAL_NUMBER~COUNTRY_CODE, not a full number twice.
     * Requires event-scoped country-code/recipient checks described in the guide.
     * Do NOT assume this bypasses SMSDispatcher's database country-code selection.
     */
    public TransactionStatus publishSms(SessionContext context, String ownerPartyId,
            String targetUserId, String businessReference, Instant approvedAt,
            String localNumber, String countryCode) throws com.ofss.digx.infra.exceptions.Exception {
        String local = required(localNumber, "localNumber");
        String country = required(countryCode, "countryCode");
        if (!country.matches("[1-9][0-9]{0,2}") || !local.matches("[0-9]{4,14}")
                || country.length() + local.length() > 15)
            throw new IllegalArgumentException("Invalid separated SMS number / country code");
        return publish(context, ownerPartyId, targetUserId, businessReference, approvedAt,
            DestinationType.SMS, local + "~" + country);
    }

    private TransactionStatus publish(SessionContext context, String ownerPartyId,
            String targetUserId, String businessReference, Instant approvedAt,
            DestinationType destination, String address) throws com.ofss.digx.infra.exceptions.Exception {
        if (context == null || approvedAt == null) throw new IllegalArgumentException("Missing approved context");
        required(context.getUserId(), "actorUserId");
        required(context.getTargetUnit(), "targetUnit");
        String party = identifier(ownerPartyId, "ownerPartyId");
        String user = identifier(targetUserId, "targetUserId");
        String reference = identifier(businessReference, "businessReference");
        NotificationDetail detail = new NotificationDetail();
        detail.setRecipientId(party);
        detail.setRecipientType(SubscriberType.EXTERNAL.toString());
        detail.setDestination(destination);
        detail.setDispatchAddress(address);
        BmNotificationActivityLogDTO log = new BmNotificationActivityLogDTO();
        log.setCustomerId(party);
        log.setBmDemoUserId(user);
        log.setBmDemoReference(reference);
        log.setBmDemoApprovedAt(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH)
            .withZone(ZoneId.of("Asia/Hong_Kong")).format(approvedAt));
        log.setNotificationDetails(new NotificationDetail[] { detail });

        String originalParty = context.getTransactingPartyCode();
        String originalLocale = context.getUserLocale();
        try {
            context.setTransactingPartyCode(party);
            context.setUserLocale("en"); // Example SQL provides en only; extend both sides together.
            // Keep the real BM actor identity. Never impersonate the recipient in SessionContext.
            return publisher.publish(context, ACTIVITY_ID, EVENT_ID, new com.ofss.fc.datatype.Date(), log);
        } finally {
            context.setTransactingPartyCode(originalParty);
            context.setUserLocale(originalLocale);
        }
    }
    private static String required(String value, String field) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Missing " + field);
        return value.trim();
    }
    private static String identifier(String value, String field) {
        String result = required(value, field);
        if (!result.matches("[A-Za-z0-9@._-]{1,128}")) throw new IllegalArgumentException("Invalid " + field);
        return result;
    }
}
