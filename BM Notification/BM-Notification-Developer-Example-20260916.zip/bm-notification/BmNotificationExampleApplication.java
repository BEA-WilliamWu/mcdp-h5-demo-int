package com.ofss.digx.cz.bea.app.notifications.example;

import com.ofss.digx.app.AbstractApplication;

/** Thin bridge demonstrating the real, protected OBDX event API. Not auto-registered. */
public class BmNotificationExampleApplication extends AbstractApplication {
    public BmNotificationExample publisher() {
        return new BmNotificationExample((context, activity, event, at, payload) ->
            super.registerActivityAndGenerateEvent(context, activity, event, at, payload));
    }
}
