# 源码索引

基线：`b55652b0`。以下为原项目中的路径和当时的行号，修改后行号可能变化；建议用关键字搜索。ZIP只含开发示例，不包含这些项目源码或依赖。

## BM现有通知业务，需注意 README 第12节中的通道/事件不一致

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.module.hosttohost/src/com/ofss/digx/cz/bea/app/hosttohost/service/HostToHostManagement.java`
- 行号：`334`；定位关键字：`private void notifyHostToHostManagement`

## approvedExecution 分支调用通知；不是最终COMMIT保证

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.module.hosttohost/src/com/ofss/digx/cz/bea/app/hosttohost/service/HostToHostManagement.java`
- 行号：`547`；定位关键字：`private String processSave`

## 公司邮箱/电话的选择

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.module.hosttohost/src/com/ofss/digx/cz/bea/app/hosttohost/service/HostToHostManagement.java`
- 行号：`507`；定位关键字：`private NotificationDetail buildNotification`

## 1216审批通知意图捕获，有特定业务范围

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.module.hosttohost/src/com/ofss/digx/cz/bea/app/hosttohost/service/HthUserAccessNotification.java`
- 行号：`30`；定位关键字：`class HthUserAccessNotification`

## 已提交意图发布、上下文恢复

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/HthUserAccessNotificationService.java`
- 行号：`22`；定位关键字：`public void process`

## HTH事件白名单及可靠派送，不是通用BM默认路径

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/HthContactNotificationDispatch.java`
- 行号：`26`；定位关键字：`static boolean matches`

## 邮件入口、adapter及默认处理分支

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/EmailDispatcher.java`
- 行号：`1051`；定位关键字：`public DispatchResult dispatchAlert`

## 邮件MNG调用及审计异常处理

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/EmailDispatcher.java`
- 行号：`354`；定位关键字：`public DispatchResult sendMNGMail`

## 邮件请求构造，package-private

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/EmailDispatcher.java`
- 行号：`565`；定位关键字：`List<MNGEmailAlertsDTO> buildMNGrequest`

## 短信入口、mock及长度检查

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/SMSDispatcher.java`
- 行号：`123`；定位关键字：`public DispatchResult dispatchAlert`

## 短信国家码优先规则

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/SMSDispatcher.java`
- 行号：`511`；定位关键字：`SMS_DISPATCHER_SKIP_COUNTRY_CODE_EVENTID_LIST`

## 短信请求构造，package-private

- 文件：`consulting/middleware/projects/module/com.ofss.digx.cz.bea.domain.service.dispatch/src/com/ofss/digx/cz/bea/domain/service/dispatch/SMSDispatcher.java`
- 行号：`643`；定位关键字：`List<MNGSmsAlertDTO> buildMNGrequest`

## BM邮件路由：BMMNG/MNG

- 文件：`consulting/middleware/projects/ext-xface/com.ofss.digx.cz.bea.extxface.app.impl/src/com/ofss/digx/cz/bea/extxface/alerts/impl/assembler/MNGEmailAdapterAssembler.java`
- 行号：`48`；定位关键字：`System.getProperty("isAdmin")`

## BM短信路由：BMMNGSMS/MNGSMS

- 文件：`consulting/middleware/projects/ext-xface/com.ofss.digx.cz.bea.extxface.app.impl/src/com/ofss/digx/cz/bea/extxface/alerts/impl/assembler/MNGSmsAdapterAssembler.java`
- 行号：`48`；定位关键字：`System.getProperty("isAdmin")`

## 通过EndpointFactory调用外部邮件网关

- 文件：`consulting/middleware/projects/ext-xface/com.ofss.digx.cz.bea.extxface.app.impl/src/com/ofss/digx/cz/bea/extxface/alerts/impl/MNGEmailAdapter.java`
- 行号：`60`；定位关键字：`getEndpoint`

## 通过EndpointFactory调用外部短信网关

- 文件：`consulting/middleware/projects/ext-xface/com.ofss.digx.cz.bea.extxface.app.impl/src/com/ofss/digx/cz/bea/extxface/alerts/impl/MNGSmsAdapter.java`
- 行号：`65`；定位关键字：`getEndpoint`

## BM/其他接口ID常量

- 文件：`consulting/middleware/projects/ext-xface/com.ofss.digx.cz.bea.extxface.app.impl/src/com/ofss/digx/cz/bea/extxface/app/impl/CZInterfaceConstants.java`
- 行号：`221`；定位关键字：`BM_MNG_SEND_SMS`

## 多业务单元配置及本地声明刷新间隔

- 文件：`consulting/config/Preferences.xml`
- 行号：`124`；定位关键字：`name="DispatchDetails"`

## 配置名与数据库category映射

- 文件：`consulting/config/Preferences.xml`
- 行号：`196`；定位关键字：`name="Dispatchers"`

## 配置与验证参考

- `consulting/db/branch_change_history/20260916_HTH_User_Access_1216/2_HTH_Access_Notification_Config.sql`：当前event/template/attribute表结构及完整映射模式。
- `devtools/backend-compile/tests/diagnose_hth_notifications.sql`：既有MNG、dispatcher、mock、schema/synonym诊断方式。
- `devtools/backend-compile/tests/verify_hth_template_metadata.py`：实际HostServiceMetadataService解析DTO的检查方式。

## 框架API

`com.ofss.digx.app.AbstractApplication.registerActivityAndGenerateEvent` 的签名通过工程JAR核对，并由本包桥接类实际编译验证。依赖来自 `consulting/middleware/lib`；目标UAT的实际类加载版本仍需一致。
