# 本地验证记录

日期：2026-09-16。源码基线：b55652b0。执行环境：macOS，OpenJDK 21，Java 8 target。

命令：

```sh
python3 devtools/examples/bm-notification/verify.py
```

输出：

```text
PASS: all example Java sources compile against actual project dependencies (Java 8 target).
PASS: offline publication contract, address validation, context restoration,
      and real framework metadata lookup for all three DTO attributes.
PASS: example SQL placeholder names and explicit target-unit bind are consistent.
NOT RUN: Oracle SQL execution/replay, managed-server event generation, MNG or actual delivery.
```

额外检查：README 包内链接均可定位；源码索引中的19处关键字已与当前文件核对。

边界：隔离运行替换ActivityLog银行名称初始化父层、SessionContext和Date，使用fake publisher；真实项目依赖编译与实际HostServiceMetadataService getter解析另有检查。没有执行Oracle、启动WebLogic、发布真实event或调用MNG。没有发送邮件/短信。Windows命令仅提供使用方式，本次未在Windows运行。
