-- REFERENCE CONFIGURATION ONLY. Not executed by the example or verification script.
-- Run the complete PL/SQL block in the OBDX notification configuration schema.
-- Bind :BM_TARGET_UNIT to the actual notification SessionContext.targetUnit.
-- Do not assume the BM unit is OBDX_BU. This example installs English only.
-- Existing action template '1', decision '0', dispatchers and MNG providers
-- must already be available in the environment. This is not a fresh-platform bootstrap.
-- Reruns replace only this demo event's bindings and this unit's demo templates.
-- Global activity/event/metadata IDs belong exclusively to this example.
-- No COMMIT here: inspect with diagnose.sql and COMMIT or ROLLBACK explicitly.
DECLARE
    v_unit VARCHAR2(100) := TRIM(:BM_TARGET_UNIT);
    v_activity CONSTANT VARCHAR2(200) :=
        'com.ofss.digx.cz.bea.app.notifications.example.BmNotificationExample.publish';
    v_event CONSTANT VARCHAR2(100) := 'BM_EXAMPLE_APPROVED';
    v_dto CONSTANT VARCHAR2(200) :=
        'com.ofss.digx.cz.bea.app.notifications.example.BmNotificationActivityLogDTO';
    v_template VARCHAR2(100);
    v_body VARCHAR2(4000);
    v_subject VARCHAR2(200);
BEGIN
    SAVEPOINT BM_EXAMPLE_CONFIG;
    IF v_unit IS NULL OR UPPER(v_unit) LIKE '%CHANGE_ME%' THEN
        RAISE_APPLICATION_ERROR(-20001, 'Supply the actual BM notification target unit.');
    END IF;

    INSERT INTO DIGX_EP_ACT_B
      (COD_ACT_ID, TXT_ACT_NAME, TXT_ACT_DESC, MODULE_TYPE, FLG_IP_REQD, FLG_OP_REQD,
       FLG_LOG_REQD, TXT_LOG_CLASS, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY,
       LAST_UPDATED_DATE, OBJECT_VERSION_NUMBER, OBJECT_STATUS, DOMAIN_OBJECT_EXTN)
    SELECT v_activity, 'BmNotificationExample.publish', 'BM notification developer example',
           'PC', NULL, NULL, NULL, NULL, USER, SYSDATE, USER, SYSDATE, 1, 'A', 'CZ'
      FROM DUAL WHERE NOT EXISTS
        (SELECT 1 FROM DIGX_EP_ACT_B WHERE COD_ACT_ID = v_activity);

    -- Global event bindings: this exact demo ID must not be shared by another feature.
    DELETE FROM DIGX_EP_EVT_REC_B WHERE COD_ACT_ID=v_activity AND COD_EVENT_ID=v_event;
    DELETE FROM DIGX_EP_ACT_EVT_ACN_B WHERE COD_ACT_ID=v_activity AND COD_EVENT_ID=v_event;
    DELETE FROM DIGX_EP_ACT_EVT_B WHERE COD_ACT_ID=v_activity AND COD_EVENT_ID=v_event;

    INSERT INTO DIGX_PM_EVENT_ALL_B
      (EVENT_CODE, EVENT_DESC, PRODUCT_CLASS, PRICING_EVENT_TYPE, ALERT_EVENT_TYPE,
       FINANCIAL_TYPE, PRICING_DOMAIN_CATEGORY, ACCT_DOMAIN_CATEGORY, ALERTS_FLAG,
       FEES_FLAG, DOCUMENTATION_FLAG, ACCOUNTING_FLAG, ACCT_ENTRY_FLAG, DOMAIN_CODE,
       REWARDS_FLAG, RESTRICT_OFFER_FLAG, TASK_NAME, FEE_RECOGNITION_BRANCH_TYPE,
       DOMAIN_GEN_BANK_LEVEL_FLAG, DOMAIN_SPE_BANK_LEVEL_FLAG, TXN_RES_FLAG)
    SELECT v_event, 'BM notification developer example', NULL, NULL, NULL, NULL, NULL,
           NULL, 'Y', 'N', 'N', 'N', 'N', NULL, 'N', 'N', NULL, NULL, 'N', 'N', 'N'
      FROM DUAL WHERE NOT EXISTS
        (SELECT 1 FROM DIGX_PM_EVENT_ALL_B WHERE EVENT_CODE=v_event);
    UPDATE DIGX_PM_EVENT_ALL_B SET ALERTS_FLAG='Y' WHERE EVENT_CODE=v_event;

    INSERT INTO DIGX_EP_ACT_EVT_B
      (COD_ACT_ID, COD_EVENT_ID, TXT_ACT_EVT_DESC, TXT_EVT_TYP, TXT_ACT_EVT_TYP, DOMAIN_OBJECT_EXTN)
    VALUES (v_activity, v_event, 'BM notification developer example', 'OTHER', 'ONLINE', 'CZ');

    INSERT INTO DIGX_EP_ACT_EVT_ACN_B
      (COD_ACT_ID, COD_EVENT_ID, COD_ACTION_ID, FLG_TRANSACTIONAL, ACTION_SOURCE,
       COD_DEC_ID, FLG_CONDITIONAL, COD_ACN_TMPL_ID, ALERT_NAME, CREATED_BY, CREATION_DATE,
       LAST_UPDATED_BY, LAST_UPDATED_DATE, OBJECT_VERSION_NUMBER, NUM_RETRY_CNT,
       FLG_RETRY_ALLOWED, EXPIRY_DATE, ALERT_TYPE, ALERT_DISPATCH_TYPE, OBJECT_STATUS,
       DOMAIN_OBJECT_EXTN)
    VALUES (v_activity, v_event, 'A', 'N', NULL, '0', 'N', '1', 'BM example approved',
            USER, SYSDATE, USER, SYSDATE, 1, 0, 'N', DATE '2099-12-31', 'M', 'I', 'A', 'CZ');

    FOR a IN (
        SELECT 'bmDemoUserId' attr, 'BmDemoUserId' field FROM DUAL UNION ALL
        SELECT 'bmDemoReference', 'BmDemoReference' FROM DUAL UNION ALL
        SELECT 'bmDemoApprovedAt', 'BmDemoApprovedAt' FROM DUAL
    ) LOOP
        INSERT INTO DIGX_MD_GEN_ATTR_LEGACY_B
          (COD_CONSTRAINT_ATTR_ID, TXT_CONSTRAINT_ATTR_NAME, DATA_TYPE, CREATED_BY,
           CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATED_DATE, OBJECT_VERSION_NUMBER, OBJECT_STATUS)
        SELECT a.attr, a.attr, 'java.lang.String', USER, SYSDATE, USER, SYSDATE, 1, 'A'
          FROM DUAL WHERE NOT EXISTS
            (SELECT 1 FROM DIGX_MD_GEN_ATTR_LEGACY_B WHERE COD_CONSTRAINT_ATTR_ID=a.attr);

        UPDATE DIGX_MD_SERVICE_ATTR
           SET TYP_DATA_AVAIL='INDIRECT', TYP_DATA_SRC='DTO', COD_ATTR_ID=a.attr,
               COD_SERVICE_ID=v_activity, PARAMETER_NAME=NULL, REF_ENT_DEFN_ID=NULL,
               KEY_SERVICE_ATTR_ID=NULL, REF_FIELD_DEFN_ID=v_dto || '.' || a.field,
               OBJECT_STATUS='A', LAST_UPDATED_BY=USER, LAST_UPDATED_DATE=SYSDATE
         WHERE COD_SERVICE_ATTR_ID=v_activity || '.' || a.attr || '.DTO';
        INSERT INTO DIGX_MD_SERVICE_ATTR
          (COD_SERVICE_ATTR_ID, TYP_DATA_AVAIL, TYP_DATA_SRC, COD_ATTR_ID, COD_SERVICE_ID,
           PARAMETER_NAME, REF_ENT_DEFN_ID, KEY_SERVICE_ATTR_ID, CREATED_BY, CREATION_DATE,
           LAST_UPDATED_BY, LAST_UPDATED_DATE, OBJECT_VERSION_NUMBER, OBJECT_STATUS, REF_FIELD_DEFN_ID)
        SELECT v_activity || '.' || a.attr || '.DTO', 'INDIRECT', 'DTO', a.attr, v_activity,
               NULL, NULL, NULL, USER, SYSDATE, USER, SYSDATE, 1, 'A', v_dto || '.' || a.field
          FROM DUAL WHERE NOT EXISTS
            (SELECT 1 FROM DIGX_MD_SERVICE_ATTR
              WHERE COD_SERVICE_ATTR_ID=v_activity || '.' || a.attr || '.DTO');
    END LOOP;

    FOR d IN (SELECT 'EMAIL' destination FROM DUAL UNION ALL SELECT 'SMS' FROM DUAL) LOOP
        v_template := 'BM_EXAMPLE_' || d.destination || '_EN';
        IF d.destination='EMAIL' THEN
            v_subject := 'BM example - request approved';
            v_body := '<p>Request approved.</p><p>User: #bmDemoUserId#</p>' ||
                      '<p>Reference: #bmDemoReference#</p>' ||
                      '<p>Approved at: #bmDemoApprovedAt# HKT</p>';
        ELSE
            v_subject := NULL;
            v_body := 'Approved: #bmDemoReference#. User: #bmDemoUserId#. #bmDemoApprovedAt# HKT.';
        END IF;

        DELETE FROM DIGX_EP_MSG_SRC_B WHERE COD_MESS_TMPL_ID=v_template AND DETERMINANT_VALUE=v_unit;
        DELETE FROM DIGX_EP_MSG_ATTR_B WHERE COD_MESS_TMPL_ID=v_template AND DETERMINANT_VALUE=v_unit;
        DELETE FROM DIGX_EP_MSG_TMPL_B WHERE COD_TMPL_ID=v_template AND DETERMINANT_VALUE=v_unit;
        INSERT INTO DIGX_EP_MSG_TMPL_B
          (COD_TMPL_ID, DESTINATION_TYPE, MSG_TMPL_NAME, MSG_TMPL_DESC, TXT_MSG_TMPL,
           CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATED_DATE, OBJECT_VERSION_NUMBER,
           OBJECT_STATUS, TXT_SUBJECT_TMPL, DOMAIN_OBJECT_EXTN, DETERMINANT_VALUE)
        VALUES (v_template, d.destination, 'BM example ' || d.destination, 'Developer example only',
                v_body, USER, SYSDATE, USER, SYSDATE, 1, 'A', v_subject, 'CZ', v_unit);

        INSERT INTO DIGX_EP_EVT_REC_B
          (COD_ACT_ID, COD_EVENT_ID, COD_ACTION_ID, COD_MSG_TMPL_ID, TXT_DEST_TYP, COD_DEC_ID,
           FLG_CONDITIONAL, SUBSCRIBER_TYPE, RECIPIENT_TYPE, ALERTTYPE, DOMAIN_OBJECT_EXTN,
           LOCALE, GROUPE_NAME, BANKER_TYPE, AMOUNT, UNSECURE_MSG_TMPL_ID, SUBSCRIBER_VALUE)
        VALUES (v_activity, v_event, 'A', v_template, d.destination, '0', 'N', 'EXTERNAL',
                NULL, 'M', 'CZ', 'en', NULL, 'NA', 0, NULL, 'USER');

        FOR a IN (
            SELECT 'bmDemoUserId' attr FROM DUAL UNION ALL
            SELECT 'bmDemoReference' FROM DUAL UNION ALL
            SELECT 'bmDemoApprovedAt' FROM DUAL
        ) LOOP
            INSERT INTO DIGX_EP_MSG_ATTR_B
              (COD_MESS_TMPL_ID, COD_ATTR_ID, ATTR_MASK, DATA_ATTR_ORDER, DOMAIN_OBJECT_EXTN, DETERMINANT_VALUE)
            VALUES (v_template, a.attr, 'D', NULL, 'CZ', v_unit);
            INSERT INTO DIGX_EP_MSG_SRC_B
              (COD_MESS_TMPL_ID, COD_ATTR_ID, COD_ACT_ID, COD_SERVICE_ATTR_ID, DETERMINANT_VALUE)
            VALUES (v_template, a.attr, v_activity, v_activity || '.' || a.attr || '.DTO', v_unit);
        END LOOP;
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO BM_EXAMPLE_CONFIG;
        RAISE;
END;
/

-- SQL*Plus/SQLcl uses the final slash to execute the block. In clients executing a
-- selected PL/SQL statement directly, select DECLARE through END; without the slash.
-- Run diagnose.sql in this same session, verify expected bindings, then COMMIT.
-- Review SMS country-code rules separately: this script does not edit BCO lists,
-- provider URLs, mock switches, datasource settings or JVM properties.
