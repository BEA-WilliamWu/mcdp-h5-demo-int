"""Local, offline checks. Compiles against project JARs; never publishes or sends.

Runtime tests substitute ActivityLog's bank-name bootstrap parent, SessionContext
and Date to avoid application-server configuration startup. They use the real
base DTO and real HostServiceMetadataService. This is not an integration test
of the event engine, Oracle, a managed-server transaction or MNG.
Usage: python3 verify.py /path/to/hth-application
Requires JAVA_HOME (JDK >= 9), Python 3 and this repository's dependency JARs.
"""
from pathlib import Path
import os
import re
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE.parents[2]
JAVA = Path(os.environ["JAVA_HOME"]) / "bin"
JARS = sorted((ROOT / "consulting/middleware/lib").rglob("*.jar"))
if not JARS:
    raise SystemExit("No project dependency JARs found; pass the repository root.")
CP = os.pathsep.join(map(str, [ROOT / "devtools/backend-compile/build/classes/java/main", *JARS]))

TEST = r'''
import java.lang.reflect.Proxy;
import java.time.Instant;
import java.util.Collections;
import com.ofss.fc.app.context.SessionContext;
import com.ofss.fc.enumeration.ep.DestinationType;
import com.ofss.fc.xface.ep.dto.NotificationDetail;
import com.ofss.fc.framework.domain.service.hostservice.metadata.HostServiceMetadataService;
import com.ofss.fc.framework.domain.entity.service.metadata.IServiceAttribute;
import com.ofss.fc.framework.domain.metadata.IGenericAttributeDefinition;
import com.ofss.fc.enumeration.MessageDataSourceType;
import com.ofss.fc.datatype.NameValuePair;
import com.ofss.digx.cz.bea.app.notifications.example.*;

public class BmExampleContractTest {
    private static int calls;
    private static BmNotificationActivityLogDTO captured;
    private static void check(boolean ok, String description) {
        if (!ok) throw new AssertionError(description);
    }
    public static void main(String[] args) throws Exception {
        SessionContext c = new SessionContext();
        c.setUserId("BM_OPERATOR_DEMO"); c.setTargetUnit("TEST_UNIT");
        c.setTransactingPartyCode("ORIGINAL_PARTY"); c.setUserLocale("zh-Hant");
        Instant at = Instant.parse("2030-01-01T01:00:00Z");
        BmNotificationExample example = new BmNotificationExample((context, activity, event, date, dto) -> {
            calls++; captured = dto;
            check("BM_OPERATOR_DEMO".equals(context.getUserId()), "actor must be preserved");
            check("PARTY_DEMO".equals(context.getTransactingPartyCode()), "recipient party context");
            check("en".equals(context.getUserLocale()), "example locale");
            check(BmNotificationExample.ACTIVITY_ID.equals(activity), "activity ID");
            check(BmNotificationExample.EVENT_ID.equals(event), "event ID");
            return null; // No event engine or external side effects.
        });
        example.publishEmail(c, "PARTY_DEMO", "USER_DEMO@PARTY_DEMO", "BMREF001", at,
                             "recipient@example.invalid");
        NotificationDetail d = captured.getNotificationDetails()[0];
        check(d.getDestination() == DestinationType.EMAIL, "email destination");
        check("PARTY_DEMO".equals(d.getRecipientId()), "party is not an email address");
        check("EXTERNAL".equals(d.getRecipientType()), "external recipient");
        check("recipient@example.invalid".equals(d.getDispatchAddress()), "explicit address");
        check("ORIGINAL_PARTY".equals(c.getTransactingPartyCode()), "party restored");
        check("zh-Hant".equals(c.getUserLocale()), "locale restored");
        metadata(captured, "bmDemoUserId", "USER_DEMO@PARTY_DEMO");
        metadata(captured, "bmDemoReference", "BMREF001");
        metadata(captured, "bmDemoApprovedAt", "01/01/2030 09:00:00");

        example.publishSms(c, "PARTY_DEMO", "USER_DEMO@PARTY_DEMO", "BMREF001", at,
                           "00000000", "852"); // Fake publisher only; not a sendable test number.
        d = captured.getNotificationDetails()[0];
        check(d.getDestination() == DestinationType.SMS, "sms destination");
        check("00000000~852".equals(d.getDispatchAddress()), "legacy address contract");
        try {
            example.publishEmail(c, "PARTY_DEMO", "USER_DEMO", "BMREF001", at,
                                 "a@example.invalid\r\nBcc:b@example.invalid");
            throw new AssertionError("invalid email accepted");
        } catch (IllegalArgumentException expected) { }
        try {
            example.publishSms(c, "PARTY_DEMO", "USER_DEMO", "BMREF001", at, "+85212345678", "852");
            throw new AssertionError("unseparated number accepted");
        } catch (IllegalArgumentException expected) { }
        check(calls == 2, "invalid addresses must not be published");

        BmNotificationExample failing = new BmNotificationExample((context, activity, event, date, dto) -> {
            throw new IllegalStateException("synthetic publisher failure");
        });
        try {
            failing.publishEmail(c, "PARTY_DEMO", "USER_DEMO", "BMREF001", at, "a@example.invalid");
            throw new AssertionError("publisher exception swallowed");
        } catch (IllegalStateException expected) { }
        check("ORIGINAL_PARTY".equals(c.getTransactingPartyCode()), "party restored on failure");
        check("zh-Hant".equals(c.getUserLocale()), "locale restored on failure");
        check("BM_OPERATOR_DEMO".equals(c.getUserId()), "actor unchanged on failure");
        System.out.println("PASS: offline publication contract, address validation, context restoration,");
        System.out.println("      and real framework metadata lookup for all three DTO attributes.");
    }
    private static void metadata(BmNotificationActivityLogDTO dto, String field, String expected) throws Exception {
        String ref = BmNotificationActivityLogDTO.class.getName() + "." +
                     Character.toUpperCase(field.charAt(0)) + field.substring(1);
        IGenericAttributeDefinition generic = (IGenericAttributeDefinition) Proxy.newProxyInstance(
            IGenericAttributeDefinition.class.getClassLoader(), new Class[] { IGenericAttributeDefinition.class },
            (p,m,a) -> {
                if (m.getName().equals("getName")) return field;
                if (m.getName().equals("getDataType")) return "java.lang.String";
                return null;
            });
        IServiceAttribute attr = (IServiceAttribute) Proxy.newProxyInstance(IServiceAttribute.class.getClassLoader(),
            new Class[] { IServiceAttribute.class }, (p,m,a) -> {
                switch (m.getName()) {
                    case "fetchIsInError": return false;
                    case "getGenericAttribute": return generic;
                    case "getSourceType": return MessageDataSourceType.DTO;
                    case "getRefFieldDefnId": return ref;
                    default: return null;
                }
            });
        NameValuePair pair = new HostServiceMetadataService(null).fetchNameValue(
            attr, Collections.emptyMap(), null, dto);
        check(expected.equals(pair.getValue()), "framework getter resolution: " + field);
    }
}
'''

def run(command):
    result = subprocess.run(list(map(str, command)), capture_output=True, text=True)
    if result.returncode:
        print((result.stdout + result.stderr)[-6000:])
        raise SystemExit(result.returncode)
    return result.stdout

with tempfile.TemporaryDirectory(prefix="bm-notification-example-") as tmp:
    temp = Path(tmp)
    real = temp / "real"; real.mkdir()
    isolated = temp / "isolated"; isolated.mkdir()
    javac = [JAVA / "javac", "-proc:none", "--release", "8", "-Xlint:-options", "-cp", CP]
    run([*javac, "-d", real, *sorted(HERE.glob("*.java"))])
    print("PASS: all example Java sources compile against actual project dependencies (Java 8 target).")
    stub = temp / "ActivityLog.java"
    stub.write_text("package com.ofss.digx.app.alerts.dto.eventgen; "
                    "public class ActivityLog extends com.ofss.fc.xface.ep.dto.ActivityLog {}")
    context_stub = temp / "SessionContext.java"
    context_stub.write_text("package com.ofss.fc.app.context; public class SessionContext {"
        "private String user,unit,party,locale;"
        "public String getUserId(){return user;} public void setUserId(String s){user=s;}"
        "public String getTargetUnit(){return unit;} public void setTargetUnit(String s){unit=s;}"
        "public String getTransactingPartyCode(){return party;} public void setTransactingPartyCode(String s){party=s;}"
        "public String getUserLocale(){return locale;} public void setUserLocale(String s){locale=s;} }")
    date_stub = temp / "Date.java"
    date_stub.write_text("package com.ofss.fc.datatype; public class Date {}")
    harness = temp / "BmExampleContractTest.java"; harness.write_text(TEST)
    run([*javac, "-d", isolated, stub, context_stub, date_stub, HERE / "BmNotificationActivityLogDTO.java",
         HERE / "BmNotificationExample.java", harness])
    print(run([JAVA / "java", "-cp", str(isolated) + os.pathsep + CP, "BmExampleContractTest"]).strip())

sql = (HERE / "config-example.sql").read_text()
fields = set(re.findall(r"#(bmDemo\w+)#", sql))
assert fields == {"bmDemoUserId", "bmDemoReference", "bmDemoApprovedAt"}
for field in fields:
    assert "'" + field + "'" in sql
    assert "'" + field[0].upper() + field[1:] + "'" in sql
assert ":BM_TARGET_UNIT" in sql
print("PASS: example SQL placeholder names and explicit target-unit bind are consistent.")
print("NOT RUN: Oracle SQL execution/replay, managed-server event generation, MNG or actual delivery.")
