// Readable application logic only. The collection already includes the offline RSA library.
(function () {
    // Generated request values have request-local scope; never persist keys/passwords/signatures.
    ["loginBody", "client_assertion", "password_signature", "requestSign", "requestTime", "messageId"].forEach(function (name) {
        pm.variables.unset(name);
    });
    pm.environment.unset("accessToken");
    pm.request.body.update({mode: "raw", raw: "{}", options: {raw: {language: "json"}}});

    function value(name) {
        var result = pm.environment.get(name);
        return result === undefined || result === null ? "" : String(result);
    }
    function required(name) {
        var result = value(name);
        if (!result.trim()) throw new Error("Please fill Environment Current Value: " + name);
        return result;
    }
    function pem(name) {
        return required(name).replace(/\\r\\n/g, "\n").replace(/\\n/g, "\n").trim();
    }
    function readRsa(name, passphraseName) {
        var text = pem(name), key;
        try {
            if (/ENCRYPTED/.test(text)) {
                key = forge.pki.decryptRsaPrivateKey(text, required(passphraseName));
            } else {
                key = forge.pki.privateKeyFromPem(text);
            }
        } catch (_) {
            throw new Error("Invalid RSA PEM or passphrase in " + name + "; use PKCS#1/PKCS#8 PEM.");
        }
        if (!key || !key.n || !key.d || key.n.bitLength() < 2048) {
            throw new Error(name + " must be an RSA private key of at least 2048 bits.");
        }
        return key;
    }
    function sha256(text) {
        var md = forge.md.sha256.create();
        md.update(text, "utf8");
        return md.digest().toHex();
    }
    function rsaSign(text, key) {
        var md = forge.md.sha256.create();
        md.update(text, "utf8");
        return key.sign(md); // RSASSA-PKCS1-v1_5 SHA-256, matching SHA256withRSA.
    }
    function b64url(binary) {
        return forge.util.encode64(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
    }
    function encodeJson(object) {
        return b64url(forge.util.encodeUtf8(JSON.stringify(object)));
    }
    function uuid() { return pm.variables.replaceIn("{{$guid}}"); }
    function decodeClaims(jwt) {
        try {
            var parts = jwt.split(".");
            if (parts.length !== 3 || !parts[2]) throw new Error("invalid JWT");
            var encoded = parts[1].replace(/-/g, "+").replace(/_/g, "/");
            encoded += "=".repeat((4 - encoded.length % 4) % 4);
            return JSON.parse(forge.util.decodeUtf8(forge.util.decode64(encoded)));
        } catch (_) { throw new Error("externalClientAssertion must contain a signed JWT."); }
    }

    var clientId = required("clientId").trim();
    var closeId = required("closeId").trim();
    var password = required("password"); // Never trim or otherwise alter a password.
    required("apicClientId");
    required("apicClientSecret");
    var resolvedUrl = pm.variables.replaceIn(pm.request.url.toString());
    if (!/^https:\/\//i.test(resolvedUrl) && !/^http:\/\/127\.0\.0\.1:\d+\//.test(resolvedUrl)) {
        throw new Error("Configure an HTTPS token URL in the selected Environment.");
    }
    if (resolvedUrl.indexOf("{{") >= 0 || !/\/auth\/corporate\/v1\/getToken$/.test(resolvedUrl)) {
        throw new Error("Token URL must end in /auth/corporate/v1/getToken (no query string).");
    }
    var clockSkew = Number(value("clockSkewSeconds") || "5");
    if (!Number.isFinite(clockSkew) || clockSkew < 0 || clockSkew > 60) {
        throw new Error("clockSkewSeconds must be between 0 and 60.");
    }
    var now = Math.floor(Date.now() / 1000);
    var passwordKey = readRsa("rsaPrivateKeyPem", "rsaPrivateKeyPassphrase");
    var assertion, mode = value("jwtMode") || "auto_rs256";
    if (mode === "external") {
        assertion = required("externalClientAssertion").trim();
        var claims = decodeClaims(assertion);
        if (claims.iss !== clientId || claims.sub !== clientId || claims["close-id"] !== closeId) {
            throw new Error("External JWT iss/sub/close-id do not match clientId/closeId.");
        }
        if (!claims.aud || !claims.jti || typeof claims.iat !== "number" || typeof claims.exp !== "number" ||
                claims.iat > now || claims.exp <= now || claims.iat >= claims.exp) {
            throw new Error("External JWT must have valid aud, jti, iat and future exp.");
        }
    } else if (mode === "auto_rs256") {
        var audience = required("audience").trim();
        var jwtKey = value("jwtPrivateKeyPem").trim() ? readRsa("jwtPrivateKeyPem", "jwtPrivateKeyPassphrase") : passwordKey;
        var header = {alg: "RS256", typ: "JWT"};
        if (value("jwtKid").trim()) header.kid = value("jwtKid").trim();
        var payload = {iss: clientId, sub: clientId, aud: audience, iat: now - clockSkew,
            exp: now + 120, jti: uuid(), "close-id": closeId};
        var signingInput = encodeJson(header) + "." + encodeJson(payload);
        assertion = signingInput + "." + b64url(rsaSign(signingInput, jwtKey));
    } else { throw new Error("jwtMode must be auto_rs256 or external."); }

    var passwordSignature = forge.util.encode64(rsaSign(sha256(password), passwordKey));
    var body = JSON.stringify({client_assertion: assertion, password_signature: passwordSignature});
    var requestTime = String(Date.now() - clockSkew * 1000);
    var signaturePath = value("signaturePath") || "/auth/corporate/v1/getToken";
    if (signaturePath[0] !== "/" || /[\r\n?#]/.test(signaturePath)) {
        throw new Error("signaturePath must be the Jersey-relative path, starting with / and without query/newlines.");
    }
    // Actual HthBffRequestHeaderFilter: raw JSON body, not body hash, no trailing newline.
    var canonical = "POST\n" + signaturePath + "\n\n" + requestTime + "\n" + body;
    var requestSign = forge.util.encode64(rsaSign(canonical, passwordKey));
    pm.variables.set("loginBody", body);
    pm.variables.set("client_assertion", assertion);
    pm.variables.set("password_signature", passwordSignature);
    pm.variables.set("requestTime", requestTime);
    pm.variables.set("requestSign", requestSign);
    pm.variables.set("messageId", uuid());
    pm.request.body.update({mode: "raw", raw: body, options: {raw: {language: "json"}}});
    [
        ["Content-Type", "application/json"], ["Accept", "application/json"],
        ["Message-Id", pm.variables.get("messageId")], ["Channel", "HTH"], ["Client-Id", clientId],
        ["Request-Time", requestTime], ["Request-Sign", requestSign],
        ["X-IBM-Client-Id", value("apicClientId")], ["X-IBM-Client-Secret", value("apicClientSecret")]
    ].forEach(function (entry) { pm.request.headers.upsert({key: entry[0], value: entry[1]}); });
})();
