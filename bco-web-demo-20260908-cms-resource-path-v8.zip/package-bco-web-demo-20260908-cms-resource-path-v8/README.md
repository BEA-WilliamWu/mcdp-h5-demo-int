# BCO Web Demo v8 — CMS 图片内外网访问修复

包版本：`cms-resource-path-v8`。目标镜像标签：`bco-demo-20260908-cms-resource-path-fix-08`。
这个源代码包本身不代表镜像已经推送或部署。不要继续使用之前同名反复更新的 v7 包。

## 本次修复

用户提供的 MCDP 返回使用 `/cms/acmsresource/`，v6 只匹配 `/cms/acms-resource/`，所以五张图片一直保留 Ali NLB 域名。v8 识别这两种明确的图片路径，保留资源根目录，并改成浏览器当前站点的 `/mcdp_demo/cms-assets/<资源根>/...`。

内网 ALB 的 `/mcdp_demo` 直接转到 `mcdp-demo-web`；外网受限 NLB 先经过 `imk-frontend`。两者都需要图片代理：前者已打入本包 Docker 镜像，后者由本包路由脚本更新。只更新其中一项不构成完整升级。

保持四个展位、三语素材、频控、排期、点击/曝光及右下角客服浮标逻辑。资源代理只接受 GET/HEAD 图片路径。IMK 审核和数据库无须调整，CMS 和 MCDP 活动无须重建。

## 1. 在 Mac 构建并推送

本机目录已准备好；拿到 ZIP 的其他人需要先解压，再进入对应目录。

```bash
cd /Users/devs/DWksp/bcm-cms/deliverables/bco-e2e-demo-20260908/package-bco-web-demo-20260908-cms-resource-path-v8
shasum -a 256 -c SHA256SUMS.txt
IMAGE_TAG=bco-demo-20260908-cms-resource-path-fix-08 bash scripts/publish-acr.sh
```

发布脚本在本机隐藏输入凭据。等它显示 `Published successfully` 且镜像标签与上面完全一致，再执行下一步。不要把凭据粘贴到聊天。

## 2. 在 Mac 复制 Workbench 升级命令

```bash
cd /Users/devs/DWksp/bcm-cms/deliverables/bco-e2e-demo-20260908/package-bco-web-demo-20260908-cms-resource-path-v8
bash scripts/print-upgrade-command.sh | pbcopy
```

打开 Alibaba Workbench 的 `alicloud:/#` 终端，粘贴并回车。命令会升级 Demo 镜像，然后运行路由脚本。路由脚本先读取已知 CMS 客服 PNG，检查 Demo 直连的图片返回，再备份并更新 `imk-nginx`、重启 `imk-frontend` 并比较图片内容。

检查使用 Kubernetes Service HTTP proxy，不依赖 `kubectl exec`。如果当前账号没有 Service proxy 读取权限，脚本会在改动路由前停止，保留输出供排查，不会把验证失败标为成功。

预期最后显示：

```text
BCO_DEMO_ROUTE_OK
```

同时输出的三份图片 SHA-256 必须一致：CMS 源图片、Demo 直连代理、IMK 外网入口代理。备份文件保留在 Workbench 输出的 `/tmp/bco-demo-route-v8.*` 目录。

仅在需要重跑路由检查时，在 Mac 复制路由脚本：

```bash
BCO_SCRIPT=/Users/devs/DWksp/bcm-cms/deliverables/bco-e2e-demo-20260908/package-bco-web-demo-20260908-cms-resource-path-v8/enable-restricted-bco-demo-route.sh
{ printf "printf '%%s' '"; base64 -i "$BCO_SCRIPT" | tr -d '\n'; printf "' | base64 -d | bash\n"; } | pbcopy
```

已知配置重复执行不会重复插入路由。不要重跑旧 v4-v7 的路由脚本。

## 3. 浏览器验收

内网浏览器打开 `http://10.23.34.52:443/mcdp_demo/bco.html?lang=en&v=8`；外网使用当前获授权的 IMK NLB 主机和同一路径。这里仍是 HTTP 的 443 端口。

1. 强制刷新页面。开发者工具 Network 中 `bco-material.js` 的查询参数应有 `cms-resource-path-v8`。
2. 切换到 Img 类型。真正的图片请求应使用当前页面域名，路径形如 `/mcdp_demo/cms-assets/acmsresource/1237469588841562112/image/20260906/1281289380933140480.png`，响应为 200 且有图片内容。
3. `mgw.htm` 原始 JSON 中仍可出现旧 Ali 图片域名；这是投放快照，前端在交给 SDK 前改写。判断依据是 Img 请求和图片元素地址，不是原始 JSON。
4. 首页三张轮播、文字公告、弹屏、右下角客服浮标应能显示；弹屏是否出现仍受既有频控和排期约束。
5. 依次切换 English、简体、繁體，再点 Apply / reload，核对对应素材及点击跳转。

浏览器 Console 的只读检查：

```javascript
console.table([...document.querySelectorAll('.mcdp-view-wrap img')].map(i => ({
  src: i.currentSrc || i.src,
  loaded: i.complete && i.naturalWidth > 0
})));
```

若仍失败，保留一个 Img 请求的完整 Request URL、状态码和响应 Content-Type。这能区分版本未更新、代理失败和源图片不存在。

## 交付与验证范围

包含全部 public 文件、SDK、五个打包素材、Nginx 配置、Dockerfile、构建发布脚本、WorkBench 命令生成脚本以及源文件校验清单。

本地回归覆盖三语真实返回结构、五个 SDK 图片元素、旧路由升级与重复执行、Nginx 配置语法、两种资源根的原路径转发、图片内容一致性和方法/路径限制。云端和两种网络的最终验收以步骤 2、3 的实际结果为准。
