#!/usr/bin/env bash
# BCO route v8: preserve both observed CMS resource roots; verify over HTTP.
set -Eeuo pipefail
set +x
umask 077

stop() { echo "STOP: $*" >&2; exit 1; }

# Pure file transformation used by the offline Nginx regression tests.
render_config() {
  local input="$1" output="$2" bco_render_dir
  bco_render_dir="$(mktemp -d /tmp/bco-route-render.XXXXXX)"
  # Remove generated asset locations from v4-v8, including the invalid v5
  # regex block. All unrelated locations and their contents are preserved.
  awk '
    /^[[:space:]]*# (BEGIN|END) BCO_CMS_ASSETS/ { next }
    /^[[:space:]]*# BCO same-origin CMS image proxy:/ { next }
    /^[[:space:]]*# resource root observed in UAT\./ { next }
    /^[[:space:]]*# this route from being used as a general-purpose proxy\./ { next }
    /^[[:space:]]*location[[:space:]]+(\^~[[:space:]]+)?\/mcdp_demo\/cms-assets\/((acmsresource|acms-resource)\/)?[[:space:]]*\{/ { dropping=1; depth=0 }
    dropping {
      line=$0; opened=gsub(/\{/, "{", line); closed=gsub(/\}/, "}", line)
      depth+=opened-closed
      if (depth==0) { dropping=0; skip_blank=1 }
      next
    }
    skip_blank && /^[[:space:]]*$/ { next }
    { skip_blank=0; print }
    END { if (dropping) exit 2 }
  ' "$input" > "$bco_render_dir/clean.conf" || stop "Unclosed generated asset block; no cluster change"

  local demo_count proxy_count
  demo_count="$(grep -Ec '^[[:space:]]*location[[:space:]]+(\^~[[:space:]]+)?/mcdp_demo/[[:space:]]*\{' "$bco_render_dir/clean.conf" || true)"
  proxy_count="$(grep -Ec '^[[:space:]]*location[[:space:]]+(\^~[[:space:]]+)?/mpaas-proxy/[[:space:]]*\{' "$bco_render_dir/clean.conf" || true)"
  [[ "$demo_count" -le 1 && "$proxy_count" -le 1 ]] || stop "Duplicate top-level Demo/proxy routes; no cluster change"
  : > "$bco_render_dir/missing.conf"
  if [[ "$demo_count" == 0 ]]; then
    cat >> "$bco_render_dir/missing.conf" <<'NGINX'
        location ^~ /mcdp_demo/ {
            proxy_pass http://mcdp-demo-web:80;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_read_timeout 60s;
        }
NGINX
  fi
  if [[ "$proxy_count" == 0 ]]; then
    cat >> "$bco_render_dir/missing.conf" <<'NGINX'
        location /mpaas-proxy/ {
            proxy_pass http://mpaas-proxy:80;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_read_timeout 60s;
        }
NGINX
  fi
  if [[ -s "$bco_render_dir/missing.conf" ]]; then
    [[ "$(grep -Ec '^[[:space:]]*location[[:space:]]+/[[:space:]]*\{' "$bco_render_dir/clean.conf" || true)" == 1 ]] || stop "Cannot find a unique root location for insertion"
  fi
  awk -v routes="$bco_render_dir/missing.conf" '
    /^[[:space:]]*location[[:space:]]+\/[[:space:]]*\{/ {
      while ((getline line < routes)>0) print line
      close(routes)
    }
    /^[[:space:]]*location[[:space:]]+\/mcdp_demo\/[[:space:]]*\{/ {
      sub(/location[[:space:]]+\/mcdp_demo\//, "location ^~ /mcdp_demo/")
    }
    { print }
  ' "$bco_render_dir/clean.conf" > "$bco_render_dir/base.conf"

  cat > "$bco_render_dir/assets.conf" <<'NGINX'
        # BEGIN BCO_CMS_ASSETS v8
        location ^~ /mcdp_demo/cms-assets/acmsresource/ {
            # Quote braces in Nginx regular expressions. Only image files.
            if ($uri !~ "^/mcdp_demo/cms-assets/acmsresource/[0-9]+/image/[0-9]{8}/[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.(avif|gif|jpe?g|png|webp)$") { return 404; }
            limit_except GET HEAD { deny all; }
            rewrite ^/mcdp_demo/cms-assets/acmsresource/(.*)$ /cms/acmsresource/$1 break;
            proxy_pass http://cms-admin:8115;
            proxy_pass_request_headers off;
            proxy_set_header Host cms-admin;
            proxy_set_header Connection "";
            proxy_hide_header Set-Cookie;
            proxy_read_timeout 30s;
        }
        location ^~ /mcdp_demo/cms-assets/acms-resource/ {
            if ($uri !~ "^/mcdp_demo/cms-assets/acms-resource/[0-9]+/image/[0-9]{8}/[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.(avif|gif|jpe?g|png|webp)$") { return 404; }
            limit_except GET HEAD { deny all; }
            rewrite ^/mcdp_demo/cms-assets/acms-resource/(.*)$ /cms/acms-resource/$1 break;
            proxy_pass http://cms-admin:8115;
            proxy_pass_request_headers off;
            proxy_set_header Host cms-admin;
            proxy_set_header Connection "";
            proxy_hide_header Set-Cookie;
            proxy_read_timeout 30s;
        }
        location ^~ /mcdp_demo/cms-assets/ { return 404; }
        # END BCO_CMS_ASSETS
NGINX
  awk -v assets="$bco_render_dir/assets.conf" '
    /^[[:space:]]*location[[:space:]]+\^~[[:space:]]+\/mcdp_demo\/[[:space:]]*\{/ {
      while ((getline line < assets)>0) print line
      close(assets)
    }
    { print }
  ' "$bco_render_dir/base.conf" > "$output"
  [[ "$(grep -Ec '^[[:space:]]*location[[:space:]]+\^~[[:space:]]+/mcdp_demo/[[:space:]]*\{' "$output" || true)" == 1 ]] || stop "Expected exactly one priority Demo route"
  [[ "$(grep -Fc '# BEGIN BCO_CMS_ASSETS v8' "$output" || true)" == 1 ]] || stop "Expected one v8 asset block"
}

if [[ "${1:-}" == --render-config && $# == 3 ]]; then
  render_config "$2" "$3"
  exit 0
fi
[[ $# == 0 ]] || stop "Usage: enable-restricted-bco-demo-route.sh"
namespace="${NAMESPACE:-cms-dev}"
public_service="${PUBLIC_SERVICE:-imk-public-debug}"
frontend="${FRONTEND_DEPLOYMENT:-imk-frontend}"
for cmd in kubectl awk sed mktemp grep tr cmp sha256sum od; do
  command -v "$cmd" >/dev/null || stop "Missing command: $cmd"
done
k() { kubectl -n "$namespace" "$@"; }
work_dir="$(mktemp -d /tmp/bco-demo-route-v8.XXXXXX)"
echo "BCO_DEMO_ROUTE_REVISION=20260908-v8"
echo "Configuration backup and verification retained at: $work_dir"

svc_shape="$(k get service "$public_service" -o go-template='{{.spec.type}}|{{.spec.selector.app}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}|{{range .spec.loadBalancerSourceRanges}}{{.}},{{end}}')"
[[ "$svc_shape" == LoadBalancer\|imk-frontend\|443:80/TCP,* ]] || stop "Unexpected public Service shape"
cidrs="${svc_shape##*|}"
[[ -n "$cidrs" ]] || stop "Public Service has no source allow-list"
while IFS= read -r cidr; do
  [[ "$cidr" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/32$ ]] || stop "Allow-list is not /32-only"
done < <(tr ',' '\n' <<< "$cidrs" | sed '/^$/d')
[[ "$(k get service mcdp-demo-web -o go-template='{{.spec.type}}|{{.spec.selector.app}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}')" == 'ClusterIP|mcdp-demo-web|80:http/TCP,' ]] || stop "Unexpected Demo Service"
[[ "$(k get service cms-admin -o go-template='{{.spec.type}}|{{.spec.selector.app}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}')" == 'ClusterIP|cms-admin|8115:http/TCP,' ]] || stop "Unexpected CMS Service"
[[ "$(k get service mpaas-proxy -o go-template='{{.spec.type}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}')" == ClusterIP\|80:*\/TCP,* ]] || stop "Unexpected MCDP proxy Service"

# Service-proxy GETs avoid kubectl exec / Kata runtime errors. Failure stops
# before mutation; success requires image bytes, not a login page or JSON.
api_root="/api/v1/namespaces/$namespace/services"
probe_path="1237469588841562112/image/20260906/1281289380933140480.png"
http_get() { kubectl --request-timeout=40s get --raw "$api_root/$1/proxy/$2" > "$3"; }
http_get 'http:cms-admin:8115' "cms/acmsresource/$probe_path" "$work_dir/cms-source.png" || stop "Cannot read known CMS image through Kubernetes HTTP proxy; configuration unchanged"
signature="$(od -An -tx1 -N8 "$work_dir/cms-source.png" | tr -d ' \n')"
[[ "$signature" == 89504e470d0a1a0a ]] || stop "CMS source did not return a PNG image; configuration unchanged"
http_get 'http:mcdp-demo-web:80' mcdp_demo/bco-material.js "$work_dir/demo-material.js" || stop "Cannot read Demo adapter; configuration unchanged"
grep -Fq 'cms-resource-path-v8' "$work_dir/demo-material.js" || stop "Deploy the v8 Demo image first; configuration unchanged"
http_get 'http:mcdp-demo-web:80' "mcdp_demo/cms-assets/acmsresource/$probe_path" "$work_dir/demo-proxied.png" || stop "Demo direct-route image check failed; configuration unchanged"
cmp -s "$work_dir/cms-source.png" "$work_dir/demo-proxied.png" || stop "Demo direct route did not return the exact CMS image bytes; configuration unchanged"

config_map="$(k get deployment "$frontend" -o go-template='{{range .spec.template.spec.volumes}}{{if .configMap}}{{.configMap.name}}{{"\n"}}{{end}}{{end}}' | sed '/^$/d')"
[[ -n "$config_map" && "$config_map" != *$'\n'* ]] || stop "Expected one frontend ConfigMap volume"
[[ "$(k get configmap "$config_map" -o go-template='{{range $k, $v := .data}}{{$k}}{{"\n"}}{{end}}' | sed '/^$/d')" == default.conf ]] || stop "ConfigMap has unexpected keys"
k get configmap "$config_map" -o yaml > "$work_dir/configmap-before.yaml"
k get configmap "$config_map" -o jsonpath='{.data.default\.conf}' > "$work_dir/default.conf"
grep -Fq 'location /marketing-management/' "$work_dir/default.conf" || stop "Unexpected IMK proxy configuration"
render_config "$work_dir/default.conf" "$work_dir/updated.conf"
if ! cmp -s "$work_dir/default.conf" "$work_dir/updated.conf"; then
  k create configmap "$config_map" --from-file=default.conf="$work_dir/updated.conf" --dry-run=client -o yaml | k apply -f -
  k rollout restart "deployment/$frontend"
fi
k rollout status "deployment/$frontend" --timeout=10m

front_proxy="http:$public_service:443"
http_get "$front_proxy" "mcdp_demo/cms-assets/acmsresource/$probe_path" "$work_dir/proxied.png" || stop "Rollout complete, but same-origin image HTTP check failed"
cmp -s "$work_dir/cms-source.png" "$work_dir/proxied.png" || stop "Image proxy did not return the exact CMS image bytes"
http_get "$front_proxy" mcdp_demo/bco-material.js "$work_dir/material.js" || stop "Cannot read client adapter"
grep -Fq 'cms-resource-path-v8' "$work_dir/material.js" || stop "Route/image check passed, but Demo client is not v8; deploy the v8 image"
http_get "$front_proxy" mcdp_demo/bco.html "$work_dir/bco.html" || stop "Cannot read Demo page"
grep -Fq 'BCO Web' "$work_dir/bco.html" || stop "Unexpected Demo page"
echo "BCO_DEMO_ROUTE_OK"
sha256sum "$work_dir/cms-source.png" "$work_dir/demo-proxied.png" "$work_dir/proxied.png"
echo "Passed: frontend rollout, v8 adapter, and exact CMS image bytes through both Demo and IMK routes. Browser acceptance remains."
