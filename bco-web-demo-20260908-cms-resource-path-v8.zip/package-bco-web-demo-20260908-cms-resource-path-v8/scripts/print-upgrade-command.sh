#!/usr/bin/env bash
# Generate a single Workbench command; no local or cloud changes.
set -Eeuo pipefail
package_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
route="$package_dir/enable-restricted-bco-demo-route.sh"
[[ -f "$route" ]] || { echo 'Package route script missing' >&2; exit 1; }
grep -Fq 'BCO_DEMO_ROUTE_REVISION=20260908-v8' "$route" || { echo 'Wrong route version' >&2; exit 1; }
printf "printf '%%s' '"
{
  printf '%s\n' '#!/usr/bin/env bash' 'set -Eeuo pipefail' 'set +x'
  printf '%s\n' 'kubectl -n cms-dev set image deployment/mcdp-demo-web mcdp-demo-web=bcm-dev-registry-vpc.cn-hongkong.cr.aliyuncs.com/bcm-dev/mcdp-demo-web:bco-demo-20260908-cms-resource-path-fix-08'
  printf '%s\n' 'kubectl -n cms-dev rollout status deployment/mcdp-demo-web --timeout=10m'
  cat "$route"
} | base64 | tr -d '\n'
printf "' | base64 -d | bash\n"
