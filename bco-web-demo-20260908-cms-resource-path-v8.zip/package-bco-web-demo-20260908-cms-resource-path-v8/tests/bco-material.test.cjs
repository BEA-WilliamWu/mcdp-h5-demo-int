const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const api = require("../public/bco-material.js");

function content(languages = ["en", "sc", "tc"]) {
  return JSON.stringify(languages.map((language) => ({
    language, title: language + " CMS title",
    attrData: JSON.stringify({
      main_title: language + " title", subtitle: language + " description",
      button_text: language + " button", link_url: "#time-deposit",
      image: JSON.stringify([{ fileUrl: "http://demo.test:443/cms/" + language + ".png" }]),
      activity_desc: language + " campaign"
    })
  })));
}
function response() {
  return {
    success: true, traceId: "test-trace",
    spaceInfoList: api.ZONES.map((zoneCode, i) => ({
      zoneCode, multiStyle: ["ROTATION", "ANNOUNCEMENT", "BANNER", "BUOY"][i],
      width: 144, height: 144, location: i === 2 ? "FULL" : "FIRSTSCREENMIDDLERIGHT",
      rotationTime: 5, displayMaxCount: 3, cacheTime: 3600,
      spaceObjectList: [{
        objectId: "test-" + zoneCode, contentType: "URL", content: content(),
        behaviors: [{ behavior: "ALWAYS", showTimes: 1 }],
        crontabList: [], priority: 1, logExtInfo: [{ key: "groupId", value: "test-group" }],
        colors: [{ key: "textColor", value: "#111111" }, { key: "bgColor", value: "#eeeeee" }]
      }]
    }))
  };
}

for (const language of api.LANGUAGES) {
  test("nested JSON decodes exact " + language + " fields without mutation", () => {
    const raw = content(["tc", "en", "sc"]);
    const result = api.decode(raw, language);
    assert.equal(result.title, language + " title");
    assert.equal(result.subtitle, language + " description");
    assert.equal(result.buttonText, language + " button");
    assert.equal(result.campaign, language + " campaign");
    assert.equal(result.image, "http://demo.test:443/cms/" + language + ".png");
    assert.equal(raw, content(["tc", "en", "sc"]));
  });
}
test("published CMS language map and object-valued attrData decode", () => {
  assert.equal(api.decode({ sc: { attrData: { main_title: "简体" } } }, "sc").title, "简体");
});
test("current MCDP CMS wrapper decodes its nested content language array", () => {
  const wrapped = JSON.stringify({
    uid: "bcm-v2-content-rotation",
    url: "http://cms-static:8118/content-deposit",
    content: JSON.parse(content(["tc", "en", "sc"]))
  });
  const result = api.decode(wrapped, "en");
  assert.equal(result.title, "en title");
  assert.equal(result.image, "http://demo.test:443/cms/en.png");
});
test("missing language never falls back to English", () => {
  assert.throws(() => api.decode(content(["en"]), "tc"), /Missing CMS language/);
});
test("duplicate language, malformed attrData, unknown language are rejected", () => {
  assert.throws(() => api.decode(content(["en", "en"]), "en"), /Duplicate/);
  assert.throws(() => api.decode([{ language: "en", attrData: "{" }], "en"), /attrData/);
  assert.throws(() => api.decode(content(), "fr"), /Unsupported/);
});
test("unsafe URLs rejected, HTTP:443 preserved, no invented host or forced HTTPS", () => {
  for (const value of ["javascript:alert(1)", "java\nscript:x", "data:text/html,x", "//evil.test/x", "/\\evil.test/x", "https://null/x", "https://u:p@example.test/x", "ftp://example.test/x"]) {
    assert.equal(api.safeURL(value, false), "", value);
  }
  assert.equal(api.safeURL("http://demo.test:443/image.png", true), "http://demo.test:443/image.png");
  assert.equal(api.safeURL("/cms/a.png", true), "/cms/a.png");
  assert.equal(api.safeURL("#time-deposit", false), "#time-deposit");
  assert.equal(api.safeURL("#time-deposit", true), "");
  assert.equal(api.imageURL([{ fileFullPath: "https://demo.test/a.png" }]), "https://demo.test/a.png");
});
test("only the known CMS public-image path is adapted to the current Demo origin", () => {
  const external = "http://external-nlb.test:443/cms/acms-resource/123456/image/20260908/12812893842019.jpg";
  assert.equal(api.sameOriginCmsImage(external, "http://10.23.34.52:443"),
    "http://10.23.34.52:443/mcdp_demo/cms-assets/acms-resource/123456/image/20260908/12812893842019.jpg");
  const actualUatPath = "http://external-nlb.test:443/cms/acmsresource/123456/image/20260908/12812893842019.jpg";
  assert.equal(api.sameOriginCmsImage(actualUatPath, "http://10.23.34.52:443"),
    "http://10.23.34.52:443/mcdp_demo/cms-assets/acmsresource/123456/image/20260908/12812893842019.jpg");
  assert.equal(api.sameOriginCmsImage("https://example.test/not-cms/image.png", "http://10.23.34.52:443"),
    "https://example.test/not-cms/image.png");
  assert.equal(api.sameOriginCmsImage("http://external-nlb.test:443/cms/acms-resource/not-a-number/image/20260908/a.jpg", "http://10.23.34.52:443"),
    "http://external-nlb.test:443/cms/acms-resource/not-a-number/image/20260908/a.jpg");
});
test("CMS wrapper image uses the restricted same-origin asset route when supplied", () => {
  const raw = response();
  raw.spaceInfoList[0].spaceObjectList[0].content = JSON.stringify([{
    language: "en", attrData: { main_title: "Rotation", image: [{
      fileUrl: "http://external-nlb.test:443/cms/acms-resource/123456/image/20260908/12812893842019.jpg"
    }] }
  }]);
  const adapted = api.adaptResponse(raw, "en", "http://10.23.34.52:443");
  assert.equal(adapted.response.spaceInfoList[0].spaceObjectList[0].hrefUrl,
    "http://10.23.34.52:443/mcdp_demo/cms-assets/acms-resource/123456/image/20260908/12812893842019.jpg");
});
test("all four placements retain rules, tracking IDs, shape and original input", () => {
  const input = response();
  const before = JSON.stringify(input);
  const adapted = api.adaptResponse(input, "sc");
  assert.equal(adapted.diagnostics.length, 4);
  for (let i = 0; i < 4; i++) {
    const original = input.spaceInfoList[i];
    const space = adapted.response.spaceInfoList[i];
    for (const key of ["zoneCode", "multiStyle", "location", "displayMaxCount", "rotationTime", "cacheTime"]) assert.equal(space[key], original[key]);
    const item = space.spaceObjectList[0];
    for (const key of ["behaviors", "crontabList", "priority", "logExtInfo", "objectId"]) assert.deepEqual(item[key], original.spaceObjectList[0][key]);
    assert.equal(item.hrefUrl, "http://demo.test:443/cms/sc.png");
    assert.equal(item.actionUrl, "#time-deposit");
    if (i !== 1) assert.equal(item.contentType, "PIC");
    else assert.equal(item.content, "sc title — sc description");
  }
  assert.equal(JSON.stringify(input), before);
});
test("rotation preserves all three creatives and server ordering", () => {
  const raw = response();
  const item = raw.spaceInfoList[0].spaceObjectList[0];
  raw.spaceInfoList[0].spaceObjectList = [3, 1, 2].map((id) => ({ ...item, objectId: id }));
  assert.deepEqual(api.adaptResponse(raw, "tc").response.spaceInfoList[0].spaceObjectList.map((x) => x.objectId), [3, 1, 2]);
});
test("empty response remains empty, malformed response is not success", () => {
  assert.deepEqual(api.adaptResponse({ spaceInfoList: [] }, "en").diagnostics, []);
  assert.throws(() => api.adaptResponse({ code: -1, msg: "busy" }, "en"), /spaceInfoList/);
});
test("one malformed CMS creative does not hide valid neighbors or show defaults", () => {
  const raw = response();
  raw.spaceInfoList[0].spaceObjectList[0].content = content(["en"]);
  const result = api.adaptResponse(raw, "tc");
  assert.equal(result.response.spaceInfoList[0].spaceObjectList.length, 0);
  assert.equal(result.response.spaceInfoList[1].spaceObjectList.length, 1);
  assert.match(result.diagnostics[0].error, /Missing CMS language/);
});
test("CMS image required for image slots, not text notice", () => {
  const raw = response();
  raw.spaceInfoList.forEach((s) => { s.spaceObjectList[0].content = [{ language: "en", attrData: { main_title: "Text only" } }]; });
  const result = api.adaptResponse(raw, "en");
  assert.deepEqual(result.response.spaceInfoList.map((s) => s.spaceObjectList.length), [0, 1, 0, 0]);
});
test("native creatives and unrelated zones pass through unchanged", () => {
  const native = { contentType: "PIC", content: null, hrefUrl: "https://demo.test/a.png" };
  const other = { zoneCode: "offersCIH", spaceObjectList: [{ contentType: "URL", content: "legacy" }] };
  const raw = { spaceInfoList: [{ zoneCode: "home_rotation", spaceObjectList: [native] }, other] };
  assert.equal(api.adaptResponse(raw, "en").response.spaceInfoList[0].spaceObjectList[0], native);
  assert.equal(api.adaptResponse(raw, "en").response.spaceInfoList[1], other);
});
test("native MCDP PIC with a CMS asset URL uses the restricted same-origin route", () => {
  const native = {
    contentType: "PIC",
    hrefUrl: "http://external-nlb.test:443/cms/acms-resource/123456/image/20260908/12812893842019.jpg"
  };
  const raw = { spaceInfoList: [{ zoneCode: "floating_buoy", spaceObjectList: [native] }] };
  const adapted = api.adaptResponse(raw, "en", "http://10.23.34.52:443");
  assert.equal(adapted.response.spaceInfoList[0].spaceObjectList[0].hrefUrl,
    "http://10.23.34.52:443/mcdp_demo/cms-assets/acms-resource/123456/image/20260908/12812893842019.jpg");
  assert.equal(native.hrefUrl, "http://external-nlb.test:443/cms/acms-resource/123456/image/20260908/12812893842019.jpg");
});
test("oversized single creative fails closed without aborting other zones", () => {
  const raw = response(); raw.spaceInfoList[0].spaceObjectList[0].content = "[".repeat(2000001);
  const result = api.adaptResponse(raw, "en");
  assert.match(result.diagnostics[0].error, /2 MB/);
  assert.equal(result.response.spaceInfoList[1].spaceObjectList.length, 1);
});
test("SDK adapter forwards options/context, propagates failures and restores transport", async () => {
  const request = { async getData(options) { assert.equal(this, request); assert.equal(options.userId, "test"); return response(); } };
  const original = request.getData;
  let count = 0;
  const detach = api.attach({ request }, "tc", (items) => { count += items.length; });
  assert.equal((await request.getData({ userId: "test" })).spaceInfoList.length, 4);
  assert.equal(count, 4); detach(); assert.equal(request.getData, original);
  const failing = { request: { async getData() { throw new Error("transport failure"); } } };
  api.attach(failing, "en", () => assert.fail("must not mark failed request successful"));
  await assert.rejects(failing.request.getData(), /transport failure/);
  assert.throws(() => api.attach({}, "en", () => {}), /compatibility/);
});
test("BCO page declares exactly four SDK mounts, no secret, fake preview, or global XHR patch", () => {
  const html = fs.readFileSync(path.join(__dirname, "../public/bco.html"), "utf8");
  assert.deepEqual([...html.matchAll(/data-mcdp-code="([^"]+)"/g)].map((x) => x[1]), api.ZONES);
  const js = fs.readFileSync(path.join(__dirname, "../public/bco-page.js"), "utf8");
  assert.doesNotMatch(js, /appSecret\s*:|secretKey\s*:|XMLHttpRequest\.prototype|innerHTML|localStorage/);
  assert.doesNotMatch(html, /data-preview=|Live MCDP/);
});

// Execute the real bundled SDK in an isolated DOM. Network is stubbed before SDK
// evaluation; these tests prove local compatibility, not real MAS/ACS delivery.
const { JSDOM, VirtualConsole } = require(process.env.BCO_TEST_JSDOM ||
  path.resolve(__dirname, "../../../beacms/beacms-vue-v251203/node_modules/jsdom"));
const vendor = fs.readFileSync(path.join(__dirname, "../public/vendor/mpaas-mcdp-h5-render/index.js"), "utf8");
function sdkDOM(raw) {
  const virtualConsole = new VirtualConsole();
  const dom = new JSDOM(api.ZONES.map((code) => `<div class="mcdp-view-wrap" data-mcdp-code="${code}"></div>`).join(""), {
    url: "http://bco.test/mcdp_demo/bco.html", runScripts: "outside-only", virtualConsole
  });
  const w = dom.window;
  const requests = [];
  w.XMLHttpRequest = class {
    open(method, url) { this.method = method; this.url = url; this.readyState = 1; }
    setRequestHeader() {}
    getAllResponseHeaders() { return "content-type: application/json"; }
    abort() {}
    send(body) {
      requests.push({ url: this.url, body });
      this.status = 200; this.responseText = "{}"; this.readyState = 4;
      queueMicrotask(() => { if (this.onreadystatechange) this.onreadystatechange(); });
    }
  };
  w.HTMLCanvasElement.prototype.getContext = () => ({ fillRect() {}, measureText: () => ({ width: 0 }) });
  w.eval(vendor);
  w.McdpView.request.getData = async (options) => {
    assert.deepEqual(Array.from(options._data[0].spaceCodeList), api.ZONES);
    return raw;
  };
  return { dom, w, requests };
}
const config = { appId: "test-app", workspaceId: "UAT", reportURL: "http://offline.test", uploadURL: "http://offline.test/mdap", userId: "test", utdid: "test-browser" };

// Mirrors the six-object, four-zone payload supplied from UAT on 2026-09-08.
// The historical defect was the missing hyphen in /cms/acmsresource/.
function capturedUatShape() {
  const raw = response();
  const ids = [["1281289373421142016.jpg", "1281289377707720704.jpg", "1281285419111022592.jpg"], ["1281289384280195072.jpg"], ["1281289384280195072.jpg"], ["1281289380933140480.png"]];
  raw.spaceInfoList.forEach((space, i) => {
    const template = space.spaceObjectList[0];
    space.spaceObjectList = ids[i].map((file, j) => ({ ...template, objectId: i * 10 + j,
      content: JSON.stringify({ uid: "bcm-v2-content-" + space.zoneCode,
        content: api.LANGUAGES.map((language) => ({ language, attrData: {
          main_title: language + " title", link_url: "#support",
          image: [{ fileFullPath: "http://external-nlb.test:443/cms/acmsresource/1237469588841562112/image/20260906/" + file }]
        } })) })
    }));
  });
  return raw;
}
for (const language of api.LANGUAGES) test("captured UAT shape renders all five SDK images on same origin: " + language, async () => {
  const raw = capturedUatShape();
  const before = JSON.stringify(raw);
  const { dom, w } = sdkDOM(raw);
  try {
    const errors = [];
    api.attach(w.McdpView, language, () => {}, (e) => errors.push(String(e.message)), w.location.origin);
    w.McdpView.init(config);
    await new Promise((resolve) => setTimeout(resolve, 50));
    assert.deepEqual(errors, []);
    const images = [...w.document.querySelectorAll(".mcdp-view-wrap img")];
    assert.equal(images.length, 5);
    for (const img of images) assert.match(img.src, /^http:\/\/bco.test\/mcdp_demo\/cms-assets\/acmsresource\/1237469588841562112\/image\/20260906\//);
    assert.equal(w.document.querySelector('[data-mcdp-code="home_notice"] span').innerText, language + " title");
    assert.equal(JSON.stringify(raw), before);
  } finally { dom.window.close(); }
});

for (const language of api.LANGUAGES) test("actual SDK renders four " + language + " placements and retains native close/click handlers", async () => {
  const { dom, w, requests } = sdkDOM(response());
  try {
    const errors = [];
    api.attach(w.McdpView, language, () => {}, (e) => errors.push(String(e.message)));
    w.McdpView.init(config);
    await new Promise((resolve) => setTimeout(resolve, 40));
    assert.deepEqual(errors, []);
    for (const zone of ["home_rotation", "popup_banner", "floating_buoy"]) {
      const mount = w.document.querySelector(`[data-mcdp-code="${zone}"]`);
      assert.equal(mount.querySelector("img").getAttribute("src"), "http://demo.test:443/cms/" + language + ".png", zone);
    }
    const notice = w.document.querySelector('[data-mcdp-code="home_notice"] span');
    assert.equal(notice.innerText, language + " title — " + language + " description");
    assert.ok(requests.some((request) => request.url.includes("AdShow")), "SDK attempted exposure reporting against stub transport");
    const rotation = w.document.querySelector('[data-mcdp-code="home_rotation"] img');
    rotation.click();
    await new Promise((resolve) => setTimeout(resolve, 5));
    assert.equal(w.location.hash, "#time-deposit");
    assert.ok(requests.some((request) => request.url.includes("AdClick")), "SDK attempted click reporting against stub transport");
    const popup = w.document.querySelector('[data-mcdp-code="popup_banner"]');
    popup.querySelector("svg").dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
    assert.equal(popup.style.display, "none");
  } finally { dom.window.close(); }
});
test("actual SDK still enforces exhausted frequency limit and nonmatching schedule", async () => {
  const raw = response();
  raw.spaceInfoList[0].spaceObjectList[0].behaviors = [{ behavior: "CLOSE_AFTER_TIMES", showTimes: 0 }];
  raw.spaceInfoList[2].spaceObjectList[0].crontabList = ["*@*@*@13@*"];
  const { dom, w } = sdkDOM(raw);
  try {
    const errors = [];
    api.attach(w.McdpView, "en", () => {}, (e) => errors.push(String(e.message)));
    w.McdpView.init(config);
    await new Promise((resolve) => setTimeout(resolve, 40));
    assert.deepEqual(errors, []);
    assert.equal(w.document.querySelector('[data-mcdp-code="home_rotation"] img'), null);
    assert.equal(w.document.querySelector('[data-mcdp-code="popup_banner"] img'), null);
    assert.ok(w.document.querySelector('[data-mcdp-code="floating_buoy"] img'));
  } finally { dom.window.close(); }
});
test("actual SDK errors reach page handler instead of a false successful state", async () => {
  const { dom, w } = sdkDOM({ code: -1 });
  try {
    const errors = [];
    api.attach(w.McdpView, "en", () => assert.fail("invalid response"), (e) => errors.push(String(e.message)));
    w.McdpView.init(config);
    await new Promise((resolve) => setTimeout(resolve, 40));
    assert.equal(errors.length, 1);
    assert.match(errors[0], /spaceInfoList/);
  } finally { dom.window.close(); }
});
