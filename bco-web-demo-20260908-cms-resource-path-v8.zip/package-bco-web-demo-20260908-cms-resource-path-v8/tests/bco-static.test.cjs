const test = require("node:test");
const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const { once } = require("node:events");
const path = require("node:path");

test("local server serves BCO entry/adapter/CSS without cache and retains legacy entry", async () => {
  const port = 30000 + process.pid % 20000;
  const child = spawn(process.execPath, [path.resolve(__dirname, "../server.mjs")], {
    env: { ...process.env, HOST: "127.0.0.1", PORT: String(port), MPAAS_PROXY_URL: "http://127.0.0.1:9/mpaas-proxy" },
    stdio: ["ignore", "pipe", "pipe"]
  });
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("Local server startup timeout")), 3000);
      child.once("error", (error) => { clearTimeout(timer); reject(error); });
      child.once("exit", (code) => { clearTimeout(timer); reject(new Error("Local server exited: " + code)); });
      child.stdout.once("data", () => { clearTimeout(timer); resolve(); });
    });
    for (const [file, mime] of [["bco.html", "text/html"], ["bco-material.js", "text/javascript"], ["bco-page.js", "text/javascript"], ["bco.css", "text/css"]]) {
      const response = await fetch(`http://127.0.0.1:${port}/mcdp_demo/${file}`);
      assert.equal(response.status, 200);
      assert.equal(response.headers.get("cache-control"), "no-store");
      assert.ok(response.headers.get("content-type").startsWith(mime));
      assert.ok((await response.text()).length > 100);
    }
    const legacy = await fetch(`http://127.0.0.1:${port}/mcdp_demo/`);
    assert.equal(legacy.status, 200);
    assert.match(await legacy.text(), /href="\.\/bco.html"/);

    const css = await (await fetch(`http://127.0.0.1:${port}/mcdp_demo/bco.css`)).text();
    assert.match(css, /data-mcdp-code="floating_buoy"/);
    assert.match(css, /position:\s*fixed/);
    assert.match(css, /position:\s*fixed\s*!important/);
    assert.match(css, /right:\s*max\(20px/);
  } finally {
    if (child.exitCode === null) { child.kill("SIGTERM"); await once(child, "exit"); }
  }
});
