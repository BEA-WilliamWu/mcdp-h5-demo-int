#!/usr/bin/env bash
# Expose only the BCO Demo page and its existing MCDP proxy through the
# already source-restricted IMK debug NLB.  It does not create an NLB, alter
# its allow-list, touch Secrets, or change application images.
set -Eeuo pipefail
set +x

namespace="${NAMESPACE:-cms-dev}"
public_service="${PUBLIC_SERVICE:-imk-public-debug}"
frontend="${FRONTEND_DEPLOYMENT:-imk-frontend}"
demo_service="${DEMO_SERVICE:-mcdp-demo-web}"

for cmd in kubectl awk sed mktemp; do
  command -v "$cmd" >/dev/null || { echo "Missing command: $cmd" >&2; exit 2; }
done

stop() { echo "STOP: $*" >&2; exit 1; }
k() { kubectl -n "$namespace" "$@"; }
work_dir="$(mktemp -d /tmp/bco-demo-route.XXXXXX)"
trap 'rm -rf "$work_dir"' EXIT

# The NLB must already be limited to named /32 addresses.  This is a hard
# guard: this script never creates or broadens a public entry point.
svc_shape="$(k get service "$public_service" -o go-template='{{.spec.type}}|{{.spec.selector.app}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}|{{range .spec.loadBalancerSourceRanges}}{{.}},{{end}}')"
[[ "$svc_shape" == LoadBalancer\|imk-frontend\|443:80/TCP,* ]] || stop "Unexpected public Service shape: $public_service"
cidrs="${svc_shape##*|}"
[[ -n "$cidrs" ]] || stop "Public Service has no source allow-list"
while IFS= read -r cidr; do
  [[ "$cidr" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/32$ ]] || stop "Allow-list is not /32-only: $cidr"
done < <(tr ',' '\n' <<< "$cidrs" | sed '/^$/d')

demo_shape="$(k get service "$demo_service" -o go-template='{{.spec.type}}|{{.spec.selector.app}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}')"
[[ "$demo_shape" == 'ClusterIP|mcdp-demo-web|80:http/TCP,' ]] || stop "Unexpected Demo Service shape"
proxy_shape="$(k get service mpaas-proxy -o go-template='{{.spec.type}}|{{.spec.selector.app}}|{{range .spec.ports}}{{.port}}:{{.targetPort}}/{{.protocol}},{{end}}')"
[[ "$proxy_shape" == ClusterIP\|*\|80:*\/TCP,* ]] || stop "Unexpected mpaas-proxy Service shape"

config_map="$(k get deployment "$frontend" -o go-template='{{range .spec.template.spec.volumes}}{{if .configMap}}{{.configMap.name}}{{"\n"}}{{end}}{{end}}' | sed '/^$/d')"
[[ -n "$config_map" && "$config_map" != *$'\n'* ]] || stop "Expected exactly one frontend ConfigMap volume"
k get configmap "$config_map" -o jsonpath='{.data.default\.conf}' > "$work_dir/default.conf"
config_keys="$(k get configmap "$config_map" -o go-template='{{range $k, $v := .data}}{{$k}}{{"\n"}}{{end}}' | sed '/^$/d')"
[[ "$config_keys" == 'default.conf' ]] || stop "ConfigMap has additional data keys; no replacement made"
grep -Fq 'location /marketing-management/' "$work_dir/default.conf" || stop "Frontend configuration is not the expected IMK proxy configuration"
if grep -Fq 'location ^~ /mcdp_demo/' "$work_dir/default.conf"; then
  stop "Demo route already has static-file priority; no change made"
fi

if grep -Fq 'location /mcdp_demo/' "$work_dir/default.conf"; then
  # Route was installed previously, but a later regex location took ownership
  # of .css/.js requests. Promote it without changing its upstream.
  grep -Fq 'location /mpaas-proxy/' "$work_dir/default.conf" \
    || stop "Existing Demo route has no matching MCDP proxy route"
  sed 's|location /mcdp_demo/ {|location ^~ /mcdp_demo/ {|' \
    "$work_dir/default.conf" > "$work_dir/updated.conf"
else
  route_file="$work_dir/route.conf"
  cat > "$route_file" <<'NGINX'
        # Restricted BCO browser demo. The NLB source allow-list is verified above.
        location ^~ /mcdp_demo/ {
            proxy_pass http://mcdp-demo-web:80;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_read_timeout 60s;
        }

        # Required by bco-page.js; backend signing remains inside mpaas-proxy.
        location /mpaas-proxy/ {
            proxy_pass http://mpaas-proxy:80;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_read_timeout 60s;
        }

NGINX
  awk -v route_file="$route_file" '
  /^[[:space:]]*location[[:space:]]+\/[[:space:]]*\{[[:space:]]*$/ {
    while ((getline line < route_file) > 0) print line
    close(route_file)
  }
  { print }
' "$work_dir/default.conf" > "$work_dir/updated.conf"
fi
[[ "$(grep -Fc 'location ^~ /mcdp_demo/' "$work_dir/updated.conf")" == 1 ]] || stop "Expected exactly one priority Demo route"

# `default.conf` is the sole ConfigMap data key, verified above.  The live
# field is owned by the existing client-side kubectl apply manager, so retain
# that manager rather than force a server-side ownership transfer.
k create configmap "$config_map" --from-file=default.conf="$work_dir/updated.conf" --dry-run=client -o yaml \
  | k apply -f -
k rollout restart "deployment/$frontend"
k rollout status "deployment/$frontend" --timeout=10m

pod="$(k get pods -l app=imk-frontend -o jsonpath='{range .items[?(@.status.phase=="Running")]}{.metadata.name}{"\n"}{end}' | head -n 1)"
[[ -n "$pod" ]] || stop "No running IMK frontend Pod after rollout"
k exec "$pod" -c imk-frontend -- sh -ec '
  wget -q -T 15 -O /tmp/bco.html http://127.0.0.1/mcdp_demo/bco.html
  grep -Fq "BCO Web" /tmp/bco.html
  wget -q -T 15 -O /tmp/proxy.json http://127.0.0.1/mpaas-proxy/api/status
  test -s /tmp/proxy.json
'
echo "BCO_DEMO_ROUTE_OK"
echo "Open: http://<existing-imk-NLB-host>:443/mcdp_demo/bco.html?lang=en"
