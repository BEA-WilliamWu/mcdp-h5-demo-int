#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
CMS_MATERIAL_SQL="$ROOT_DIR/deploy/acs/sql/003_offers_cih_demo.sql"
ZONE_MAPPING_SQL="$ROOT_DIR/deploy/acs/sql/004_mcdp_saas_zone_material_mappings.sql"
NAMESPACE="${NAMESPACE:-cms-dev}"
MYSQL_POD="${MYSQL_POD:-shared-mysql-0}"
MYSQL_CONTAINER="${MYSQL_CONTAINER:-shared-mysql}"

for command_name in base64 tr; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Required command not found: $command_name" >&2
    exit 1
  }
done

for sql_file in "$CMS_MATERIAL_SQL" "$ZONE_MAPPING_SQL"; do
  [[ -f "$sql_file" ]] || {
    echo "SQL file not found: $sql_file" >&2
    exit 1
  }
done

encoded_sql="$({
  printf 'START TRANSACTION;\n'
  command cat "$CMS_MATERIAL_SQL"
  printf '\n'
  command cat "$ZONE_MAPPING_SQL"
  printf '\nCOMMIT;\n'
} | base64 | tr -d '\r\n')"

printf '%s\n' 'set +o history 2>/dev/null || true'
printf 'printf %%s %q | kubectl exec -i -n %q %q -c %q -- sh -ec %q\n' \
  "$encoded_sql" \
  "$NAMESPACE" \
  "$MYSQL_POD" \
  "$MYSQL_CONTAINER" \
  'base64 -d | MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql --protocol=socket -uroot'

printf '%s\n' \
  "kubectl exec -n $NAMESPACE $MYSQL_POD -c $MYSQL_CONTAINER -- sh -ec 'MYSQL_PWD=\"\$MYSQL_ROOT_PASSWORD\" mysql --protocol=socket -uroot -Nse \"SELECT COUNT(*) FROM cms.acms_composer WHERE model_id=\\\"bcm-demo-app-model-cih-offer\\\" AND language=\\\"en\\\" AND status IN (\\\"1\\\",\\\"6\\\",\\\"7\\\",\\\"8\\\"); SELECT COUNT(*) FROM imk.sys_dict_data WHERE DICT_TYPE IN (\\\"home_rotation\\\",\\\"home_notice\\\",\\\"popup_banner\\\",\\\"floating_buoy\\\") AND DICT_VALUE=\\\"bcm-demo-app-model-cih-offer\\\" AND STATUS=\\\"0\\\";\"'"
