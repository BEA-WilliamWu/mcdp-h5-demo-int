/* One SDK initialisation per page avoids stale responses and duplicate SDK timers. */
(function () {
  "use strict";
  const params = new URLSearchParams(location.search);
  const language = BcoMaterial.LANGUAGES.includes(params.get("lang")) ? params.get("lang") : "en";
  const userId = (params.get("user") || "web-demo-user").slice(0, 128);
  const $ = (id) => document.getElementById(id);
  const status = (message) => { $("status").textContent = message; };
  let received = false;
  const record = (message) => {
    $("events").textContent = (new Date().toLocaleTimeString() + " " + message + "\n" + $("events").textContent).slice(0, 6000);
  };
  $("language").value = language;
  $("userId").value = userId;
  document.documentElement.lang = { en: "en", sc: "zh-CN", tc: "zh-TW" }[language];
  $("settings").addEventListener("submit", (event) => {
    event.preventDefault();
    const query = new URLSearchParams({ lang: $("language").value, user: $("userId").value.trim() });
    location.assign(location.pathname + "?" + query);
  });

  function showResults(items, response) {
    received = true;
    $("results").replaceChildren();
    for (const zone of BcoMaterial.ZONES) {
      const entries = items.filter((item) => item.zone === zone);
      const card = document.createElement("article");
      const heading = document.createElement("h3");
      heading.textContent = zone;
      card.appendChild(heading);
      const add = (text) => { const p = document.createElement("p"); p.textContent = text; card.appendChild(p); };
      if (!entries.length) add("本次未返回素材；检查已审核活动、有效期、人群和展位配置。");
      for (const entry of entries) {
        if (entry.error) { add("解析失败: " + entry.error); continue; }
        if (entry.native) { add("MCDP 原生素材，交由 SDK 渲染。"); continue; }
        const m = entry.material;
        add("CMS 已解析 / " + m.language + " / " + String(entry.objectId || "无 objectId"));
        add(m.title); add(m.subtitle); add("按钮: " + m.buttonText + " → " + (m.link || "无安全链接"));
        add("图片: " + (m.image || "无图片（文字公告）"));
      }
      $("results").appendChild(card);
    }
    const errors = items.filter((item) => item.error).length;
    status("MCDP 已返回 " + response.spaceInfoList.length + " 个展位；解析错误 " + errors + "。展示、图片及上报仍以实际结果为准。");
    record("响应已接收，CMS 语言=" + language + "；未修改服务端规则。");
  }

  // These events observe actual SDK images only; no hidden request marks an image readable.
  document.addEventListener("load", (event) => {
    const image = event.target;
    if (image.tagName === "IMG" && image.closest(".mcdp-view-wrap")) {
      record("图片已加载: " + image.currentSrc + " (" + image.naturalWidth + "×" + image.naturalHeight + ")");
    }
  }, true);
  document.addEventListener("error", (event) => {
    const image = event.target;
    if (image.tagName === "IMG" && image.closest(".mcdp-view-wrap")) {
      record("图片加载失败: " + image.src);
      status("已发现图片加载失败；本次不能判定 Demo 通过。");
    }
  }, true);

  try {
    const onError = (error) => {
      received = true;
      status("MCDP 请求或 SDK 渲染失败；Demo 未通过。");
      record(String(error && error.message || "Unknown SDK error"));
    };
    BcoMaterial.attach(window.McdpView, language, showResults, onError);
    const proxy = location.origin + "/mpaas-proxy";
    status("正在查询四个展位…");
    McdpView.init({
      appId: "ALIHK291A058251056", workspaceId: "UAT", tenantId: "VEXJGYYS",
      reportURL: proxy, uploadURL: proxy + "/mdap", userId, utdid: "bco-web-demo-browser",
      onError
    });
    setTimeout(() => { if (!received) status("15 秒内未收到有效展位响应；检查代理与活动，不能判定成功。"); }, 15000);
  } catch (error) {
    status("初始化失败: " + error.message);
    record(error.message);
  }
})();
