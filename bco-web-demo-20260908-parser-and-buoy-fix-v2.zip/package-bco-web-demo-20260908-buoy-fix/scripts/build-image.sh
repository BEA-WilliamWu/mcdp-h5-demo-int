#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_CONTEXT="$PROJECT_DIR"

IMAGE_TAG="${IMAGE_TAG:-$(date +%Y%m%d%H%M%S)}"
IMAGE_NAME="${IMAGE_NAME:-mcdp-demo-web}"
PLATFORM="${PLATFORM:-linux/amd64}"
LOCAL_IMAGE="${LOCAL_IMAGE:-$IMAGE_NAME:$IMAGE_TAG}"
NGINX_IMAGE="${NGINX_IMAGE:-docker.m.daocloud.io/library/nginx:1.25-alpine}"

docker build \
  --platform "$PLATFORM" \
  --build-arg "NGINX_IMAGE=$NGINX_IMAGE" \
  -f "$PROJECT_DIR/Dockerfile" \
  -t "$LOCAL_IMAGE" \
  "$BUILD_CONTEXT"

echo "Built image: $LOCAL_IMAGE"
