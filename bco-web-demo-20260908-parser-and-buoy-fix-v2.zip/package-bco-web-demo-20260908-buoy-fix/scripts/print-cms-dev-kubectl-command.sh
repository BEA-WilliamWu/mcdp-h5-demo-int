#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="$(cd "$SCRIPT_DIR/.." && pwd)/k8s/cms-dev.yaml"

if [[ ! -f "$MANIFEST" ]]; then
  echo "Manifest not found: $MANIFEST" >&2
  exit 1
fi

encoded_manifest="$(base64 < "$MANIFEST" | tr -d '\r\n')"
printf "printf '%%s' '%s' | base64 -d | kubectl apply -f -\n" "$encoded_manifest"
