#!/usr/bin/env bash
set -Eeuo pipefail

umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${PROJECT_DIR:-}"
BUILD_SCRIPT="${BUILD_SCRIPT:-}"

if [[ -z "$PROJECT_DIR" || -z "$BUILD_SCRIPT" || ! -f "$BUILD_SCRIPT" ]]; then
  echo "PROJECT_DIR and BUILD_SCRIPT must point to a project and its build script." >&2
  exit 1
fi

ACR_REGISTRY="${ACR_REGISTRY:-bcm-dev-registry.cn-hongkong.cr.aliyuncs.com}"
ACR_VPC_REGISTRY="${ACR_VPC_REGISTRY:-bcm-dev-registry-vpc.cn-hongkong.cr.aliyuncs.com}"
ACR_NAMESPACE="${ACR_NAMESPACE:-bcm-dev}"
ACR_REGION_ID="${ACR_REGION_ID:-cn-hongkong}"
ACR_API_ENDPOINT="${ACR_API_ENDPOINT:-cr.cn-hongkong.aliyuncs.com}"
ACR_INSTANCE_NAME="${ACR_INSTANCE_NAME:-bcm-dev}"
ACR_INSTANCE_ID="${ACR_INSTANCE_ID:-}"
IMAGE_TAG="${IMAGE_TAG:-$(date +%Y%m%d%H%M%S)}"
IMAGE_NAME="${IMAGE_NAME:-mpaas-proxy}"
PLATFORM="${PLATFORM:-linux/amd64}"
LOCAL_IMAGE="${LOCAL_IMAGE:-$IMAGE_NAME:$IMAGE_TAG}"
GO_IMAGE="${GO_IMAGE:-docker.m.daocloud.io/library/golang:1.23-alpine}"
RUNTIME_IMAGE="${RUNTIME_IMAGE:-docker.m.daocloud.io/library/alpine:3.20}"

PUBLIC_IMAGE="$ACR_REGISTRY/$ACR_NAMESPACE/$IMAGE_NAME:$IMAGE_TAG"
VPC_IMAGE="$ACR_VPC_REGISTRY/$ACR_NAMESPACE/$IMAGE_NAME:$IMAGE_TAG"

if [[ -z "${HTTPS_PROXY:-}" && -z "${https_proxy:-}" && -z "${ALL_PROXY:-}" && -z "${all_proxy:-}" ]] && \
  command -v scutil >/dev/null 2>&1; then
  proxy_snapshot="$(scutil --proxy)"
  proxy_enabled="$(awk '/HTTPSEnable/ { print $3; exit }' <<<"$proxy_snapshot")"
  proxy_host="$(awk '/HTTPSProxy/ { print $3; exit }' <<<"$proxy_snapshot")"
  proxy_port="$(awk '/HTTPSPort/ { print $3; exit }' <<<"$proxy_snapshot")"

  if [[ "$proxy_enabled" == "1" && -n "$proxy_host" && "$proxy_port" =~ ^[0-9]+$ ]]; then
    export HTTPS_PROXY="http://$proxy_host:$proxy_port"
    export HTTP_PROXY="$HTTPS_PROXY"
    export ALL_PROXY="$HTTPS_PROXY"
    echo "==> Using macOS system HTTPS proxy: $proxy_host:$proxy_port"
  fi

  unset proxy_snapshot proxy_enabled proxy_host proxy_port
fi

for required_command in docker; do
  if ! command -v "$required_command" >/dev/null 2>&1; then
    echo "Required command not found: $required_command" >&2
    exit 1
  fi
done

echo "==> Building local image before requesting any credential"
IMAGE_TAG="$IMAGE_TAG" \
IMAGE_NAME="$IMAGE_NAME" \
LOCAL_IMAGE="$LOCAL_IMAGE" \
PLATFORM="$PLATFORM" \
GO_IMAGE="$GO_IMAGE" \
RUNTIME_IMAGE="$RUNTIME_IMAGE" \
bash "$BUILD_SCRIPT"

for required_command in aliyun crane jq curl; do
  if ! command -v "$required_command" >/dev/null 2>&1; then
    echo "Required command not found: $required_command" >&2
    echo "The image has been built locally as: $LOCAL_IMAGE"
    echo "No AccessKey was requested."
    exit 1
  fi
done

registry_reachable() {
  curl -sS -o /dev/null \
    --connect-timeout 8 \
    --max-time 15 \
    "https://$ACR_REGISTRY/v2/"
}

detect_public_ipv4() {
  local endpoint
  local candidate

  for endpoint in https://api.ipify.org https://4.ipw.cn https://ifconfig.co/ip; do
    candidate="$(curl -4 -sS --connect-timeout 6 --max-time 12 "$endpoint" 2>/dev/null || true)"
    if [[ "$candidate" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done

  return 1
}

needs_network_repair=0
public_egress_ip=""

echo "==> Checking ACR network route before requesting credentials"
if ! registry_reachable; then
  public_egress_ip="$(detect_public_ipv4 || true)"

  if [[ -z "$public_egress_ip" ]]; then
    cat >&2 <<EOF
Cannot reach $ACR_REGISTRY on TCP 443.
No credential was requested or loaded.

The public egress IP could not be detected. Enable the ACR Enterprise Edition
public Registry endpoint and add the proxy egress IP as a /32 ACL entry.
EOF
    exit 2
  fi

  cat <<EOF
Cannot currently reach $ACR_REGISTRY on TCP 443.
Detected public egress IP: $public_egress_ip

The next optional step will use the AccessKey only in this process to:
  1. inspect the ACR Registry Internet endpoint;
  2. enable that endpoint if disabled; and
  3. add exactly $public_egress_ip/32 if it is missing.
EOF

  printf 'Continue with this exact ACR network change? [y/N]: '
  IFS= read -r network_confirmation
  case "$network_confirmation" in
    y|Y|yes|YES)
      needs_network_repair=1
      ;;
    *)
      echo "No credential was requested or loaded. No ACR setting was changed."
      echo "The image remains local as: $LOCAL_IMAGE"
      exit 2
      ;;
  esac
fi

printf 'Alibaba Cloud AccessKey ID (hidden): '
IFS= read -r -s ALIBABA_CLOUD_ACCESS_KEY_ID
printf '\nAlibaba Cloud AccessKey Secret (hidden): '
IFS= read -r -s ALIBABA_CLOUD_ACCESS_KEY_SECRET
printf '\n'

if [[ -z "$ALIBABA_CLOUD_ACCESS_KEY_ID" || -z "$ALIBABA_CLOUD_ACCESS_KEY_SECRET" ]]; then
  echo "AccessKey ID and Secret are both required." >&2
  exit 1
fi

export ALIBABA_CLOUD_ACCESS_KEY_ID
export ALIBABA_CLOUD_ACCESS_KEY_SECRET
export ALIBABA_CLOUD_IGNORE_PROFILE=TRUE
export ALIBABA_CLOUD_REGION_ID="$ACR_REGION_ID"

if [[ -z "$ACR_INSTANCE_ID" ]]; then
  echo "==> Looking up ACR instance ID for $ACR_INSTANCE_NAME"
  if instance_response="$(aliyun cr ListInstance \
    --endpoint "$ACR_API_ENDPOINT" \
    --InstanceName "$ACR_INSTANCE_NAME" \
    --PageNo 1 \
    --PageSize 30)"; then
    ACR_INSTANCE_ID="$(jq -r \
      --arg instance_name "$ACR_INSTANCE_NAME" \
      '[.Instances[] | select(.InstanceName == $instance_name) | .InstanceId][0] // empty' \
      <<<"$instance_response" || true)"
  else
    echo "Automatic lookup failed. The AccessKey may not have cr:ListInstance." >&2
  fi
fi

if [[ -z "$ACR_INSTANCE_ID" ]]; then
  printf 'ACR instance ID (cri-...): '
  IFS= read -r ACR_INSTANCE_ID
fi

if [[ ! "$ACR_INSTANCE_ID" =~ ^cri-[A-Za-z0-9]+$ ]]; then
  echo "Invalid ACR instance ID." >&2
  exit 1
fi

if [[ "$needs_network_repair" == "1" ]]; then
  requested_cidr="$public_egress_ip/32"
  echo "==> Inspecting ACR Registry Internet endpoint"
  endpoint_response="$(aliyun cr ListInstanceEndpoint \
    --endpoint "$ACR_API_ENDPOINT" \
    --InstanceId "$ACR_INSTANCE_ID" \
    --ModuleName Registry \
    --Summary false)"

  endpoint_enabled="$(jq -r \
    '[.Endpoints[] | select(((.EndpointType // "") | ascii_downcase) == "internet")][0].Enable // false' \
    <<<"$endpoint_response")"

  if [[ "$endpoint_enabled" != "true" ]]; then
    echo "==> Enabling ACR Registry Internet endpoint"
    aliyun cr UpdateInstanceEndpointStatus \
      --endpoint "$ACR_API_ENDPOINT" \
      --InstanceId "$ACR_INSTANCE_ID" \
      --EndpointType internet \
      --Enable true \
      --ModuleName Registry >/dev/null
  else
    echo "==> ACR Registry Internet endpoint is already enabled"
  fi

  if jq -e \
    --arg requested_cidr "$requested_cidr" \
    '.Endpoints[] | select(((.EndpointType // "") | ascii_downcase) == "internet") | .AclEntries[]? | select(.Entry == $requested_cidr)' \
    <<<"$endpoint_response" >/dev/null; then
    echo "==> ACR Registry ACL already contains $requested_cidr"
  else
    echo "==> Adding ACR Registry ACL entry $requested_cidr"
    acl_created=0
    for acl_attempt in 1 2 3 4; do
      if aliyun cr CreateInstanceEndpointAclPolicy \
        --endpoint "$ACR_API_ENDPOINT" \
        --InstanceId "$ACR_INSTANCE_ID" \
        --EndpointType internet \
        --Entry "$requested_cidr" \
        --Comment "bea-mcdp-secure-publish" \
        --ModuleName Registry >/dev/null; then
        acl_created=1
        break
      fi

      if [[ "$acl_attempt" != "4" ]]; then
        echo "ACL update is not ready yet; retrying..." >&2
        sleep $((acl_attempt * 3))
      fi
    done

    if [[ "$acl_created" != "1" ]]; then
      echo "Failed to add the exact ACR ACL entry $requested_cidr." >&2
      exit 1
    fi
  fi

  echo "==> Waiting for the ACR Registry endpoint to accept connections"
  registry_ready=0
  for readiness_attempt in 1 2 3 4 5 6 7 8 9 10 11 12; do
    if registry_reachable >/dev/null 2>&1; then
      registry_ready=1
      break
    fi
    sleep 5
  done

  if [[ "$registry_ready" != "1" ]]; then
    echo "The ACL change was submitted, but the Registry endpoint is still unreachable." >&2
    echo "Keep the proxy network egress fixed and retry this script after the ACR change finishes." >&2
    exit 2
  fi

  unset endpoint_response endpoint_enabled requested_cidr acl_created acl_attempt registry_ready readiness_attempt
fi

echo "==> Requesting a one-hour ACR login token"
token_response="$(aliyun cr GetAuthorizationToken \
  --endpoint "$ACR_API_ENDPOINT" \
  --InstanceId "$ACR_INSTANCE_ID")"

temporary_username="$(jq -er '.TempUsername // empty' <<<"$token_response")"
authorization_token="$(jq -er '.AuthorizationToken // empty' <<<"$token_response")"

unset ALIBABA_CLOUD_ACCESS_KEY_ID
unset ALIBABA_CLOUD_ACCESS_KEY_SECRET
unset instance_response
unset token_response

auth_directory="$(mktemp -d "${TMPDIR:-/tmp}/bea-mcdp-acr-auth.XXXXXX")"
archive_directory="$(mktemp -d "${TMPDIR:-/tmp}/bea-mcdp-acr-images.XXXXXX")"

cleanup() {
  unset authorization_token temporary_username

  if [[ -n "${auth_directory:-}" && "$auth_directory" == *'/bea-mcdp-acr-auth.'* ]]; then
    rm -rf -- "$auth_directory"
  fi
  if [[ -n "${archive_directory:-}" && "$archive_directory" == *'/bea-mcdp-acr-images.'* ]]; then
    rm -rf -- "$archive_directory"
  fi
}
trap cleanup EXIT INT TERM

printf '%s' "$authorization_token" | \
  DOCKER_CONFIG="$auth_directory" \
  crane auth login --username "$temporary_username" --password-stdin "$ACR_REGISTRY"

unset authorization_token temporary_username

echo "==> Temporary registry login succeeded"

expected_arch="${PLATFORM##*/}"
architecture="$(docker image inspect "$LOCAL_IMAGE" --format '{{.Architecture}}')"
if [[ "$architecture" != "$expected_arch" ]]; then
  echo "Expected $expected_arch image, got $architecture: $LOCAL_IMAGE" >&2
  exit 1
fi

archive_path="$archive_directory/$IMAGE_NAME-$IMAGE_TAG-$expected_arch.tar"
echo "==> Saving local image to a temporary archive"
docker save "$LOCAL_IMAGE" -o "$archive_path"

echo "==> Pushing with temporary ACR token"
crane_push_attempts="${CRANE_PUSH_RETRIES:-3}"
for push_attempt in $(seq 1 "$crane_push_attempts"); do
  echo "    attempt $push_attempt/$crane_push_attempts: $PUBLIC_IMAGE"
  if DOCKER_CONFIG="$auth_directory" crane push "$archive_path" "$PUBLIC_IMAGE"; then
    break
  fi

  if [[ "$push_attempt" == "$crane_push_attempts" ]]; then
    echo "Failed to push $PUBLIC_IMAGE." >&2
    echo "The local image is still available as: $LOCAL_IMAGE" >&2
    exit 1
  fi

  sleep $((push_attempt * 5))
done

cat <<EOF

Published successfully:
  public:  $PUBLIC_IMAGE
  acs-vpc: $VPC_IMAGE

Use this image in $PROJECT_DIR/k8s/cms-dev.yaml:
  image: $VPC_IMAGE

The AccessKey was not written to disk. The temporary registry login is being removed now.
EOF
