#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

PROJECT_DIR="$PROJECT_DIR" \
BUILD_SCRIPT="$SCRIPT_DIR/build-image.sh" \
IMAGE_NAME="${IMAGE_NAME:-mcdp-demo-web}" \
exec bash "$SCRIPT_DIR/publish-acr-secure.sh" "$@"
