# BCO Web Demo 本地调试包

版本：`local-debug-20260909`。已包含 `localhost-cms-proxy-fix-01` 图片代理修复；前端基于 `cms-resource-path-v8`。

## 包内仅有 10 个文件

```text
README.md                  本说明
SHA256SUMS.txt              文件完整性校验
server.mjs                 本地静态服务、MCDP 与受限图片代理
start-mac.sh               Mac 启动
start-windows.cmd          Windows 启动
public/
  bco.html                 BCO 四展位页面
  bco.css                  样式和右下角客服浮标位置
  bco-material.js          CMS 三语 JSON 解析与图片地址适配
  bco-page.js              页面初始化和诊断
  vendor/mpaas-mcdp-h5-render/index.js   现有 SDK（必需）
```

不含 Docker、Nginx、Kubernetes、数据库 SQL、发布脚本、测试文件、node_modules、旧 CIH 页面或备用图片。
图片仍来自真实 MCDP/CMS，没有用包内图片伪装投放成功。不要删除 vendor SDK，否则四个展位不能渲染。

## 运行条件

1. 电脑已有 Node.js；不需要 npm install，也不需要 Docker。
2. 电脑能访问内网 `http://10.23.34.52:443`，且内网已部署 mPaaS 代理与 v8 的受限 CMS 图片路由。
3. CMS 素材已发布，MCDP 活动已上线、在有效期内且命中测试用户。localhost 并不是离线模式。

无需在本机填写 AccessKey 或 App Secret，无需操作 Workbench 或数据库。使用获授权的 UAT 测试用户；SDK 仍可能产生曝光/点击日志。

## Mac 启动

先在旧服务的终端按 Ctrl+C，避免 5179 端口被占用。
当前这台 Mac 已准备好的绝对目录：

```bash
cd /Users/devs/DWksp/bcm-cms/deliverables/bco-e2e-demo-20260909/bco-web-demo-local-20260909
bash start-mac.sh
```

其他电脑先解压 ZIP，进入自己的实际解压目录再执行 `bash start-mac.sh`。
可选校验：在包目录执行 `shasum -a 256 -c SHA256SUMS.txt`，应全部 OK。

## Windows 启动

先完整解压 ZIP，不要在压缩文件预览窗口里运行。
双击解压目录中的 `start-windows.cmd`，保持窗口打开。

也可将包解压到 `C:\BCO`，在 PowerShell 执行：

```powershell
Set-Location 'C:\BCO\bco-web-demo-local-20260909'
.\start-windows.cmd
```

## 打开与调试

浏览器打开：

`http://localhost:5179/mcdp_demo/bco.html?lang=en&user=web-demo-user`

`http://localhost:5179/` 和 `/mcdp_demo/` 也直接进入 BCO 页面，不再进入旧 CIH 示例。
若 localhost 被本机代理/IPv6 设置影响，可尝试 `http://127.0.0.1:5179/mcdp_demo/bco.html`。
不要使用 file://、仅支持静态文件的 Live Server，或省略 5179 端口。

- 修改 HTML/CSS/JS：保存后强制刷新浏览器。
- 修改 server.mjs 或环境变量：Ctrl+C 停止后重新启动。
- 切换语言：选 English/简体/繁體后点 Apply / reload。
- 验证：三张轮播、公告、弹屏、右下角客服浮标及点击落地。弹屏仍受排期和频控约束。
- 关闭：终端按 Ctrl+C。

## 上游与图片配置

默认配置：

| 配置 | 默认值/作用 |
| --- | --- |
| HOST | `127.0.0.1`，仅本机访问 |
| PORT | `5179` |
| MPAAS_PROXY_URL | `http://10.23.34.52:443/mpaas-proxy` |
| CMS_ASSETS_URL | 默认从 MPAAS_PROXY_URL 取相同协议/主机/端口，路径为 `/mcdp_demo/cms-assets/` |

本地 `/mpaas-proxy/*` 转发到内网 RPC/日志代理。
本地 `/mcdp_demo/cms-assets/acmsresource/...` 或 `acms-resource/...` 转发到内网对应图片路由。
这里只允许 GET/HEAD 和受限图片文件路径，不转发图片请求中的 Cookie、Authorization、Referer 或查询参数，不接受任意目标 URL。
保留内网现有 HTTP:443，不擅自改成 HTTPS。

如管理员提供了其他已授权入口，可修改启动前的环境变量。Mac 示例：

```bash
MPAAS_PROXY_URL=http://10.23.34.52:443/mpaas-proxy \
CMS_ASSETS_URL=http://10.23.34.52:443/mcdp_demo/cms-assets/ \
bash start-mac.sh
```

Windows PowerShell：

```powershell
$env:MPAAS_PROXY_URL='http://10.23.34.52:443/mpaas-proxy'
$env:CMS_ASSETS_URL='http://10.23.34.52:443/mcdp_demo/cms-assets/'
.\start-windows.cmd
```

CMS_ASSETS_URL 必须是固定图片代理基址，不是单张图片或需要登录的 CMS 管理地址。
不填用户名、密码、签名查询参数。以前设置过该变量时，检查启动日志避免继续使用旧入口。

## 确认图片代理正常

1. 打开 `http://localhost:5179/healthz`，确认 `localProxyRevision` 是 `localhost-cms-proxy-fix-01`。
2. 浏览器 Network 中查看真正的 Img 请求。应使用 localhost 下的 `/mcdp_demo/cms-assets/...`，返回 200 和图片内容。
3. 原始 mgw.htm JSON 中仍有旧 Ali 域名可以是正常的；判断实际 Img 请求，不只看原始 JSON。

| 现象 | 处理 |
| --- | --- |
| 启动提示端口占用 | 停止旧服务，或改 PORT 并访问对应端口 |
| healthz 无修订号 / Static file not found | 检查是否还在使用旧 server.mjs 或旧本地服务 |
| 图片 401/403/404 | 查内网完整图片路径、权限和受限图片路由；不以目录地址的 401 判断图片不存在 |
| 图片 502/504 | 检查网络、上游入口；登录页/重定向不会被当作图片成功 |
| 四展位返回但没素材 | 核对活动、人群、有效期和渠道；本地代理不修改这些规则 |

交付验证在本机隔离 HTTP 上游进行；未操作真实 CMS/MCDP/MAS，内网显示效果仍需实际验证。
