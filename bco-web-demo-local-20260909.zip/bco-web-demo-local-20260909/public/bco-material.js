/* cms-resource-path-v8: CMS content decoder; no network or storage access. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.BcoMaterial = factory();
})(typeof globalThis === "object" ? globalThis : this, function () {
  "use strict";
  const ZONES = Object.freeze(["home_rotation", "home_notice", "popup_banner", "floating_buoy"]);
  const LANGUAGES = Object.freeze(["en", "sc", "tc"]);
  const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
  const object = (value) => value && typeof value === "object" && !Array.isArray(value);

  function parse(value) {
    // CMS content, attrData and image may each be JSON-encoded independently.
    for (let i = 0; i < 3 && typeof value === "string"; i++) {
      if (value.length > 2000000) throw new Error("CMS payload exceeds 2 MB");
      try { value = JSON.parse(value); } catch (_) { break; }
    }
    return value;
  }

  function safeURL(value, image) {
    if (typeof value !== "string") return "";
    const url = value.trim();
    if (!url || /[\u0000-\u0020\u007f\\]/.test(url)) return "";
    if (/^\/(?!\/)/.test(url) || (!image && /^#/.test(url))) return url;
    try {
      const parsed = new URL(url);
      if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password ||
          ["null", "undefined"].includes(parsed.hostname.toLowerCase())) return "";
      return url; // In particular, do not silently change temporary HTTP:443 to HTTPS.
    } catch (_) { return ""; }
  }

  function imageURL(value) {
    const parsed = parse(value);
    const first = Array.isArray(parsed) ? parsed[0] : parsed;
    const candidate = object(first)
      ? first.fileUrl || first.fileFullPath || first.url || first.hrefUrl || first.src
      : first;
    return safeURL(candidate, true);
  }

  // MCDP stores the CMS image URL that existed when a task was reviewed.  In
  // UAT that can be an external NLB host which an intranet browser cannot
  // reach.  Only translate the known, public CMS image shape to the narrowly
  // scoped same-origin asset route; never turn an arbitrary remote URL into a
  // proxy request.
  function sameOriginCmsImage(value, origin) {
    const url = safeURL(value, true);
    if (!url || !origin || /^\/(?!\/)/.test(url)) return url;
    try {
      const parsed = new URL(url);
      // CMS has emitted both `acmsresource` and `acms-resource` paths in
      // UAT. Preserve the exact resource root so the same-origin proxy can
      // forward to the matching CMS endpoint.
      const match = parsed.pathname.match(/^\/cms\/(acms-?resource)\/(.+)$/);
      if (!match) return url;
      const resourceRoot = match[1].toLowerCase();
      const assetPath = match[2];
      if (!/^[0-9]+\/image\/[0-9]{8}\/[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.(avif|gif|jpe?g|png|webp)$/.test(assetPath)) return url;
      const current = new URL(origin);
      if (!/^https?:$/.test(current.protocol)) return url;
      return current.origin + "/mcdp_demo/cms-assets/" + resourceRoot + "/" + assetPath;
    } catch (_) { return url; }
  }

  function decode(content, language) {
    if (!LANGUAGES.includes(language)) throw new Error("Unsupported CMS language");
    const value = parse(content);
    // Current CMS/MCDP creatives wrap the localized records in a content array:
    // { uid, url, content: [{ language, attrData }, ...] }.  Older creatives
    // are the array itself (or a language-keyed object), so normalize only a
    // content array whose members are explicit localized records.
    const localized = object(value) && Array.isArray(value.content) &&
      value.content.every((item) => object(item) && typeof item.language === "string")
      ? value.content
      : value;
    let entry;
    if (Array.isArray(localized)) {
      const matches = localized.filter((item) => object(item) && item.language === language);
      if (matches.length !== 1) throw new Error(matches.length ? "Duplicate CMS language" : "Missing CMS language: " + language);
      entry = matches[0];
    } else if (object(localized) && own(localized, language)) {
      entry = parse(localized[language]);
    } else if (object(localized) && localized.language === language) {
      entry = localized;
    } else {
      throw new Error("Unsupported or missing CMS language content: " + language);
    }
    if (!object(entry)) throw new Error("Invalid CMS language entry");
    const fields = parse(entry.attrData);
    if (!object(fields)) throw new Error("Invalid CMS attrData");
    const text = (value) => typeof value === "string" || typeof value === "number" ? String(value) : "";
    return {
      language,
      title: text(fields.main_title || entry.title || fields.title),
      subtitle: text(fields.subtitle),
      buttonText: text(fields.button_text),
      image: imageURL(fields.image),
      link: safeURL(fields.link_url, false),
      campaign: text(fields.activity_desc)
    };
  }

  function adaptResponse(response, language, assetOrigin) {
    if (!LANGUAGES.includes(language)) throw new Error("Unsupported CMS language");
    if (!object(response) || !Array.isArray(response.spaceInfoList)) throw new Error("MCDP response has no spaceInfoList");
    const diagnostics = [];
    const spaceInfoList = response.spaceInfoList.map((space) => {
      if (!object(space) || !ZONES.includes(space.zoneCode)) return space;
      if (!Array.isArray(space.spaceObjectList)) {
        diagnostics.push({ zone: space.zoneCode, error: "Missing spaceObjectList" });
        return { ...space, spaceObjectList: [] };
      }
      const spaceObjectList = space.spaceObjectList.flatMap((item) => {
        if (!object(item)) return [];
        try {
          const parsed = parse(item.content);
          const isCms = item.contentType === "URL" || item.type === "URL" || (parsed && typeof parsed === "object");
          if (!isCms) {
            // Some MCDP activity configurations persist a CMS image as a
            // native PIC rather than a CMS URL wrapper. Apply the same
            // narrowly scoped rewrite before the SDK creates its <img>.
            const hrefUrl = sameOriginCmsImage(item.hrefUrl, assetOrigin);
            if (hrefUrl !== item.hrefUrl) {
              diagnostics.push({ zone: space.zoneCode, objectId: item.objectId, native: true, assetProxy: true });
              return [{ ...item, hrefUrl }];
            }
            diagnostics.push({ zone: space.zoneCode, objectId: item.objectId, native: true });
            return [item]; // Native PIC/GIF/LOTTIE/text stays with the SDK.
          }
          const decoded = decode(item.content, language);
          const material = { ...decoded, image: sameOriginCmsImage(decoded.image, assetOrigin) };
          const notice = space.multiStyle === "ANNOUNCEMENT";
          if (!notice && !material.image) throw new Error("CMS image missing or URL unsafe");
          if (notice && !material.title && !material.subtitle) throw new Error("CMS notice text missing");
          diagnostics.push({ zone: space.zoneCode, objectId: item.objectId, material });
          return [{
            ...item, // Preserve objectId, behaviors, crontabList, logExtInfo and all server rules.
            contentType: notice ? item.contentType : "PIC",
            hrefUrl: material.image,
            actionUrl: material.link,
            // The bundled notice renderer assigns innerText, not innerHTML.
            content: notice ? [material.title, material.subtitle].filter(Boolean).join(" — ") : item.content
          }];
        } catch (error) {
          diagnostics.push({ zone: space.zoneCode, objectId: item.objectId, error: error.message });
          return []; // No fallback to a different language or a fake default creative.
        }
      });
      return { ...space, spaceObjectList };
    });
    return { response: { ...response, spaceInfoList }, diagnostics };
  }

  function attach(sdk, language, onResponse, onError, assetOrigin) {
    if (!sdk || !sdk.request || typeof sdk.request.getData !== "function") {
      throw new Error("Bundled SDK compatibility check failed: request.getData unavailable");
    }
    const request = sdk.request;
    const original = request.getData;
    // This bundled version reads _config.onError, not initConfig.onError.
    const originalError = sdk._config && sdk._config.onError;
    if (sdk._config && typeof onError === "function") sdk._config.onError = onError;
    request.getData = async function () {
      const raw = await original.apply(this, arguments);
      const result = adaptResponse(raw, language, assetOrigin);
      onResponse(result.diagnostics, result.response);
      return result.response;
    };
    return () => {
      request.getData = original;
      if (sdk._config && typeof onError === "function") sdk._config.onError = originalError;
    };
  }

  return { ZONES, LANGUAGES, decode, safeURL, imageURL, sameOriginCmsImage, adaptResponse, attach };
});
