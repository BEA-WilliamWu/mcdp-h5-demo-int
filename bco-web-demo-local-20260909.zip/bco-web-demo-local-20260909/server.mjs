import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const host = process.env.HOST || "127.0.0.1";
const port = Number(process.env.PORT || 5179);
const proxyTarget = new URL(
  process.env.MPAAS_PROXY_URL || "http://10.23.34.52:443/mpaas-proxy"
);
const localProxyRevision = "localhost-cms-proxy-fix-01";
// Reuse the deployed restricted image route, not the authenticated CMS UI.
// This is a server-side setting; callers cannot choose an arbitrary upstream.
const cmsAssetsTarget = new URL(process.env.CMS_ASSETS_URL ||
  new URL("/mcdp_demo/cms-assets/", proxyTarget.origin));
if (!["http:", "https:"].includes(cmsAssetsTarget.protocol) ||
    cmsAssetsTarget.username || cmsAssetsTarget.password ||
    cmsAssetsTarget.search || cmsAssetsTarget.hash) {
  throw new Error("CMS_ASSETS_URL must be an HTTP(S) base URL without credentials, query or fragment");
}
const cmsAssetsTimeout = Number(process.env.CMS_ASSETS_TIMEOUT_MS || 15000);
if (!Number.isInteger(cmsAssetsTimeout) || cmsAssetsTimeout < 1 || cmsAssetsTimeout > 60000) {
  throw new Error("CMS_ASSETS_TIMEOUT_MS must be an integer from 1 to 60000");
}
const cmsAssetsPrefix = "/mcdp_demo/cms-assets/";
const cmsAssetPattern = /^\/mcdp_demo\/cms-assets\/(acmsresource|acms-resource)\/[0-9]+\/image\/[0-9]{8}\/[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.(avif|gif|jpe?g|png|webp)$/;
const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "public");

const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webp": "image/webp"
};

function sendJSON(response, status, payload) {
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8"
  });
  response.end(`${JSON.stringify(payload)}\n`);
}

function serveStatic(request, response, pathname) {
  const relativePath = pathname === "/mcdp_demo/"
    ? "bco.html" // Local-only package: no legacy CIH page or preview assets.
    : decodeURIComponent(pathname.slice("/mcdp_demo/".length));
  const filePath = path.resolve(publicDir, relativePath);

  if (filePath !== publicDir && !filePath.startsWith(`${publicDir}${path.sep}`)) {
    sendJSON(response, 403, { success: false, message: "Forbidden" });
    return;
  }

  fs.stat(filePath, (error, stat) => {
    if (error || !stat.isFile()) {
      sendJSON(response, 404, { success: false, message: "Static file not found" });
      return;
    }

    response.writeHead(200, {
      "cache-control": ["bco.html", "bco-material.js", "bco-page.js", "bco.css"].includes(relativePath) ? "no-store" : "public, max-age=3600",
      "content-length": stat.size,
      "content-type": mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream"
    });
    fs.createReadStream(filePath).pipe(response);
  });
}

function proxyRequest(request, response, requestURL) {
  const suffix = requestURL.pathname.slice("/mpaas-proxy".length);
  const targetPath = `${proxyTarget.pathname.replace(/\/$/, "")}${suffix || "/"}${requestURL.search}`;
  const headers = { ...request.headers, host: proxyTarget.host };
  delete headers.connection;
  delete headers["content-length"];

  const transport = proxyTarget.protocol === "https:" ? https : http;
  const upstream = transport.request({
    protocol: proxyTarget.protocol,
    hostname: proxyTarget.hostname,
    port: proxyTarget.port || (proxyTarget.protocol === "https:" ? 443 : 80),
    method: request.method,
    path: targetPath,
    headers
  }, (upstreamResponse) => {
    response.writeHead(upstreamResponse.statusCode || 502, upstreamResponse.headers);
    upstreamResponse.pipe(response);
  });

  upstream.on("error", (error) => {
    if (!response.headersSent) {
      sendJSON(response, 502, {
        success: false,
        message: `Cannot reach ACS mPaaS proxy: ${error.message}`,
        target: proxyTarget.toString()
      });
    } else {
      response.destroy(error);
    }
  });

  request.pipe(upstream);
}

function proxyCmsAsset(request, response, rawPath) {
  if (request.method !== "GET" && request.method !== "HEAD") {
    response.setHeader("allow", "GET, HEAD");
    sendJSON(response, 405, { success: false, message: "CMS assets only allow GET and HEAD" });
    return;
  }
  // Validate before URL parsing can normalize traversal/encoded segments.
  if (!cmsAssetPattern.test(rawPath)) {
    sendJSON(response, 404, { success: false, message: "CMS image path not allowed" });
    return;
  }
  const suffix = rawPath.slice(cmsAssetsPrefix.length);
  const target = new URL(cmsAssetsTarget);
  target.pathname = cmsAssetsTarget.pathname.replace(/\/$/, "") + "/" + suffix;
  // Deliberately ignore caller queries and all browser headers, including
  // Cookie, Authorization, Referer, Range and conditional-cache headers.
  const transport = target.protocol === "https:" ? https : http;
  const fail = (status, message) => {
    if (response.destroyed || response.writableEnded) return;
    if (response.headersSent) response.destroy(new Error(message));
    else sendJSON(response, status, { success: false, message });
  };
  const upstream = transport.request(target, {
    method: request.method,
    agent: false,
    headers: { accept: "image/avif,image/webp,image/png,image/jpeg,image/gif" }
  }, (incoming) => {
    const status = incoming.statusCode || 502;
    const contentType = String(incoming.headers["content-type"] || "");
    if (status !== 200 || !/^image\/(avif|gif|jpeg|png|webp)(?:;|$)/i.test(contentType)) {
      // Never redirect the browser back to an external image host or render
      // a CMS login page as a successful image. Do not relay upstream cookies.
      fail(status >= 400 && status <= 599 ? status : 502,
        status === 200 ? "CMS asset upstream did not return an image" :
          `CMS asset upstream returned HTTP ${status}; check the restricted image route`);
      incoming.destroy();
      return;
    }
    const headers = {
      "content-type": contentType,
      "cache-control": "no-store",
      "x-content-type-options": "nosniff"
    };
    if (incoming.headers["content-length"]) headers["content-length"] = incoming.headers["content-length"];
    response.writeHead(200, headers);
    incoming.on("error", () => fail(502, "CMS asset response interrupted"));
    incoming.pipe(response);
  });
  const deadline = setTimeout(() => {
    fail(504, "CMS asset upstream timed out");
    upstream.destroy();
  }, cmsAssetsTimeout);
  upstream.on("error", () => fail(502, "Cannot reach CMS asset upstream"));
  response.on("close", () => {
    clearTimeout(deadline);
    upstream.destroy();
  });
  upstream.end();
}

const server = http.createServer((request, response) => {
  const rawPath = (request.url || "/").split("?")[0];
  if (rawPath === "/mcdp_demo/cms-assets" || rawPath.startsWith(cmsAssetsPrefix)) {
    proxyCmsAsset(request, response, rawPath);
    return;
  }
  const requestURL = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);

  if (requestURL.pathname === "/healthz") {
    sendJSON(response, 200, { ok: true, localProxyRevision });
    return;
  }
  if (requestURL.pathname === "/" || requestURL.pathname === "/mcdp_demo") {
    response.writeHead(307, { location: "/mcdp_demo/" + requestURL.search });
    response.end();
    return;
  }
  if (requestURL.pathname.startsWith("/mcdp_demo/")) {
    serveStatic(request, response, requestURL.pathname);
    return;
  }
  if (requestURL.pathname === "/mpaas-proxy" || requestURL.pathname.startsWith("/mpaas-proxy/")) {
    proxyRequest(request, response, requestURL);
    return;
  }

  sendJSON(response, 404, { success: false, message: "Route not found" });
});

server.listen(port, host, () => {
  console.log(`MCDP demo: http://localhost:${server.address().port}/mcdp_demo/bco.html`);
  console.log(`ACS proxy: ${proxyTarget.toString()}`);
  console.log(`CMS images: ${cmsAssetsTarget.toString()} (${localProxyRevision})`);
});
