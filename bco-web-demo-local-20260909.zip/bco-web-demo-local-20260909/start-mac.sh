#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required. Install Node.js, then run this script again." >&2
  exit 1
fi
export HOST="${HOST:-127.0.0.1}"
export PORT="${PORT:-5179}"
export MPAAS_PROXY_URL="${MPAAS_PROXY_URL:-http://10.23.34.52:443/mpaas-proxy}"
exec node server.mjs
