@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install Node.js, then run this script again.
  pause
  exit /b 1
)
if not defined HOST set "HOST=127.0.0.1"
if not defined PORT set "PORT=5179"
if not defined MPAAS_PROXY_URL set "MPAAS_PROXY_URL=http://10.23.34.52:443/mpaas-proxy"
node server.mjs
if errorlevel 1 pause
