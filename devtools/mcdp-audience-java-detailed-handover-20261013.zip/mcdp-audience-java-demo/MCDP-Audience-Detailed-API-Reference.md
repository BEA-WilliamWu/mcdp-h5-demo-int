# MCDP Audience Synchronization

Detailed API Reference for External Systems

Version 0.4.0 | 13 October 2026 | Companion Java demo 0.3.0

## 1 Purpose and interface status

This reference describes how an external system can prepare and submit user or device audiences to MCDP, maintain the source audience mapping, and verify the resulting membership. The companion Java client implements six operations over five MCDP Actions. CMS and IMK are not runtime dependencies of this demo.

**Integration status:** the Action names and business fields are observed in the MCDP console. The direct AccessKey RPC binding is an integration candidate. Confirm its endpoint, authorization, parameter names and response contract with the mPaaS owner before production use. No live MCDP audience request has been sent by this demo validation.

| Operation | MCDP Action | Purpose |
| --- | --- | --- |
| create | `CreateMcdpCrowd` | Create an audience with initial members |
| update | `CreateMcdpCrowd` | Submit changes to an existing audience |
| list | `ListMcdpCrowd` | Find audiences within one destination scope |
| detail | `QueryMcdpCrowdgetbybizid` | Read one audience by its business ID |
| members | `QueryMcdpCrowdgetmoreentity` | Read one page of audience members |
| delete-member | `DeleteMcdpCrowddeleteentity` | Remove one member from an audience |

### How to use this reference

Sections 2–5 define the destination, authentication and data conventions. Sections 6–11 specify each operation. Sections 12–14 cover responses and synchronization recovery. Sections 15–18 describe Java integration, execution, acceptance tests and source references.

**Evidence labels used throughout:** “Console observed” means a console Action or form behavior; “Demo rule” means behavior enforced locally by the supplied Java implementation; “Candidate binding” means the proposed direct server request; “Confirm in UAT” means a service contract decision still required from the mPaaS owner.

Audience synchronization does not publish a Banner, attach an audience to an activity, or switch an activity online. Those are separate activity operations. BCO activity unit 181 and BCM activity unit 182 are not audience `bizId` values.

<!-- PAGEBREAK -->
## 2 Destination and configuration

Select `BCO` or `BCM` explicitly for every operation. A destination consists of the channel, endpoint, tenant, application and workspace. Store separate mappings for UAT and production, even when the source audience ID is identical.

| Configuration field | Type and requirement | Meaning |
| --- | --- | --- |
| `endpoint` | Required string | Owner supplied HTTPS RPC root; not the console URL |
| `appId` | Required string | Destination mPaaS application ID |
| `workspaceId` | Required string | Destination workspace; `UAT` is an example |
| `tenantId` | Required string | Tenant containing the destination application |
| `regionId` | Required string | Region; `cn-hongkong` is the example configuration |
| `apiVersion` | Required string | Version accepted by the destination; example `2020-10-28` |
| `timeoutMs` | Integer at config root | Default 15000; demo range 1000–120000 ms |

The following is a configuration fragment for BCO. The package contains a complete two-channel `config.example.json`. All `YOUR_` and `REPLACE_WITH_` values must be replaced before execution.

```json
{
  "timeoutMs": 15000,
  "channels": {
    "BCO": {
      "endpoint": "https://YOUR_BCO_MPAAS_RPC_ENDPOINT/",
      "appId": "YOUR_BCO_APP_ID",
      "workspaceId": "UAT",
      "tenantId": "YOUR_BCO_TENANT_ID",
      "regionId": "cn-hongkong",
      "apiVersion": "2020-10-28"
    }
  }
}
```

The demo accepts only an HTTPS root endpoint without query, fragment or embedded credentials. It rejects console hosts and placeholder values during live execution. Dry run permits placeholders so developers can inspect request construction offline.

The mPaaS owner must provide an AccessKey or STS role authorized for the specified tenant, application, workspace and crowd operations. An exact RAM policy and public or private network route are environment decisions; neither is encoded by this demo.

<!-- PAGEBREAK -->
## 3 Common request contract

**Candidate binding:** all six Java operations use `POST /` over HTTPS, including reads. The body is UTF-8 form data. Business JSON is carried inside a named form field for writes; it is not sent as the raw HTTP body. Parameter names are case sensitive.

```http
POST / HTTP/1.1
Host: YOUR_MPAAS_RPC_HOST
Content-Type: application/x-www-form-urlencoded; charset=UTF-8

<percent-encoded common and operation parameters>
```

| Parameter | Required | Value supplied by the Java client |
| --- | --- | --- |
| `Action` | Yes | Exact Action for the selected operation |
| `Version` | Yes | Configured `apiVersion` |
| `RegionId` | Yes | Configured `regionId` |
| `Format` | Yes in demo | `JSON` |
| `AppId` | Yes in demo | Configured application ID |
| `WorkspaceId` | Yes in demo | Configured workspace ID |
| `TenantId` | Yes in demo | Configured tenant ID |
| `AccessKeyId` | Yes | Credential identifier |
| `SecurityToken` | STS only | Temporary session token; omitted when blank |
| `SignatureMethod` | Yes | `HMAC-SHA1` |
| `SignatureVersion` | Yes | `1.0` |
| `Timestamp` | Yes | UTC time to seconds, such as `2026-10-13T01:00:00Z` |
| `SignatureNonce` | Yes | A fresh UUID for each attempted request |
| `Signature` | Yes | Base64 HMAC computed as specified in Section 4 |

The AccessKey secret is used locally for signing and is never a request parameter. With STS, use a matching key ID, secret and security token from the same session. Include the token in the signed parameter set.

Write payloads also contain lower camel case `appId`, `workspaceId` and `tenantId`, inserted from configuration. Callers must not put scope fields in the operation payload: `buildRequest` rejects unsupported keys. The outer business field names in Sections 6–11 require direct RPC confirmation.

<!-- PAGEBREAK -->
## 4 Authentication and signature calculation

The Java implementation follows the Alibaba Cloud RPC V2 HMAC-SHA1 convention used by the existing compatibility approach. The official RPC page marks V2 as discontinued and recommends V3. Confirm which protocol the MCDP endpoint accepts before adopting this transport; the supplied demo does not implement V3.

### Calculation performed by the demo

1. Collect all common, scope and operation parameters as string values. Exclude `Signature` itself. Include `SecurityToken` when present.
2. Sort the parameter names in ascending order. Percent encode each key and value using UTF-8 and RFC 3986 conventions, then join `key=value` pairs with `&`.
3. Build `StringToSign = "POST&%2F&" + percentEncode(canonicalForm)`.
4. Compute HMAC-SHA1 of the UTF-8 string to sign with the UTF-8 key `AccessKeySecret + "&"`.
5. Base64 encode the raw HMAC bytes. Add this value as `Signature`, then form encode the complete parameter map for the HTTP body.

| Input | Percent encoded result |
| --- | --- |
| Space | `%20`, not `+` |
| Literal plus | `%2B` |
| Asterisk | `%2A` |
| Slash | `%2F` |
| Letters, digits, `-_.~` | Unchanged |
| Other characters | UTF-8 bytes encoded with uppercase hexadecimal |

```java
var signed = McdpClient.signedParameters(
    request, credentials,
    java.time.Instant.now(),
    java.util.UUID.randomUUID().toString());
String formBody = McdpClient.formEncode(signed);
```

Serialize the business JSON once and sign exactly the string that will be sent. Changing whitespace, member order or JSON serialization after signing changes the signature. Do not manually encode the JSON before passing it to `buildRequest`; the client applies the required encoding layers.

Keep the system clock synchronized. A fresh nonce prevents replay of the same signed request; it is **not** an audience creation idempotency key. Regenerating a signature after a timeout can still duplicate a business operation.

Reference: [Alibaba Cloud RPC request and signature convention](https://www.alibabacloud.com/help/en/sdk/product-overview/rpc-mechanism). This reference supports the signing convention, not the MCDP crowd endpoint or business contract.

<!-- PAGEBREAK -->
## 5 Audience identifiers and member data

| Field | Meaning and handling |
| --- | --- |
| `bizId` | MCDP audience business ID. Empty only when creating; use the returned or verified ID for later operations. |
| `id` | MCDP internal audience record ID used by console editing. Preserve it as a string; it is distinct from `bizId`. |
| `name` | Audience display name. Demo accepts a nonblank string of at most 30 Java UTF-16 code units. Name uniqueness is not guaranteed. |
| `type` | Integer `0` for user IDs or `2` for device IDs. These are console observed values. |
| `entities` | Comma separated member IDs in the write JSON. The local demo also accepts newline separated text before normalization. |
| `entity` | A single member ID for deletion; an optional console query field for member retrieval. |
| `lastEntityId` | Opaque member pagination cursor. The console uses the last row's `key`; do not assume it equals the displayed member ID. |

### Normalization and local limits

Keep all IDs as strings, including numeric-looking values such as `"000001"`. The target ID namespace must match the identity used by the consuming MCDP targeting client. A source CRM number is not automatically an MCDP user ID.

For `entities`, the demo removes an initial UTF-8 BOM, splits on commas and CR/LF, trims each token, removes blank tokens and deduplicates while retaining first-seen order. Each resulting ID must be shorter than 100 Java UTF-16 code units and contain no remaining ASCII control characters. The resulting list must be nonempty.

**Demo limits:** at most 1000 unique IDs per request and 256 KiB of UTF-8 entities input. These are client limits, not published MCDP service quotas. There is no automatic batch splitting because update merge behavior has not been established.

```text
Input:  "000001,000002\n000001\n 000003 "
Output: "000001,000002,000003"
```

The `SourceAdapter` accepts a `memberIds` array but requires each element to be an already clean, nonempty string without comma, control characters or surrounding whitespace. It converts the array to the API representation. The low-level API payload itself does not accept a JSON array for `entities`.

The console has a large TXT upload workflow with a 50 MB UI limit. The Java `--entities-file` option only reads a local file and sends inline IDs; it does not implement that upload endpoint. Obtain the bulk import contract separately for larger audiences.

<!-- PAGEBREAK -->
## 6 Create an audience

**Action:** `CreateMcdpCrowd` · **Java operation:** `create` · **Effect:** write

Console observed route: `POST /webapi/mappcenter/mcdp/crowd/createCrowd`. The direct RPC candidate sends business JSON in the following exact outer field:

```text
MpaasMappcenterMcdpCrowdCreateJsonStr
```

| Payload field | Type and requirement | Demo behavior |
| --- | --- | --- |
| `name` | Required string | Nonblank; maximum 30 UTF-16 code units |
| `type` | Required integer | `0` user ID or `2` device ID |
| `entities` | Required string | Nonempty after normalization; Section 5 limits apply |
| `bizId` | Optional empty string | Omitted value becomes `""`; nonempty value rejected |
| `id` | Not allowed | A new audience must not carry an existing record ID |

Illustrative operation payload. The package also contains a create payload in `examples/create.json` with different test names and IDs:

```json
{
  "name": "Partner UAT Audience",
  "type": 0,
  "entities": "000001,000002,000003"
}
```

Decoded value of the candidate outer JSON field after scope injection:

```json
{
  "name": "Partner UAT Audience",
  "type": 0,
  "entities": "000001,000002,000003",
  "bizId": "",
  "appId": "YOUR_BCO_APP_ID",
  "workspaceId": "UAT",
  "tenantId": "YOUR_BCO_TENANT_ID"
}
```

Use `McdpClient.buildRequest(scope, "create", payload)`. A successful transport response only acknowledges the request. Resolve and persist the actual `bizId` and internal `id`, then query detail and members before marking synchronization complete. Their exact response paths must be confirmed in UAT.

Creation deduplication is not established. If the response is lost, reconcile through list, detail and membership queries before repeating the write. Audience name alone is not a reliable unique key.

<!-- PAGEBREAK -->
## 7 Update an audience

**Action:** `CreateMcdpCrowd` · **Java operation:** `update` · **Effect:** write

Update uses the same console route and candidate JSON field as creation. Supplying the existing `bizId` selects the update path in the observed UI behavior.

| Payload field | Type and requirement | Demo behavior |
| --- | --- | --- |
| `bizId` | Required string | Existing nonblank audience business ID |
| `id` | String when provided | Optional in low-level client; required in saved SourceAdapter binding |
| `name` | Required string | Full display name, even when only members change |
| `type` | Required integer | `0` or `2`; SourceAdapter rejects type changes |
| `entities` | Required string | Nonempty normalized member list |

```json
{
  "bizId": "REPLACE_WITH_CROWD_BIZ_ID",
  "id": "REPLACE_WITH_DETAIL_ID",
  "name": "Partner UAT Audience",
  "type": 0,
  "entities": "000002,000003"
}
```

`buildRequest(scope, "update", payload)` wraps this JSON in `MpaasMappcenterMcdpCrowdCreateJsonStr` and injects the lower camel case scope fields. The outer request also carries the common scope and signature parameters from Section 3.

### Membership semantics must be established

The supplied client does not assert that update replaces, appends or merges membership. To determine the behavior in UAT, create an isolated audience containing A and B, update it with B and C, then read all resulting members. B/C indicates replacement; A/B/C indicates addition or merge. Also confirm how repeated updates and renamed audiences behave.

Do not divide a large snapshot into repeated updates until the service's merge behavior and limits are confirmed. Under replacement semantics, sending a second chunk could remove the first chunk.

Empty `entities` is rejected locally and is not a supported clear-all operation. There is no whole-audience deletion operation in this package. Confirm the appropriate MCDP operation before implementing either behavior.

After an acknowledged update, query detail and all members to compare with the intended state. Serialize writes for each source audience and destination; the demo contains no server version check or concurrency lock.

<!-- PAGEBREAK -->
## 8 List audiences

**Action:** `ListMcdpCrowd` · **Java operation:** `list` · **Effect:** read

Console observed route: `GET /webapi/mappcenter/mcdp/crowd/getCrowdList`. The Java direct RPC candidate uses HTTPS POST and ordinary form parameters, with no JSON wrapper field.

| Local payload field | Candidate RPC field | Type and requirement |
| --- | --- | --- |
| `pageNo` | `PageNo` | Positive integer; default 1 |
| `pageSize` | `PageSize` | Positive integer; default 20 |
| `name` | `Name` | Optional audience name filter; use a string |

```json
{
  "pageNo": 1,
  "pageSize": 20,
  "name": "Partner UAT Audience"
}
```

Decoded operation-specific form parameters:

```text
Action=ListMcdpCrowd
PageNo=1
PageSize=20
Name=Partner UAT Audience
```

The signed body additionally includes the common scope fields and authentication parameters from Section 3. Do not put `pageNo` or `pageSize` inside a create-style JSON wrapper. Local input uses lower camel case; the candidate form fields use an initial capital letter.

`buildRequest(scope, "list", Map.of())` supplies page 1 and size 20. The local client requires integer values within signed 32-bit range and rejects zero, negatives and fractional numbers. It does not enforce a service page size ceiling. Optional query fields currently accept scalar strings or numbers; the recommended contract for `name` is a string.

### Reading and reconciliation

Capture a real UAT response to establish the row collection path, total count, page numbering and end condition. Do not assume a field named `records`, `items` or `total` without confirmation. The Java client returns generic data and does not automatically iterate pages.

Name matching may be exact, prefix or partial; confirm it before using results for recovery. If more than one audience matches, use detail and membership evidence to identify the intended record rather than selecting the first row. Preserve `bizId` and `id` as strings when creating the local mapping.

An HTTP 200 response by itself does not prove that the audience list was returned successfully. Apply the response rules in Section 12 and verify the agreed business schema.

<!-- PAGEBREAK -->
## 9 Read audience details

**Action:** `QueryMcdpCrowdgetbybizid` · **Java operation:** `detail` · **Effect:** read

Console observed route: `GET /webapi/mappcenter/mcdp/crowd/getByBizId`. The candidate direct request sends `BizId` as an ordinary form parameter.

| Local payload field | Candidate RPC field | Type and requirement |
| --- | --- | --- |
| `bizId` | `BizId` | Required nonblank string for the audience in the selected destination |

```json
{
  "bizId": "REPLACE_WITH_CROWD_BIZ_ID"
}
```

```text
Action=QueryMcdpCrowdgetbybizid
BizId=REPLACE_WITH_CROWD_BIZ_ID
```

Add the scope and authentication parameters from Section 3. The operation payload accepts only `bizId`; do not pass `id`, source-system audience IDs or activity unit IDs instead.

### Intended use

1. Resolve the record after creation or after a potentially ambiguous write.
2. Read metadata before preparing an update, including the internal `id` used by the console edit form.
3. Check the audience type and display name against the stored source mapping.
4. Query members separately to verify the actual audience content.

The following fields are required by the receiving system's mapping logic. They are a **mapping checklist**, not a declared MCDP response schema:

| Mapping value | Required handling |
| --- | --- |
| Audience business ID | Persist as string; identify the exact response path in UAT |
| Internal record ID | Persist as string for subsequent SourceAdapter updates |
| Audience type | Verify user versus device identity before writing |
| Audience name | Compare with the intended display name |
| Destination scope | Use the authenticated request scope as part of the mapping key |

Confirm the not-found and inaccessible-audience response separately. A null payload, empty object or business error must not automatically trigger creation: it may indicate a wrong workspace or a permission problem. The demo does not implement an automatic “query or create” operation.

<!-- PAGEBREAK -->
## 10 Read audience members

**Action:** `QueryMcdpCrowdgetmoreentity` · **Java operation:** `members` · **Effect:** read

Console observed route: `GET /webapi/mappcenter/mcdp/crowd/getMoreEntity`. The candidate RPC maps local fields to ordinary form parameters.

| Local field | Candidate RPC field | Type and requirement |
| --- | --- | --- |
| `bizId` | `BizId` | Required nonblank audience business ID |
| `lastEntityId` | `LastEntityId` | Optional string cursor; omit for the initial query pending UAT confirmation |
| `entity` | `Entity` | Optional member query value; filtering semantics require confirmation |

Initial query:

```json
{"bizId":"REPLACE_WITH_CROWD_BIZ_ID"}
```

Subsequent query using the opaque key from the prior page:

```json
{
  "bizId": "REPLACE_WITH_CROWD_BIZ_ID",
  "lastEntityId": "REPLACE_WITH_LAST_ROW_KEY"
}
```

The console uses the last returned row's `key` for continuation. Preserve that value as a string; do not calculate it from the displayed entity. There is no `pageSize` input for this operation in the current demo; unknown fields are rejected.

### Pagination implementation guidance

Make one request per page. After validating the response schema, collect its members and extract the continuation key. Stop only according to the service's confirmed end condition. Treat a repeated cursor, repeated page without advancement, malformed row or failed request as an incomplete scan. Use a configured page cap to prevent an infinite loop.

The full response collection path, page size, ordering, cursor expiry and end-of-list marker require UAT confirmation. The demo does not guess these values or automatically traverse pages.

Do not change membership while scanning if a consistent comparison is required. Stable snapshot semantics are not established. Maintain a deduplicated set for comparison and record whether every page was read successfully. A partial scan must not be used as the basis for deleting “missing” members.

The optional `entity` field may help look up one member once its matching behavior is confirmed. Do not assume that a negative filtered result is authoritative until exact matching and indexing delay have been established.

<!-- PAGEBREAK -->
## 11 Delete one audience member

**Action:** `DeleteMcdpCrowddeleteentity` · **Java operation:** `delete-member` · **Effect:** write

Console observed route: `POST /webapi/mappcenter/mcdp/crowd/deleteEntity`. The candidate direct RPC carries business JSON in the following exact outer field:

```text
MpaasMappcenterMcdpCrowddeleteentityDeleteJsonStr
```

| Payload field | Type and requirement | Demo behavior |
| --- | --- | --- |
| `bizId` | Required string | Nonblank audience business ID |
| `entity` | Required string | Exactly one unpadded member ID; comma lists are rejected |

```json
{
  "bizId": "REPLACE_WITH_CROWD_BIZ_ID",
  "entity": "000001"
}
```

Decoded candidate JSON wrapper value:

```json
{
  "bizId": "REPLACE_WITH_CROWD_BIZ_ID",
  "entity": "000001",
  "appId": "YOUR_BCO_APP_ID",
  "workspaceId": "UAT",
  "tenantId": "YOUR_BCO_TENANT_ID"
}
```

The signed form also includes the common scope fields and Action. The method removes one member from an audience; it does not delete the audience record, remove the source customer or disable an MCDP activity.

### Verification and repeat behavior

Read back membership after acknowledgment. The repeated-delete and nonexistent-member response contracts are not established. Do not interpret every error as “already absent”, and do not automatically retry an ambiguous delete without checking remote state.

Before using this operation for synchronization differences, obtain a complete and consistent remote membership set, establish which source system owns the audience, and serialize writes for the same audience. The supplied client deliberately has no bulk deletion loop or automatic remove-all behavior.

For device audiences, pass the device identifier exactly as stored. User and device IDs must not be mixed within one audience.

<!-- PAGEBREAK -->
## 12 Response handling

The Java demo exposes a normalized `McdpClient.Result`. It retains the original response for reconciliation and applies a conservative compatibility classifier. This local result type is not the official MCDP response schema.

| Java result accessor | Type | Meaning |
| --- | --- | --- |
| `outcome()` | String | `acknowledged`, `error` or `unknown` |
| `httpStatus()` | Integer or null | HTTP status when a complete response was received |
| `requestId()` | Object or null | Top-level `RequestId` or `requestId` |
| `data()` | Object or null | Decoded generic content; inspect only against the confirmed schema |
| `raw()` | String or null | Original body; may contain audience member data |
| `reason()` | String or null | Local explanation for incomplete transport |

The classifier unwraps JSON strings up to four times and checks the top level and `ResultContent` or `resultContent`. `ResultCode=OK`, `Code` equal to `0`, `200` or `OK`, and `Success=true` are recognized acknowledgments, including the supported lower camel case variants. Any recognized failure or non-2xx HTTP status takes precedence. A 2xx response without a recognized marker remains `unknown`.

Data is taken from nested `Data` or `data`, then from the decoded content itself, or from top-level data when content is absent. No audience ID or pagination schema is inferred from this value.

### Illustrative local response fixtures

These examples test the classifier only. They are not captured MCDP crowd responses and do not define service error codes.

```json
{"ResultCode":"OK","RequestId":"demo-request-001",
 "ResultContent":"{\"success\":true,\"data\":{}}"}
```

With HTTP 200, this fixture produces `acknowledged`. Empty data still does not prove that an audience was created or populated.

```json
{"ResultCode":"OK","ResultContent":{"success":false}}
```

With HTTP 200, this fixture produces `error`, because a nested failure overrides the outer acknowledgment. HTTP 200 with `{}` produces `unknown`. Validate actual UAT envelopes before integrating schema-specific response extraction.

<!-- PAGEBREAK -->
## 13 Errors and recovery

| Observation | Interpretation | Required handling |
| --- | --- | --- |
| Local payload or config validation fails | Request construction was rejected | Correct the input; confirm the journal and exception stage before deciding that nothing was sent |
| HTTP non-2xx | HTTP failure; body may include business details | Retain status, raw body and request ID; classify the cause before retry |
| HTTP 2xx with a failure marker | Business operation reported failure | Read the returned code and message; do not treat it as success |
| HTTP 2xx without a known success marker | Result is not understood | Preserve raw body and reconcile; update the parser only against a confirmed contract |
| Timeout, interruption, connection loss or oversized response | Complete result unavailable | Treat a write as potentially committed; query remote state first |
| Acknowledgment but membership differs | Synchronization is not verified | Check scope, ID type, update semantics and indexing completion |

No official crowd error-code catalog is embedded in this demo. The owner should supply codes for authorization, signature, invalid parameters, missing audience, quota and temporary service failures. Retain real codes rather than mapping unknown values to invented names.

### Retry policy

The client contains no application retry loop. Its JDK transport requires connection retry to be disabled and all-method retry to remain disabled. HTTP redirects are not followed. A caller must not wrap writes in a generic automatic retry policy.

For an ambiguous create, find and verify the possible newly created audience before trying again. For an ambiguous update or delete, query the existing audience and compare membership. If the state cannot be determined, retain a pending reconciliation record rather than claiming success or generating a new audience.

Reads may be retried by the integrating system using an agreed bounded delay and service limits. Persist pagination progress, but do not assume a saved cursor remains valid indefinitely. Retrying a read does not resolve an inconsistent or changing membership snapshot.

### Operational limits

The default request timeout is 15 seconds. The transport limits response buffering to 4 MiB; an oversized response becomes `unknown`. These are demo settings, not service availability guarantees. Keep audit records protected because original responses can contain member IDs. Avoid logging AccessKey secrets, STS tokens, signed form bodies or complete member lists to general application logs.

<!-- PAGEBREAK -->
## 14 Synchronization workflow and mapping

Maintain one durable mapping for each source audience and destination. A recommended uniqueness key is the source system, source audience ID, channel, endpoint, tenant, application and workspace. The same source audience may have independent BCO UAT, BCM UAT and production records.

```json
{
  "sourceSystem": "PARTNER_SYSTEM",
  "sourceAudienceId": "SEGMENT_001",
  "channel": "BCO",
  "endpoint": "https://YOUR_BCO_MPAAS_RPC_ENDPOINT/",
  "tenantId": "YOUR_BCO_TENANT_ID",
  "appId": "YOUR_BCO_APP_ID",
  "workspaceId": "UAT",
  "bizId": "REPLACE_WITH_CROWD_BIZ_ID",
  "id": "REPLACE_WITH_DETAIL_ID",
  "type": 0
}
```

This mapping is local integration data, not an MCDP API request or response. Store actual IDs obtained through verified MCDP results. The example placeholders cannot be executed.

1. Validate the source snapshot, agreed ID namespace and selected destination. Deduplicate members and record a source revision or content hash.
2. Acquire an application lock for this mapping. If no binding exists, prepare a create; otherwise verify its destination and type before preparing an update.
3. Persist a durable operation intent before sending. Include operation ID, source revision, target scope and an appropriate protected payload reference.
4. Send once. Persist the complete result and request ID before advancing the source checkpoint. An incomplete result enters reconciliation.
5. Query detail and members. Mark the revision verified only after the target scope, metadata and complete membership satisfy the agreed update semantics.
6. Release the lock. Schedule a later source revision only after the earlier write is resolved or deliberately superseded through a defined process.

Suggested local states are prepared, sent with unknown result, acknowledged, membership verified and reconciliation required. These are integration states, not MCDP fields.

`SourceAdapter.prepare(scope, snapshot, null)` creates a request. Passing a stored binding prepares an update and checks source identity, destination and type. It does not save mappings, discover IDs, call the network, implement a scheduler or compare remote membership. The integrating application owns those steps.

<!-- PAGEBREAK -->
## 15 Java integration

The package is a custom Java HTTP client, not an official MCDP SDK. It requires Java 17 or later and has no third-party runtime libraries. The supplied JAR uses Java 17 bytecode; builds and offline tests were run on OpenJDK 21. A Java 17 runtime execution test is still a target-environment check.

| Java entry point | Responsibility |
| --- | --- |
| `selectChannel(config, channel)` | Validate and select BCO or BCM destination configuration |
| `buildRequest(scope, operation, payload)` | Validate input and construct candidate RPC parameters |
| `preview(request)` | Return redacted request metadata without sending anything |
| `execute(request, credentials, transport)` | Validate endpoint, sign, send once and classify the response |
| `SourceAdapter.prepare(scope, snapshot, binding)` | Convert a source audience snapshot to create or update |
| `classifyResponse(status, raw)` | Normalize a complete HTTP response for local handling |

### Minimal library usage

The following assumes `config` is an already parsed configuration map. Construct it from protected application configuration; the demo's JSON utility can parse UTF-8 JSON.

```java
import demo.mcdp.McdpClient;
import java.util.Map;

var scope = McdpClient.selectChannel(config, "BCO");
var payload = Map.<String, Object>of(
    "name", "Partner UAT Audience",
    "type", 0,
    "entities", "000001,000002,000003");
var request = McdpClient.buildRequest(scope, "create", payload);
System.out.println(McdpClient.preview(request));
// Persist a durable operation intent before an actual send.
var credentials = McdpClient.Credentials.fromEnvironment(
    System.getenv());
var result = McdpClient.execute(
    request, credentials, McdpClient.jdkTransport());
// Persist result, reconcile unknown, and verify remote members.
```

Start the JVM with both properties before initializing any HTTP client:

```text
-Djdk.httpclient.disableRetryConnect=true
-Djdk.httpclient.enableAllMethodRetry=false
```

`run.sh` sets these flags. The library does not automatically journal calls: the embedding system must provide durable intent and result storage. Use `bash run.sh library-demo` for a complete executable source-adapter example with no network activity.

<!-- PAGEBREAK -->
## 16 Command line execution and audit

Run commands from the Java demo directory. The package includes a JAR; rebuilding and tests require a JDK. Set `JAVA_HOME` when needed. Rebuild after changing Java sources.

```bash
bash build.sh
bash test.sh
bash run.sh create --channel BCO \
  --config config.example.json --payload examples/create.json
```

The final command is an offline preview. For a confirmed UAT connection, copy `config.example.json` to `config.local.json`, replace all placeholders, prepare the appropriate payload, and use the hidden-input credential helper:

```bash
bash run-with-credentials.sh list --channel BCO \
  --config config.local.json --payload examples/list.json \
  --execute --response-out ./uat-list-001.jsonl
```

| Option | Behavior |
| --- | --- |
| `--channel` | Required explicit `BCO` or `BCM` |
| `--payload` | Required UTF-8 JSON operation payload file |
| `--config` | Optional path; defaults to `config.local.json` |
| `--entities-file` | Create/update only; reads local TXT into inline entities |
| `--execute` | Enables a network request; omitted means preview |
| `--response-out` | Required with execute; new JSONL file on a POSIX filesystem |

Credentials may also be supplied through `ALIBABA_CLOUD_ACCESS_KEY_ID`, `ALIBABA_CLOUD_ACCESS_KEY_SECRET` and optional `ALIBABA_CLOUD_SECURITY_TOKEN`. Do not place them in payload or configuration files distributed to other teams.

Before sending, the CLI exclusively creates the journal with mode 0600 and flushes a `request_may_be_sent` record. It then appends `response_observed`, including the original response. An intent-only file means the outcome requires reconciliation. Never reuse an existing response filename or infer that an interrupted process made no change.

Exit codes are 0 for preview or acknowledgment, 1 for local validation, file or runtime errors, 2 for classified HTTP/business error, and 3 for unknown outcome. Exit 1 may occur after sending if response persistence fails. Exit 0 does not certify membership. Configuration, payload and entities input files are each limited to 256 KiB by the CLI.

<!-- PAGEBREAK -->
## 17 Acceptance tests and contract confirmation

Use isolated UAT audiences and agreed test identities. Run the read-only scope check first. Keep evidence from each operation, including destination, timestamp, HTTP status, request ID, sanitized request shape and verified business result.

| Test | Required observation |
| --- | --- |
| Destination and authentication | Each BCO/BCM configuration accesses only its intended tenant, application and workspace |
| Create | One audience appears with a usable string bizId, internal id, expected name and type |
| Detail | Metadata is returned at confirmed paths; a missing record is distinguishable from authorization failure |
| Member read | Every page is readable; cursor progression and final-page condition are established |
| Update | A/B updated with B/C proves replacement or addition behavior; repeat behavior is recorded |
| Delete member | One member is removed; another remains; missing-member and repeat-delete outcomes are captured |
| Identity | A sample user or device can be matched by the downstream targeting client |
| Error handling | Invalid scope, bad signature, expired token and invalid payload produce understood responses |
| Lost response recovery | A controlled ambiguous write is reconciled without a duplicate audience or unverified checkpoint |
| Limits | Owner confirms payload size, member count, pagination size, rate limits and import completion timing |

### Owner supplied contract items

Confirm the root RPC endpoint and routing for each environment; API version and signing protocol; Action availability for external AccessKey callers; exact JSON wrapper and query field names; RAM or role authorization; response schema and business success/error codes; whether update requires internal `id`; update merge behavior; import consistency and polling expectations; cursor format and termination; write idempotency and concurrency behavior; and the supported bulk import mechanism.

Record these decisions in a versioned integration contract before removing any candidate labels from this reference. If the supported server API differs from the console mapping, change the client adapter and its tests to that owner-provided contract.

### Validation already completed

The companion demo builds Java 17 bytecode and passed 16 offline tests on OpenJDK 21. Tests cover request construction, validation, signing and local response behavior. Offline previews exercise all six operations for both channels and the source adapter. They do not verify live MCDP authentication, remote response fields, data import or targeting effectiveness.

<!-- PAGEBREAK -->
## 18 Sources and implementation index

### Official protocol references

[Alibaba Cloud RPC request syntax and signature method V2](https://www.alibabacloud.com/help/en/sdk/product-overview/rpc-mechanism) describes the common signing convention and its current lifecycle status. It does not specify the crowd Actions or their business parameters.

[Oracle Java HTTP client module documentation](https://docs.oracle.com/en/java/javase/20/docs/api/java.net.http/module-summary.html) describes HTTP client properties, including connection and method retry controls. Validate the selected Java vendor and version in the deployment environment.

### Console evidence

The MCDP audience list and edit UI exposes the five Action names, console routes, user/device type values, audience form fields and member continuation behavior used in this reference. Relevant resources are the [mPaaS console](https://mpaas.console.alibabacloud.com/), [mPaaS application configuration](https://mappcenter.mpaas.cn-hongkong.aliyuncs.com/aliyunPublic), and the [observed MCDP UI bundle](https://edge.zkobjects.com/page/mpaas-mcdp/mcdp/mcdp-6b0717a3.js). Console resources may require authentication or change between releases.

The console proxy at `/data/api.json` and routes under `/webapi/mappcenter/mcdp/crowd/` identify browser behavior. They are not endorsed server integration URLs. A service integration must use its own credentials and the confirmed server endpoint.

### Companion package index

| File | Purpose |
| --- | --- |
| `McdpClient.java` | Scope, operation payloads, signing, HTTP transport and response classification |
| `SourceAdapter.java` | Source snapshot and destination binding validation |
| `Demo.java` | Command line parsing, input files and execution journal |
| `LibraryDemo.java` | Executable offline example for embedding the adapter |
| `Json.java` | JSON parser and writer used by the dependency-free client |
| `DemoTests.java` | Offline assertions for the supplied implementation |
| `config.example.json` | Separate destination configuration for BCO and BCM |
| `examples/` | Six operation payloads, source snapshot, binding and member TXT |
| `README.md` | Original Java quick start and integration guide |
| `SHA256SUMS` | Integrity checks for distributed package files |

Main Java source files reside under `src/main/java/demo/mcdp/`; tests are under `src/test/java/demo/mcdp/`. This reference documents the existing Java demo 0.3.0. Document version 0.4.0 adds the detailed per-operation contract and integration guidance without changing Java runtime behavior.
