# MCDP audience synchronization API and Java demo

This handover package is for an external system that owns audience membership
and needs to synchronize those audiences directly to MCDP. It contains an
English API reference, an independent Java client, command-line examples and
a source-system adapter example. The receiving system does not need CMS, IMK,
an IMK database or an ACS deployment to run the demo.

The Hong Kong BCM-UAT console explicitly maps audience creation and update to
`CreateMcdpCrowd`. The companion client implements six commands covering five
Actions, including queries and deletion of an individual member.

**Status as of 13 October 2026:** Action names, console paths and the business
fields described below were observed in Chrome. Direct AccessKey invocation,
the crowd-specific server RPC parameter schema, service quotas and update
semantics have not been verified against MCDP. The runnable client is an
integration candidate, not a production-certified audience synchronizer.

The demo uses Java 17 or later and only JDK standard libraries, with Bash
launchers for macOS and Linux. It needs no Maven dependencies, Node.js or Python.
This is custom HTTP client code, not an official MCDP SDK. No live crowd request
was sent during package preparation. Java 17 bytecode was compiled and tested
on OpenJDK 21; execution on a Java 17 runtime was not tested here.

## Quick start

From this directory:

```bash
bash build.sh
bash test.sh
bash run.sh library-demo
bash run.sh create --channel BCO --config config.example.json \
  --payload examples/create.json
```

The last two commands preview plans without credentials or network access.
They show the scope, Action, parameter names and member count, with member values
redacted. `--execute` is required to send any request, including a read.

## Integration boundary and responsibilities

The intended connection is:

```text
External system audience store
  -> server-side sync job or service
  -> MCDP SaaS RPC endpoint
  -> audience scoped to AppId and WorkspaceId
```

BCO and BCM are target role profiles, selected explicitly for every operation.
The external system supplies audience names and member IDs, stores the returned
MCDP identity, and schedules synchronization. The mPaaS owner supplies the target
scope, endpoint, permissions and confirmed API contract. IMK is not an
intermediary in this design. The service credentials belong on the server;
browser cookies and the MCDP display SDK are not used by this package.

Before implementation, agree which identifiers the consuming application sends
to MCDP. A user audience must contain the same user identifier used for targeting;
do not assume that a source database customer number, account number or phone
number is that identifier. The transport preserves IDs as strings, including
leading zeros. Agree any identity conversion with the consuming application.

### Configuration to obtain from the mPaaS owner

| Setting | Required value or decision |
| --- | --- |
| Endpoint | Confirmed HTTPS RPC service root reachable from the external server. A VPC endpoint requires the corresponding private network route. |
| AppId | Target application for the selected BCO or BCM role. |
| WorkspaceId | Exact target environment value; obtain UAT and production values separately. |
| TenantId | Target tenant and any required tenant suffix for server calls. |
| RegionId and Version | Confirm crowd support; the example uses cn-hongkong and 2020-10-28. |
| Credentials and permissions | RAM AccessKey or STS credentials authorized for the five crowd Actions; obtain the precise policy from the service owner. |
| Contract | Confirm the candidate outer parameters, response schema and accepted signature transport below. |
| Population behavior | Confirm append versus replacement, processing delay, pagination, request limits and large-file import support. |

The archive contains placeholders and synthetic IDs only. Supply environment
configuration and credentials through the recipient's normal configuration and
secret-management process. Keep UAT and production in separate configuration
files and maintain separate audience mappings.

### Audience identity and synchronization order

1. Read the source audience and select its destination role and workspace.
2. Look up the local mapping using source system, source audience ID, role,
   endpoint, TenantId, AppId and WorkspaceId.
3. If no mapping exists, call `create`. Resolve and verify the returned audience
   `bizId` and internal `id` through the confirmed response and detail schema,
   then persist the mapping. Do not guess the ID from the audience name.
4. If a mapping exists, call `update` with that `bizId`, internal `id` and the
   original audience type. Never pass a source audience ID as the MCDP `bizId`.
5. Query details and all member pages after processing to verify the result.
   An acknowledged request alone does not prove population synchronization.
6. Record the source version or hash, request ID, outcome and last verified
   population. Serialize writes to the same destination audience.

`examples/binding.example.json` illustrates an application-owned mapping record;
it is not a MCDP request or a captured server response. The current demo refuses
an empty audience and does not implement a full synchronization scheduler,
automatic pagination, automatic retries, large-file upload or bulk replacement.
In particular, an empty source extract must not silently clear a live audience.

## Calling from a Java application

The source is under `src/main/java/demo/mcdp`. The package contains a runnable
JAR and its source. Rebuild with `bash build.sh` after making source changes;
`run.sh` otherwise uses the supplied JAR. A JDK 17+ is required for build and
tests; Java 17+ is sufficient to run the supplied JAR. No dependency download is
needed. `JAVA_HOME`, when set, selects the Java installation.

The main entry points are `McdpClient`, `SourceAdapter`, `Demo` and `LibraryDemo`.
`Json` is a small bundled JSON codec with duplicate-key rejection and exact
number parsing. Audience IDs must still be supplied as JSON strings. No Spring,
IMK database or official Alibaba Cloud SDK is required.

`SourceAdapter.prepare` converts a source-system array of member IDs into the
MCDP `entities` string. It checks the stored source and destination mapping and
prevents changing the type of an existing audience. `LibraryDemo` is a runnable
create/update preview using the synthetic example files:

```bash
bash run.sh library-demo
```

To integrate, add the client classes or JAR to the receiving Java application's
classpath. The application call sequence is:

```java
import demo.mcdp.Demo;
import demo.mcdp.McdpClient;
import demo.mcdp.SourceAdapter;
import java.nio.file.Path;

var config = Demo.readObject(Path.of("config.local.json"));
var snapshot = Demo.readObject(Path.of("source.local.json"));
var scope = McdpClient.selectChannel(config, "BCO");
// null means create. For update, load the persisted mapping.
var request = SourceAdapter.prepare(scope, snapshot, null);
var credentials = McdpClient.Credentials.fromEnvironment(System.getenv());
var transport = McdpClient.jdkTransport();
// Persist an operation intent before making this network call.
var result = McdpClient.execute(request, credentials, transport);
// Save result.raw(), result.requestId() and result.outcome().
// Resolve and store the returned bizId through the confirmed schema.
// Reconcile uncertain writes and query members to verify the population.
```

This fragment belongs inside an application method that handles file and
validation errors. The receiving system supplies durable state and verified
response-to-ID parsing. `execute` sends immediately when called. It does not
create the CLI journal; retain operation intent and responses in your own
restricted persistence store. A non-null mapping selects update.

The standalone CLI sets the following JDK retry properties at JVM startup.
Set the same flags before any HTTP client is initialized when embedding the
client in another application. `jdkTransport()` checks their configured values.
TLS certificate and hostname checks remain enabled, redirects are disabled,
and the application does not retry operations:

```bash
java -Djdk.httpclient.disableRetryConnect=true \
  -Djdk.httpclient.enableAllMethodRetry=false \
  -jar mcdp-audience-demo.jar list --channel BCO \
  --config config.example.json --payload examples/list.json
```

The command above previews only. Add `--execute` and a new `--response-out` path
only after replacing configuration placeholders and confirming the server
contract. The JDK retry properties are documented in the
[Oracle HTTP client reference](https://docs.oracle.com/en/java/javase/20/docs/api/java.net.http/module-summary.html).
The client submits form-encoded HTTPS POST requests with a bounded 4 MiB
response buffer and the configured request timeout. Its transport interface
can be replaced in the receiving application; preserve TLS validation, bounded
responses and reconciliation of uncertain writes.

## Confirmed interfaces

All console paths below have the prefix `/webapi/mappcenter/mcdp/crowd/`.
The method column is the console business method; the candidate RPC client sends
signed POST requests to the configured service root for every operation.

| Purpose | Action | Console method and suffix | Demo command |
| --- | --- | --- | --- |
| Create or update an audience | `CreateMcdpCrowd` | POST `createCrowd` | `create`, `update` |
| List audiences | `ListMcdpCrowd` | GET `getCrowdList` | `list` |
| Query audience details | `QueryMcdpCrowdgetbybizid` | GET `getByBizId` | `detail` |
| Query audience members | `QueryMcdpCrowdgetmoreentity` | GET `getMoreEntity` | `members` |
| Delete one member | `DeleteMcdpCrowddeleteentity` | POST `deleteEntity` | `delete-member` |

The creation mapping is:

```text
POST /webapi/mappcenter/mcdp/crowd/createCrowd
  -> mpaas.mappcenter.mcdp.crowd.create
  -> CreateMcdpCrowd
```

The browser used `/data/api.json?...:mPaaSsing` as a logged-in console proxy.
That address and its cookies are not a server integration contract. Do not
configure the demo with the console URL or reuse browser cookies for Batch.

## Audience request fields

| Business field | Meaning and observed behavior |
| --- | --- |
| `bizId` | Empty for creation; existing audience business ID for update and queries. |
| `id` | The edit page also sends the internal ID returned by audience details. Its server-side mandatory status is unconfirmed. Include the returned value for an update. |
| `name` | Audience name; the console limits it to 30 characters. |
| `type` | `0` for user IDs; `2` for device IDs. The console disables changing this field for an existing audience. |
| `entities` | A string of IDs separated by English commas or newlines, not a JSON array. |
| `appId` | Target mPaaS application, supplied by the selected channel configuration. |
| `workspaceId` | Target workspace, supplied by configuration. Do not assume UAT and production share audience IDs. |
| `tenantId` | Target tenant, supplied by configuration. The console wrapper adds a language suffix; the server-side requirement for that suffix is unconfirmed. |

Create business example, before common scope injection:

```json
{
  "bizId": "",
  "name": "BCO Audience Demo",
  "type": 0,
  "entities": "TEST_USER_001,TEST_USER_002"
}
```

Update uses the same Action. Replace the placeholders in `examples/update.json`
with the values obtained from the target audience details. Preserve its type.
The demo deliberately requires an explicit `update` command and nonempty `bizId`
to prevent accidentally creating a second audience.

**Update behavior is unresolved.** Submitting a list may append, replace or
otherwise merge members. The UI code alone does not establish the server
semantics. Do not use the demo to perform a full replacement until the UAT
experiment below proves the behavior. It never splits updates into batches.

### Direct input and file input

The console describes direct IDs as shorter than 100 characters. Its file
import accepts TXT up to 50 MB, one ID per line, and imports duplicates once.
That file workflow uploads a file before submitting the audience request;
its complete upload contract has not been established here.

The demo's `--entities-file` is **local TXT parsing followed by direct `entities`
submission**, not the console's large-file upload API. It trims outer whitespace,
preserves leading zeros, removes a UTF-8 BOM and duplicates, and rejects invalid
IDs. Its own conservative limits are 256 KiB per input file and 1,000 unique IDs
per request. These are demo limits, not verified MCDP quotas. A stricter service
limit may still apply. It uses Java String length for character checks.

```bash
bash run.sh create --channel BCO --config config.example.json \
  --payload examples/create.json --entities-file examples/entities.txt
```

## Query and deletion inputs

```text
list           {"pageNo":1,"pageSize":20}
detail         {"bizId":"<audience business ID>"}
members        {"bizId":"<audience business ID>","lastEntityId":""}
delete-member  {"bizId":"<audience business ID>","entity":"<one exact ID>"}
```

The detail view sends `bizId` and uses `lastEntityId` for loading subsequent
members. It takes that cursor from the last returned row's `key`. The demo
returns one page per call; verify the response schema and cursor termination
before adding an automatic loop. List pagination fields and PascalCase query
bindings remain candidates for server-side validation.

`entity` is singular for deletion. Deleting a member does not delete the
audience. Whole-audience deletion is intentionally outside this demo.

## Candidate server RPC binding

The existing Java `McdpSaasRpcClient` uses Alibaba Cloud HMAC-SHA1 RPC signatures
and a single JSON-string parameter for `CreateMcdpGroup`. This demo applies that
same transport convention to the observed crowd Actions. The following
crowd-specific outer field names are **inferred**, not a captured signed AK call:

| Command | Candidate outer business parameter |
| --- | --- |
| `create`, `update` | `MpaasMappcenterMcdpCrowdCreateJsonStr` |
| `delete-member` | `MpaasMappcenterMcdpCrowddeleteentityDeleteJsonStr` |
| `list` | `PageNo`, `PageSize`, optional `Name` |
| `detail` | `BizId` |
| `members` | `BizId`, optional `LastEntityId`, optional `Entity` |

Common scope fields are `AppId`, `WorkspaceId` and `TenantId`. Write JSON retains
the lower camel-case business keys and includes `appId`, `workspaceId` and
`tenantId`. Scope cannot be overridden by a payload file.

The example API version `2020-10-28` comes from the existing IMK integration;
its applicability to these crowd Actions must be confirmed. No service endpoint
is guessed: both channel endpoints in `config.example.json` are placeholders.
Confirm the endpoint, API version, crowd operation availability, RAM permissions,
outer parameter casing and tenant suffix with the mPaaS owner before execution.

The client signs the sorted parameters, sends a form-encoded POST to `/`, and
supports an optional STS token. It follows the repository's compatibility
transport. Alibaba Cloud now marks the V2 signing guide as discontinued and
recommends V3; confirm that the target still accepts the existing transport, or
replace it with the supported SDK/V3 transport before production use.
[Alibaba Cloud RPC signing reference](https://www.alibabacloud.com/help/en/sdk/product-overview/rpc-mechanism).

## Configure and execute in UAT

```bash
cp config.example.json config.local.json
mkdir -p results
```

Edit `config.local.json` with the confirmed endpoint and scope for each role.
BCO and BCM are explicitly selected configuration profiles. They may share an
application if the agreed design requires it; the demo does not assume either
shared or separate applications. Activity unit IDs such as 181 and 182 are
not audience `bizId` values and are not used to select an audience.

Credentials are read only from `ALIBABA_CLOUD_ACCESS_KEY_ID`,
`ALIBABA_CLOUD_ACCESS_KEY_SECRET` and optional `ALIBABA_CLOUD_SECURITY_TOKEN`.
Use a secret manager to provide them, or the hidden-input Bash helper below.
Do not add credentials to the JSON configuration.

Start with a list request after reviewing the candidate contract:

```bash
bash run-with-credentials.sh list --channel BCO \
  --payload examples/list.json --execute \
  --response-out results/bco-list-01.jsonl
```

Preview and then submit a new synthetic audience when ready:

```bash
bash run.sh create --channel BCO --payload examples/create.json
bash run-with-credentials.sh create --channel BCO \
  --payload examples/create.json --execute \
  --response-out results/bco-create-01.jsonl
```

After reading the returned audience business ID and internal ID, make local
copies of the relevant example JSON files and replace the placeholders:

```bash
bash run.sh detail --channel BCO --payload detail.local.json
bash run.sh members --channel BCO --payload members.local.json
bash run.sh update --channel BCO --payload update.local.json
bash run.sh delete-member --channel BCO --payload delete-member.local.json
```

These four commands preview only. For an intended live call, use the credential
helper and add `--execute --response-out results/<unique-name>.jsonl`. Repeat
with `--channel BCM` and BCM-specific IDs to verify channel isolation.

The CLI live mode requires a POSIX filesystem and saves responses as a
two-record JSON Lines journal with file mode 0600. Library users on other
platforms must provide equivalent private persistence.
The file is reserved before sending and must not already exist. The first
record marks a request that may have been sent; the second stores the observed
outcome and raw response. A file with only its first record means the process
may have stopped after a remote write. Reconcile the target before retrying.
The journal may contain member identifiers; keep it outside source control.

## Response interpretation and recovery

| Outcome | Meaning | CLI exit code |
| --- | --- | --- |
| Dry run | Plan built; no network request | 0 |
| `acknowledged` | HTTP and a recognized response marker indicate acceptance; population is not verified | 0 |
| `error` | HTTP or a recognized application marker reports failure | 2 |
| `unknown` | Missing success marker, incomplete response or transport failure | 3 |
| Local validation error | Configuration, payload, credentials or file operation could not complete | 1 |

The parser handles `ResultCode`, `ResultContent`, JSON embedded as strings,
`Code` and `Success` with their lower camel-case variants. This supports the
existing project's response style; the actual crowd response schema is still
to be verified. A request ID alone is not success. Acknowledgment is not proof
that an asynchronous import completed or that the exact intended members exist.

The client enforces HTTPS root endpoints, rejects console URLs, does not follow
redirects, and does not retry any operation automatically. A timeout after a
write may still mean the server committed it. Check the audience before issuing
another create or update. A local result-file error after execution also requires
reconciliation; do not interpret a nonzero exit code as proof of no remote change.

## UAT acceptance sequence

1. Confirm server contract and permissions; successfully query the intended
   app and workspace. Save the request ID and raw envelope.
2. Create a synthetic audience with IDs A and B. Obtain its `bizId` and internal
   `id` from the response/details, and wait until its population is available.
3. Update that audience with B and C. Read all pages: B/C suggests replacement;
   A/B/C suggests addition. Account for processing delay before deciding.
4. Delete B explicitly and verify the remaining members, without deleting the
   audience or making assumptions about update behavior.
5. Repeat within BCM, with separately recorded scope and IDs. Verify that BCO
   requests never target BCM accidentally.
6. Record field names, response examples, pagination termination, quotas and
   replay behavior. Only then connect the external system's scheduled sync job.

For production integration, keep the mapping from source group to MCDP `bizId`
scoped by source system, source audience, role, endpoint, TenantId, AppId and
WorkspaceId. Store operation status and request ID,
serialize concurrent updates to one audience, and reconcile uncertain writes.
Until replacement semantics are proven, do not implement automatic chunked
replacement or deletion of members missing from a source extract.

Audience synchronization is separate from activity publication. Creating an
audience does not automatically bind it to a Banner or set an MCDP activity online.
Those use the activity/group integration and require separate validation.

## Package and verification

- `mcdp-audience-demo.jar`: runnable Java 17 bytecode with no external libraries.
- `src/main/java/demo/mcdp/McdpClient.java`: request validation, RPC signing,
  HTTP transport, response classification and reusable public API.
- `src/main/java/demo/mcdp/SourceAdapter.java`: source snapshot and destination
  mapping validation before create or update.
- `src/main/java/demo/mcdp/Demo.java`: command-line entry and private journal.
- `src/main/java/demo/mcdp/LibraryDemo.java`: runnable offline integration example.
- `src/main/java/demo/mcdp/Json.java`: bundled JSON reader and writer.
- `build.sh`, `test.sh`, `run.sh`, `run-with-credentials.sh`: build, verification
  and launch scripts. Rebuild the JAR after modifying the source.
- `config.example.json`, `examples/`: target profiles, six request payloads,
  source snapshot, mapping example and synthetic member file.
- `src/test/java/demo/mcdp/DemoTests.java`: 16 offline tests covering an independent
  signing vector, simulated HTTP, scope checks, large IDs, bounded response
  handling, source mapping and private journal behavior.
- `MCDP-Audience-API-Guide.docx`: English API and Java integration guide.
- `START-HERE.txt`: handover steps for the receiving development team.
- `SHA256SUMS`: hashes of the distributed files, including source and JAR.

The source compiles with `javac --release 17`. The build, 16 tests and CLI
previews passed on OpenJDK 21. The tests use simulated responses and do not send
live MCDP requests. They do not certify endpoint reachability, RAM permissions,
server parameter bindings or member-update behavior. Confirm those in UAT.

## Evidence and source locations

- [Hong Kong console entry](https://mappcenter.mpaas.cn-hongkong.aliyuncs.com/aliyunPublic):
  `window.MPAAS_CONFIG.onexActionMap` maps console paths to mPaaS operations and
  Actions; observed through Chrome Network Response on 13 October 2026.
- [Loaded MCDP module](https://edge.zkobjects.com/page/mpaas-mcdp/mcdp/mcdp-6b0717a3.js):
  form submit, type values 0/2, member fields, UI file limits and request wrapper.
  This is evidence from the deployed console, not a stable published server API specification.
- [Alibaba Cloud RPC signature guide](https://www.alibabacloud.com/help/en/sdk/product-overview/rpc-mechanism):
  signing reference and independent test vector; also documents migration to V3.
- Repository: `beaimk/marketing-manage-production/src/main/java/com/hkbea/microservice/imk/marketingmanagement/util/McdpSaasRpcClient.java`
  supplies the existing transport pattern, but its Action allowlist does not
  currently contain these audience operations.
- Repository: `beaimk/marketing-manage-production/src/main/java/com/hkbea/microservice/imk/marketingmanagement/service/WhiteListServiceImpl.java`
  calls legacy `/openapi/crowd/createCrowd` and `/openapi/crowd/deleteEntity`.
  Those legacy REST paths must not be mistaken for the SaaS RPC endpoint.
