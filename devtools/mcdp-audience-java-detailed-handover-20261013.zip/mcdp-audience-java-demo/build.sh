#!/usr/bin/env bash
set -euo pipefail
demo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
javac_bin=${JAVA_HOME:+$JAVA_HOME/bin/}javac
jar_bin=${JAVA_HOME:+$JAVA_HOME/bin/}jar
command -v "$javac_bin" >/dev/null || { echo 'A JDK 17+ is required to build.' >&2; exit 1; }
mkdir -p "$demo_dir/build"
build_tmp=$(mktemp -d "$demo_dir/build/compile.XXXXXX")
trap 'rm -rf -- "$build_tmp"' EXIT
mkdir -p "$build_tmp/classes"
"$javac_bin" --release 17 -encoding UTF-8 -Xlint:all -d "$build_tmp/classes" "$demo_dir"/src/main/java/demo/mcdp/*.java
"$jar_bin" --create --file "$build_tmp/mcdp-audience-demo.jar" --main-class demo.mcdp.Demo -C "$build_tmp/classes" .
mv "$build_tmp/mcdp-audience-demo.jar" "$demo_dir/mcdp-audience-demo.jar"
echo "BUILD_OK: $demo_dir/mcdp-audience-demo.jar (Java 17 bytecode)"
