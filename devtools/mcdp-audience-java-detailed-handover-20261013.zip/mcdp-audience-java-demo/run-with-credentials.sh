#!/usr/bin/env bash
set +x
set -euo pipefail
demo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -z ${ALIBABA_CLOUD_ACCESS_KEY_ID:-} ]]; then
  read -r -s -p 'RAM AccessKey ID: ' ALIBABA_CLOUD_ACCESS_KEY_ID </dev/tty
  printf '\n' >/dev/tty
fi
if [[ -z ${ALIBABA_CLOUD_ACCESS_KEY_SECRET:-} ]]; then
  read -r -s -p 'RAM AccessKey Secret: ' ALIBABA_CLOUD_ACCESS_KEY_SECRET </dev/tty
  printf '\n' >/dev/tty
fi
if [[ -z ${ALIBABA_CLOUD_SECURITY_TOKEN:-} ]]; then
  read -r -s -p 'STS token (empty for a long-lived AccessKey): ' ALIBABA_CLOUD_SECURITY_TOKEN </dev/tty
  printf '\n' >/dev/tty
fi
export ALIBABA_CLOUD_ACCESS_KEY_ID ALIBABA_CLOUD_ACCESS_KEY_SECRET ALIBABA_CLOUD_SECURITY_TOKEN
exec bash "$demo_dir/run.sh" "$@"
