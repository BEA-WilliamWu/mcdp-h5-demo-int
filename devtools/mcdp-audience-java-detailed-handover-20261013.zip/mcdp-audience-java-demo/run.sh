#!/usr/bin/env bash
set -euo pipefail
demo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
java_bin=${JAVA_HOME:+$JAVA_HOME/bin/}java
command -v "$java_bin" >/dev/null || { echo 'Java 17+ is required.' >&2; exit 1; }
[[ -f "$demo_dir/mcdp-audience-demo.jar" ]] || bash "$demo_dir/build.sh"
java_args=(-Djdk.httpclient.disableRetryConnect=true -Djdk.httpclient.enableAllMethodRetry=false)
if [[ ${1:-} == library-demo ]]; then
  [[ $# == 1 ]] || { echo 'Usage: bash run.sh library-demo' >&2; exit 2; }
  exec "$java_bin" "${java_args[@]}" -cp "$demo_dir/mcdp-audience-demo.jar" demo.mcdp.LibraryDemo "$demo_dir"
fi
exec "$java_bin" "${java_args[@]}" -jar "$demo_dir/mcdp-audience-demo.jar" "$@"
