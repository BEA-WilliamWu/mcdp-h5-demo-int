package demo.mcdp;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.charset.*;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;
import static demo.mcdp.McdpClient.*;

/** CLI preview is the default. Live execution requires a new private journal. */
public final class Demo {
    private Demo() {}
    private static final String HELP = """
            MCDP audience Java demo (Java 17+, no third-party dependencies)
            Usage: bash run.sh <operation> --channel BCO|BCM --payload <file.json>
              [--config config.local.json] [--entities-file <file.txt>]
              [--execute --response-out <new-private-result.jsonl>]
            Operations: create, update, list, detail, members, delete-member
            Default: preview only; no credentials or network needed.
            Server RPC bindings require confirmation with the mPaaS owner.
            Run the source adapter preview: bash run.sh library-demo
            """;

    public static void main(String[] args) {
        int code;
        try { code = run(args, null, System.getenv(), System.out); }
        catch (IllegalArgumentException e) { System.err.println("DEMO_ERROR: " + e.getMessage()); code = 1; }
        catch (Exception e) { System.err.println("DEMO_ERROR: Local file or runtime operation failed; reconcile any pending journal before retrying"); code = 1; }
        if (code != 0) System.exit(code);
    }

    static Map<String, String> parseArgs(String[] args) {
        if (args.length == 0 || args.length == 1 && args[0].equals("--help")) return Map.of("help", "true");
        require(OPERATIONS.contains(args[0]), "Unknown operation; use --help");
        Map<String, String> out = new LinkedHashMap<>(); out.put("operation", args[0]);
        Set<String> seen = new HashSet<>();
        for (int i = 1; i < args.length; i++) {
            String key = args[i]; require(seen.add(key), "Duplicate option");
            if (key.equals("--execute")) { out.put("execute", "true"); continue; }
            require(Set.of("--config", "--channel", "--payload", "--entities-file", "--response-out").contains(key), "Unknown option");
            require(i + 1 < args.length && !args[i + 1].startsWith("--"), "Missing option value");
            out.put(key.substring(2), args[++i]);
        }
        require(out.containsKey("channel") && out.containsKey("payload"), "--channel and --payload are required");
        require(!out.containsKey("entities-file") || Set.of("create", "update").contains(out.get("operation")), "--entities-file only applies to create/update");
        require(!out.containsKey("execute") || out.containsKey("response-out"), "--execute requires --response-out");
        out.putIfAbsent("config", "config.local.json"); return out;
    }

    public static String readText(Path path) throws IOException {
        byte[] data;
        try (InputStream stream = Files.newInputStream(path)) { data = stream.readNBytes(MAX_INPUT + 1); }
        require(data.length <= MAX_INPUT, "Demo input file limit is 256 KiB");
        return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(data)).toString();
    }
    public static Map<String, Object> readObject(Path path) throws IOException { return Json.object(Json.parse(readText(path))); }

    // Transport injection allows offline tests with no live MCDP requests.
    static int run(String[] args, Transport transport, Map<String, String> env, PrintStream out) throws Exception {
        Map<String, String> options = parseArgs(args);
        if (options.containsKey("help")) { out.print(HELP); return 0; }
        Scope scope = selectChannel(readObject(Path.of(options.get("config"))), options.get("channel"));
        Map<String, Object> payload = readObject(Path.of(options.get("payload")));
        if (options.containsKey("entities-file")) payload.put("entities", readText(Path.of(options.get("entities-file"))));
        Request request = buildRequest(scope, options.get("operation"), payload);
        Map<String, Object> plan = preview(request);
        if (!options.containsKey("execute")) { out.println(Json.stringify(plan)); return 0; }
        validateExecution(request);
        Credentials credentials = Credentials.fromEnvironment(env);
        if (transport == null) transport = jdkTransport();
        Path journal = Path.of(options.get("response-out"));
        // POSIX permission support is required by this CLI's live mode. Library
        // callers on other platforms must provide their own private persistence.
        Result result;
        try (FileChannel file = FileChannel.open(journal, Set.of(StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE),
                PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------")))) {
            plan.put("mode", "execute"); plan.remove("networkRequests");
            append(file, Map.of("state", "request_may_be_sent", "request", plan));
            result = execute(request, credentials, transport);
            Map<String, Object> record = new LinkedHashMap<>();
            record.put("state", "response_observed"); record.put("outcome", result.outcome());
            record.put("httpStatus", result.httpStatus()); record.put("requestId", result.requestId());
            record.put("reason", result.reason()); record.put("raw", result.raw());
            append(file, record);
        }
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("mode", "execute"); summary.put("operation", request.operation()); summary.put("action", request.action());
        summary.put("channel", scope.channel()); summary.put("outcome", result.outcome());
        summary.put("httpStatus", result.httpStatus()); summary.put("requestId", result.requestId());
        summary.put("responseFile", journal.toString()); summary.put("populationVerified", false);
        out.println(Json.stringify(summary));
        return result.outcome().equals("acknowledged") ? 0 : result.outcome().equals("error") ? 2 : 3;
    }
    private static void append(FileChannel file, Object record) throws IOException {
        ByteBuffer buffer = ByteBuffer.wrap((Json.stringify(record) + "\n").getBytes(StandardCharsets.UTF_8));
        while (buffer.hasRemaining()) file.write(buffer);
        file.force(true);
    }
}
