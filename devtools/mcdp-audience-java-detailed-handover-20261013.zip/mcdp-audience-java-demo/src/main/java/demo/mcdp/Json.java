package demo.mcdp;

import java.math.BigDecimal;
import java.util.*;

/** Small strict JSON codec so the standalone demo needs only a JDK. */
public final class Json {
    private Json() {}

    public static Object parse(String text) {
        Parser p = new Parser(text);
        Object result = p.value(0);
        p.space();
        if (p.pos != text.length()) throw invalid();
        return result;
    }

    public static Map<String, Object> object(Object value) {
        if (!(value instanceof Map<?, ?> map)) throw new IllegalArgumentException("Expected a JSON object");
        Map<String, Object> result = new LinkedHashMap<>();
        for (var entry : map.entrySet()) {
            if (!(entry.getKey() instanceof String key)) throw invalid();
            result.put(key, entry.getValue());
        }
        return result;
    }

    public static String stringify(Object value) {
        StringBuilder out = new StringBuilder();
        write(value, out, 0);
        return out.toString();
    }

    private static void write(Object value, StringBuilder out, int depth) {
        if (depth > 64) throw invalid();
        if (value == null) { out.append("null"); return; }
        if (value instanceof String s) { quote(s, out); return; }
        if (value instanceof Boolean) { out.append(value); return; }
        if (value instanceof Number n) {
            try { new BigDecimal(n.toString()); } catch (NumberFormatException e) { throw invalid(); }
            out.append(n); return;
        }
        if (value instanceof Map<?, ?> map) {
            out.append('{'); boolean first = true;
            for (var item : map.entrySet()) {
                if (!(item.getKey() instanceof String key)) throw invalid();
                if (!first) out.append(','); first = false;
                quote(key, out); out.append(':'); write(item.getValue(), out, depth + 1);
            }
            out.append('}'); return;
        }
        if (value instanceof Collection<?> list) {
            out.append('['); boolean first = true;
            for (Object item : list) {
                if (!first) out.append(','); first = false;
                write(item, out, depth + 1);
            }
            out.append(']'); return;
        }
        throw invalid();
    }

    private static void quote(String s, StringBuilder out) {
        validUnicode(s);
        out.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> { if (c < 32) out.append(String.format("\\u%04x", (int)c)); else out.append(c); }
            }
        }
        out.append('"');
    }

    static void validUnicode(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isHighSurrogate(c)) {
                if (++i >= s.length() || !Character.isLowSurrogate(s.charAt(i))) throw invalid();
            } else if (Character.isLowSurrogate(c)) throw invalid();
        }
    }

    private static IllegalArgumentException invalid() {
        // Never echo an invalid payload, credentials or member values.
        return new IllegalArgumentException("Invalid JSON value or unsupported nesting");
    }

    private static final class Parser {
        private final String text;
        private int pos;
        Parser(String text) { this.text = Objects.requireNonNull(text); }
        void space() { while (pos < text.length() && " \r\n\t".indexOf(text.charAt(pos)) >= 0) pos++; }
        boolean take(char c) {
            if (pos < text.length() && text.charAt(pos) == c) { pos++; return true; }
            return false;
        }
        void need(char c) { if (!take(c)) throw invalid(); }
        Object value(int depth) {
            if (depth > 64) throw invalid();
            space(); if (pos >= text.length()) throw invalid();
            char c = text.charAt(pos);
            if (c == '"') return string();
            if (take('{')) {
                Map<String, Object> map = new LinkedHashMap<>();
                space(); if (take('}')) return map;
                do {
                    space(); String key = string(); space(); need(':');
                    if (map.containsKey(key)) throw invalid();
                    map.put(key, value(depth + 1)); space();
                    if (take('}')) return map;
                    need(',');
                } while (true);
            }
            if (take('[')) {
                List<Object> list = new ArrayList<>(); space(); if (take(']')) return list;
                do {
                    list.add(value(depth + 1)); space(); if (take(']')) return list;
                    need(',');
                } while (true);
            }
            for (String literal : List.of("true", "false", "null")) {
                if (text.startsWith(literal, pos)) {
                    pos += literal.length();
                    return literal.equals("null") ? null : literal.equals("true");
                }
            }
            int start = pos; take('-');
            if (!take('0')) { if (!digit19()) throw invalid(); while (digit()) pos++; }
            if (take('.')) { if (!digit()) throw invalid(); while (digit()) pos++; }
            if (take('e') || take('E')) {
                if (!take('+')) take('-');
                if (!digit()) throw invalid(); while (digit()) pos++;
            }
            try { return new BigDecimal(text.substring(start, pos)); }
            catch (NumberFormatException e) { throw invalid(); }
        }
        boolean digit() { return pos < text.length() && text.charAt(pos) >= '0' && text.charAt(pos) <= '9'; }
        boolean digit19() {
            if (pos < text.length() && text.charAt(pos) >= '1' && text.charAt(pos) <= '9') { pos++; return true; }
            return false;
        }
        String string() {
            need('"'); StringBuilder s = new StringBuilder();
            while (pos < text.length()) {
                char c = text.charAt(pos++);
                if (c == '"') { validUnicode(s.toString()); return s.toString(); }
                if (c < 32) throw invalid();
                if (c != '\\') { s.append(c); continue; }
                if (pos >= text.length()) throw invalid();
                switch (text.charAt(pos++)) {
                    case '"' -> s.append('"'); case '\\' -> s.append('\\'); case '/' -> s.append('/');
                    case 'b' -> s.append('\b'); case 'f' -> s.append('\f');
                    case 'n' -> s.append('\n'); case 'r' -> s.append('\r'); case 't' -> s.append('\t');
                    case 'u' -> {
                        if (pos + 4 > text.length()) throw invalid();
                        int code = 0;
                        for (int i = 0; i < 4; i++) {
                            char h = text.charAt(pos++);
                            int hex = h >= '0' && h <= '9' ? h - '0' : h >= 'a' && h <= 'f' ? h - 'a' + 10
                                    : h >= 'A' && h <= 'F' ? h - 'A' + 10 : -1;
                            if (hex < 0) throw invalid(); code = code * 16 + hex;
                        }
                        s.append((char) code);
                    }
                    default -> throw invalid();
                }
            }
            throw invalid();
        }
    }
}
