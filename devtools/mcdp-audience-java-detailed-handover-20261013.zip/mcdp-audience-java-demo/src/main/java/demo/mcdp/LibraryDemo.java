package demo.mcdp;

import java.nio.file.Path;
import java.util.*;

/** Executable integration example: synthetic data, no network calls. */
public final class LibraryDemo {
    private LibraryDemo() {}
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args.length == 0 ? "." : args[0]);
        var config = Demo.readObject(root.resolve("config.example.json"));
        var snapshot = Demo.readObject(root.resolve("examples/source-audience.json"));
        var binding = Demo.readObject(root.resolve("examples/binding.example.json"));
        var scope = McdpClient.selectChannel(config, "BCO");
        var create = SourceAdapter.prepare(scope, snapshot, null);
        var changed = new LinkedHashMap<>(snapshot);
        changed.put("memberIds", List.of("000002", "000003"));
        var update = SourceAdapter.prepare(scope, changed, binding);
        System.out.println(Json.stringify(Map.of("note", "Offline Java source adapter example; mapping IDs are placeholders",
                "create", McdpClient.preview(create), "update", McdpClient.preview(update))));
    }
}
