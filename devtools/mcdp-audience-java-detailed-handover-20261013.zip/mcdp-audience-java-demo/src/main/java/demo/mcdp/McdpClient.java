package demo.mcdp;

import java.io.*;
import java.math.BigDecimal;
import java.net.URI;
import java.net.http.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.Flow;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Custom RPC transport, not an official SDK. Crowd bindings require UAT confirmation. */
public final class McdpClient {
    public static final String CREATE_FIELD = "MpaasMappcenterMcdpCrowdCreateJsonStr";
    public static final String DELETE_FIELD = "MpaasMappcenterMcdpCrowddeleteentityDeleteJsonStr";
    public static final Set<String> OPERATIONS = Set.of("create", "update", "list", "detail", "members", "delete-member");
    public static final int MAX_INPUT = 256 * 1024;
    public static final int MAX_RESPONSE = 4 * 1024 * 1024;

    public record Scope(String channel, String endpoint, String appId, String workspaceId,
                        String tenantId, String regionId, String apiVersion, int timeoutMs) {}
    public record Credentials(String accessKeyId, String accessKeySecret, String securityToken) {
        public Credentials {
            string(accessKeyId, "accessKeyId"); string(accessKeySecret, "accessKeySecret");
        }
        public static Credentials fromEnvironment(Map<String, String> env) {
            return new Credentials(env.get("ALIBABA_CLOUD_ACCESS_KEY_ID"),
                    env.get("ALIBABA_CLOUD_ACCESS_KEY_SECRET"), env.get("ALIBABA_CLOUD_SECURITY_TOKEN"));
        }
        @Override public String toString() { return "Credentials[redacted]"; }
    }
    public record Request(Scope scope, String operation, String action, boolean write,
                          Map<String, Object> business, Map<String, String> parameters) {
        public Request {
            business = Collections.unmodifiableMap(new LinkedHashMap<>(business));
            parameters = Collections.unmodifiableMap(new LinkedHashMap<>(parameters));
        }
        @Override public String toString() { return "Request[operation=" + operation + ", payload=redacted]"; }
    }
    public record Result(String outcome, Integer httpStatus, Object requestId, Object data,
                         String raw, String reason) {
        @Override public String toString() { return "Result[outcome=" + outcome + ", response=redacted]"; }
    }
    public record WireResponse(int status, String body) {}
    @FunctionalInterface public interface Transport {
        WireResponse send(URI endpoint, String formBody, int timeoutMs) throws Exception;
    }

    public static Scope selectChannel(Map<String, Object> config, String channel) {
        require(Set.of("BCO", "BCM").contains(channel == null ? "" : channel), "Select BCO or BCM explicitly");
        Map<String, Object> c = Json.object(Json.object(config.get("channels")).get(channel));
        int timeout = integer(config.getOrDefault("timeoutMs", 15000), "timeoutMs");
        require(timeout >= 1000 && timeout <= 120000, "timeoutMs must be 1000..120000");
        return new Scope(channel, string(c.get("endpoint"), "endpoint"), string(c.get("appId"), "appId"),
                string(c.get("workspaceId"), "workspaceId"), string(c.get("tenantId"), "tenantId"),
                string(c.get("regionId"), "regionId"), string(c.get("apiVersion"), "apiVersion"), timeout);
    }

    public static String normalizeEntities(Object value) {
        String text = string(value, "entities");
        require(text.getBytes(StandardCharsets.UTF_8).length <= MAX_INPUT, "Demo input limit is 256 KiB");
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        for (String item : text.replaceFirst("^\\uFEFF", "").split("[,\\r\\n]")) {
            String id = item.strip(); if (id.isEmpty()) continue;
            require(id.length() < 100 && !id.matches("(?s).*[\\x00-\\x1f\\x7f].*"), "Invalid member ID length or control character");
            ids.add(id);
            require(ids.size() <= 1000, "Demo limit is 1000 unique IDs; automatic splitting is disabled");
        }
        require(!ids.isEmpty(), "At least one entity is required");
        return String.join(",", ids);
    }

    public static Request buildRequest(Scope scope, String operation, Map<String, Object> input) {
        require(OPERATIONS.contains(operation), "Unknown operation");
        Set<String> allowed = switch (operation) {
            case "create", "update" -> Set.of("bizId", "id", "name", "type", "entities");
            case "list" -> Set.of("pageNo", "pageSize", "name");
            case "detail" -> Set.of("bizId");
            case "members" -> Set.of("bizId", "lastEntityId", "entity");
            default -> Set.of("bizId", "entity");
        };
        require(allowed.containsAll(input.keySet()), "Unsupported payload fields; configure scope separately");
        Map<String, Object> business = new LinkedHashMap<>(input);
        boolean creation = operation.equals("create"), update = operation.equals("update");
        if (creation || update) {
            require(string(business.get("name"), "name").length() <= 30, "name must be at most 30 characters");
            int type = integer(business.get("type"), "type");
            require(type == 0 || type == 2, "type must be 0 for user IDs or 2 for device IDs");
            business.put("type", type);
            business.put("entities", normalizeEntities(business.get("entities")));
            if (creation) {
                require(!business.containsKey("id") && (!business.containsKey("bizId") || "".equals(business.get("bizId"))),
                        "create requires an empty bizId and no id");
                business.put("bizId", "");
            }
            // Keep long database IDs as strings across receiving systems.
            if (business.containsKey("id")) string(business.get("id"), "id (use a JSON string)");
        }
        if (Set.of("update", "detail", "members", "delete-member").contains(operation)) string(business.get("bizId"), "bizId");
        if (operation.equals("delete-member")) {
            String entity = string(business.get("entity"), "entity");
            String normalized = normalizeEntities(entity);
            require(!normalized.contains(",") && normalized.equals(entity), "entity must be exactly one unpadded ID");
        }
        if (operation.equals("list")) {
            business.putIfAbsent("pageNo", 1); business.putIfAbsent("pageSize", 20);
            for (String field : List.of("pageNo", "pageSize")) {
                int n = integer(business.get(field), field); require(n > 0, "Pagination values must be positive integers");
                business.put(field, n);
            }
        }
        if (operation.equals("members") && business.containsKey("lastEntityId"))
            require(business.get("lastEntityId") instanceof String, "lastEntityId must be a string");
        String action = switch (operation) {
            case "create", "update" -> "CreateMcdpCrowd";
            case "list" -> "ListMcdpCrowd";
            case "detail" -> "QueryMcdpCrowdgetbybizid";
            case "members" -> "QueryMcdpCrowdgetmoreentity";
            default -> "DeleteMcdpCrowddeleteentity";
        };
        Map<String, String> parameters = new LinkedHashMap<>();
        parameters.put("AppId", scope.appId()); parameters.put("WorkspaceId", scope.workspaceId());
        parameters.put("TenantId", scope.tenantId());
        boolean write = creation || update || operation.equals("delete-member");
        if (write) {
            Map<String, Object> body = new LinkedHashMap<>(business);
            body.put("appId", scope.appId()); body.put("workspaceId", scope.workspaceId()); body.put("tenantId", scope.tenantId());
            parameters.put(operation.equals("delete-member") ? DELETE_FIELD : CREATE_FIELD, Json.stringify(body));
        } else {
            for (var e : business.entrySet()) {
                require(e.getValue() instanceof String || e.getValue() instanceof Number, "Query parameters must be strings or numbers");
                parameters.put(Character.toUpperCase(e.getKey().charAt(0)) + e.getKey().substring(1), e.getValue().toString());
            }
        }
        return new Request(scope, operation, action, write, business, parameters);
    }

    public static Map<String, Object> preview(Request r) {
        Map<String, Object> out = new LinkedHashMap<>(); Scope s = r.scope();
        out.put("mode", "dry-run"); out.put("rpcContractStatus", "candidate - not verified with server AK");
        out.put("operation", r.operation()); out.put("action", r.action()); out.put("write", r.write());
        out.put("channel", s.channel()); out.put("endpoint", s.endpoint()); out.put("appId", s.appId());
        out.put("workspaceId", s.workspaceId()); out.put("tenantId", s.tenantId());
        out.put("apiVersion", s.apiVersion()); out.put("regionId", s.regionId());
        out.put("parameterNames", new ArrayList<>(r.parameters().keySet()));
        out.put("businessFieldNames", new ArrayList<>(r.business().keySet()));
        out.put("entityCount", r.business().containsKey("entities") ? ((String)r.business().get("entities")).split(",").length
                : r.business().containsKey("entity") ? 1 : 0);
        out.put("memberValues", "redacted"); out.put("networkRequests", 0);
        return out;
    }

    public static String percentEncode(String value) {
        Json.validUnicode(value); StringBuilder out = new StringBuilder();
        final char[] hex = "0123456789ABCDEF".toCharArray();
        for (byte b : value.getBytes(StandardCharsets.UTF_8)) {
            int c = b & 255;
            if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || "-_.~".indexOf(c) >= 0) out.append((char)c);
            else out.append('%').append(hex[c >>> 4]).append(hex[c & 15]);
        }
        return out.toString();
    }
    public static String formEncode(Map<String, String> values) {
        StringJoiner out = new StringJoiner("&");
        new TreeMap<>(values).forEach((k, v) -> out.add(percentEncode(k) + "=" + percentEncode(v)));
        return out.toString();
    }
    public static String sign(Map<String, String> parameters, String secret, String method) {
        try {
            Map<String, String> unsigned = new TreeMap<>(parameters); unsigned.remove("Signature");
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(new SecretKeySpec((secret + "&").getBytes(StandardCharsets.UTF_8), "HmacSHA1"));
            return Base64.getEncoder().encodeToString(mac.doFinal((method + "&%2F&" + percentEncode(formEncode(unsigned))).getBytes(StandardCharsets.UTF_8)));
        } catch (java.security.GeneralSecurityException e) { throw new IllegalStateException("HMAC initialization failed"); }
    }
    public static Map<String, String> signedParameters(Request r, Credentials c, Instant now, String nonce) {
        Map<String, String> p = new LinkedHashMap<>(r.parameters());
        p.put("Action", r.action()); p.put("AccessKeyId", c.accessKeyId()); p.put("Format", "JSON");
        p.put("Version", r.scope().apiVersion()); p.put("RegionId", r.scope().regionId());
        p.put("SignatureMethod", "HMAC-SHA1"); p.put("SignatureVersion", "1.0"); p.put("SignatureNonce", nonce);
        p.put("Timestamp", now.truncatedTo(ChronoUnit.SECONDS).toString());
        if (c.securityToken() != null && !c.securityToken().isBlank()) p.put("SecurityToken", c.securityToken());
        p.put("Signature", sign(p, c.accessKeySecret(), "POST")); return p;
    }

    public static void validateExecution(Request r) {
        URI u;
        try { u = URI.create(r.scope().endpoint()); } catch (IllegalArgumentException e) { throw new IllegalArgumentException("Invalid RPC endpoint"); }
        require("https".equalsIgnoreCase(u.getScheme()) && u.getHost() != null && !u.getHost().toLowerCase(Locale.ROOT).contains("console.")
                && (u.getPath().isEmpty() || u.getPath().equals("/")) && u.getUserInfo() == null && u.getQuery() == null && u.getFragment() == null,
                "Use an HTTPS RPC root endpoint without credentials, query or console path");
        String all = r.scope().toString() + Json.stringify(r.business());
        require(!java.util.regex.Pattern.compile("YOUR_|REPLACE_WITH_|<[^>]+>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(all).find(),
                "Replace all configuration and business ID placeholders before execution");
    }
    public static Result execute(Request r, Credentials c, Transport transport) {
        validateExecution(r);
        String form = formEncode(signedParameters(r, c, Instant.now(), UUID.randomUUID().toString()));
        try {
            WireResponse wire = transport.send(URI.create(r.scope().endpoint()), form, r.scope().timeoutMs());
            return classifyResponse(wire.status(), wire.body());
        } catch (Exception e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            return new Result("unknown", null, null, null, null, "No complete response. Reconcile remotely before retrying a write.");
        }
    }
    public static Result classifyResponse(int status, String raw) {
        Object envelope = unwrap(raw), content = unwrap(field(envelope, "ResultContent", "resultContent"));
        boolean failed = status < 200 || status >= 300, acknowledged = false;
        for (Object layer : new Object[]{envelope, content}) {
            Object rc = field(layer, "ResultCode", "resultCode"), code = field(layer, "Code", "code"), success = field(layer, "Success", "success");
            if (rc != null) { if ("OK".equals(rc)) acknowledged = true; else failed = true; }
            if (code != null) { if (Set.of("0", "200", "OK").contains(code.toString())) acknowledged = true; else failed = true; }
            if (Boolean.FALSE.equals(success) || "false".equals(success)) failed = true;
            if (Boolean.TRUE.equals(success) || "true".equals(success)) acknowledged = true;
        }
        Object data = field(content, "Data", "data");
        if (data == null) data = content != null ? content : field(envelope, "Data", "data");
        return new Result(failed ? "error" : acknowledged ? "acknowledged" : "unknown", status,
                field(envelope, "RequestId", "requestId"), unwrap(data), raw, null);
    }
    private static Object unwrap(Object value) {
        for (int i = 0; i < 4 && value instanceof String s; i++) {
            try { value = Json.parse(s); } catch (IllegalArgumentException e) { break; }
        }
        return value;
    }
    private static Object field(Object value, String upper, String lower) {
        if (!(value instanceof Map<?, ?> map)) return null;
        return map.get(upper) != null ? map.get(upper) : map.get(lower);
    }

    /** Configure these flags at JVM startup before any HttpClient is initialized. */
    public static Transport jdkTransport() {
        require("true".equals(System.getProperty("jdk.httpclient.disableRetryConnect"))
                && "false".equals(System.getProperty("jdk.httpclient.enableAllMethodRetry")),
                "Use run.sh or start the JVM with the documented HTTP retry flags");
        return (endpoint, form, timeoutMs) -> {
            HttpClient client = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
                    .followRedirects(HttpClient.Redirect.NEVER).connectTimeout(Duration.ofMillis(timeoutMs)).build();
            HttpRequest request = HttpRequest.newBuilder(endpoint).timeout(Duration.ofMillis(timeoutMs))
                    .header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                    .POST(HttpRequest.BodyPublishers.ofString(form, StandardCharsets.UTF_8)).build();
            HttpResponse<byte[]> response = client.send(request, info -> new BoundedBody());
            return new WireResponse(response.statusCode(), new String(response.body(), StandardCharsets.UTF_8));
        };
    }
    static final class BoundedBody implements HttpResponse.BodySubscriber<byte[]> {
        private final CompletableFuture<byte[]> future = new CompletableFuture<>();
        private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        private Flow.Subscription subscription;
        public CompletionStage<byte[]> getBody() { return future; }
        public void onSubscribe(Flow.Subscription value) {
            if (subscription != null) { value.cancel(); return; }
            subscription = value; value.request(1);
        }
        public void onNext(List<ByteBuffer> items) {
            if (future.isDone()) return;
            for (ByteBuffer item : items) {
                if (item.remaining() > MAX_RESPONSE - buffer.size()) {
                    subscription.cancel(); future.completeExceptionally(new IOException("Response exceeds demo limit")); return;
                }
                byte[] bytes = new byte[item.remaining()]; item.get(bytes); buffer.writeBytes(bytes);
            }
            subscription.request(1);
        }
        public void onError(Throwable error) { future.completeExceptionally(error); }
        public void onComplete() { future.complete(buffer.toByteArray()); }
    }

    static String string(Object value, String name) {
        require(value instanceof String && !((String)value).isBlank(), name + " must be a nonempty string");
        Json.validUnicode((String)value); return (String)value;
    }
    static int integer(Object value, String name) {
        require(value instanceof Number, name + " must be an integer");
        try { return new BigDecimal(value.toString()).intValueExact(); }
        catch (ArithmeticException | NumberFormatException e) { throw new IllegalArgumentException(name + " must be an integer"); }
    }
    static void require(boolean valid, String message) { if (!valid) throw new IllegalArgumentException(message); }
}
