package demo.mcdp;

import java.util.*;
import static demo.mcdp.McdpClient.*;

/** Example source-system mapping. Mapping fields are never sent as RPC fields. */
public final class SourceAdapter {
    private SourceAdapter() {}
    public static Request prepare(Scope scope, Map<String, Object> snapshot, Map<String, Object> binding) {
        for (String key : List.of("sourceSystem", "sourceAudienceId")) string(snapshot.get(key), key);
        String idType = string(snapshot.get("idType"), "idType");
        require(idType.equals("user") || idType.equals("device"), "idType must be user or device");
        int type = idType.equals("user") ? 0 : 2;
        require(snapshot.get("memberIds") instanceof List<?> && !((List<?>)snapshot.get("memberIds")).isEmpty(),
                "An empty source snapshot cannot clear a remote audience");
        List<String> ids = new ArrayList<>();
        for (Object value : (List<?>) snapshot.get("memberIds")) {
            String id = string(value, "member ID (keep IDs as strings)");
            require(id.equals(id.strip()) && !id.matches("(?s).*[,\\x00-\\x1f\\x7f].*"),
                    "Each member ID must be one unpadded string without delimiters or control characters");
            ids.add(id);
        }
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("name", snapshot.get("name")); body.put("type", type); body.put("entities", String.join(",", ids));
        if (binding != null) {
            for (String key : List.of("sourceSystem", "sourceAudienceId"))
                require(Objects.equals(binding.get(key), snapshot.get(key)), "Stored mapping belongs to another source audience");
            Map<String, String> destination = Map.of("channel", scope.channel(), "endpoint", scope.endpoint(),
                    "tenantId", scope.tenantId(), "appId", scope.appId(), "workspaceId", scope.workspaceId());
            destination.forEach((key, expected) -> require(expected.equals(binding.get(key)), "Stored mapping has a different destination " + key));
            require(integer(binding.get("type"), "binding type") == type, "An existing audience type cannot be changed");
            body.put("bizId", string(binding.get("bizId"), "binding bizId"));
            body.put("id", string(binding.get("id"), "binding id (keep IDs as strings)"));
        }
        return buildRequest(scope, binding == null ? "create" : "update", body);
    }
}
