package demo.mcdp;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import static demo.mcdp.McdpClient.*;

/** Dependency-free test harness. All HTTP responses are simulated. */
public final class DemoTests {
    private static int passed;
    @FunctionalInterface interface Check { void run() throws Exception; }
    private static final Scope SCOPE = new Scope("BCO", "https://rpc.example.test/", "app-bco", "UAT", "tenant-bco", "cn-hongkong", "2020-10-28", 15000);
    private static final Credentials CREDS = new Credentials("testid", "testsecret", "test-token");
    private static Map<String, Object> body() { return new LinkedHashMap<>(Map.of("name", "Demo audience", "type", 0, "entities", "000001,000002")); }
    private static Map<String, Object> config() { return Map.of("channels", Map.of("BCO", Map.of("endpoint", SCOPE.endpoint(), "appId", SCOPE.appId(),
            "workspaceId", "UAT", "tenantId", SCOPE.tenantId(), "regionId", SCOPE.regionId(), "apiVersion", SCOPE.apiVersion()),
            "BCM", Map.of("endpoint", SCOPE.endpoint(), "appId", "app-bcm", "workspaceId", "UAT", "tenantId", "tenant-bcm",
                    "regionId", SCOPE.regionId(), "apiVersion", SCOPE.apiVersion()))); }
    private static void check(String name, Check task) throws Exception { task.run(); passed++; System.out.println("PASS " + name); }
    private static void eq(Object expected, Object actual) { if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + " but got " + actual); }
    private static void yes(boolean actual) { if (!actual) throw new AssertionError("Assertion failed"); }
    private static void rejects(Check task) throws Exception {
        try { task.run(); } catch (Exception expected) { return; }
        throw new AssertionError("Expected rejection");
    }
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args.length == 0 ? "." : args[0]);
        check("independent published Alibaba RPC signature vector", () -> {
            Map<String, String> p = Map.of("AccessKeyId", "testid", "Action", "DescribeDedicatedHosts", "Format", "JSON", "RegionId", "cn-beijing",
                    "SignatureMethod", "HMAC-SHA1", "SignatureNonce", "edb2b34af0af9a6d14deaf7c1a5315eb", "SignatureVersion", "1.0",
                    "Timestamp", "2023-03-13T08:34:30Z", "Version", "2014-05-26");
            eq("9NaGiOspFP5UPcwX8Iwt2YJXXuk=", sign(p, "testsecret", "GET"));
            yes(!sign(p, "testsecret", "POST").equals(sign(p, "testsecret", "GET")));
        });
        check("RFC3986 Unicode and canonical ordering", () -> {
            eq("a%20b%2B%21%2A%27%28%29~%E4%B8%AD", percentEncode("a b+!*'()~中"));
            eq("a=a%20b&z=%2B", formEncode(Map.of("z", "+", "a", "a b")));
        });
        check("strict JSON round trip and exact large IDs", () -> {
            String text = "{\"id\":9007199254740999,\"s\":\"\\u4e2d\\n😀\",\"a\":[true,false,null,-1.25e2]}";
            Object parsed = Json.parse(text);
            eq("9007199254740999", Json.object(parsed).get("id").toString());
            eq(parsed, Json.parse(Json.stringify(parsed)));
            for (String bad : List.of("{\"x\":null,\"x\":1}", "[1,]", "01", "1e", ".1", "true false", "\"\\uD800\"", "\"\\uＦＦＦＦ\"", "\"\\q\"", "{x:1}"))
                rejects(() -> Json.parse(bad));
            rejects(() -> Json.parse("[".repeat(70) + "0" + "]".repeat(70)));
        });
        check("member normalization preserves leading zeros and rejects excessive input", () -> {
            eq("001,002", normalizeEntities("\ufeff001\r\n002,001\n"));
            rejects(() -> normalizeEntities("x".repeat(100)));
            rejects(() -> normalizeEntities("a\tbad"));
            rejects(() -> normalizeEntities(" ,\n"));
            rejects(() -> normalizeEntities(String.join(",", java.util.stream.IntStream.range(0,1001).mapToObj(Integer::toString).toList())));
        });
        check("explicit BCO and BCM scope selection with no payload override", () -> {
            rejects(() -> selectChannel(config(), null));
            eq("app-bcm", buildRequest(selectChannel(config(), "BCM"), "create", body()).parameters().get("AppId"));
            Map<String, Object> input = body(); input.put("appId", "injected"); rejects(() -> buildRequest(SCOPE, "create", input));
        });
        check("create and update identities remain distinct", () -> {
            Map<String, Object> input = body(); input.put("bizId", "W-existing"); input.put("id", "9007199254740999");
            rejects(() -> buildRequest(SCOPE, "create", input));
            Request update = buildRequest(SCOPE, "update", input);
            eq("W-existing", update.business().get("bizId")); eq("9007199254740999", update.business().get("id"));
            rejects(() -> buildRequest(SCOPE, "update", body()));
            input.put("id", 123); rejects(() -> buildRequest(SCOPE, "update", input));
        });
        check("all six operation examples build with the expected Actions", () -> {
            for (String op : OPERATIONS) {
                Request request = buildRequest(SCOPE, op, Demo.readObject(root.resolve("examples/" + op + ".json")));
                yes(request.action().contains("McdpCrowd"));
            }
            eq("QueryMcdpCrowdgetmoreentity", buildRequest(SCOPE, "members", Map.of("bizId", "W-test", "lastEntityId", "cursor")).action());
            rejects(() -> buildRequest(SCOPE, "delete-member", Map.of("bizId", "W-test", "entity", "001,002")));
            rejects(() -> buildRequest(SCOPE, "list", Map.of("pageNo", 0)));
        });
        check("STS and UTC timestamps are signed without mutating the plan", () -> {
            Request request = buildRequest(SCOPE, "create", body());
            var signed = signedParameters(request, CREDS, Instant.parse("2026-10-13T01:02:03.456Z"), "nonce-1");
            eq("2026-10-13T01:02:03Z", signed.get("Timestamp")); eq("test-token", signed.get("SecurityToken"));
            eq(sign(signed, CREDS.accessKeySecret(), "POST"), signed.get("Signature"));
            yes(!request.parameters().containsKey("AccessKeyId")); yes(!CREDS.toString().contains("testsecret"));
        });
        check("endpoint validation prevents console and placeholder execution", () -> {
            for (String endpoint : List.of("http://rpc.test/", "https://rpc.test/path", "https://u:p@rpc.test/", "https://rpc.test/?x=1", "https://mpaas.console.alibabacloud.com/")) {
                Scope bad = new Scope("BCO", endpoint, "app", "UAT", "tenant", "cn-hongkong", "2020-10-28", 15000);
                rejects(() -> validateExecution(buildRequest(bad, "create", body())));
            }
            rejects(() -> validateExecution(buildRequest(SCOPE, "detail", Map.of("bizId", "REPLACE_WITH_BIZ_ID"))));
        });
        check("response classification keeps ambiguous outcomes unknown", () -> {
            eq("unknown", classifyResponse(200, "{\"RequestId\":\"r\"}").outcome());
            eq("unknown", classifyResponse(200, "<html>proxy</html>").outcome());
            eq("error", classifyResponse(403, "{\"ResultCode\":\"OK\"}").outcome());
            eq("error", classifyResponse(200, "{\"ResultCode\":\"OK\",\"ResultContent\":\"{\\\"success\\\":false}\"}").outcome());
            Result result = classifyResponse(200, "{\"ResultCode\":\"OK\",\"ResultContent\":{\"data\":\"W-test\"}}");
            eq("acknowledged", result.outcome()); eq("W-test", result.data());
        });
        check("mock transport receives signed form and is never retried", () -> {
            AtomicInteger calls = new AtomicInteger();
            Request request = buildRequest(SCOPE, "create", body());
            Result ok = execute(request, CREDS, (uri, form, timeout) -> {
                calls.incrementAndGet(); eq(SCOPE.endpoint(), uri.toString()); eq(15000, timeout);
                yes(form.contains("Action=CreateMcdpCrowd")); yes(form.contains("Signature=")); yes(form.contains("000001%2C000002"));
                return new WireResponse(200, "{\"ResultCode\":\"OK\",\"RequestId\":\"mock-1\"}");
            });
            eq(1, calls.get()); eq("acknowledged", ok.outcome());
            Result unknown = execute(request, CREDS, (uri, form, timeout) -> { calls.incrementAndGet(); throw new IOException("connection closed"); });
            eq(2, calls.get()); eq("unknown", unknown.outcome());
        });
        check("bounded HTTP response cancels oversized downloads", () -> {
            var subscriber = new BoundedBody(); AtomicInteger cancelled = new AtomicInteger();
            subscriber.onSubscribe(new Flow.Subscription() { public void request(long n) {} public void cancel() { cancelled.incrementAndGet(); } });
            subscriber.onNext(List.of(ByteBuffer.wrap(new byte[MAX_RESPONSE + 1])));
            eq(1, cancelled.get()); yes(subscriber.getBody().toCompletableFuture().isCompletedExceptionally());
        });
        check("source mapping preserves IDs and prevents wrong-target or type updates", () -> {
            var snapshot = Demo.readObject(root.resolve("examples/source-audience.json"));
            var binding = Demo.readObject(root.resolve("examples/binding.example.json"));
            var scope = selectChannel(Demo.readObject(root.resolve("config.example.json")), "BCO");
            Request request = SourceAdapter.prepare(scope, snapshot, null);
            eq("000001,000002", request.business().get("entities")); yes(!request.business().containsKey("sourceSystem"));
            eq("update", SourceAdapter.prepare(scope, snapshot, binding).operation());
            for (String key : List.of("sourceSystem", "sourceAudienceId", "channel", "endpoint", "appId", "tenantId", "workspaceId")) {
                var changed = new LinkedHashMap<>(binding); changed.put(key, "different"); rejects(() -> SourceAdapter.prepare(scope, snapshot, changed));
            }
            var changed = new LinkedHashMap<>(snapshot); changed.put("idType", "device"); rejects(() -> SourceAdapter.prepare(scope, changed, binding));
            for (List<?> ids : List.of(List.of(), List.of(123), List.of("0001,0002"), List.of(" 001"))) {
                changed.put("idType", "user"); changed.put("memberIds", ids); rejects(() -> SourceAdapter.prepare(scope, changed, null));
            }
        });
        check("CLI dry run is credential-free and makes zero transport calls", () -> {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            int code = Demo.run(new String[]{"create", "--channel", "BCO", "--config", root.resolve("config.example.json").toString(),
                    "--payload", root.resolve("examples/create.json").toString()}, (u,f,t) -> { throw new AssertionError("No network expected"); }, Map.of(), new PrintStream(bytes));
            eq(0, code); yes(bytes.toString().contains("\"networkRequests\":0")); yes(!bytes.toString().contains("TEST_USER_001"));
        });
        check("CLI rejects incorrect flags and requires a journal for execution", () -> {
            rejects(() -> Demo.parseArgs(new String[]{"list", "--channel", "BCO", "--payload", "x", "--execute"}));
            rejects(() -> Demo.parseArgs(new String[]{"list", "--channel", "BCO", "--payload", "x", "--excute"}));
            rejects(() -> Demo.parseArgs(new String[]{"list", "--channel", "BCO", "--channel", "BCM", "--payload", "x"}));
        });
        check("CLI reserves a private journal before sending and refuses overwrite", () -> {
            Path dir = Files.createTempDirectory("mcdp-java-tests-");
            try {
                Files.writeString(dir.resolve("config.json"), Json.stringify(config()));
                Files.writeString(dir.resolve("payload.json"), Json.stringify(body()));
                Path journal = dir.resolve("result.jsonl"); AtomicInteger calls = new AtomicInteger();
                String[] cmd = {"create", "--channel", "BCO", "--config", dir.resolve("config.json").toString(), "--payload", dir.resolve("payload.json").toString(),
                        "--execute", "--response-out", journal.toString()};
                Map<String, String> env = Map.of("ALIBABA_CLOUD_ACCESS_KEY_ID", "testid", "ALIBABA_CLOUD_ACCESS_KEY_SECRET", "testsecret");
                ByteArrayOutputStream logged = new ByteArrayOutputStream();
                Transport mock = (u,f,t) -> {
                    calls.incrementAndGet(); yes(Files.readString(journal).contains("request_may_be_sent"));
                    return new WireResponse(200, "{\"ResultCode\":\"OK\",\"ResultContent\":{\"data\":\"W-test\"}}");
                };
                eq(0, Demo.run(cmd, mock, env, new PrintStream(logged))); eq(1, calls.get());
                eq(2, Files.readAllLines(journal).size()); eq("rw-------", PosixFilePermissions.toString(Files.getPosixFilePermissions(journal)));
                yes(!logged.toString().contains("000001")); yes(!logged.toString().contains("testsecret"));
                rejects(() -> Demo.run(cmd, mock, env, new PrintStream(logged))); eq(1, calls.get());
            } finally {
                try (var files = Files.walk(dir)) { for (Path p : files.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); }
            }
        });
        System.out.println("TESTS_OK: " + passed + " offline tests; no live MCDP calls");
    }
}
