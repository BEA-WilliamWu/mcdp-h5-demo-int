#!/usr/bin/env bash
set -euo pipefail
demo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
javac_bin=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_bin=${JAVA_HOME:+$JAVA_HOME/bin/}java
mkdir -p "$demo_dir/build"
test_tmp=$(mktemp -d "$demo_dir/build/test.XXXXXX")
trap 'rm -rf -- "$test_tmp"' EXIT
"$javac_bin" --release 17 -encoding UTF-8 -Xlint:all -d "$test_tmp" \
  "$demo_dir"/src/main/java/demo/mcdp/*.java "$demo_dir"/src/test/java/demo/mcdp/*.java
exec_status=0
"$java_bin" -cp "$test_tmp" demo.mcdp.DemoTests "$demo_dir" || exec_status=$?
exit "$exec_status"
