# mPaaS MCDP Web 集成参考 Demo

版本：2026-08-25  
用途：供 BEA 内网 BCO Web 开发人员验证 mPaaS MCDP 智能投放，并作为项目集成参考。

## 1. 交付内容

本包是一个无需安装依赖、无需构建的 Web Demo：

- `server.mjs`：基于 Node.js 标准库的静态服务和同源转发服务。
- `public/index.html`：完整 Demo 页面及 MCDP 初始化、展位渲染代码。
- `public/vendor/mpaas-mcdp-h5-render/index.js`：mPaaS MCDP Web SDK。
- `docs/mcdpSDK使用说明.md`：SDK 原始使用说明。
- `docs/PROJECT-README.md`：完整项目说明。

本包不包含 `node_modules`、Vite、npm 依赖、Docker/Kubernetes 文件和 App Secret。

## 2. 推荐访问架构

```text
BCO 浏览器
  -> BCO 同源 Web 服务 /mpaas-proxy
  -> ACS mpaas-proxy
  -> MGS / MAS PrivateLink
```

浏览器不应直接访问 MGS/MAS PrivateLink，也不应保存 App Secret。App Secret 只允许配置在 ACS 的 `mpaas-proxy` 服务端 Secret 或环境变量中。

当前 UAT 代理地址：

```text
http://10.23.34.52:443/mpaas-proxy
```

当前已部署 Demo：

```text
http://10.23.34.52:443/mcdp_demo/
```

## 3. Windows 直接运行

要求：Windows 已安装 Node.js 18 或更高版本。

在 PowerShell 中进入解压后的目录：

```powershell
$env:MPAAS_PROXY_URL="http://10.23.34.52:443/mpaas-proxy"
node server.mjs
```

在 Windows CMD 中：

```bat
set MPAAS_PROXY_URL=http://10.23.34.52:443/mpaas-proxy
node server.mjs
```

然后用 Chrome 或 Edge 打开：

```text
http://localhost:5179/mcdp_demo/
```

不要直接双击 `index.html`。通过 `server.mjs` 打开后，请求会先发到本机同源路径，再由 Node 转发到 ACS，避免浏览器跨域和 PrivateLink 直连问题。

## 4. 当前 MCDP 配置

| 参数 | UAT 值 | 说明 |
| --- | --- | --- |
| `appId` | `ALIHK291A058251056` | mPaaS 应用 ID |
| `workspaceId` | `UAT` | 工作空间 |
| `tenantId` | `VEXJGYYS` | 租户 ID |
| `reportURL` | `/mpaas-proxy` | MGS 同源代理路径 |
| `uploadURL` | `/mpaas-proxy/mdap` | MAS 同源代理路径 |
| `userId` | 业务用户标识 | 可用于人群命中，正式项目应传真实且稳定的用户 ID |
| `utdid` | 设备或浏览器标识 | Web 端应生成并持久化稳定标识 |

Demo 使用的展位码：

| 展位 | 展位码 |
| --- | --- |
| 首页轮播 | `home_rotation` |
| 首页公告 | `home_notice` |
| 弹屏 | `popup_banner` |
| 浮标 | `floating_buoy` |

## 5. 最小集成代码

页面中放置展位容器：

```html
<div class="mcdp-view-wrap" data-mcdp-code="home_rotation"></div>
<div class="mcdp-view-wrap" data-mcdp-code="home_notice"></div>
<div class="mcdp-view-wrap" data-mcdp-code="popup_banner"></div>
<div class="mcdp-view-wrap" data-mcdp-code="floating_buoy"></div>
```

加载 SDK 并初始化：

```html
<script src="./vendor/mpaas-mcdp-h5-render/index.js"></script>
<script>
  McdpView.init({
    appId: 'ALIHK291A058251056',
    workspaceId: 'UAT',
    tenantId: 'VEXJGYYS',
    reportURL: location.origin + '/mpaas-proxy',
    uploadURL: location.origin + '/mpaas-proxy/mdap',
    userId: getCurrentUserId(),
    utdid: getStableBrowserId()
  });
</script>
```

BCO 正式集成时需要完成以下工作：

1. 将 SDK 文件纳入 BCO 自身静态资源发布流程。
2. 在需要展示内容的位置加入对应的 `data-mcdp-code` 容器。
3. 登录后传入真实、稳定的 `userId`；浏览器标识作为 `utdid` 持久化。
4. 将 BCO 域名下的 `/mpaas-proxy` 转发到 ACS `mpaas-proxy`。
5. 不要把 App Secret、签名私钥或云账号 AccessKey 写入 HTML/JavaScript。

完整初始化和结果渲染逻辑请查看 `public/index.html`。

## 6. 后台活动要求

页面内容来自 MCDP 后台活动，不是本地 Mock 数据。要正常返回内容，后台至少需要：

1. 创建并启用展位。
2. 创建可访问的图片或自定义素材。
3. 创建“主动营销活动”，关联展位和素材，并确保活动已发布、在有效期内。
4. 活动人群需覆盖测试使用的 `userId`/`utdid`，或配置为适合联调的全量人群。
5. Web SDK 在桌面浏览器中的平台识别可能与后台活动平台条件有关；联调活动建议同时包含 iOS、Android 和 HarmonyOS。

“互动营销活动”通常依赖 MAS 行为事件触发，仅调用展位查询接口不一定会直接返回活动内容。

## 7. 验证真实请求

打开浏览器开发者工具的 Network 面板，刷新页面并确认：

- 出现发往当前站点 `/mpaas-proxy/mgw.htm` 的 MGS 请求。
- HTTP 状态为 `200`，响应中的 `spaceObjectList` 包含对应展位内容。
- 页面轮播、公告、弹屏和浮标内容与 MCDP 后台活动素材一致。
- 曝光、点击等 MAS 请求通过 `/mpaas-proxy/mdap` 上报。

也可以先检查 ACS 代理：

```text
http://10.23.34.52:443/mpaas-proxy/healthz
http://10.23.34.52:443/mpaas-proxy/api/mcdp-proxy-status
```

状态接口只应显示 App Secret 已配置，不应返回完整 Secret。

## 8. 常见问题

| 现象 | 检查项 |
| --- | --- |
| 页面没有发出请求 | 必须通过 Node/Web 服务打开；确认 SDK 文件成功加载，展位容器和展位码存在 |
| 浏览器跨域或请求一直 Pending | 使用站点同源 `/mpaas-proxy`；不要让浏览器直接访问 MGS、MAS 或 PrivateLink IP |
| `/mpaas-proxy` 返回 500 | 检查 ACS 代理 Pod 日志、App Secret、PrivateLink DNS/IP 和 TLS 配置 |
| 请求成功但内容为空 | 检查活动状态、有效期、人群、平台、工作空间及展位素材关联 |
| 提示 public key 未配置 | 检查 MCDP Web SDK 配置和当前应用的加密/验签要求；不要用其他应用的公钥 |
| 弹屏遮挡页面 | Demo 弹屏可点击右上角关闭按钮或遮罩关闭 |

## 9. 安全约束

- 禁止在浏览器代码、Local Storage、日志或截图中保存 App Secret。
- 禁止把阿里云 AccessKey 打进前端包或镜像。
- 正式环境应限制代理允许的来源、请求路径、方法和请求大小，并配置超时、审计日志及限流。
- UAT 参数仅用于联调；生产环境须替换为生产应用、工作空间、租户和代理地址。
