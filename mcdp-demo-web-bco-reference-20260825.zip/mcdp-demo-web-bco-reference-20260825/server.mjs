import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const host = process.env.HOST || "0.0.0.0";
const port = Number(process.env.PORT || 5179);
const proxyTarget = new URL(
  process.env.MPAAS_PROXY_URL || "http://10.23.34.52:443/mpaas-proxy"
);
const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "public");

const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webp": "image/webp"
};

function sendJSON(response, status, payload) {
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8"
  });
  response.end(`${JSON.stringify(payload)}\n`);
}

function serveStatic(request, response, pathname) {
  const relativePath = pathname === "/mcdp_demo/"
    ? "index.html"
    : decodeURIComponent(pathname.slice("/mcdp_demo/".length));
  const filePath = path.resolve(publicDir, relativePath);

  if (filePath !== publicDir && !filePath.startsWith(`${publicDir}${path.sep}`)) {
    sendJSON(response, 403, { success: false, message: "Forbidden" });
    return;
  }

  fs.stat(filePath, (error, stat) => {
    if (error || !stat.isFile()) {
      sendJSON(response, 404, { success: false, message: "Static file not found" });
      return;
    }

    response.writeHead(200, {
      "cache-control": relativePath === "index.html" ? "no-store" : "public, max-age=3600",
      "content-length": stat.size,
      "content-type": mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream"
    });
    fs.createReadStream(filePath).pipe(response);
  });
}

function proxyRequest(request, response, requestURL) {
  const suffix = requestURL.pathname.slice("/mpaas-proxy".length);
  const targetPath = `${proxyTarget.pathname.replace(/\/$/, "")}${suffix || "/"}${requestURL.search}`;
  const headers = { ...request.headers, host: proxyTarget.host };
  delete headers.connection;
  delete headers["content-length"];

  const transport = proxyTarget.protocol === "https:" ? https : http;
  const upstream = transport.request({
    protocol: proxyTarget.protocol,
    hostname: proxyTarget.hostname,
    port: proxyTarget.port || (proxyTarget.protocol === "https:" ? 443 : 80),
    method: request.method,
    path: targetPath,
    headers
  }, (upstreamResponse) => {
    response.writeHead(upstreamResponse.statusCode || 502, upstreamResponse.headers);
    upstreamResponse.pipe(response);
  });

  upstream.on("error", (error) => {
    if (!response.headersSent) {
      sendJSON(response, 502, {
        success: false,
        message: `Cannot reach ACS mPaaS proxy: ${error.message}`,
        target: proxyTarget.toString()
      });
    } else {
      response.destroy(error);
    }
  });

  request.pipe(upstream);
}

const server = http.createServer((request, response) => {
  const requestURL = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);

  if (requestURL.pathname === "/healthz") {
    sendJSON(response, 200, { ok: true });
    return;
  }
  if (requestURL.pathname === "/" || requestURL.pathname === "/mcdp_demo") {
    response.writeHead(307, { location: "/mcdp_demo/" });
    response.end();
    return;
  }
  if (requestURL.pathname.startsWith("/mcdp_demo/")) {
    serveStatic(request, response, requestURL.pathname);
    return;
  }
  if (requestURL.pathname === "/mpaas-proxy" || requestURL.pathname.startsWith("/mpaas-proxy/")) {
    proxyRequest(request, response, requestURL);
    return;
  }

  sendJSON(response, 404, { success: false, message: "Route not found" });
});

server.listen(port, host, () => {
  console.log(`MCDP demo: http://localhost:${port}/mcdp_demo/`);
  console.log(`ACS proxy: ${proxyTarget.toString()}`);
});
