# payment-engine-srv Code Review

## 结论

原代码存在多项会影响支付正确性的高风险问题：受理事件违反数据库非空约束、数据库事务提交前直接发送 MQ、延迟支付调度未启用、CHATS 失败被强制覆盖为成功、EPH 补偿查询使用已删除的 MAIN 字段，以及下游凭据、请求和响应正文可能进入代码库或日志。

本副本按“支付安全优先”完成修复。外部调用继续保持在数据库事务之外；确定结果通过 CAS 更新状态；不确定结果不自动重发支付，而是进入补偿查询或人工复核。

## 已修复问题

| 严重度 | 原问题 | 风险 | 处理 |
|---|---|---|---|
| P0 | 初始 EVENT 未写 `DOWNSTREAM_SYSTEM`、`EVENT_TYPE` | 首笔插入即可违反 NOT NULL | 增加 `PAYMENT_ENGINE / PAYMENT_ACCEPTED` 受理事件并统一初始化 |
| P0 | Submit 在数据库事务提交前直接发送 MQ | Worker 可能读不到 MAIN 后 ACK，形成永久丢单 | Submit 只落库；Scanner 在提交后投递；Worker 对暂不可见状态 recover |
| P0 | LATER 交易扫描任务未启用 | 延迟交易永远不执行 | 恢复可配置 `@Scheduled`，只扫描到期批次 |
| P0 | CHATS 非 `00` 返回仍被强制改成 COMPLETED | 明确失败被记账为成功 | 删除强制成功逻辑，按响应码映射 COMPLETED/FAILED |
| P0 | CHATS/BG3 MAIN 与 EVENT 分开提交，部分 EVENT 又缺必填字段 | 状态与审计证据不一致，或事件插入失败 | 新增执行结果持久化事务，MAIN/EVENT/批次状态原子更新 |
| P0 | CHATS/EPH 结果未知仍可能由 MQ 重发 | 下游已扣款时会重复支付 | CHATS 转人工复核；EPH 写查询标记并 ACK，禁止自动重发 I006 |
| P0 | EPH I005 复用 intake EVENT 并再次插入 | 多个 `order_id=1`，后续 `selectOne` 抛异常 | I005 改为新审计事件，intake 事件保持不可变 |
| P0 | EPH I006 没有查询次数和查询标记闭环 | I037 候选永远选不到 | I006/HTTP 未知事件初始化 query count、eligible time 和 payment source |
| P0 | I037 更新已从 MAIN 删除的 EPH 列 | Oracle 运行时 SQL 失败 | 查询字段只更新 EVENT；MAIN 只更新状态模型字段 |
| P1 | I037 claim 先改 MAIN、后改 EVENT且无事务 | claim 一半成功，交易永久卡住 | EVENT 计数 CAS 与 MAIN 状态在短事务内提交 |
| P1 | 恢复任务使用旧快照 `updateById` | 可把刚完成交易覆盖成人工复核 | 使用 `PROCESSING + cutoff` 条件 CAS，并刷新批次状态 |
| P1 | CHATS pre-check 只看 HTTP 200 | 业务拒绝仍会受理，match key 未保存 | 校验业务响应码并持久化 transaction match key，缺字段时 fail closed |
| P1 | 批量查询 `main.*, event.*` 且逐笔查询事件/批次 | 重复列映射错误和 N+1 性能问题 | 显式选择事件字段；批次摘要和最新事件改为批量加载 |
| P1 | 流控更新为“先查再改”且版本被重复递增 | 并发更新丢失，客户端拿不到版本 | 返回版本号，数据库 CAS，Profile/Param 同事务写入，ID 改 ASSIGN_ID |
| P1 | TT 可受理但没有 Worker 路由 | 永久停留待处理状态 | 从支持枚举和 OpenAPI 中移除，入口直接拒绝 |
| P1 | 明文环境凭据、跳过 TLS、完整报文日志 | 凭据及客户支付数据泄漏、中间人风险 | 配置改环境变量；TLS 默认严格；移除正文、SQL stdout、API header/response 日志 |
| P2 | FPS/CHATS payeeName 校验被注释 | 下游构包失败 | 恢复必填校验；补充 proxy 至少一个识别字段 |
| P2 | LATER 可提交过去日期、批次无上限 | 无意义积压或资源耗尽 | 禁止过去日期；单批最多 1000 笔 |
| P2 | 流控同步硬编码 1 秒 | 多实例产生无谓 DB/Redis 压力 | 改成配置项，默认 60 秒 |
| P2 | Helm Deployment 使用 `apps/v1beta2` | 新版 Kubernetes 无法部署 | Deployment 和 HPA target 改 `apps/v1` |

## 一致性模型

当前采用保守的 at-least-once 投递模型：MAIN 的 `PENDING` 是待投递事实源，Scanner 发送 MQ 后以事务把 MAIN 改为 `QUEUED` 并推进批次指针。MQ 与 Oracle 不是 XA，因此发送成功、DB 更新失败时仍可能产生重复 delivery；Worker 通过 `QUEUED -> PROCESSING` CAS 保证只有一个执行者，`PROCESSING` 的重复消息只 ACK，不重复调用下游。

Worker 在下游调用前 ACK。这样可避免下游已执行但 MQ 回滚后自动重复扣款；代价是 ACK 后进程崩溃会留下 `PROCESSING`，恢复任务会把超时交易转人工复核，而不是自动重放。

## 验证结果

- 全部 203 个 Java 源文件经 tree-sitter Java 解析，无语法错误。
- `application.yml` 与 OpenAPI YAML 均可解析。
- `git diff --check` 通过。
- 新增校验单测覆盖 FPS/CHATS payeeName 与未实现 TT 的拒绝行为。
- Gradle wrapper 已修正执行权限和 CRLF shebang 问题。
- 完整 `compileJava/test` 未能完成：项目依赖企业 Artifactory 中的私有 Gradle 插件，当前环境与该仓库 TLS 握手失败。这是外部依赖访问阻塞，不代表编译已通过。

## 仍需项目方确认

1. 用企业 JDK 17、VPN/证书和 Artifactory 凭据执行 `./gradlew clean test`。
2. 用 CHATS 正式 schema 做 pre-check/confirm 合约测试，确认响应码及 transaction match key 的实际 JSON 路径。
3. 用 Oracle 验证 I037 的 `NVL`、`FETCH FIRST` 和 MyBatis 参数绑定，并跑并发 claim 测试。
4. 用真实 MQ backout/reconnect 场景验证 PENDING visibility window、重复 delivery 和 BOQ 行为。
5. 管理 API 默认关闭；若启用 `pe.flow.admin.enabled=true`，必须由 Spring Security 或网关提供认证授权。
6. 当前工作树已删除明文凭据，但 Git 历史与原目录仍含旧值；应立即轮换对应凭据，并按组织流程清理仓库历史。
7. EPH 审计事件与最终 MAIN CAS 仍不是一个跨 HTTP 的整体事务；若要求严格事件溯源，建议下一阶段引入正式 outbox/event state machine 表。
