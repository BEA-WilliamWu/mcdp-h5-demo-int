# payment-engine-srv

`payment-engine-srv` 是银行支付引擎后端服务，用于接收单笔和批量付款请求，完成参数校验、幂等控制、业务落库、审计记录，并通过 Scanner、IBM MQ、Worker、限流和账户锁机制受控调用下游主机系统。

这个服务不是同步付款接口。提交 API 返回成功只表示请求已经被支付引擎受理并持久化，不表示 BG3 或 EPH 已经完成资金划转。真实付款结果需要通过状态查询接口查看。

## 项目目标

项目的核心目标是做“受控实时”的支付处理：

- 上游可以近实时提交付款请求。
- 支付引擎先把请求安全落库，避免入口阻塞在下游主机调用上。
- Scanner 按批次顺序把交易投递到 MQ。
- Worker 按交易类型、队列优先级、限流额度和付款账号锁执行交易。
- 下游 BG3/EPH 返回后，服务回写交易状态和下游返回字段。
- 上游通过查询 API 获取最终或处理中状态。

核心矛盾是实时性和主机保护。系统必须让上游尽快得到受理结果，同时不能把突发流量直接打到 BG3、EPH 或 CICS 类主机系统。

## 技术栈

| 层面 | 当前使用 |
|---|---|
| 语言 | Java 21 |
| 框架 | Spring Boot 3.5.7 |
| 构建 | Gradle Wrapper / Gradle 8.12 |
| Web | Spring MVC |
| 参数校验 | Spring Validation |
| AOP | Spring AOP |
| ORM | MyBatis-Plus 3.5.16 |
| 数据库 | Oracle JDBC + Flyway |
| Redis | Spring Data Redis + Redisson |
| MQ | IBM MQ JMS starter + Spring JMS |
| 下游 HTTP | BG3 OpenFeign，EPH JDK HttpClient |
| 日志 | Log4j2 |
| API 文档 | SpringDoc OpenAPI / Swagger UI |
| 测试 | JUnit Platform / Spring Boot Test |

## 如何获取项目

需要先准备好 Git、JDK 21 和能访问仓库的 SSH 凭证。

```bash
git clone git@xdogitprd.intranet.hkbea.com:ipe/payment-engine-srv.git
cd payment-engine-srv
```

如果团队使用的是内部镜像或 fork，请将 clone 地址替换为团队提供的仓库地址。

## 构建、测试和打包

项目使用 Gradle Wrapper，不要求本机全局安装 Gradle。

```bash
./gradlew test
./gradlew clean test
./gradlew clean build
./gradlew bootJar
```

构建产物位于：

```text
build/libs/
```

常见用途：

| 命令 | 用途 |
|---|---|
| `./gradlew test` | 运行测试。 |
| `./gradlew clean test` | 清理后运行测试。 |
| `./gradlew clean build` | 编译、测试并构建完整产物。 |
| `./gradlew bootJar` | 生成 Spring Boot 可执行 jar。 |

## 本地启动

启动前需要确认本地或目标环境已经准备好必要依赖：

- JDK 21。
- Oracle 数据库连接。
- Flyway migration 可执行。
- 如果启用 Redis/Redisson、Scanner、Worker 或 IBM MQ，需要准备对应外部服务。
- 如果启用真实 BG3/EPH 调用，需要通过环境变量、Secret 或外部配置注入 endpoint、client id、client secret、证书等敏感配置。

本地直接启动：

```bash
./gradlew bootRun
```

使用已打包 jar 启动：

```bash
java -jar build/libs/payment-engine-srv-0.0.1-SNAPSHOT.jar
```

注意：

- `application.yml` 默认激活 `local` profile。
- 不要把真实数据库密码、Redis 密码、MQ 密钥、BG3/EPH client secret、token 或证书写入仓库。
- `application-local.yml` 用于本地环境，不应随意提交真实配置。
- IBM MQ 默认关闭，只有显式打开配置后才会连接 MQ。

## 整体业务流程

```text
上游系统
  -> 提交 API
  -> Bean Validation + 业务校验
  -> 幂等检查
  -> 写入批次、交易和 API 审计表
  -> 返回受理响应
  -> Scanner 扫描待发送批次
  -> 按批内顺序发送 MqMessage 到 IBM MQ
  -> Worker 按交易类型消费 mq0/mq1
  -> RRateLimiter 限流准入
  -> 获取付款账号锁
  -> 调用 BG3 或 EPH
  -> 回写 MAIN 状态和下游字段
  -> 上游调用结果查询 API
```

### 1. 提交受理

上游通过提交 API 发送单笔或批量付款。Controller 只做协议层工作：接收请求、触发校验、调用 service、返回统一响应。

提交服务负责：

- 基础参数校验。
- 交易类型、渠道、金额、付款人和收款人字段校验。
- 幂等检查。
- 写入 `IPE_PAYMENT_BATCH_HDR`。
- 写入 `IPE_PAYMENT_TXN_MAIN`。
- 写入 `IPE_UPSTREAM_API_AUDIT`。
- 返回批次号、交易号和受理结果。

提交成功后交易通常处于 `PENDING`，等待 Scanner 后续处理。

### 2. Scanner 扫描和 MQ 投递

Scanner 负责把已经落库的交易按顺序投递到 MQ。

关键规则：

- 使用 `lock:scanner` 分布式锁，避免多个 Pod 并发扫描同一批次。
- 优先恢复 `DISPATCHING` 批次，再处理新的 `PENDING` 批次。
- 按 `ORDER_ID` 顺序发送交易。
- 发送成功后更新交易为 `QUEUED`，推进批次头 `MQ_SEND_POINTER`。
- 发送失败时停止本轮扫描，等待后续重试。

### 3. 队列路由

系统按交易类型和渠道选择队列：

| 交易类型 | HTH 优先队列 | 普通队列 |
|---|---|---|
| `INTERNAL` | `internal-mq0` | `internal-mq1` |
| `FPS` | `fps-mq0` | `fps-mq1` |

规则：

- HTH 渠道进入 `mq0`。
- 其他渠道进入 `mq1`。
- Worker 对同一交易类型优先消费 `mq0`，`mq0` 为空再消费 `mq1`。

### 4. Worker 执行

Worker 从 IBM MQ 收到消息后，不直接无条件调用下游。它会先执行保护逻辑：

```text
校验 MQ 消息
  -> 校验 DB 交易状态
  -> 获取交易类型执行锁
  -> RRateLimiter 申请限流许可
  -> 获取付款账号锁
  -> 标记交易 PROCESSING
  -> 调用交易处理器
  -> 明确可以 ACK 后确认 MQ 消息
```

保护规则：

- DB 交易不是可执行状态时，不调用下游。
- 路由不一致或消息非法时，不调用下游。
- 限流无许可时，不调用下游。
- 同一付款账号已有交易处理中时，不并行调用下游。
- 下游结果未知、MQ redelivery、backout、DLQ 和人工处理规则需要按 UAT 和运维规则谨慎确认。

### 5. 下游调用

当前主要下游：

| 交易类型 | 下游 | 说明 |
|---|---|---|
| `INTERNAL` | BG3 / QA3 | 行内转账，当前调用层使用 OpenFeign。 |
| `FPS` | EPH | 跨行 FPS 支付，当前包含 I005/I006 编排和状态查询补偿骨架。 |
| `CHATS` / `TT` | 后续能力 | 当前不进入首期正式下游执行主线。 |

BG3 和 EPH 调用成功或失败后，执行服务会回写交易主表中的状态、错误码、下游返回码、reference 和排障字段。

### 6. 结果查询

当前正式对外闭环是查询 API：

```text
POST /result/query
```

当前代码要求按 `transactionId` 查询。查询 API 是只读接口，不触发 MQ、Worker、BG3、EPH 或查询补偿。

主动回调协议仍未实现。BCO/CDC 回调、签名、重试、SLA 和收费触发仍需要外部确认。

## 主要接口

所有公开业务接口返回统一响应模型 `ApiResponse<T>`，成功业务码为 `00`。请求可携带 `X-RequestId`，未提供时服务端生成 traceId。

| 能力 | 方法和路径 | 说明 |
|---|---|---|
| BCO 单笔提交 | `POST /bulk/single-credit-transfer` | 单笔提交，后端生成 `batchId`。 |
| BCO 批量提交 | `POST /bulk/multiple-credit-transfer` | 批量提交，调用方传入 `batchId`。 |
| 外部渠道提交 | `POST /outward/credit-transfer` | 外部渠道单笔或批量提交。 |
| 结果查询 | `POST /result/query` | 按 `transactionId` 查询交易结果和批次摘要。 |
| 流控配置查询 | `POST /api/flow-control/profile/query` | 内部管理接口，隐藏于 OpenAPI。 |
| 流控配置创建 | `POST /api/flow-control/profile/create` | 内部管理接口，隐藏于 OpenAPI。 |
| 流控配置更新 | `POST /api/flow-control/profile/update` | 内部管理接口，隐藏于 OpenAPI。 |
| 手工 BG3 触发 | `POST /api/local-e2e/bg3/execute` | 隐藏联调接口，需要显式打开配置。 |
| 手工 EPH 触发 | `POST /api/local-e2e/eph/execute` | 隐藏联调接口，需要显式打开配置。 |

Swagger 地址：

```text
http://localhost:8080/swagger-ui/index.html
http://localhost:8080/v3/api-docs
```

## 状态机

批次状态：

```text
PENDING -> DISPATCHING -> COMPLETED / PARTIAL_FAILED
```

交易状态：

```text
PENDING -> QUEUED -> PROCESSING -> COMPLETED / FAILED / NSF
```

状态说明：

| 状态 | 对象 | 含义 |
|---|---|---|
| `PENDING` | batch/txn | 已落库，等待 Scanner。 |
| `DISPATCHING` | batch | Scanner 正在发送或等待断点恢复。 |
| `QUEUED` | txn | 已投递 MQ，等待 Worker。 |
| `PROCESSING` | txn | Worker 已进入执行阶段或下游结果闭环阶段。 |
| `COMPLETED` | batch/txn | 明确成功。 |
| `FAILED` | txn | 明确失败，或按当前规则记录为失败。 |
| `NSF` | txn | 余额不足。 |
| `PARTIAL_FAILED` | batch | 批次内部分交易失败。 |

## 数据库

数据库 schema 通过 Flyway 管理，迁移文件位于：

```text
src/main/resources/db/migration/
```

核心表：

| 表 | 用途 |
|---|---|
| `IPE_PAYMENT_BATCH_HDR` | 批次头表，保存批次状态、总笔数、总金额、Scanner 断点 `MQ_SEND_POINTER` 等。 |
| `IPE_PAYMENT_TXN_MAIN` | 交易主表，保存交易状态、付款/收款字段、金额、下游返回字段、错误字段和补偿字段。 |
| `IPE_UPSTREAM_API_AUDIT` | 上游 API 审计表，记录请求、响应、trace、耗时和业务主键。 |
| `IPE_FLOW_CONTROL_PROFILE` | 流控 profile。 |
| `IPE_FLOW_CONTROL_PARAM` | 流控参数，运行时同步到 Redisson `RRateLimiter`。 |

当前迁移版本覆盖：

- 初始化核心表、索引和 sequence。
- 批次头 `API_SOURCE`、`MQ_SEND_POINTER`。
- EPH I005/I006 输入、返回和查询补偿字段。
- BG3 返回字段和请求补充字段。

不要修改已经执行过的历史 migration。新增字段、索引或约束应创建新的 Flyway migration。

## 项目目录和包结构

根目录：

```text
.
├── AGENTS.md
├── README.md
├── build.gradle
├── settings.gradle
├── gradlew
├── docs/
├── src/
│   ├── main/
│   │   ├── java/com/bea/payment/
│   │   └── resources/
│   └── test/
└── gradle/
```

Java 主包：

```text
src/main/java/com/bea/payment
├── Application.java
├── bulk
│   ├── annotation
│   ├── api
│   ├── aspect
│   ├── config
│   ├── constants
│   ├── mapper
│   ├── model
│   │   ├── dto
│   │   └── entity
│   ├── service
│   ├── service/impl
│   ├── validator
│   └── internal
│       ├── bg3
│       │   ├── client
│       │   ├── config
│       │   └── model
│       ├── eph
│       │   ├── config
│       │   ├── model
│       │   ├── query
│       │   └── xml
│       └── flow
│           ├── cache
│           ├── config
│           ├── loader
│           ├── model
│           ├── mq
│           ├── ratelimit
│           ├── scanner
│           ├── util
│           └── worker
└── common
    ├── advice
    ├── async
    ├── config
    ├── constants
    ├── context
    ├── exception
    ├── filter
    ├── logging
    ├── mybatis
    ├── response
    └── util
```

包职责：

| 包 | 职责 |
|---|---|
| `com.bea.payment.Application` | Spring Boot 启动入口，启用 MyBatis mapper scan 和 BG3 Feign client scan。 |
| `bulk.api` | REST Controller，接收提交、查询、流控管理和手工触发请求。 |
| `bulk.service` / `bulk.service.impl` | 业务编排，包括提交、查询、下游执行等。 |
| `bulk.validator` | 业务校验和跨字段校验。 |
| `bulk.mapper` | MyBatis-Plus mapper。 |
| `bulk.model.dto` | API 请求和响应 DTO。 |
| `bulk.model.entity` | 数据库实体。 |
| `bulk.constants` | 业务枚举和常量。 |
| `bulk.internal.flow` | Scanner、MQ routing、IBM MQ adapter、Worker、限流、流控配置缓存。 |
| `bulk.internal.bg3` | BG3/QA3 internal transfer 调用链、Feign client、DTO 和状态回写。 |
| `bulk.internal.eph` | EPH I005/I006 XML 编排、执行服务、查询补偿骨架。 |
| `common.response` | 统一 API 响应模型。 |
| `common.exception` | `BaseException`、`BusinessException`、`ValidationException`、`SystemException`。 |
| `common.advice` | 全局异常处理和响应封装。 |
| `common.context` / `common.filter` | traceId、请求上下文和 filter。 |
| `common.logging` | API 日志、访问日志和敏感信息处理。 |
| `common.mybatis` | MyBatis-Plus 审计字段自动填充。 |
| `common.async` | 异步线程上下文传递。 |
| `common.util` | 日期时间等通用工具。 |

## 项目基座能力

### 统一响应

公开业务接口使用 `ApiResponse<T>`：

- `code`
- `message`
- `data`
- `traceId`
- `timestamp`

业务成功码为 `00`。业务校验失败、业务拒绝和系统异常通过统一异常处理映射为标准响应。

### 异常体系

项目异常层级：

```text
BaseException
├── BusinessException
├── ValidationException
└── SystemException
```

使用原则：

- 参数或业务校验失败使用 validation 相关机制。
- 状态冲突、幂等冲突、业务拒绝使用 `BusinessException`。
- 技术依赖失败或不可恢复异常使用 `SystemException` 或由全局异常处理兜底。

### Trace 和请求上下文

请求可传入 `X-RequestId`。未传时服务端生成 traceId。traceId 会进入：

- API 响应。
- 日志。
- API 审计。
- 请求上下文。

异步执行通过上下文装饰器传递必要上下文。

### 审计和日志

项目包含：

- API 请求/响应日志。
- API 访问耗时日志。
- 慢接口阈值配置。
- `IPE_UPSTREAM_API_AUDIT` 审计表。
- MyBatis-Plus 自动填充创建人、创建时间、更新时间、软删除和版本字段。

日志不得输出真实密码、client secret、token、证书、完整账号等敏感信息。

### 限流和锁

限流使用 Redisson `RRateLimiter`，不是手工 TokenBucket。

当前规则：

- 首期限流交易类型为 `INTERNAL` 和 `FPS`。
- 流控 profile/param 从数据库加载。
- `RatePolicySync` 将有效策略同步到 Redis。
- 无匹配窗口、非法配置、Redis 异常等情况 fail closed，不调用下游。
- 同一付款账号跨 `INTERNAL` 和 `FPS` 不允许并行执行。

### IBM MQ

IBM MQ 当前作为正式 MQ 路径。Local MQ runtime 已下线。

当前规则：

- IBM MQ 默认关闭。
- 不使用 CCDT。
- UAT/生产按 MQ 团队提供的 host、port/connName、queue manager、channel、队列和安全参数直连。
- Producer 校验队列 allowlist 和消息必填字段。
- Consumer/Worker 的 redelivery、backout、DLQ、poison message 和人工处理流程仍需要 UAT 证据和运维规则确认。

## 配置说明

主要配置文件：

```text
src/main/resources/application.yml
src/main/resources/application-local.yml
```

共享默认配置放在 `application.yml`。本地 profile 使用 `application-local.yml`。

关键配置域：

| 前缀 | 说明 |
|---|---|
| `spring.datasource` | Oracle 数据库连接。 |
| `spring.flyway` | Flyway migration。 |
| `bulk.eph` | EPH endpoint、path、接口标识、timeout、TLS hostname verification。 |
| `bulk.bg3` | BG3 base url、path、timeout、client id/secret、控制字段。 |
| `pe.ibm-mq` | IBM MQ 总开关、consumer、worker、真实 processor 开关。 |
| `pe.mq` | MQ allowlist 和队列名。 |
| `pe.rate-limit` | 限流支持交易类型。 |
| `pe.scanner` | Scanner 调度间隔。 |
| `payment.api.log` | API 日志开关和慢接口阈值。 |
| `payment.channel` | 渠道白名单。 |

敏感值必须通过环境变量、Secret 或部署平台配置注入，不写入仓库。

## 当前边界和已知未完成项

当前已经具备：

- 付款提交、校验、幂等、落库和审计。
- 查询 API。
- Flow control profile 管理和 `RRateLimiter` 基础设施。
- Scanner 第一阶段。
- IBM MQ producer、receive client 和 Worker orchestrator 第一版。
- BG3 Feign 调用层、执行服务和手工触发接口。
- EPH I005/I006 编排、执行服务、查询补偿骨架和手工触发接口。

仍需外部确认或后续生产化：

- IBM MQ UAT/生产连接参数、TLS/证书、Secret 管理。
- IBM MQ redelivery、backout count、backout queue/DLQ、poison message 和清理责任。
- `PROCESSING` 超时恢复和人工处理闭环。
- BG3 timeout/IO 后人工处理 SLA。
- EPH 查询接口契约、认证、容量、最大查询次数和 SLA。
- BCO/CDC 主动回调协议。
- EBK 每日限额校验和 SO3 手续费接口资料。

## 开发注意事项

- 不要提交真实密码、client secret、token、证书、生产 endpoint 或完整账号。
- 不要随意修改 `application-local.yml`。
- 不要修改已执行过的历史 Flyway migration。
- 不要把提交 API 设计成同步等待下游完成。
- 不要在未确认 MQ/下游契约前宣称 Worker 生产闭环完成。
- 不要把 Local MQ 当作当前正式运行路径。

## 更多文档

仓库内还有更细的设计、交付和运行文档：

```text
docs/
├── README.md
├── delivery/
├── design/
├── runbook/
├── interface-spec/
└── archive/
```

如果只想了解项目全貌，先读本 README 即可。需要评审设计、排查联调或追溯历史时，再进入 `docs/` 查阅对应专题文档。
