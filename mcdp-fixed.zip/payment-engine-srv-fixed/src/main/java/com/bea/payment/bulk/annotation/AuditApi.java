package com.bea.payment.bulk.annotation;

import com.bea.payment.bulk.constants.ApiNameEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface AuditApi {
    ApiNameEnum value();
}
