package com.bea.payment.bulk.api;


import com.bea.payment.bulk.model.dto.FlowControlProfileCreateRequest;
import com.bea.payment.bulk.model.dto.FlowControlProfileQueryRequest;
import com.bea.payment.bulk.model.dto.FlowControlProfileResponse;
import com.bea.payment.bulk.model.dto.FlowControlProfileUpdateRequest;
import com.bea.payment.bulk.service.FlowControlProfileService;
import com.bea.payment.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Hidden;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Flow Control Profile 管理 API
 */
@RestController
@RequestMapping("/api/flow-control/profile")
@Hidden
@ConditionalOnProperty(prefix = "pe.flow.admin", name = "enabled", havingValue = "true")
public class FlowControlProfileController {

    private final FlowControlProfileService service;

    public FlowControlProfileController(FlowControlProfileService service) { this.service = service; }

    @PostMapping("/query")
    public ApiResponse<List<FlowControlProfileResponse>> query(@RequestBody FlowControlProfileQueryRequest request) {
        return ApiResponse.success(
                service.queryProfiles(request)
        );
    }

    @PostMapping("/create")
    public ApiResponse<Void> create(@RequestBody FlowControlProfileCreateRequest request) {
        service.createProfile(request);
        return ApiResponse.success(null);
    }

    @PostMapping("/update")
    public ApiResponse<Void> update(@RequestBody FlowControlProfileUpdateRequest request) {
        service.updateProfile(request);
        return ApiResponse.success(null);
    }
}
