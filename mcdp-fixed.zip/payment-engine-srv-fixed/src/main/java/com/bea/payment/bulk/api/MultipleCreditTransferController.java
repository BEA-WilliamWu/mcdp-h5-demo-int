package com.bea.payment.bulk.api;

import com.bea.payment.bulk.annotation.AuditApi;
import com.bea.payment.bulk.model.dto.BatchCreditTransferRequest;
import com.bea.payment.bulk.model.dto.SubmitResponse;
import com.bea.payment.bulk.service.PaymentSubmitService;
import com.bea.payment.bulk.constants.ApiNameEnum;
import com.bea.payment.common.constants.HeaderConstants;
import com.bea.payment.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bulk")
@Tag(name = PaymentApiExamples.TAG)
public class MultipleCreditTransferController {

    private final PaymentSubmitService service;

    public MultipleCreditTransferController(PaymentSubmitService service) {
        this.service = service;
    }

    @AuditApi(ApiNameEnum.MULTIPLE_CREDIT_TRANSFER)
    @Operation(
            operationId = "submitMultipleCreditTransfers",
            summary = "Submit multiple credit transfers",
            description = """
                    Accepts a BCO payment batch and transaction details. After validating totals, counts, and identifiers, the service persists the batch for controlled dispatch.

                    When batch `transactionType=FPS`, each detail must provide `fps`; these fields are persisted to MAIN as EPH I005/I006 API input.

                    When batch `transactionType=INTERNAL`, `fps` must be omitted. BG3 control fields come from IPE configuration, and BG3 response fields are written back to MAIN only after downstream execution.

                    Transactions receive `orderId` according to request order. Acceptance does not represent final posting.
                    """,
            parameters = @Parameter(
                    name = HeaderConstants.TRACE_ID,
                    in = ParameterIn.HEADER,
                    description = PaymentApiExamples.REQUEST_ID_DESCRIPTION,
                    example = "31dfd480-3fb3-4eb3-bd26-9a7c92761645"
            )
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            required = true,
            description = "Batch payment submission request; successful submission means acceptance and persistence only",
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = BatchCreditTransferRequest.class),
                    examples = @ExampleObject(name = "FPS payroll via EPH", value = PaymentApiExamples.MULTIPLE_REQUEST)
            )
    )
    @ApiResponses(@io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200",
            description = PaymentApiExamples.BUSINESS_RESPONSE_DESCRIPTION,
            useReturnTypeSchema = true,
            headers = @Header(
                    name = HeaderConstants.TRACE_ID,
                    description = "Request correlation identifier",
                    schema = @Schema(type = "string")
            ),
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    examples = {
                            @ExampleObject(name = "Accepted", value = PaymentApiExamples.ACCEPTED_RESPONSE),
                            @ExampleObject(name = "Validation failed", value = PaymentApiExamples.VALIDATION_FAILURE_RESPONSE),
                            @ExampleObject(name = "Duplicate request", value = PaymentApiExamples.DUPLICATE_FAILURE_RESPONSE)
                    }
            )
    ))
    @PostMapping("/multiple-credit-transfer")
    public ApiResponse<SubmitResponse> submit(@RequestBody BatchCreditTransferRequest request) {
        SubmitResponse response = service.submitMultiple(request);
        return ApiResponse.success(response);
    }
}
