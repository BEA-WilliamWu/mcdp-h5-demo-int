package com.bea.payment.bulk.api;

import com.bea.payment.bulk.annotation.AuditApi;
import com.bea.payment.bulk.callback.H2hOnlineOutwardResponse;
import com.bea.payment.bulk.callback.H2hOnlineOutwardService;
import com.bea.payment.bulk.model.dto.BatchCreditTransferRequest;
import com.bea.payment.bulk.constants.ApiNameEnum;
import com.bea.payment.common.constants.HeaderConstants;
import com.bea.payment.common.response.ApiResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/outward")
@Tag(name = PaymentApiExamples.TAG)
public class OutwardCreditTransferController {

    private final H2hOnlineOutwardService service;

    public OutwardCreditTransferController(H2hOnlineOutwardService service) {
        this.service = service;
    }

    @AuditApi(ApiNameEnum.OUTWARD_CREDIT_TRANSFER)
    @Operation(
            operationId = "submitOutwardCreditTransfer",
            summary = "Submit outward credit transfer",
            description = """
                    Accepts outward payment submissions from whitelisted channels, with one or multiple details, and persists them in the common batch model for controlled processing.

                    For `transactionType=FPS`, each detail must provide `fps`; for `transactionType=INTERNAL`, `fps` must be omitted and BG3 control fields are supplied by IPE configuration.

                    The caller provides `batchId` and each `transactionId`; identifiers must carry the same prefix as the channel.

                    Successful acceptance only means the request is persisted for Scanner/Worker processing; it does not indicate downstream payment completion.
                    """,
            parameters = @Parameter(
                    name = HeaderConstants.TRACE_ID,
                    in = ParameterIn.HEADER,
                    description = PaymentApiExamples.REQUEST_ID_DESCRIPTION,
                    example = "31dfd480-3fb3-4eb3-bd26-9a7c92761645"
            )
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            required = true,
            description = "Outward payment submission request; successful submission means acceptance and persistence only",
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = BatchCreditTransferRequest.class),
                    examples = @ExampleObject(name = "INTERNAL via BG3", value = PaymentApiExamples.OUTWARD_REQUEST)
            )
    )
    @ApiResponses(@io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200",
            description = PaymentApiExamples.BUSINESS_RESPONSE_DESCRIPTION,
            useReturnTypeSchema = true,
            headers = @Header(
                    name = HeaderConstants.TRACE_ID,
                    description = "Request correlation identifier",
                    schema = @Schema(type = "string")
            ),
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    examples = {
                            @ExampleObject(name = "Accepted", value = PaymentApiExamples.ACCEPTED_RESPONSE),
                            @ExampleObject(name = "Validation failed", value = PaymentApiExamples.VALIDATION_FAILURE_RESPONSE),
                            @ExampleObject(name = "Duplicate request", value = PaymentApiExamples.DUPLICATE_FAILURE_RESPONSE)
                    }
            )
    ))
    @PostMapping("/credit-transfer")
    public ApiResponse<?> submit(@RequestBody BatchCreditTransferRequest request) {
        H2hOnlineOutwardResponse response = service.submit(request);
        return ApiResponse.success(response.body());
    }
}
