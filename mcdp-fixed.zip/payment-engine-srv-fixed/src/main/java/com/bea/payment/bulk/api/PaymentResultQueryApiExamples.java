package com.bea.payment.bulk.api;

final class PaymentResultQueryApiExamples {

    static final String TAG = "Payment Result Enquiry";

    static final String QUERY_REQUEST = """
            {
              "batchId": "BCO20260604103025000001"
            }
            """;

    static final String QUERY_RESPONSE = """
            {
              "code": "00",
              "message": "Success",
              "data": [
                {
                  "transactionId": "BCO20260604103025000002",
                  "ipeReferenceId": "018f6a12-6f7b-7a91-9c2d-8e3f4a5b6c7d",
                  "batchId": "BCO20260604103025000001",
                  "batchStatus": "DISPATCHED",
                  "batchTerminal": false,
                  "channel": "BCO",
                  "channelReference": "PAY-REF-000001",
                  "transactionType": "FPS",
                  "status": "PROCESSING",
                  "terminal": false,
                  "statusReason": "EPH_QUERY_PENDING",
                  "amount": 10000.00,
                  "currency": "HKD",
                  "downstreamSystem": "EPH",
                  "downstreamReference": "FPS-REF-202606040001",
                  "errorCode": "EPH_TIMEOUT",
                  "errorMessage": "EPH request timed out",
                  "lastUpdatedAt": "2026-06-04T10:35:25+08:00"
                }
              ],
              "traceId": "31dfd480-3fb3-4eb3-bd26-9a7c92761645",
              "timestamp": "2026-06-04T10:35:25.118+08:00"
            }
            """;

    private PaymentResultQueryApiExamples() {
    }
}
