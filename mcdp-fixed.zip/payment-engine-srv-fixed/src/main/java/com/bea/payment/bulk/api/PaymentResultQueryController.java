package com.bea.payment.bulk.api;

import com.bea.payment.bulk.model.dto.PaymentResultQueryRequest;
import com.bea.payment.bulk.model.dto.PaymentResultQueryResponse;
import com.bea.payment.bulk.service.PaymentResultQueryService;
import com.bea.payment.common.constants.HeaderConstants;
import com.bea.payment.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/result")
@Tag(name = PaymentResultQueryApiExamples.TAG)
public class PaymentResultQueryController {

    private final PaymentResultQueryService service;

    public PaymentResultQueryController(PaymentResultQueryService service) {
        this.service = service;
    }

    @Operation(
            operationId = "queryPaymentResults",
            summary = "Query payment result",
            description = """
                    Provides a formal upstream enquiry API for payment transaction results.

                    Provide `batchId` to return all transactions in the batch. Provide `transactionId`
                    to return one simplified transaction result. When both are provided, `transactionId`
                    takes precedence. The response data is always a list.

                    The response exposes only external-facing business fields: identifiers, normalized status,
                    terminal-state judgement, amount/currency, downstream system/reference, error summary and
                    last update time. It does not expose internal batch status, worker attempts, MQ internals,
                    EPH I005/I006 details, BG3 detail fields, query-compensation internals, account numbers,
                    endpoints, certificates, Redis keys, lock keys or exception stacks.

                    This API is read-only and does not trigger callback, Scanner, Worker, MQ, BG3, EPH,
                    or EPH status-query compensation.
                    """,
            parameters = @Parameter(
                    name = HeaderConstants.TRACE_ID,
                    in = ParameterIn.HEADER,
                    description = PaymentApiExamples.REQUEST_ID_DESCRIPTION,
                    example = "31dfd480-3fb3-4eb3-bd26-9a7c92761645"
            )
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            required = true,
            description = "Payment result enquiry request. Provide transactionId or batchId.",
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResultQueryRequest.class),
                    examples = @ExampleObject(name = "Query by batchId",
                            value = PaymentResultQueryApiExamples.QUERY_REQUEST)
            )
    )
    @ApiResponses(@io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200",
            description = PaymentApiExamples.BUSINESS_RESPONSE_DESCRIPTION,
            useReturnTypeSchema = true,
            headers = @Header(
                    name = HeaderConstants.TRACE_ID,
                    description = "Request correlation identifier",
                    schema = @Schema(type = "string")
            ),
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    examples = @ExampleObject(name = "Payment result",
                            value = PaymentResultQueryApiExamples.QUERY_RESPONSE)
            )
    ))
    @PostMapping("/query")
    public ApiResponse<List<PaymentResultQueryResponse>> query(@RequestBody PaymentResultQueryRequest request) {
        return ApiResponse.success(service.query(request));
    }
}
