package com.bea.payment.bulk.api;

import com.bea.payment.bulk.annotation.AuditApi;
import com.bea.payment.bulk.constants.ApiNameEnum;
import com.bea.payment.bulk.model.dto.SingleCreditTransferRequest;
import com.bea.payment.bulk.model.dto.SubmitResponse;
import com.bea.payment.bulk.service.PaymentSubmitService;
import com.bea.payment.common.constants.HeaderConstants;
import com.bea.payment.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bulk")
@Tag(name = PaymentApiExamples.TAG)
public class SingleCreditTransferController {

    private final PaymentSubmitService service;

    public SingleCreditTransferController(PaymentSubmitService service) {
        this.service = service;
    }

    @AuditApi(ApiNameEnum.SINGLE_CREDIT_TRANSFER)
    @Operation(
            operationId = "submitSingleCreditTransfer",
            summary = "Submit single credit transfer",
            description = """
                    Accepts one BCO payment transaction, creates a batch after validation, and persists it for downstream processing.

                    `transactionType=FPS` is treated as EPH FPS payment in the first release and requires EPH I005/I006 input fields under `fps`.

                    `transactionType=INTERNAL` enters the BG3/QA3 internal-transfer flow. BG3 control fields are supplied by IPE configuration, not by this submission API.

                    Acceptance does not represent final settlement. Consumers should retain `batchId` and `traceId` for subsequent enquiry and audit.
                    """,
            parameters = @Parameter(
                    name = HeaderConstants.TRACE_ID,
                    in = ParameterIn.HEADER,
                    description = PaymentApiExamples.REQUEST_ID_DESCRIPTION,
                    example = "31dfd480-3fb3-4eb3-bd26-9a7c92761645"
            )
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            required = true,
            description = "Single payment submission request; successful submission means acceptance and persistence only",
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = SingleCreditTransferRequest.class),
                    examples = @ExampleObject(name = "FPS via EPH", value = PaymentApiExamples.SINGLE_REQUEST)
            )
    )
    @ApiResponses(@io.swagger.v3.oas.annotations.responses.ApiResponse(
            responseCode = "200",
            description = PaymentApiExamples.BUSINESS_RESPONSE_DESCRIPTION,
            useReturnTypeSchema = true,
            headers = @Header(
                    name = HeaderConstants.TRACE_ID,
                    description = "Request correlation identifier",
                    schema = @Schema(type = "string")
            ),
            content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    examples = {
                            @ExampleObject(name = "Accepted", value = PaymentApiExamples.ACCEPTED_RESPONSE),
                            @ExampleObject(name = "Validation failed", value = PaymentApiExamples.VALIDATION_FAILURE_RESPONSE),
                            @ExampleObject(name = "Duplicate request", value = PaymentApiExamples.DUPLICATE_FAILURE_RESPONSE)
                    }
            )
    ))
    @PostMapping("/single-credit-transfer")
    public ApiResponse<SubmitResponse> submit(@RequestBody SingleCreditTransferRequest request) {
        SubmitResponse response = service.submitSingle(request);
        return ApiResponse.success(response);
    }
}
