package com.bea.payment.bulk.aspect;

import com.bea.payment.bulk.annotation.AuditApi;
import com.bea.payment.bulk.constants.ApiNameEnum;
import com.bea.payment.bulk.model.entity.UpstreamApiAuditEntity;
import com.bea.payment.bulk.service.UpstreamApiAuditService;
import com.bea.payment.common.context.RequestContextHolder;
import com.bea.payment.common.logging.ApiLogUtils;
import com.bea.payment.common.response.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Date;

/**
 * API 审计切面。
 *
 * <p>拦截标记了 {@link AuditApi} 的接口调用，记录请求、响应、耗时、traceId
 * 以及批次号或交易号等审计字段，便于后续排查和追踪。</p>
 *
 * <p>审计保存走异步线程，避免阻塞主接口链路；保存失败只记录日志，不影响接口返回。</p>
 */
@Aspect
@Component
public class AuditApiAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditApiAspect.class);

    private final UpstreamApiAuditService auditService;
    private final ApiLogUtils apiLogUtils;
    private final ThreadPoolTaskExecutor paymentTaskExecutor;

    public AuditApiAspect(UpstreamApiAuditService auditService,
                          ApiLogUtils apiLogUtils,
                          ThreadPoolTaskExecutor paymentTaskExecutor) {
        this.auditService = auditService;
        this.apiLogUtils = apiLogUtils;
        this.paymentTaskExecutor = paymentTaskExecutor;
    }

    /**
     * 执行接口审计。
     *
     * <p>方法正常返回时记录响应体和结果码；方法抛出异常时记录异常摘要后继续抛出原异常。</p>
     */
    @Around("@annotation(auditApi)")
    public Object audit(ProceedingJoinPoint joinPoint, AuditApi auditApi) throws Throwable {
        Date requestTime = new Date();
        long startTime = System.currentTimeMillis();
        String requestBody = apiLogUtils.toMaskedJsonSafely(joinPoint.getArgs());

        Object result;
        try {
            result = joinPoint.proceed();
        } catch (Throwable ex) {
            // 异常场景也写审计，再把原异常交给全局异常处理。
            long duration = System.currentTimeMillis() - startTime;
            Date responseTime = new Date();
            asyncSave(buildAudit(auditApi.value(), requestTime, responseTime, duration,
                    requestBody, "\"<exception: " + apiLogUtils.maskText(ex.getMessage()) + ">\"", null, null),
                    "exception");
            throw ex;
        }
        long duration = System.currentTimeMillis() - startTime;
        Date responseTime = new Date();
        String responseBody = apiLogUtils.toMaskedJsonSafely(result);

        String batchId = null;
        String transactionId = null;
        String resultCode = null;

        if (result instanceof ApiResponse<?> apiResp) {
            resultCode = apiResp.getCode();
        }

        ApiNameEnum apiName = auditApi.value();
        if (joinPoint.getArgs().length > 0) {
            Object req = joinPoint.getArgs()[0];
            batchId = invokeStringGetter(req, "getBatchId");
            if (apiName == ApiNameEnum.SINGLE_CREDIT_TRANSFER) {
                transactionId = invokeStringGetter(req, "getTransactionId");
            }
        }

        UpstreamApiAuditEntity audit = buildAudit(apiName, requestTime, responseTime, duration,
                requestBody, responseBody, batchId, transactionId);
        audit.setResultCode(resultCode);

        asyncSave(audit, "success");

        return result;
    }

    private String invokeStringGetter(Object target, String methodName) {
        try {
            Object val = target.getClass().getMethod(methodName).invoke(target);
            return val instanceof String s ? s : null;
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }
    /**
     * 构造审计实体。
     *
     * <p>这里仅做字段汇总，不访问数据库；traceId 优先从请求上下文中读取。</p>
     */
    private UpstreamApiAuditEntity buildAudit(ApiNameEnum apiName,
                                               Date requestTime, Date responseTime, long durationMs,
                                               String requestBody, String responseBody,
                                               String batchId, String transactionId) {
        HttpServletRequest request = currentRequest();
        String traceId = getTraceId();

        UpstreamApiAuditEntity audit = new UpstreamApiAuditEntity();
        audit.setApiName(apiName.getCode());
        audit.setApiPath(request != null ? request.getRequestURI() : null);
        audit.setHttpMethod("POST");
        audit.setChannel(extractChannel(batchId));
        audit.setRequestId(traceId);
        audit.setBusinessType(null); // set by caller if needed
        audit.setBatchId(batchId);
        audit.setTransactionId(transactionId);
        audit.setProcessDurationMs(durationMs);
        audit.setTraceId(traceId);
        audit.setRequestTime(requestTime);
        audit.setResponseTime(responseTime);
        audit.setRequestBodyRaw(requestBody);
        audit.setResponseBodyRaw(responseBody);
        return audit;
    }

    /**
     * 异步保存审计记录。
     *
     * <p>审计失败不能影响主交易链路，因此这里只记录错误日志。</p>
     */
    private void asyncSave(UpstreamApiAuditEntity audit, String context) {
        try {
            paymentTaskExecutor.execute(() -> {
                try {
                    auditService.save(audit);
                } catch (Exception e) {
                    log.error("AUDIT_SAVE_FAILED context={}, apiName={}, batchId={}, error={}",
                            context, audit.getApiName(), audit.getBatchId(), e.getMessage(), e);
                }
            });
        } catch (Exception e) {
            log.error("AUDIT_SUBMIT_FAILED context={}, apiName={}, error={}",
                    context, audit.getApiName(), e.getMessage(), e);
        }
    }

    /**
     * 获取当前 HTTP 请求。
     */
    private HttpServletRequest currentRequest() {
        var attr = org.springframework.web.context.request.RequestContextHolder.getRequestAttributes();
        if (attr instanceof ServletRequestAttributes sra) {
            return sra.getRequest();
        }
        return null;
    }

    /**
     * 获取当前 traceId。
     */
    private String getTraceId() {
        var ctx = RequestContextHolder.get();
        return ctx != null ? ctx.getTraceContext().getTraceId() : null;
    }

    /**
     * 从 batchId 中提取渠道前缀。
     *
     * <p>例如 HTH20240601001 提取为 HTH。</p>
     */
    private String extractChannel(String batchId) {
        if (batchId != null && batchId.length() >= 3) {
            return batchId.substring(0, 3);
        }
        return null;
    }
}
