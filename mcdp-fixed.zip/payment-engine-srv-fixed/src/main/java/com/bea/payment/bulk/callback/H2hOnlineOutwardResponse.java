package com.bea.payment.bulk.callback;

public record H2hOnlineOutwardResponse(Object body, boolean hthOnline) {
}
