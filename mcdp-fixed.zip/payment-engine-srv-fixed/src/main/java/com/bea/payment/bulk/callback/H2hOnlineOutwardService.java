package com.bea.payment.bulk.callback;

import com.bea.payment.bulk.constants.ChannelEnum;
import com.bea.payment.bulk.constants.TimeOfTransferEnum;
import com.bea.payment.bulk.internal.chats.ChatsHttpClient;
import com.bea.payment.bulk.internal.chats.ChatsPaymentOrchestrator;
import com.bea.payment.bulk.internal.chats.config.ChatsProperties;
import com.bea.payment.bulk.internal.chats.model.ChatsPerCheckTransferRequest;
import com.bea.payment.bulk.model.dto.*;
import com.bea.payment.bulk.service.PaymentResultQueryService;
import com.bea.payment.bulk.service.PaymentSubmitService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

import static com.bea.payment.common.util.DateTimeUtils.toIntegerDate;
import static com.bea.payment.common.util.StringUtil.getPart;

@Service
public class H2hOnlineOutwardService {

    private static final Logger log = LoggerFactory.getLogger(H2hOnlineOutwardService.class);

    private final PaymentSubmitService submitService;
    private final PaymentResultQueryService resultQueryService;
    private final PaymentCallbackProperties properties;

    public H2hOnlineOutwardService(PaymentSubmitService submitService,
                                   PaymentResultQueryService resultQueryService,
                                   PaymentCallbackTaskService callbackTaskService,
                                   PaymentCallbackProperties properties) {
        this.submitService = Objects.requireNonNull(submitService, "submitService must not be null");
        this.resultQueryService = Objects.requireNonNull(resultQueryService, "resultQueryService must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
    }

    public H2hOnlineOutwardResponse submit(BatchCreditTransferRequest request) {

        boolean hthOnline = isHthOnline(request);
        SubmitResponse accepted = submitService.submitOutward(request);
        if (!hthOnline) {
            return new H2hOnlineOutwardResponse(accepted, false);
        }

        // HTH online 只给单笔 NOW 交易一个短等待窗口；不把下游慢调用绑在 API 线程上。
        String transactionId = request.getTransactions().get(0).getTransactionId();
        PaymentResultQueryResponse result = waitForCurrentResult(transactionId);
        if (Boolean.TRUE.equals(result.getTerminal())) {
            log.info("[HTH-ONLINE] terminal result returned within wait window: transactionId={}, status={}",
                    transactionId, result.getStatus());
            return new H2hOnlineOutwardResponse(result, true);
        }

        return new H2hOnlineOutwardResponse(result, true);
    }

    private PaymentResultQueryResponse waitForCurrentResult(String transactionId) {
        Duration timeout = positiveOrDefault(properties.getHthOnlineWaitTimeout(), Duration.ofSeconds(5));
        Duration interval = positiveOrDefault(properties.getPollInterval(), Duration.ofMillis(200));
        Instant deadline = Instant.now().plus(timeout);
        PaymentResultQueryResponse last = resultQueryService.queryByTransactionId(transactionId);

        // 轮询查询口径结果；只要进入终态就立即返回，超时则返回最后一次非终态快照。
        while (!Boolean.TRUE.equals(last.getTerminal()) && Instant.now().isBefore(deadline)) {
            sleep(interval, deadline);
            last = resultQueryService.queryByTransactionId(transactionId);
        }
        return last;
    }

    private void sleep(Duration interval, Instant deadline) {
        long remainingMillis = Duration.between(Instant.now(), deadline).toMillis();
        long sleepMillis = Math.min(interval.toMillis(), Math.max(remainingMillis, 0L));
        if (sleepMillis <= 0L) {
            return;
        }
        try {
            Thread.sleep(sleepMillis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private boolean isHthOnline(BatchCreditTransferRequest request) {
        if (request == null) {
            return false;
        }
        List<TransactionDetailRequest> transactions = request.getTransactions();
        return ChannelEnum.HTH.getCode().equalsIgnoreCase(nullToEmpty(request.getChannel()))
                && TimeOfTransferEnum.NOW.getCode().equalsIgnoreCase(nullToEmpty(request.getTimeOfTransfer()))
                && transactions != null
                && transactions.size() == 1;
    }

    private Duration positiveOrDefault(Duration value, Duration fallback) {
        return value == null || value.isZero() || value.isNegative() ? fallback : value;
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
