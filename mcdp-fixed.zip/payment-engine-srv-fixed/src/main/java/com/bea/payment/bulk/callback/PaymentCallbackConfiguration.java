package com.bea.payment.bulk.callback;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(PaymentCallbackProperties.class)
public class PaymentCallbackConfiguration {
}
