package com.bea.payment.bulk.callback;

import com.bea.payment.bulk.model.dto.PaymentResultQueryResponse;
import com.bea.payment.common.response.StandardResultCode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Objects;

@Component
public class PaymentCallbackHttpClient {

    private static final int MAX_RESPONSE_LENGTH = 4000;

    private final PaymentCallbackProperties properties;
    private final ObjectMapper objectMapper;

    public PaymentCallbackHttpClient(PaymentCallbackProperties properties,
            ObjectMapper objectMapper) {
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper must not be null");
    }

    public PaymentCallbackHttpResult postResult(String callbackUrl, PaymentResultQueryResponse payload) {
        RestTemplate restTemplate = new RestTemplateBuilder()
                .connectTimeout(properties.getConnectTimeout())
                .readTimeout(properties.getReadTimeout())
                .build();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        HttpEntity<PaymentResultQueryResponse> entity = new HttpEntity<>(payload, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(callbackUrl, entity, String.class);
            String responseBody = truncate(response.getBody(), MAX_RESPONSE_LENGTH);
            if (!response.getStatusCode().is2xxSuccessful()) {
                return new PaymentCallbackHttpResult(false, response.getStatusCode().value(), responseBody,
                        null, "CALLBACK_HTTP_STATUS", "Callback HTTP status is not 2xx");
            }
            return validateBody(response.getStatusCode().value(), responseBody);
        } catch (RestClientException e) {
            return new PaymentCallbackHttpResult(false, null, null, null,
                    "CALLBACK_HTTP_ERROR", truncate(e.getMessage(), 1000));
        }
    }

    private PaymentCallbackHttpResult validateBody(int httpStatus, String responseBody) {
        if (responseBody == null || responseBody.isBlank()) {
            return new PaymentCallbackHttpResult(false, httpStatus, responseBody, null,
                    "CALLBACK_EMPTY_RESPONSE", "Callback response body is required");
        }
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            String code = text(root, "code");
            String message = text(root, "message");
            if (code == null || code.isBlank()) {
                return new PaymentCallbackHttpResult(false, httpStatus, responseBody, null,
                        "CALLBACK_RESPONSE_CODE_MISSING", "Callback ApiResponse code is required");
            }
            if (!StandardResultCode.SUCCESS.getCode().equals(code)) {
                return new PaymentCallbackHttpResult(false, httpStatus, responseBody, code,
                        "CALLBACK_RESPONSE_FAILURE",
                        truncate(firstText(message, "Callback ApiResponse indicates failure"), 1000));
            }
            return new PaymentCallbackHttpResult(true, httpStatus, responseBody, code, null, null);
        } catch (JsonProcessingException e) {
            return new PaymentCallbackHttpResult(false, httpStatus, responseBody, null,
                    "CALLBACK_RESPONSE_PARSE_FAILED", truncate(e.getMessage(), 1000));
        }
    }

    private String text(JsonNode root, String fieldName) {
        if (root == null || root.get(fieldName) == null || root.get(fieldName).isNull()) {
            return null;
        }
        return root.get(fieldName).asText();
    }

    private String firstText(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        return value.substring(0, maxLength);
    }
}
