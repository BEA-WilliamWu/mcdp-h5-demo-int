package com.bea.payment.bulk.callback;

public record PaymentCallbackHttpResult(
        boolean success,
        Integer httpStatus,
        String responseBody,
        String actualStatus,
        String errorCode,
        String errorMessage) {
}
