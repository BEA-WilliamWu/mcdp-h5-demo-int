package com.bea.payment.bulk.callback;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

@ConfigurationProperties(prefix = "pe.callback")
@Getter
@Setter
public class PaymentCallbackProperties {

    private boolean enabled = true;
    private Duration hthOnlineWaitTimeout = Duration.ofSeconds(5);
    private Duration pollInterval = Duration.ofMillis(200);
    private int maxAttempts = 5;
    private Duration backoffBaseInterval = Duration.ofMinutes(1);
    private Duration inProgressTimeout = Duration.ofMinutes(10);
    private Duration connectTimeout = Duration.ofSeconds(3);
    private Duration readTimeout = Duration.ofSeconds(5);
    private boolean savePayload = true;
    private boolean maskPayload = true;
    private Scheduler scheduler = new Scheduler();

    @Getter
    @Setter
    public static class Scheduler {
        private boolean enabled = true;
        private Duration fixedDelay = Duration.ofSeconds(30);
        private int maxTasksPerRun = 50;
    }
}
