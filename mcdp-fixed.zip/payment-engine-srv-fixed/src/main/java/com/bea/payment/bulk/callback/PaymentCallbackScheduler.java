package com.bea.payment.bulk.callback;

import com.bea.payment.bulk.model.entity.PaymentCallbackTaskEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Component
public class PaymentCallbackScheduler {

    private static final Logger log = LoggerFactory.getLogger(PaymentCallbackScheduler.class);

    private final PaymentCallbackTaskService taskService;
    private final PaymentCallbackProperties properties;

    public PaymentCallbackScheduler(PaymentCallbackTaskService taskService,
            PaymentCallbackProperties properties) {
        this.taskService = Objects.requireNonNull(taskService, "taskService must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
    }
}
