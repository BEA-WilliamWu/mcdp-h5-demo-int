package com.bea.payment.bulk.callback;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.CallbackStatusEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.mapper.PaymentCallbackAttemptMapper;
import com.bea.payment.bulk.mapper.PaymentCallbackTaskMapper;
import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.BatchCreditTransferRequest;
import com.bea.payment.bulk.model.dto.PaymentResultQueryResponse;
import com.bea.payment.bulk.model.entity.PaymentCallbackAttemptEntity;
import com.bea.payment.bulk.model.entity.PaymentCallbackTaskEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.service.PaymentResultQueryService;
import com.bea.payment.common.logging.SensitiveDataMasker;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
public class PaymentCallbackTaskService {

    private static final Logger log = LoggerFactory.getLogger(PaymentCallbackTaskService.class);
    private static final String NOT_DELETED = "N";
    private static final String YES = "Y";
    private static final String NO = "N";
    private static final String CREATING = "P";
    private static final String ATTEMPT_SUCCESS = "SUCCESS";
    private static final String ATTEMPT_FAILED = "FAILED";
    private static final int MAX_PAYLOAD_LENGTH = 4000;
    private static final int MAX_ERROR_LENGTH = 1000;

    private final PaymentCallbackTaskMapper taskMapper;
    private final PaymentCallbackAttemptMapper attemptMapper;
    private final PaymentTxnMainMapper txnMainMapper;
    private final PaymentTxnEventMapper eventMapper;
    private final PaymentResultQueryService resultQueryService;
    private final PaymentCallbackHttpClient httpClient;
    private final PaymentCallbackProperties properties;
    private final ObjectMapper objectMapper;
    private final SensitiveDataMasker sensitiveDataMasker;
    private final TransactionTemplate transactionTemplate;

    public PaymentCallbackTaskService(PaymentCallbackTaskMapper taskMapper,
                                      PaymentCallbackAttemptMapper attemptMapper,
                                      PaymentTxnMainMapper txnMainMapper, PaymentTxnEventMapper eventMapper,
                                      PaymentResultQueryService resultQueryService,
                                      PaymentCallbackHttpClient httpClient,
                                      PaymentCallbackProperties properties,
                                      ObjectMapper objectMapper,
                                      SensitiveDataMasker sensitiveDataMasker,
                                      TransactionTemplate transactionTemplate) {
        this.taskMapper = Objects.requireNonNull(taskMapper, "taskMapper must not be null");
        this.attemptMapper = Objects.requireNonNull(attemptMapper, "attemptMapper must not be null");
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.eventMapper = Objects.requireNonNull(eventMapper, "eventMapper must not be null");
        this.resultQueryService = Objects.requireNonNull(resultQueryService, "resultQueryService must not be null");
        this.httpClient = Objects.requireNonNull(httpClient, "httpClient must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper must not be null");
        this.sensitiveDataMasker = Objects.requireNonNull(sensitiveDataMasker, "sensitiveDataMasker must not be null");
        this.transactionTemplate = Objects.requireNonNull(transactionTemplate, "transactionTemplate must not be null");
    }

    /**
     * 领取到期 callback task。
     *
     * <p>这里的事务只包住“查一条可执行 task + 标记 IN_PROGRESS”的短操作。
     * SQL 使用 Oracle {@code FOR UPDATE SKIP LOCKED}，多 Pod 会跳过彼此锁住的行，
     * 减少同时拿到同一批 task 后空转。</p>
     */
    @Transactional
    public List<PaymentCallbackTaskEntity> claimDueTasks(Date now, int limit) {
        closeExhaustedTasks(now);
        List<PaymentCallbackTaskEntity> claimed = new ArrayList<>();
        int max = Math.max(limit, 1);
        for (int i = 0; i < max; i++) {
            Date claimTime = Date.from(Instant.now());
            Date staleInProgressCutoff = new Date(claimTime.getTime() - inProgressTimeoutMillis());
            PaymentCallbackTaskEntity task = taskMapper.selectOneDueTaskForUpdate(claimTime, staleInProgressCutoff);
            if (task == null) {
                break;
            }
            int attemptNo = safeInt(task.getAttemptCount()) + 1;
            // claimToken 是本次执行权凭证；HTTP 回来更新结果时必须带上它，防止旧 Pod 覆盖新结果。
            String claimToken = UUID.randomUUID().toString();
            int updated = taskMapper.update(null, new LambdaUpdateWrapper<PaymentCallbackTaskEntity>()
                    .eq(PaymentCallbackTaskEntity::getCallbackTaskId, task.getCallbackTaskId())
                    .eq(PaymentCallbackTaskEntity::getIsDeleted, NOT_DELETED)
                    .apply("NVL(ATTEMPT_COUNT, 0) < NVL(MAX_ATTEMPTS, 1)")
                    .and(wrapper -> dueTaskCondition(wrapper, claimTime, staleInProgressCutoff))
                    .set(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.IN_PROGRESS.getCode())
                    .set(PaymentCallbackTaskEntity::getAttemptCount, attemptNo)
                    .set(PaymentCallbackTaskEntity::getLastAttemptTime, claimTime)
                    .set(PaymentCallbackTaskEntity::getClaimToken, claimToken)
                    .set(PaymentCallbackTaskEntity::getLastUpdateDate, claimTime));
            if (updated == 1) {
                task.setCallbackStatus(CallbackStatusEnum.IN_PROGRESS.getCode());
                task.setAttemptCount(attemptNo);
                task.setLastAttemptTime(claimTime);
                task.setClaimToken(claimToken);
                claimed.add(task);
            }
        }
        return claimed;
    }

    /**
     * 收口已经耗尽次数的历史或异常任务。
     *
     * <p>claim 阶段会预增 attemptCount。若最后一次执行的 Pod 在 HTTP 调用后挂死，
     * task 可能停在 IN_PROGRESS 且次数已耗尽。这里不再重新回调，而是把它关闭为失败。</p>
     */
    private void closeExhaustedTasks(Date now) {
        Date staleInProgressCutoff = new Date(now.getTime() - inProgressTimeoutMillis());
        taskMapper.update(null, new LambdaUpdateWrapper<PaymentCallbackTaskEntity>()
                .eq(PaymentCallbackTaskEntity::getIsDeleted, NOT_DELETED)
                .apply("NVL(ATTEMPT_COUNT, 0) >= NVL(MAX_ATTEMPTS, 1)")
                .and(wrapper -> wrapper
                        .in(PaymentCallbackTaskEntity::getCallbackStatus,
                                CallbackStatusEnum.PENDING.getCode(), CallbackStatusEnum.RETRY.getCode())
                        .or()
                        .eq(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.IN_PROGRESS.getCode())
                        .le(PaymentCallbackTaskEntity::getLastAttemptTime, staleInProgressCutoff))
                .set(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.CALLBACK_FAILED.getCode())
                .set(PaymentCallbackTaskEntity::getCompletedTime, now)
                .set(PaymentCallbackTaskEntity::getNextRetryTime, null)
                .set(PaymentCallbackTaskEntity::getLastErrorCode, "CALLBACK_ATTEMPTS_EXHAUSTED")
                .set(PaymentCallbackTaskEntity::getLastErrorMessage, "Callback attempts exhausted")
                .set(PaymentCallbackTaskEntity::getClaimToken, null)
                .set(PaymentCallbackTaskEntity::getLastUpdateDate, now));
    }

    /**
     * 执行一条已领取的 callback task。
     *
     * <p>task 理论上只会在 MAIN 终态后创建。这里仍保留一次防御性终态检查：
     * 如果发现非终态，只释放 task 并记录日志，不插入 attempt。</p>
     */
    public void processTask(PaymentCallbackTaskEntity task) {
        PaymentResultQueryResponse payload = resultQueryService.queryByTransactionId(task.getTransactionId());
        if (!Boolean.TRUE.equals(payload.getTerminal())) {
            releaseUnexpectedNonTerminalTask(task, payload);
            return;
        }

        int attemptNo = safeInt(task.getAttemptCount());
        Date startedAt = new Date();
        PaymentCallbackHttpResult result = httpClient.postResult(task.getCallbackUrl(), payload);
        Date finishedAt = new Date();
        String storedPayload = serializeForStorage(payload);
        completeAttempt(task, attemptNo, payload, result, storedPayload, startedAt, finishedAt);
    }

    /**
     * task 到期领取条件。
     *
     * <p>PENDING/RETRY 到期可以领取；IN_PROGRESS 超过超时时间说明原 Pod 可能崩溃，
     * 允许其他 Pod 重新领取。</p>
     */
    private void dueTaskCondition(LambdaUpdateWrapper<PaymentCallbackTaskEntity> wrapper, Date now,
            Date staleInProgressCutoff) {
        wrapper.in(PaymentCallbackTaskEntity::getCallbackStatus,
                        CallbackStatusEnum.PENDING.getCode(), CallbackStatusEnum.RETRY.getCode())
                .le(PaymentCallbackTaskEntity::getNextRetryTime, now)
                .or()
                .eq(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.IN_PROGRESS.getCode())
                .le(PaymentCallbackTaskEntity::getLastAttemptTime, staleInProgressCutoff);
    }

    /**
     * 防御性释放异常的非终态 task。
     *
     * <p>该路径不算一次真实 HTTP 回调，因此不写 attempt，只把 task 放回 PENDING 等下轮再看。</p>
     */
    private void releaseUnexpectedNonTerminalTask(PaymentCallbackTaskEntity task, PaymentResultQueryResponse payload) {
        Date nextRetryTime = new Date(System.currentTimeMillis() + pollIntervalMillis());
        int updated = taskMapper.update(null, new LambdaUpdateWrapper<PaymentCallbackTaskEntity>()
                .eq(PaymentCallbackTaskEntity::getCallbackTaskId, task.getCallbackTaskId())
                .eq(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.IN_PROGRESS.getCode())
                .eq(PaymentCallbackTaskEntity::getClaimToken, task.getClaimToken())
                .set(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.PENDING.getCode())
                .set(PaymentCallbackTaskEntity::getAttemptCount, Math.max(safeInt(task.getAttemptCount()) - 1, 0))
                .set(PaymentCallbackTaskEntity::getNextRetryTime, nextRetryTime)
                .set(PaymentCallbackTaskEntity::getLastResultStatus, payload.getStatus())
                .set(PaymentCallbackTaskEntity::getLastErrorCode, "CALLBACK_RESULT_NON_TERMINAL")
                .set(PaymentCallbackTaskEntity::getLastErrorMessage, "Current payment result is not terminal")
                .set(PaymentCallbackTaskEntity::getLastPayload, serializeForStorage(payload))
                .set(PaymentCallbackTaskEntity::getClaimToken, null));
        if (updated == 1) {
            log.warn("[CALLBACK] Claimed callback task found non-terminal result, release without attempt: taskId={}, transactionId={}, status={}",
                    task.getCallbackTaskId(), task.getTransactionId(), payload.getStatus());
        } else {
            log.warn("[CALLBACK] Skip releasing non-terminal callback task because claim was lost: taskId={}, transactionId={}",
                    task.getCallbackTaskId(), task.getTransactionId());
        }
    }

    /**
     * 构造 attempt 公共字段。
     */
    private PaymentCallbackAttemptEntity baseAttempt(PaymentCallbackTaskEntity task, int attemptNo,
            PaymentResultQueryResponse payload, Date startedAt) {
        PaymentCallbackAttemptEntity attempt = new PaymentCallbackAttemptEntity();
        attempt.setCallbackTaskId(task.getCallbackTaskId());
        attempt.setTransactionId(task.getTransactionId());
        attempt.setAttemptNo(attemptNo);
        attempt.setCallbackUrl(task.getCallbackUrl());
        attempt.setExpectedStatus(payload.getStatus());
        attempt.setStartedAt(startedAt);
        return attempt;
    }

    /**
     * 保存一次 HTTP 回调结果，并推进 task 状态。
     *
     * <p>先按 claimToken 更新 task，成功后才插入 attempt。这样即使原 Pod 的 claim
     * 已经被超时回收，也不会留下重复 attemptNo。该短事务不包含 HTTP 调用。</p>
     */
    private void completeAttempt(PaymentCallbackTaskEntity task, int attemptNo, PaymentResultQueryResponse payload,
            PaymentCallbackHttpResult result, String storedPayload, Date startedAt, Date finishedAt) {
        transactionTemplate.executeWithoutResult(status -> {
            int updated = result.success()
                    ? markSucceeded(task, payload, result, storedPayload, finishedAt)
                    : markFailedOrRetry(task, payload, result, storedPayload, finishedAt, attemptNo);
            if (updated == 0) {
                log.warn("[CALLBACK] Skip attempt insert because callback task claim was lost: taskId={}, transactionId={}, attemptNo={}",
                        task.getCallbackTaskId(), task.getTransactionId(), attemptNo);
                return;
            }

            PaymentCallbackAttemptEntity attempt = baseAttempt(task, attemptNo, payload, startedAt);
            attempt.setRequestPayload(storedPayload);
            attempt.setHttpStatus(result.httpStatus());
            attempt.setResponseBody(result.responseBody());
            attempt.setActualStatus(result.actualStatus());
            attempt.setAttemptStatus(result.success() ? ATTEMPT_SUCCESS : ATTEMPT_FAILED);
            attempt.setErrorCode(result.errorCode());
            attempt.setErrorMessage(truncate(result.errorMessage(), MAX_ERROR_LENGTH));
            attempt.setFinishedAt(finishedAt);
            attemptMapper.insert(attempt);
        });
    }

    /**
     * HTTP 回调成功后关闭 task。
     */
    private int markSucceeded(PaymentCallbackTaskEntity task, PaymentResultQueryResponse payload,
            PaymentCallbackHttpResult result, String storedPayload, Date finishedAt) {
        return taskMapper.update(null, new LambdaUpdateWrapper<PaymentCallbackTaskEntity>()
                .eq(PaymentCallbackTaskEntity::getCallbackTaskId, task.getCallbackTaskId())
                .eq(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.IN_PROGRESS.getCode())
                .eq(PaymentCallbackTaskEntity::getClaimToken, task.getClaimToken())
                .set(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.CALLBACK_SUCCEEDED.getCode())
                .set(PaymentCallbackTaskEntity::getLastAttemptTime, finishedAt)
                .set(PaymentCallbackTaskEntity::getCompletedTime, finishedAt)
                .set(PaymentCallbackTaskEntity::getLastResultStatus, payload.getStatus())
                .set(PaymentCallbackTaskEntity::getLastHttpStatus, result.httpStatus())
                .set(PaymentCallbackTaskEntity::getLastErrorCode, null)
                .set(PaymentCallbackTaskEntity::getLastErrorMessage, null)
                .set(PaymentCallbackTaskEntity::getLastResponseBody, result.responseBody())
                .set(PaymentCallbackTaskEntity::getLastPayload, storedPayload)
                .set(PaymentCallbackTaskEntity::getClaimToken, null));
    }

    /**
     * HTTP 回调失败后进入 RETRY，或在次数耗尽后关闭为 CALLBACK_FAILED。
     */
    private int markFailedOrRetry(PaymentCallbackTaskEntity task, PaymentResultQueryResponse payload,
            PaymentCallbackHttpResult result, String storedPayload, Date finishedAt, int attemptNo) {
        boolean exhausted = attemptNo >= maxAttempts(task);
        return taskMapper.update(null, new LambdaUpdateWrapper<PaymentCallbackTaskEntity>()
                .eq(PaymentCallbackTaskEntity::getCallbackTaskId, task.getCallbackTaskId())
                .eq(PaymentCallbackTaskEntity::getCallbackStatus, CallbackStatusEnum.IN_PROGRESS.getCode())
                .eq(PaymentCallbackTaskEntity::getClaimToken, task.getClaimToken())
                .set(PaymentCallbackTaskEntity::getCallbackStatus, exhausted
                        ? CallbackStatusEnum.CALLBACK_FAILED.getCode()
                        : CallbackStatusEnum.RETRY.getCode())
                .set(PaymentCallbackTaskEntity::getLastAttemptTime, finishedAt)
                .set(PaymentCallbackTaskEntity::getCompletedTime, exhausted ? finishedAt : null)
                .set(PaymentCallbackTaskEntity::getNextRetryTime, exhausted ? null : nextRetryTime(attemptNo))
                .set(PaymentCallbackTaskEntity::getLastResultStatus, payload.getStatus())
                .set(PaymentCallbackTaskEntity::getLastHttpStatus, result.httpStatus())
                .set(PaymentCallbackTaskEntity::getLastErrorCode, result.errorCode())
                .set(PaymentCallbackTaskEntity::getLastErrorMessage,
                        truncate(result.errorMessage(), MAX_ERROR_LENGTH))
                .set(PaymentCallbackTaskEntity::getLastResponseBody, result.responseBody())
                .set(PaymentCallbackTaskEntity::getLastPayload, storedPayload)
                .set(PaymentCallbackTaskEntity::getClaimToken, null));
    }

    private Date nextRetryTime(int failedAttemptNo) {
        Duration base = properties.getBackoffBaseInterval();
        if (base == null || base.isZero() || base.isNegative()) {
            base = Duration.ofMinutes(1);
        }
        long multiplier = 1L << Math.min(Math.max(failedAttemptNo - 1, 0), 20);
        return new Date(System.currentTimeMillis() + base.toMillis() * multiplier);
    }

    private long pollIntervalMillis() {
        Duration interval = properties.getPollInterval();
        if (interval == null || interval.isZero() || interval.isNegative()) {
            return Duration.ofMillis(200).toMillis();
        }
        return interval.toMillis();
    }

    private long inProgressTimeoutMillis() {
        Duration timeout = properties.getInProgressTimeout();
        if (timeout == null || timeout.isZero() || timeout.isNegative()) {
            return Duration.ofMinutes(10).toMillis();
        }
        return timeout.toMillis();
    }

    private String serializeForStorage(PaymentResultQueryResponse payload) {
        if (!properties.isSavePayload()) {
            return null;
        }
        Object value = properties.isMaskPayload() ? sensitiveDataMasker.mask(payload) : payload;
        try {
            return truncate(objectMapper.writeValueAsString(value), MAX_PAYLOAD_LENGTH);
        } catch (JsonProcessingException e) {
            return "{\"error\":\"payload serialization failed\"}";
        }
    }

    private int safeInt(Integer value) {
        return value == null ? 0 : value;
    }

    private int maxAttempts(PaymentCallbackTaskEntity task) {
        if (task == null || task.getMaxAttempts() == null) {
            return Math.max(properties.getMaxAttempts(), 1);
        }
        return Math.max(task.getMaxAttempts(), 1);
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        return value.substring(0, maxLength);
    }
}
