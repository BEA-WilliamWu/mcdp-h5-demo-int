package com.bea.payment.bulk.config;

import lombok.Getter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Getter
public class ChannelWhitelistConfig {

    private final Set<String> whitelist;

    public ChannelWhitelistConfig(
            @Value("${pe.channel.whitelist:BCO,HTH}") String channels) {
        this.whitelist = Arrays.stream(channels.split(","))
                .map(String::trim)
                .map(String::toUpperCase)
                .collect(Collectors.toSet());
    }

    public boolean isValid(String channel) {
        return channel != null && whitelist.contains(channel.toUpperCase());
    }

}
