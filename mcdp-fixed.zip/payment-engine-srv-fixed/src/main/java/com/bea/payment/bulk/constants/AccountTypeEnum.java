package com.bea.payment.bulk.constants;


import lombok.Getter;
@Getter
public enum AccountTypeEnum {
    SSA("SSA", "Saving Account"),
    CUR("CUR", "Current Account");

    private final String code;
    private final String value;

    AccountTypeEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

}