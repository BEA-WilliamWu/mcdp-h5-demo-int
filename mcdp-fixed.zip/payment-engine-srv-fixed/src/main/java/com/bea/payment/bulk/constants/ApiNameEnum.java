package com.bea.payment.bulk.constants;


import lombok.Getter;
@Getter
public enum ApiNameEnum {

    SINGLE_CREDIT_TRANSFER("SINGLE_CREDIT_TRANSFER"),
    MULTIPLE_CREDIT_TRANSFER("MULTIPLE_CREDIT_TRANSFER"),
    OUTWARD_CREDIT_TRANSFER("OUTWARD_CREDIT_TRANSFER");

    private final String code;

    ApiNameEnum(String code) { this.code = code; }

}
