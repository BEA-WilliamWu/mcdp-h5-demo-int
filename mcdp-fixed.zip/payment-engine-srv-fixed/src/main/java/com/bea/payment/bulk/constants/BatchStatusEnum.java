package com.bea.payment.bulk.constants;


import lombok.Getter;
@Getter
public enum BatchStatusEnum {

    PENDING("PENDING"),
    DISPATCHING("DISPATCHING"),
    DISPATCHED("DISPATCHED"),
    COMPLETED("COMPLETED"),
    ALL_FAILED("ALL_FAILED"),
    PARTIAL_SUCCESS("PARTIAL_SUCCESS"),
    UNKNOWN("UNKNOWN"),
    MANUAL_REVIEW("MANUAL_REVIEW");

    private final String code;

    BatchStatusEnum(String code) { this.code = code; }

}
