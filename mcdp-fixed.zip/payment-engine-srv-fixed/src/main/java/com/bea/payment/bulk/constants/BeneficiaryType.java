package com.bea.payment.bulk.constants;


import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.StandardResultCode;

public enum BeneficiaryType {

    ACCOUNT,
    FPS,
    MOBILE,
    EMAIL;

    public static BeneficiaryType from(String value) {
        if (value == null || value.isBlank()) {
            throw new BusinessException(
                    StandardResultCode.INVALID_PAYEE,
                    "payee.payeeType is required"
            );
        }

        try {
            return BeneficiaryType.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new BusinessException(
                    StandardResultCode.INVALID_PAYEE,
                    "unsupported payee.payeeType: " + value
            );
        }
    }
}