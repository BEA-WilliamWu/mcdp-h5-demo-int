package com.bea.payment.bulk.constants;

import lombok.Getter;

@Getter
public enum CallbackStatusEnum {

    PENDING("PENDING"),
    IN_PROGRESS("IN_PROGRESS"),
    RETRY("RETRY"),
    CALLBACK_SUCCEEDED("CALLBACK_SUCCEEDED"),
    CALLBACK_FAILED("CALLBACK_FAILED");

    private final String code;

    CallbackStatusEnum(String code) {
        this.code = code;
    }
}
