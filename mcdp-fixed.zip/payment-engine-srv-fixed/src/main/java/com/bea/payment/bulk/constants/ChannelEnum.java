package com.bea.payment.bulk.constants;

import lombok.Getter;

import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
public enum ChannelEnum {

    BCO("BCO"),
    HTH("HTH");

    private final String code;

    private static final Set<String> CODE_SET =
            Arrays.stream(values()).map(ChannelEnum::getCode).collect(Collectors.toSet());

    ChannelEnum(String code) { this.code = code; }

    public static boolean isValid(String channel) {
        return channel != null && CODE_SET.contains(channel.toUpperCase());
    }

    public static void validate(String channel) {
        if (!isValid(channel)) {
            throw new ValidationException(
                    StandardResultCode.INVALID_CHANNEL,
                    "Invalid channel: " + channel + ", allowed: " + CODE_SET
            );
        }
    }
}
