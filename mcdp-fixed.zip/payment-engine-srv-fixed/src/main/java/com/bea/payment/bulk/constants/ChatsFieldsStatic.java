package com.bea.payment.bulk.constants;

import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
public class ChatsFieldsStatic {

    public static final String HDR_CH_SRC_IND = "I";

    public static final String HDR_MESSAGE_ID_HTCC1 = "HTCC1";
    public static final String HDR_MESSAGE_ID_HTC02 = "HTC02";

    public static final String HDR_BANK_CODE = "015";

    public static final String HDR_INT_BANK_CODE = "01";

    public static final String HDR_MEDIA_CODE = "CDC";

    public static final String HDR_RT_TIMEOUT_FLG = "0";

    public static final Integer HDR_COMP_CODE = 1;

    public static final String HDR_INPUT_USER_ID = "  ";

    public static final String HDR_TXN_NUMBER = "00000000000000000000000000000000000";

    public static final Integer REL_AC_SEQ = 0;

    public static final Integer REL_AC_STATUS = 0;

    public static final String RESEND_FLAG = "1";

    public static final BigDecimal CHRG_DISC_RATE = BigDecimal.ZERO;


}
