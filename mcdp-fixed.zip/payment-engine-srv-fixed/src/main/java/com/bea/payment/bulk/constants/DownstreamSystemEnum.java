package com.bea.payment.bulk.constants;


import lombok.Getter;
/**
 * 下游系统枚举。
 *
 * <p>用于标识支付交易调用的外部下游系统。</p>
 */
@Getter
public enum DownstreamSystemEnum {

    /** Payment Engine 自身产生的受理事件。 */
    PAYMENT_ENGINE("PAYMENT_ENGINE"),

    /** BG3 内部转账系统（z/OS Mainframe） */
    BG3("BG3"),

    /** EPH 快速支付系统（FPS即时支付） */
    EPH("EPH"),

    /** CHATS 香港本地支付系统 */
    CHATS("CHATS");

    private final String code;

    DownstreamSystemEnum(String code) {
        this.code = code;
    }

    /**
     * 根据代码值获取对应的下游系统枚举。
     *
     * @param value 下游系统代码（如 "BG3"、"EPH"）
     * @return 对应的枚举值
     * @throws IllegalArgumentException 如果代码值无效
     */
    public static DownstreamSystemEnum from(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Downstream system code is required");
        }
        for (DownstreamSystemEnum system : values()) {
            if (system.code.equalsIgnoreCase(value)) {
                return system;
            }
        }
        throw new IllegalArgumentException("Invalid downstream system code: " + value);
    }
}
