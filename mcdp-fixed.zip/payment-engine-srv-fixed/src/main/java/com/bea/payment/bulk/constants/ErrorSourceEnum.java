package com.bea.payment.bulk.constants;

import lombok.Getter;

@Getter
public enum ErrorSourceEnum {

    BG3("BG3"),
    EPH_I005("EPH_I005"),
    EPH_I006("EPH_I006"),
    EPH_HTTP("EPH_HTTP"),
    EPH_QUERY("EPH_QUERY"),
    CHATS("CHATS"),
    WORKER("WORKER"),
    OPS("OPS");

    private final String code;

    ErrorSourceEnum(String code) {
        this.code = code;
    }
}
