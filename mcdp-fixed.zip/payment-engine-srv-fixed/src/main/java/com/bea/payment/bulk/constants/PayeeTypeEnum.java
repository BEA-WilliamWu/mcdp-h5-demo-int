package com.bea.payment.bulk.constants;

import lombok.Getter;

import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

@Getter
public enum PayeeTypeEnum {

    ACCOUNT("ACCOUNT"),
    PROXY("PROXY");

    private final String code;

    PayeeTypeEnum(String code) { this.code = code; }

    public static PayeeTypeEnum from(String value) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(
                    StandardResultCode.INVALID_PAYEE_TYPE,
                    "payeeType is required"
            );
        }
        try {
            return PayeeTypeEnum.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new ValidationException(
                    StandardResultCode.INVALID_PAYEE_TYPE,
                    "Invalid payeeType: " + value
            );
        }
    }
}
