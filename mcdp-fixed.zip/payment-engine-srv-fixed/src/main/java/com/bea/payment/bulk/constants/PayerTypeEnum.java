package com.bea.payment.bulk.constants;

import lombok.Getter;

import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

@Getter
public enum PayerTypeEnum {

    INDIVIDUAL("INDIVIDUAL"),
    CORPORATE("CORPORATE");

    private final String code;

    PayerTypeEnum(String code) { this.code = code; }

    public static PayerTypeEnum from(String value) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(
                    StandardResultCode.INVALID_PAYER_TYPE,
                    "payerType is required"
            );
        }
        try {
            return PayerTypeEnum.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new ValidationException(
                    StandardResultCode.INVALID_PAYER_TYPE,
                    "Invalid payerType: " + value
            );
        }
    }
}
