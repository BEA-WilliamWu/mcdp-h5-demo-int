package com.bea.payment.bulk.constants;


import lombok.Getter;
@Getter
public enum PaymentStatusEnum {

    PENDING("PENDING"),
    QUEUED("QUEUED"),
    PROCESSING("PROCESSING"),
    COMPLETED("COMPLETED"),
    FAILED("FAILED"),
    MANUAL_REVIEW("MANUAL_REVIEW");

    private final String code;

    PaymentStatusEnum(String code) { this.code = code; }

}
