package com.bea.payment.bulk.constants;

public enum PaymentTxnEventTypeEnum {
    PAYMENT_ACCEPTED,
    EPH_I005,
    EPH_I006,
    EPH_I037,
    EPH_HTTP,
    BG3_TRANSFER,
    CHATS_TRANSFER
}
