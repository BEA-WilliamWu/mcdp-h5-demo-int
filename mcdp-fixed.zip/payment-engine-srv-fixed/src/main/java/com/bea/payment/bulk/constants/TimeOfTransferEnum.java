package com.bea.payment.bulk.constants;

import lombok.Getter;

import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

@Getter
public enum TimeOfTransferEnum {

    NOW("NOW"),
    LATER("LATER");

    private final String code;

    TimeOfTransferEnum(String code) { this.code = code; }

    public static TimeOfTransferEnum from(String value) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(
                    StandardResultCode.INVALID_TIME_OF_TRANSFER,
                    "timeOfTransfer is required"
            );
        }
        try {
            return TimeOfTransferEnum.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new ValidationException(
                    StandardResultCode.INVALID_TIME_OF_TRANSFER,
                    "Invalid timeOfTransfer: " + value
            );
        }
    }
}
