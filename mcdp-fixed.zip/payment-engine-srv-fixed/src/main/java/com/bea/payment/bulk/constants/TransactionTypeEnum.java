package com.bea.payment.bulk.constants;

import lombok.Getter;

import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

@Getter
public enum TransactionTypeEnum {

    FPS("FPS"),
    CHATS("CHATS"),
    INTERNAL("INTERNAL"),
    ;

    private final String code;

    TransactionTypeEnum(String code) { this.code = code; }

    public static TransactionTypeEnum from(String value) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(
                    StandardResultCode.INVALID_TRANSACTION_TYPE,
                    "transactionType is required"
            );
        }
        try {
            return TransactionTypeEnum.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new ValidationException(
                    StandardResultCode.INVALID_TRANSACTION_TYPE,
                    "Invalid transactionType: " + value
            );
        }
    }
}
