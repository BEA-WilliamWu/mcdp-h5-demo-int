package com.bea.payment.bulk.internal.bg3;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * BG3 金额格式化工具。
 *
 * <p>当前按 BG3 sample 落地的金额约定：
 * 1. JSON 字段传 15 位数字字符串；
 * 2. 金额隐含 2 位小数；
 * 3. 左侧补 0；
 * 4. 示例：`200.00 -> 00000000020000`。</p>
 *
 * <p>注意：OpenAPI 当前只声明金额字段 maxLength=15，sample 是 15 位。
 * 如果 QA3/BG3 后续确认固定 15 位，只需要调整 {@link #BG3_AMOUNT_LENGTH} 和 {@link #MAX_AMOUNT}，
 * 避免 builder 中散落手写补零逻辑。</p>
 */
public final class Bg3AmountFormatter {

    private static final int IMPLIED_DECIMAL_PLACES = 2;
    private static final int BG3_AMOUNT_LENGTH = 15;
    private static final BigDecimal MAX_AMOUNT = new BigDecimal("9999999999999.99");

    private Bg3AmountFormatter() {
    }

    /**
     * 将 IPE 的十进制金额转换为 BG3 sample 对应的 14 位隐含两位小数字符串。
     */
    public static String format(BigDecimal amount) {
        if (amount == null) {
            throw new IllegalArgumentException("BG3 amount must not be null");
        }
        BigDecimal value = amount;
        if (value.signum() < 0) {
            throw new IllegalArgumentException("BG3 amount must not be negative");
        }
        if (value.compareTo(MAX_AMOUNT) > 0) {
            throw new IllegalArgumentException("BG3 amount exceeds sample-width implied decimal limit");
        }

        BigDecimal cents = value.movePointRight(IMPLIED_DECIMAL_PLACES);
        try {
            String digits = cents.setScale(0, RoundingMode.UNNECESSARY).toPlainString();
            return leftPadWithZero(digits);
        } catch (ArithmeticException e) {
            throw new IllegalArgumentException("BG3 amount supports at most 2 decimal places", e);
        }
    }

    /**
     * 左补 0 到当前 BG3 sample 使用的 14 位长度。
     */
    private static String leftPadWithZero(String digits) {
        if (digits.length() > BG3_AMOUNT_LENGTH) {
            throw new IllegalArgumentException("BG3 amount encoded digits exceed sample width");
        }
        return "0".repeat(BG3_AMOUNT_LENGTH - digits.length()) + digits;
    }
}
