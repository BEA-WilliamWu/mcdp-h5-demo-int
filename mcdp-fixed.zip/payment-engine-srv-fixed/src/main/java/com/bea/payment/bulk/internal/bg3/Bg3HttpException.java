package com.bea.payment.bulk.internal.bg3;

import lombok.Getter;

import com.bea.payment.bulk.internal.bg3.model.Bg3HttpErrorType;

/**
 * BG3 HTTP 调用异常。
 *
 * <p>异常中保留失败类型、HTTP 状态码和响应体，后续 execution service 可以据此写入
 * `LAST_ERROR_CODE` 并进入人工处理口径。没有 HTTP 响应的失败，statusCode 固定为 -1。</p>
 */
@Getter
public class Bg3HttpException extends RuntimeException {

    private final Bg3HttpErrorType errorType;
    private final int statusCode;
    private final String responseBody;

    public Bg3HttpException(Bg3HttpErrorType errorType, String message, Throwable cause) {
        this(errorType, -1, null, message, cause);
    }

    public Bg3HttpException(Bg3HttpErrorType errorType, int statusCode, String responseBody, String message) {
        this(errorType, statusCode, responseBody, message, null);
    }

    private Bg3HttpException(Bg3HttpErrorType errorType, int statusCode, String responseBody,
            String message, Throwable cause) {
        super(message, cause);
        this.errorType = errorType;
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

}
