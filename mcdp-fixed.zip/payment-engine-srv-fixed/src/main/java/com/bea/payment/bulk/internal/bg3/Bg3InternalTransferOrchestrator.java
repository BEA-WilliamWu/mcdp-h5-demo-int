package com.bea.payment.bulk.internal.bg3;

import com.bea.payment.bulk.internal.bg3.config.Bg3Properties;
import com.bea.payment.bulk.internal.bg3.client.Bg3FeignTransport;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferRequest;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponse;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponseEnvelope;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * BG3 internal fund transfer 调用编排器。
 *
 * <p>职责边界：本类只串联一笔 INTERNAL 交易的 BG3 调用链，不查数据库、不更新 MAIN、
 * 不做 MQ ACK/NACK、不做最终 PaymentStatus 映射。后续 execution service 可以在事务边界外调用本类，
 * 再根据 `e5002ReturnCode` 或 HTTP 异常更新 MAIN。</p>
 */
public class Bg3InternalTransferOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(Bg3InternalTransferOrchestrator.class);

    private final Bg3InternalTransferRequestFactory requestFactory;
    private final Bg3FeignTransport transport;
    private final Bg3InternalTransferResponseMapper responseMapper;
    private final Bg3Properties properties;

    /**
     * 创建 BG3 internal fund transfer 编排器。
     *
     * @param requestFactory 请求 DTO 工厂
     * @param transport 已配置 baseUrl、timeout 和 API Connect header 的 Feign transport
     * @param responseMapper 响应 DTO 映射器
     * @param properties BG3 路径和控制字段配置
     */
    public Bg3InternalTransferOrchestrator(Bg3InternalTransferRequestFactory requestFactory,
            Bg3FeignTransport transport, Bg3InternalTransferResponseMapper responseMapper,
            Bg3Properties properties) {
        this.requestFactory = Objects.requireNonNull(requestFactory, "requestFactory must not be null");
        this.transport = Objects.requireNonNull(transport, "transport must not be null");
        this.responseMapper = Objects.requireNonNull(responseMapper, "responseMapper must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
    }

    /**
     * 执行一次 BG3 internal fund transfer 调用。
     *
     * <p>主流程固定为：
     * 1. 使用 MAIN 当前字段和 `pe.downstream.bg3.control` 构建 BG3 request DTO；
     * 2. 通过 Feign POST 到 QA3/BG3 internal transfer endpoint；
     * 3. 映射 `e5002Output` 并返回给上层。</p>
     *
     * <p>注意：`e5002ReturnCode!=00` 是 BG3 业务失败，不在这里抛异常；
     * HTTP 非 2xx、timeout、IO 等技术失败由 Feign transport 抛出，留给 execution service 写状态和人工处理原因。</p>
     */
    public Bg3InternalTransferResponse execute(PaymentTxnMainEntity txn, PaymentTxnEventEntity event1) {
        Objects.requireNonNull(txn, "txn must not be null");

        String transactionId = txn.getTransactionId();
        log.info("[BG3] Start executing BG3 internal transfer for transactionId={}", transactionId);

        // 1. 构建请求 DTO。字段来源和默认值规则集中在 factory，避免编排层混入报文字段细节。
        Bg3InternalTransferRequest request = requestFactory.build(txn, event1,properties);
        log.debug("[BG3] Request prepared for transactionId={}", transactionId);

        // 2. 调 QA3/BG3。Feign transport 只做 HTTP/网络异常分类，不做 BG3 业务返回码解释。
        Bg3InternalTransferResponseEnvelope envelope = transport.execute(request);
        log.info("[BG3] Response received for transactionId={}", transactionId);

        // 3. 映射 BG3 响应。最终成功/失败状态映射留给后续 execution service。
        Bg3InternalTransferResponse response = responseMapper.map(envelope);
        log.info("[BG3] Parsed response: returnCode={}, seqNumOut={}, success={} for transactionId={}",
                response.returnCode(), response.seqNumOut(), response.success(), transactionId);

        log.info("[BG3] Completed BG3 internal transfer execution for transactionId={}", transactionId);
        return response;
    }
}
