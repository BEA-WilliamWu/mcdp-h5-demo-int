package com.bea.payment.bulk.internal.bg3;

import com.bea.payment.bulk.internal.bg3.config.Bg3Properties;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferRequest;
import com.bea.payment.bulk.model.dto.Bg3EventValueRequest;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

/**
 * BG3 internal transfer 请求 DTO 工厂。
 */
public class Bg3InternalTransferRequestFactory {

    private static final String EMPTY = "";
    private static final String ZERO_CHECK_NUMBER = "000000";
    private static final String ZERO_RATE = "00000000000";
    private static final int EVENT_VALUE_SIZE = 10;
    private static final int NARRATIVE_MAX_LENGTH = 50;
    private static final TypeReference<List<Bg3EventValueRequest>> EVENT_VALUE_LIST_TYPE =
            new TypeReference<>() {};

    private final ObjectMapper objectMapper;

    public Bg3InternalTransferRequestFactory() {
        this(new ObjectMapper());
    }

    Bg3InternalTransferRequestFactory(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public Bg3InternalTransferRequest build(PaymentTxnMainEntity txn,PaymentTxnEventEntity event, Bg3Properties properties) {
        Bg3Properties.Control control = properties.getControl();
        return Bg3InternalTransferRequest.builder()
                .dfhcommarea(Bg3InternalTransferRequest.Dfhcommarea.builder()
                        .qxec5002(Bg3InternalTransferRequest.Qxec5002.builder()
                                .e5002Input(e5002Input(txn, event, control))
                                .build())
                        .build())
                .build();
    }

    private Bg3InternalTransferRequest.E5002Input e5002Input(PaymentTxnMainEntity txn,
            PaymentTxnEventEntity event,
            Bg3Properties.Control control) {
        return Bg3InternalTransferRequest.E5002Input.builder()
                .e5002OriSysCod(value(control.getOriSysCode()))
                .e5002SeqNumInp(EMPTY)
                .e5002FlgCmmt(value(control.getFlgCmmt()))
                .e5002CodEntity(value(control.getCodEntity()))
                .e5002User(value(control.getUser()))
                .e5002CenterCode(value(control.getCenterCode()))
                .e5002CodTrns(value(control.getCodTrns()))
                .e5002Pf(value(control.getPf()))
                .e5002Channel(value(control.getChannel()))
                .e5002EventValue(buildEventValues(event))
                .bgnc520i(bgnc520i(txn, event,control))
                .build();
    }

    private Bg3InternalTransferRequest.Bgnc520i bgnc520i(PaymentTxnMainEntity txn,
            PaymentTxnEventEntity event,
            Bg3Properties.Control control) {

        boolean isCnyPayeeAccount = isCny(txn.getPayeeAccountCurrency());

        return Bg3InternalTransferRequest.Bgnc520i.builder()
                .n520iFiller(EMPTY)
                .n520iDebitAccount(debitAccount(txn,event))
                .n520iCreditAccount(creditAccount(txn, event))
                .n520iExchangeRate(exchangeRate(event))
                .n520iOtherDetails(otherDetails(event))
                .n520iOtherFields(otherFields(txn, control))
                .n520iTransNumDeb(0)
                .n520iTransNumCre(0)
                .n520iRtUsed(0)
                .n520iErrorCode(EMPTY)
                .n520iFlgWaiveFee(EMPTY)
                .n520iFlgTradeInfo(Bg3InternalTransferRequest.TradeInfo.builder()
                        .n520iFlgTrade(isCnyPayeeAccount ? "N" : EMPTY)
                        .n520iFlgTradeCertified(EMPTY)
                        .build())
                .n520iFlgCnh(EMPTY)
                .n520iFlgResidentDeb(isCnyPayeeAccount ? "A" : EMPTY)
                .n520iFlgResidentCre(isCnyPayeeAccount ? "A" : EMPTY)
                .n520iFlgSmartQtn(EMPTY)
                .n520iFlgSof(EMPTY)
                .n520iFlgPof(EMPTY)
                .n520iFlgRelAcHolder(EMPTY)
                .n520iPofRemark(EMPTY)
                .n520iFlgReqPof(EMPTY)
                .n520iFlgCrRef(EMPTY)
                .n520iCrRef1(EMPTY)
                .n520iCrRef2(EMPTY)
                .n520iCrRef3(EMPTY)
                .n520iFiller2Share(EMPTY)
                .build();
    }

    /**
     * 判断收款账户币种是否为人民币。
     */
    private static boolean isCny(String currency) {
        return currency != null && "CNY".equalsIgnoreCase(currency.trim());
    }

    private static Bg3InternalTransferRequest.DebitAccount debitAccount(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        String debitCurrency = defaultIfBlank(txn.getPayerAccountCurrency(), txn.getDebitAmountCcy());
        return Bg3InternalTransferRequest.DebitAccount.builder()
                .n520iCacDeb(value(txn.getPayerAccountNo()))
                .n520iFccDeb(value(debitCurrency))
                .n520iAccnameDeb(value(txn.getPayerName()))
                .n520iFccAmtdeb(value(txn.getDebitAmountCcy()))
                .n520iAmtDebR(Bg3AmountFormatter.format(txn.getDebitAmount()))
                .n520iFccPsbdeb(value(event.getBg3FccPsbdeb()))
                .n520iNumCheckR(defaultIfBlank(event.getBg3NumCheckR(), ZERO_CHECK_NUMBER))
                .build();
    }

    private static Bg3InternalTransferRequest.CreditAccount creditAccount(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        String creditCurrency = defaultIfBlank(txn.getPayeeAccountCurrency(),
                defaultIfBlank(txn.getSettlementCurrency(), txn.getDebitAmountCcy()));
        return Bg3InternalTransferRequest.CreditAccount.builder()
                .n520iCacCre(value(txn.getPayeeAccountNo()))
                .n520iFccCre(value(creditCurrency))
                .n520iAccnameCre(value(txn.getPayeeName()))
                .n520iFccAmtcre(value(txn.getDebitAmountCcy()))
                .n520iAmtCreR(Bg3AmountFormatter.format(txn.getDebitAmount()))
                .n520iFccPsbcre(value(event.getBg3FccPsbcre()))
                .build();
    }

    private static Bg3InternalTransferRequest.ExchangeRate exchangeRate(PaymentTxnEventEntity event) {
        return Bg3InternalTransferRequest.ExchangeRate.builder()
                .n520iCcypair(value(event.getExchangeCurrencyPair()))
                .n520iRtCtrR(defaultIfBlank(event.getExchangeContractRate(), ZERO_RATE))
                .n520iRtSpecialR(defaultIfBlank(event.getExchangeSpecialRate(), ZERO_RATE))
                .n520iFlgSpRate(value(event.getExchangeSpecialRateFlag()))
                .n520iTrsyRef(value(event.getTreasuryReference()))
                .build();
    }

    private static Bg3InternalTransferRequest.OtherDetails otherDetails(PaymentTxnEventEntity event) {
        return Bg3InternalTransferRequest.OtherDetails.builder()
                .n520iDatValue(EMPTY)
                .n520iNarrative(truncate(event.getPaymentDetail1()+event.getPaymentDetail2()+event.getPaymentDetail3()+event.getPaymentDetail4(), NARRATIVE_MAX_LENGTH))
                .n520iTrfThdpty(EMPTY)
                .build();
    }

    private static Bg3InternalTransferRequest.OtherFields otherFields(PaymentTxnMainEntity txn,
            Bg3Properties.Control control) {
        return Bg3InternalTransferRequest.OtherFields.builder()
                .n520iAuthorize(EMPTY)
                .n520iCodid(EMPTY)
                .n520iCollRef(EMPTY)
                .n520iFlgTrans(value(control.getFlgTrans()))
                .n520iTypid(EMPTY)
                .n520iCodIssCtry(EMPTY)
                .n520iNumCus(EMPTY)
                .n520iCodOperDeb(value(control.getCodOperDeb()))
                .n520iCodOperCre(value(control.getCodOperCre()))
                .n520iTransRef1(value(txn.getTransactionId()))
                .n520iTransRef2(EMPTY)
                .n520iTransRef3(EMPTY)
                .n520iPassbookRef(EMPTY)
                .n520iMsofLinkRef(EMPTY)
                .n520iFlgPayType(EMPTY)
                .build();
    }

    private static Bg3InternalTransferRequest.EventValue eventValue() {
        return Bg3InternalTransferRequest.EventValue.builder()
                .e5002EventId(EMPTY)
                .e5002SwCmp(EMPTY)
                .build();
    }

    private List<Bg3InternalTransferRequest.EventValue> buildEventValues(PaymentTxnEventEntity event) {
        List<Bg3InternalTransferRequest.EventValue> list = new ArrayList<>(EVENT_VALUE_SIZE);
        List<Bg3EventValueRequest> upstreamValues = readEventValues(event.getBg3EventValuesJson());
        for (int i = 0; i < upstreamValues.size() && list.size() < EVENT_VALUE_SIZE; i++) {
            Bg3EventValueRequest upstreamValue = upstreamValues.get(i);
            if (upstreamValue == null) {
                list.add(eventValue());
                continue;
            }
            list.add(Bg3InternalTransferRequest.EventValue.builder()
                    .e5002EventId(value(upstreamValue.getE5002EventId()))
                    .e5002SwCmp(value(upstreamValue.getE5002SwCmp()))
                    .build());
        }
        while (list.size() < EVENT_VALUE_SIZE) {
            list.add(eventValue());
        }
        return list;
    }

    private List<Bg3EventValueRequest> readEventValues(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            List<Bg3EventValueRequest> values = objectMapper.readValue(json, EVENT_VALUE_LIST_TYPE);
            return values == null ? List.of() : values;
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Invalid BG3 eventValues JSON", e);
        }
    }

    private static String value(String value) {
        return value == null ? EMPTY : value;
    }

    private static String defaultIfBlank(String value, String defaultValue) {
        return value == null || value.isBlank() ? defaultValue : value;
    }

    private static String truncate(String value, int maxLength) {
        if (value.length() <= maxLength) {
            return value;
        }
        return value.substring(0, maxLength);
    }

}
