package com.bea.payment.bulk.internal.bg3;

import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponse;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponseEnvelope;

/**
 * BG3 响应 DTO 到内部状态闭环模型的转换器。
 */
public class Bg3InternalTransferResponseMapper {

    public Bg3InternalTransferResponse map(Bg3InternalTransferResponseEnvelope envelope) {
        Bg3InternalTransferResponseEnvelope.E5002Output output = output(envelope);
        return new Bg3InternalTransferResponse(
                output.getE5002ReturnCode(),
                output.getE5002SeqNumOut(),
                output.getE5002AppErrCod(),
                output.getE5002AppErrMsg(),
                output.getE5002AppWarnCod1(),
                output.getE5002AppWarnMsg1(),
                output.getE5002AppWarnCod2(),
                output.getE5002AppWarnMsg2(),
                output.getE5002OutputMsg());
    }

    private static Bg3InternalTransferResponseEnvelope.E5002Output output(
            Bg3InternalTransferResponseEnvelope envelope) {
        if (envelope == null
                || envelope.getDfhcommarea() == null
                || envelope.getDfhcommarea().getQxec5002() == null
                || envelope.getDfhcommarea().getQxec5002().getE5002Output() == null) {
            throw new IllegalArgumentException("BG3 response missing e5002Output");
        }
        return envelope.getDfhcommarea().getQxec5002().getE5002Output();
    }
}
