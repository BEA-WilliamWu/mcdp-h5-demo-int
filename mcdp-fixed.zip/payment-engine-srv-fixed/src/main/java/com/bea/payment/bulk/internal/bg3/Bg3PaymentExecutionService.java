package com.bea.payment.bulk.internal.bg3;


import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.DownstreamSystemEnum;
import com.bea.payment.bulk.constants.ErrorSourceEnum;
import com.bea.payment.bulk.constants.PaymentTxnEventTypeEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.constants.StatusReasonEnum;
import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.bg3.model.Bg3HttpErrorType;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponse;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.PaymentTxnMainConvertDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.notification.ManualReviewEmailService;
import com.bea.payment.bulk.service.PaymentExecutionPersistenceService;
import com.bea.payment.bulk.service.PaymentTxnMainService;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.StandardResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;


import java.util.Date;
import java.util.Objects;


/**
 * BG3 internal fund transfer 执行服务。
 *
 * <p>职责边界：
 * 1. 根据 transactionId 从 MAIN 表读取完整交易资料；
 * 2. 校验当前交易是否属于 INTERNAL/BG3 处理范围；
 * 3. 调用 `Bg3InternalTransferOrchestrator` 完成 BG3 HTTP 编排；
 * 4. 将 BG3 返回字段、最终状态或技术错误更新回 MAIN。</p>
 *
 * <p>注意：本服务不声明事务。BG3 是外部 HTTP 调用，不能把慢下游调用包在数据库事务里。
 * 当前每次执行只做一次 MAIN 更新；真实 Worker 的 ACK/NACK 边界后续再接入。</p>
 */
@Service
@ConditionalOnExpression("'${pe.downstream.bg3.base-url:}'.trim().length() > 0")
public class Bg3PaymentExecutionService {


    private static final Logger log = LoggerFactory.getLogger(Bg3PaymentExecutionService.class);
    private final PaymentTxnMainMapper txnMainMapper;
    private final PaymentTxnMainService txnMainService;
    private final Bg3InternalTransferOrchestrator orchestrator;
    private final PaymentExecutionPersistenceService persistenceService;
    private final ManualReviewEmailService emailService;




    public Bg3PaymentExecutionService(PaymentTxnMainMapper txnMainMapper, PaymentTxnMainService txnMainService,
                                      Bg3InternalTransferOrchestrator orchestrator,
                                      PaymentExecutionPersistenceService persistenceService,
                                      ManualReviewEmailService emailService) {
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.txnMainService = Objects.requireNonNull(txnMainService, "txnMainService must not be null");
        this.orchestrator = Objects.requireNonNull(orchestrator, "orchestrator must not be null");
        this.persistenceService = Objects.requireNonNull(persistenceService,
                "persistenceService must not be null");
        this.emailService = Objects.requireNonNull(emailService, "emailService must not be null");
    }


    /**
     * 执行一笔已落库的 BG3 internal transfer。
     *
     * <p>BG3 未确认 HTTP 非 2xx、timeout/IO 后是否可能已过账，因此这类未知结果进入
     * paymentStatus=MANUAL_REVIEW，由人工核对闭环。</p>
     */
    public Bg3InternalTransferResponse execute(String transactionId) {
        log.info("[BG3-EXEC] Start executing BG3 internal transfer for transactionId={}", transactionId);
        PaymentTxnMainConvertDTO txnMainConvertDTO = txnMainService.loadTxn(transactionId);
        PaymentTxnMainEntity txn = txnMainConvertDTO.getPaymentTxnMainEntity();
        PaymentTxnEventEntity event1 = txnMainConvertDTO.getPaymentTxnEventEntity();
        assertInternalTransaction(txn);
        txn.setLastDownstreamSystem(DownstreamSystemEnum.BG3.getCode());
        markDownstreamCalling(txn);


        try {
            // 1. 编排器负责 build JSON、POST BG3、parse response，不接触数据库。
            Bg3InternalTransferResponse response = orchestrator.execute(txn,event1);


            // 2. execution service 负责状态闭环和 MAIN 回写。
            PaymentTxnEventEntity event2 = new PaymentTxnEventEntity();
            applyBg3Response(txn,event2, response);
            persistenceService.save(txn, event2);
            log.info("[BG3-EXEC] Successfully updated transaction status to {} for transactionId={}, returnCode={}",
                    txn.getPaymentStatus(), transactionId, response.returnCode());
            return response;
        } catch (Bg3HttpException e) {
            // 3. BG3 timeout/IO/interrupted 不能误报普通失败，转人工核对。
            applyHttpFailure(txn, e);
            PaymentTxnEventEntity event = bg3HttpFailureEvent(e, txn.getLastErrorCode());
            persistenceService.save(txn, event);
            emailService.notifyManualReview(txn,event1, DownstreamSystemEnum.BG3.getCode(),
                    txn.getManualReviewReason(), bg3ExceptionInformation(e));
            log.error("[BG3-EXEC] HTTP failure with errorType={} for transactionId={}, paymentStatus={}, "
                            + "httpStatus={}, message={}",
                    e.getErrorType(), transactionId, txn.getPaymentStatus(),
                    e.getStatusCode(), e.getMessage(), e);
            return null;
        }
    }


    /**
     * 当前 BG3 执行服务只处理 INTERNAL 交易。
     */
    private void assertInternalTransaction(PaymentTxnMainEntity txn) {
        if (!TransactionTypeEnum.INTERNAL.getCode().equalsIgnoreCase(txn.getTransactionType())) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "BG3 execution only supports INTERNAL transaction");
        }
    }


    /**
     * 保存 BG3 业务响应，并按 `e5002ReturnCode` 映射最终支付状态。
     */
    private void applyBg3Response(PaymentTxnMainEntity txn, PaymentTxnEventEntity event, Bg3InternalTransferResponse response) {
        event.setDownstreamSystem(DownstreamSystemEnum.BG3.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.BG3_TRANSFER.name());
        event.setEventStage("RESPONSE");
        event.setDownstreamReference(response.seqNumOut());
        event.setResultStatus(response.success() ? "SUCCESS" : "FAILED");
        event.setResultCode(response.returnCode());
        event.setErrorCode(response.appErrorCode());
        event.setErrorMessage(response.appErrorMessage());
        event.setResponseSummary(firstText(response.appWarnMessage1(), response.appWarnMessage2()));
        if (response.success()) {
            txn.setPaymentStatus(PaymentStatusEnum.COMPLETED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_SUCCESS.getCode());
            txn.setErrorSource(null);
            txn.setLastErrorCode(null);
            txn.setManualReviewReason(null);
            txn.setManualReviewTime(null);
            txn.setExecutionEndTime(new Date());
            return;
        }


        txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
        txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
        txn.setErrorSource(ErrorSourceEnum.BG3.getCode());
        txn.setLastErrorCode(firstText(response.appErrorCode(), response.returnCode(), "BG3_REJECTED"));
        txn.setManualReviewReason(null);
        txn.setManualReviewTime(null);
        txn.setExecutionEndTime(new Date());
    }


    /**
     * 保存 BG3 HTTP/网络失败结果。
     */
    private void applyHttpFailure(PaymentTxnMainEntity txn, Bg3HttpException e) {
        String errorCode = "BG3_" + e.getErrorType().name();
        txn.setPaymentStatus(PaymentStatusEnum.MANUAL_REVIEW.getCode());
        txn.setStatusReason(errorCode);
        txn.setErrorSource(ErrorSourceEnum.BG3.getCode());
        txn.setLastErrorCode(errorCode);
        txn.setManualReviewReason(errorCode);
        txn.setManualReviewTime(new Date());
        txn.setExecutionEndTime(new Date());
    }


    private void markDownstreamCalling(PaymentTxnMainEntity txn) {
        PaymentTxnMainEntity update = new PaymentTxnMainEntity();
        update.setStatusReason(StatusReasonEnum.DOWNSTREAM_CALLING.getCode());
        int updated = txnMainMapper.update(update, new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getTxnId, txn.getTxnId())
                .eq(PaymentTxnMainEntity::getIsDeleted, "N")
                .eq(PaymentTxnMainEntity::getPaymentStatus,
                        PaymentStatusEnum.PROCESSING.getCode()));
        if (updated != 1) {
            throw new IllegalStateException("BG3 transaction is no longer PROCESSING: "
                    + txn.getTransactionId());
        }
        txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_CALLING.getCode());
    }


    private PaymentTxnEventEntity bg3HttpFailureEvent(Bg3HttpException e, String errorCode) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.BG3.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.BG3_TRANSFER.name());
        event.setEventStage("ERROR");
        event.setResultStatus("UNKNOWN");
        event.setErrorCode(errorCode);
        event.setErrorMessage(e.getMessage());
        event.setResponseSummary("BG3 HTTP failure, status=" + e.getStatusCode());
        return event;
    }


    private static String firstText(String... values) {
        if (values == null) {
            return null;
        }
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return null;
    }


    private static String bg3ExceptionInformation(Bg3HttpException e) {
        if (Bg3HttpErrorType.TIMEOUT == e.getErrorType()) {
            return "call bg3 timeout";
        }
        if (Bg3HttpErrorType.INTERRUPTED == e.getErrorType()) {
            return "call bg3 interrupted";
        }
        if (Bg3HttpErrorType.HTTP_STATUS == e.getErrorType() && e.getStatusCode() > 0) {
            return "call bg3 returned HTTP status " + e.getStatusCode();
        }
        return firstText(e.getMessage(), "call bg3 failed");
    }
}
