package com.bea.payment.bulk.internal.bg3;

import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.flow.mq.MqMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * Worker 接入 BG3 前的轻量消息处理器。
 *
 * <p>当前类刻意不依赖 IBM MQ SDK，也不处理 ACK/NACK：
 * 真实 Worker 后续只需要把反序列化后的 `MqMessage` 交给本类，
 * 本类负责判断这条消息是否应进入 BG3 internal transfer 执行链路。</p>
 */
@Component
@ConditionalOnExpression("'${pe.downstream.bg3.base-url:}'.trim().length() > 0")
public class Bg3WorkerMessageHandler {

    private static final Logger log = LoggerFactory.getLogger(Bg3WorkerMessageHandler.class);
    private final Bg3PaymentExecutionService executionService;

    public Bg3WorkerMessageHandler(Bg3PaymentExecutionService executionService) {
        this.executionService = Objects.requireNonNull(executionService, "executionService must not be null");
    }

    /**
     * 处理一条 Worker 消息。
     *
     * <p>逻辑步骤：
     * 1. 检查消息是否为空；
     * 2. 非 INTERNAL 消息不属于 BG3 内部转账链路，直接跳过；
     * 3. INTERNAL 消息只取 transactionId，完整交易参数仍由执行服务从 MAIN 表读取；
     * 4. 执行服务抛出的异常不在这里吞掉，交给未来 MQ 层决定 ACK、NACK 或人工处理。</p>
     */
    public void handle(MqMessage message) {
        Objects.requireNonNull(message, "message must not be null");

        String transactionId = message.getTransactionId();
        
        if (!TransactionTypeEnum.INTERNAL.getCode().equalsIgnoreCase(message.getTransactionType())) {
            log.debug("[BG3-HANDLER] Skipping non-INTERNAL message: transactionId={}, txType={}",
                    transactionId, message.getTransactionType());
            return;
        }

        log.info("[BG3-HANDLER] Handling INTERNAL transaction: transactionId={}", transactionId);
        
        try {
            executionService.execute(transactionId);
            log.info("[BG3-HANDLER] Successfully executed BG3 transfer: transactionId={}", transactionId);
        } catch (Exception e) {
            log.error("[BG3-HANDLER] Failed to execute BG3 transfer: transactionId={}, error={}",
                    transactionId, e.getMessage(), e);
            throw e;
        }
    }
}
