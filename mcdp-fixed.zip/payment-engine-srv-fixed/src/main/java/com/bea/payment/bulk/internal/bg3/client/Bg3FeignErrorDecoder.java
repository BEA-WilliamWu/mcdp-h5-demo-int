package com.bea.payment.bulk.internal.bg3.client;

import com.bea.payment.bulk.internal.bg3.Bg3HttpException;
import com.bea.payment.bulk.internal.bg3.model.Bg3HttpErrorType;
import feign.Response;
import feign.codec.ErrorDecoder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * BG3 Feign HTTP 状态码错误转换器。
 */
public class Bg3FeignErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {
        int status = response.status();
        String body = responseBody(response);
        return new Bg3HttpException(Bg3HttpErrorType.HTTP_STATUS, status, body,
                "BG3 returned HTTP status " + status);
    }

    private static String responseBody(Response response) {
        if (response.body() == null) {
            return null;
        }
        try {
            return new String(response.body().asInputStream().readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }
}
