package com.bea.payment.bulk.internal.bg3.client;

import com.bea.payment.bulk.internal.bg3.Bg3HttpException;
import com.bea.payment.bulk.internal.bg3.model.Bg3HttpErrorType;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferRequest;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponseEnvelope;
import feign.FeignException;
import feign.RetryableException;
import org.springframework.stereotype.Component;

import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.Objects;

/**
 * BG3 Feign 调用适配器。
 *
 * <p>Feign 负责 HTTP 发送和 JSON 编解码，本类负责把 Feign/底层网络异常统一转换为
 * BG3 调用层异常，避免 execution service 依赖 Feign 细节。</p>
 */
@Component
public class Bg3FeignTransport {

    private final Bg3InternalTransferFeignClient client;

    public Bg3FeignTransport(Bg3InternalTransferFeignClient client) {
        this.client = Objects.requireNonNull(client, "client must not be null");
    }

    public Bg3InternalTransferResponseEnvelope execute(Bg3InternalTransferRequest request) {
        try {
            return client.execute(request);
        } catch (Bg3HttpException e) {
            throw e;
        } catch (RetryableException e) {
            throw toTransportException(e);
        } catch (FeignException e) {
            throw new Bg3HttpException(Bg3HttpErrorType.IO_ERROR, e.status(), e.contentUTF8(),
                    "BG3 Feign request failed");
        } catch (RuntimeException e) {
            if (hasCause(e, InterruptedException.class)) {
                Thread.currentThread().interrupt();
                throw new Bg3HttpException(Bg3HttpErrorType.INTERRUPTED, "BG3 Feign request interrupted", e);
            }
            if (hasCause(e, SocketTimeoutException.class) || hasCause(e, InterruptedIOException.class)) {
                throw new Bg3HttpException(Bg3HttpErrorType.TIMEOUT, "BG3 Feign request timed out", e);
            }
            throw new Bg3HttpException(Bg3HttpErrorType.IO_ERROR, "BG3 Feign request failed", e);
        }
    }

    private static Bg3HttpException toTransportException(RetryableException e) {
        if (hasCause(e, SocketTimeoutException.class) || hasCause(e, InterruptedIOException.class)) {
            return new Bg3HttpException(Bg3HttpErrorType.TIMEOUT, "BG3 Feign request timed out", e);
        }
        return new Bg3HttpException(Bg3HttpErrorType.IO_ERROR, "BG3 Feign request failed", e);
    }

    private static boolean hasCause(Throwable throwable, Class<? extends Throwable> type) {
        Throwable current = throwable;
        while (current != null) {
            if (type.isInstance(current)) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }
}
