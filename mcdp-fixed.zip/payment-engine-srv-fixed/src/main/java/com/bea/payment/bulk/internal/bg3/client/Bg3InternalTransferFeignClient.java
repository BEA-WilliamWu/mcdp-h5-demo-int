package com.bea.payment.bulk.internal.bg3.client;

import com.bea.payment.bulk.internal.bg3.config.Bg3FeignConfiguration;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferRequest;
import com.bea.payment.bulk.internal.bg3.model.Bg3InternalTransferResponseEnvelope;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * BG3 internal transfer OpenFeign client。
 */
@FeignClient(
        name = "bg3InternalTransferClient",
        url = "${pe.downstream.bg3.base-url}",
        configuration = Bg3FeignConfiguration.class)
public interface Bg3InternalTransferFeignClient {

    @PostMapping(
            path = "${pe.downstream.bg3.internal-transfer-path}",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    Bg3InternalTransferResponseEnvelope execute(@RequestBody Bg3InternalTransferRequest request);
}
