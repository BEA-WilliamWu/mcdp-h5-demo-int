package com.bea.payment.bulk.internal.bg3.client;

import feign.Logger;
import org.slf4j.LoggerFactory;

/**
 * BG3 Feign metadata logger. Headers and bodies are deliberately omitted even
 * if a verbose Feign level is configured, because both can contain credentials
 * and customer payment data.
 */
public class Bg3MaskingFeignLogger extends Logger {

    @Override
    protected void log(String configKey, String format, Object... args) {
        org.slf4j.Logger logger = LoggerFactory.getLogger(configKey);
        if (!logger.isDebugEnabled()) {
            return;
        }
        String message = String.format(java.util.Locale.ROOT, format, args).trim();
        if (message.startsWith("--->") || message.startsWith("<---")) {
            logger.debug(message);
        }
    }
}
