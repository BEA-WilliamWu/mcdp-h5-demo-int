package com.bea.payment.bulk.internal.bg3.config;

import com.bea.payment.bulk.internal.bg3.Bg3InternalTransferOrchestrator;
import com.bea.payment.bulk.internal.bg3.Bg3InternalTransferRequestFactory;
import com.bea.payment.bulk.internal.bg3.Bg3InternalTransferResponseMapper;
import com.bea.payment.bulk.internal.bg3.client.Bg3FeignTransport;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * BG3 Spring 装配入口。
 *
 * <p>只有配置了 `pe.downstream.bg3.base-url` 时才创建 `Bg3InternalTransferOrchestrator`，避免本地或测试环境
 * 因缺少真实 QA3/BG3 地址而误连或启动失败。</p>
 */
@Configuration
@EnableConfigurationProperties(Bg3Properties.class)
public class Bg3ClientConfiguration {

    /**
     * 创建 BG3 request DTO 工厂。
     */
    @Bean
    public Bg3InternalTransferRequestFactory bg3InternalTransferRequestFactory() {
        return new Bg3InternalTransferRequestFactory();
    }

    /**
     * 创建 BG3 response DTO 映射器。
     */
    @Bean
    public Bg3InternalTransferResponseMapper bg3InternalTransferResponseMapper() {
        return new Bg3InternalTransferResponseMapper();
    }


    /**
     * 创建 BG3 internal transfer 编排器。
     *
     * <p>只有 HTTP client 存在时才创建，避免未配置 BG3 地址的环境出现可调用入口。</p>
     */
    @Bean
    @ConditionalOnExpression("'${pe.downstream.bg3.base-url:}'.trim().length() > 0")
    public Bg3InternalTransferOrchestrator bg3InternalTransferOrchestrator(
            Bg3InternalTransferRequestFactory requestFactory,
            Bg3FeignTransport transport,
            Bg3InternalTransferResponseMapper responseMapper,
            Bg3Properties properties) {
        return new Bg3InternalTransferOrchestrator(requestFactory, transport, responseMapper, properties);
    }
}
