package com.bea.payment.bulk.internal.bg3.config;

import com.bea.payment.bulk.internal.downstream.DownstreamTlsSupport;
import com.bea.payment.bulk.internal.bg3.client.Bg3FeignErrorDecoder;
import com.bea.payment.bulk.internal.bg3.client.Bg3MaskingFeignLogger;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.Client;
import feign.Logger;
import feign.Request;
import feign.RequestInterceptor;
import feign.Retryer;
import feign.codec.Decoder;
import feign.codec.Encoder;
import feign.codec.ErrorDecoder;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

/**
 * BG3 Feign 专用配置。
 */
public class Bg3FeignConfiguration {

    private static final String CLIENT_ID_HEADER = "X-IBM-Client-Id";
    private static final String CLIENT_SECRET_HEADER = "X-IBM-Client-Secret";

    @Bean
    public RequestInterceptor bg3ApiConnectHeaderInterceptor(Bg3Properties properties) {
        return template -> {
            if (hasText(properties.getClientId())) {
                template.header(CLIENT_ID_HEADER, properties.getClientId());
            }
            if (hasText(properties.getClientSecret())) {
                template.header(CLIENT_SECRET_HEADER, properties.getClientSecret());
            }
        };
    }

    @Bean
    public Encoder bg3FeignEncoder(ObjectProvider<ObjectMapper> objectMapperProvider) {
        return new SpringEncoder(() -> httpMessageConverters(objectMapperProvider));
    }

    @Bean
    public Decoder bg3FeignDecoder(ObjectProvider<ObjectMapper> objectMapperProvider) {
        return new SpringDecoder(() -> httpMessageConverters(objectMapperProvider));
    }

    @Bean
    public ErrorDecoder bg3FeignErrorDecoder() {
        return new Bg3FeignErrorDecoder();
    }

    @Bean
    public Client bg3FeignClient(Bg3Properties properties) {
        DownstreamTlsSupport.warnIfInsecureTlsEnabled("BG3", properties.isTlsInsecureSkipVerify());
        if (properties.isTlsInsecureSkipVerify()) {
            return new Client.Default(
                    DownstreamTlsSupport.insecureTrustAllSocketFactory(),
                    DownstreamTlsSupport.insecureHostnameVerifier());
        }
        return new Client.Default(null, null);
    }

    @Bean
    public Retryer bg3FeignRetryer() {
        return Retryer.NEVER_RETRY;
    }

    @Bean
    public Request.Options bg3FeignRequestOptions(Bg3Properties properties) {
        return new Request.Options(
                properties.resolveConnectTimeout(),
                properties.resolveReadTimeout(),
                true);
    }

    @Bean
    public Logger.Level bg3FeignLoggerLevel(Bg3Properties properties) {
        return properties.getLoggerLevel();
    }

    @Bean
    public Logger bg3FeignLogger() {
        return new Bg3MaskingFeignLogger();
    }

    private static HttpMessageConverters httpMessageConverters(ObjectProvider<ObjectMapper> objectMapperProvider) {
        ObjectMapper mapper = objectMapperProvider.getIfAvailable(ObjectMapper::new).copy();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        HttpMessageConverter<?> jacksonConverter = new MappingJackson2HttpMessageConverter(mapper);
        return new HttpMessageConverters(jacksonConverter);
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
