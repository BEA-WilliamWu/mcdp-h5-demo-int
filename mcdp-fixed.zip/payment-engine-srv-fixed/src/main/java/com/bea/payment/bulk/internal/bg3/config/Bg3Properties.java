package com.bea.payment.bulk.internal.bg3.config;

import lombok.Getter;
import lombok.Setter;

import feign.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

/**
 * BG3 / QA3 内部转账接口配置。
 *
 * <p>配置只承载连接参数和 BG3 控制字段，不在代码里硬编码真实 endpoint、client secret 或生产敏感值。
 * 业务交易字段仍从 MAIN 表读取。</p>
 */
@ConfigurationProperties(prefix = "pe.downstream.bg3")
@Getter
@Setter
public class Bg3Properties {

    /**
     * QA3 暴露给 IPE 的 BG3 基础地址。无默认真实值，避免误连。
     */
    private String baseUrl;

    /**
     * BG3 internal fund transfer path。
     */
    private String internalTransferPath = "/bgnc520i.v1";

    /**
     * 单次 BG3 HTTP 请求超时时间。
     */
    private Duration timeout = Duration.ofSeconds(10);

    /**
     * BG3 Feign 建连超时时间。
     */
    private Duration connectTimeout = Duration.ofSeconds(10);

    /**
     * BG3 Feign 读响应超时时间；为空时沿用 `timeout`。
     */
    private Duration readTimeout;

    /**
     * BG3 Feign 日志级别。默认只记录请求方法、URL 和响应状态。
     */
    private Logger.Level loggerLevel = Logger.Level.BASIC;

    /**
     * 是否跳过 BG3 HTTPS 证书链和主机名校验。
     *
     * <p>默认关闭。仅用于 SIT Pod JDK truststore 尚未导入 BG3 证书时的临时联调，
     * 证书流程完成后必须关闭。</p>
     */
    private boolean tlsInsecureSkipVerify = false;

    /**
     * API Connect client id。真实值不得提交到代码库。
     */
    private String clientId;

    /**
     * API Connect client secret。真实值不得提交到代码库。
     */
    private String clientSecret;

    /**
     * BG3 e5002Input 及常用业务控制字段。
     */
    private Control control = new Control();

    public Duration resolveConnectTimeout() {
        return connectTimeout == null ? timeout : connectTimeout;
    }

    public Duration resolveReadTimeout() {
        return readTimeout == null ? timeout : readTimeout;
    }

    @Getter
    @Setter
    public static class Control {

        private String oriSysCode;
        private String flgCmmt = "N";
        private String codEntity;
        private String user;
        private String centerCode;
        private String codTrns = "B520";
        private String pf;
        private String channel;
        private String flgTrans;
        private String codOperDeb;
        private String codOperCre;

    }
}
