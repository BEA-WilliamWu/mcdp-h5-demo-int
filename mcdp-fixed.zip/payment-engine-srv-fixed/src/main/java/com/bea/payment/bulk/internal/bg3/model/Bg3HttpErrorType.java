package com.bea.payment.bulk.internal.bg3.model;

/**
 * BG3 HTTP 调用失败分类。
 *
 * <p>这里只表达 HTTP/网络层可以稳定识别的技术失败。BG3 业务返回码
 * `e5002ReturnCode` 由 JSON parser 和后续 execution service 再映射。</p>
 */
public enum Bg3HttpErrorType {
    /** QA3/BG3 返回了非 2xx HTTP 状态码。 */
    HTTP_STATUS,
    /** 请求在配置超时时间内没有拿到响应。 */
    TIMEOUT,
    /** 建连、发送、读响应等底层 I/O 失败。 */
    IO_ERROR,
    /** 当前线程被中断，调用被迫停止。 */
    INTERRUPTED
}
