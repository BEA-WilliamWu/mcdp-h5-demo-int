package com.bea.payment.bulk.internal.bg3.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * BG3 internal transfer 请求 DTO。
 *
 * <p>字段名按 BG3 JSON 契约建模，避免调用层用字符串 Map 手工拼字段。</p>
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Bg3InternalTransferRequest {

    /**
     * Top-level BG3 communication area wrapper.
     */
    private Dfhcommarea dfhcommarea;

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Dfhcommarea {
        /**
         * BG3 qxec5002 program payload wrapper.
         */
        private Qxec5002 qxec5002;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Qxec5002 {
        /**
         * Common e5002 input header and BGNC520I internal transfer body.
         */
        private E5002Input e5002Input;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class E5002Input {
        /** Originating system code assigned for the BG3 caller. */
        private String e5002OriSysCod;
        /** Input sequence number used by BG3 for request tracing or host correlation. */
        private String e5002SeqNumInp;
        /** Commit flag for the BG3 transaction request. */
        private String e5002FlgCmmt;
        /** Entity code under which BG3 should process the transaction. */
        private String e5002CodEntity;
        /** BG3 user or technical user code for the request. */
        private String e5002User;
        /** BG3 center code associated with the caller or processing unit. */
        private String e5002CenterCode;
        /** BG3 transaction code for internal account fund transfer. */
        private String e5002CodTrns;
        /** BG3 platform or profile code used in the host control header. */
        private String e5002Pf;
        /** BG3 channel code assigned to the calling channel. */
        private String e5002Channel;
        /** BG3 event-value array; the host contract expects a fixed-size list. */
        private List<EventValue> e5002EventValue;
        /** BGNC520I internal account fund transfer request body. */
        private Bgnc520i bgnc520i;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class EventValue {
        /** BG3 event identifier for this e5002EventValue item. */
        private String e5002EventId;
        /** BG3 comparison switch paired with the event identifier. */
        private String e5002SwCmp;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Bgnc520i {
        /** BG3 filler field reserved by the host interface. */
        private String n520iFiller;
        /** Debit-side account, currency, amount, and cheque information. */
        private DebitAccount n520iDebitAccount;
        /** Credit-side account, currency, and amount information. */
        private CreditAccount n520iCreditAccount;
        /** Exchange-rate information used when the transfer involves FX. */
        private ExchangeRate n520iExchangeRate;
        /** Additional transfer details such as value date and narrative. */
        private OtherDetails n520iOtherDetails;
        /** BG3 operational flags, references, and host processing codes. */
        private OtherFields n520iOtherFields;
        /** Debit transaction number returned or maintained by BG3 host processing. */
        private Integer n520iTransNumDeb;
        /** Credit transaction number returned or maintained by BG3 host processing. */
        private Integer n520iTransNumCre;
        /** Exchange rate actually used by BG3 host processing. */
        private Integer n520iRtUsed;
        /** BG3 host error code field in the internal transfer body. */
        private String n520iErrorCode;
        /** Flag indicating whether the transfer fee is waived. */
        private String n520iFlgWaiveFee;
        /** Trade-related indicators required by BG3 when applicable. */
        private TradeInfo n520iFlgTradeInfo;
        /** CNH-related indicator used by BG3 when applicable. */
        private String n520iFlgCnh;
        /** Debit-side resident indicator used by BG3 when applicable. */
        private String n520iFlgResidentDeb;
        /** Credit-side resident indicator used by BG3 when applicable. */
        private String n520iFlgResidentCre;
        /** Smart quotation indicator used by BG3 when applicable. */
        private String n520iFlgSmartQtn;
        /** Source-of-funds indicator used by BG3 when applicable. */
        private String n520iFlgSof;
        /** Purpose-of-funds indicator used by BG3 when applicable. */
        private String n520iFlgPof;
        /** Related-account-holder indicator used by BG3 when applicable. */
        private String n520iFlgRelAcHolder;
        /** Purpose-of-funds free-text remark used by BG3 when applicable. */
        private String n520iPofRemark;
        /** Indicator that BG3 requires purpose-of-funds information. */
        private String n520iFlgReqPof;
        /** Indicator that credit reference fields are provided. */
        private String n520iFlgCrRef;
        /** First credit-side reference line. */
        private String n520iCrRef1;
        /** Second credit-side reference line. */
        private String n520iCrRef2;
        /** Third credit-side reference line. */
        private String n520iCrRef3;
        /** BG3 filler field reserved by the host interface. */
        private String n520iFiller2Share;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class DebitAccount {
        /** Debit account number. */
        private String n520iCacDeb;
        /** Debit account currency. */
        private String n520iFccDeb;
        /** Debit account name. */
        private String n520iAccnameDeb;
        /** Currency of the debit amount. */
        private String n520iFccAmtdeb;
        /** Debit amount encoded as the BG3 fixed-width amount string. */
        private String n520iAmtDebR;
        /** Debit passbook currency. */
        private String n520iFccPsbdeb;
        /** Debit cheque number. */
        private String n520iNumCheckR;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CreditAccount {
        /** Credit account number. */
        private String n520iCacCre;
        /** Credit account currency. */
        private String n520iFccCre;
        /** Credit account name. */
        private String n520iAccnameCre;
        /** Currency of the credit amount. */
        private String n520iFccAmtcre;
        /** Credit amount encoded as the BG3 fixed-width amount string. */
        private String n520iAmtCreR;
        /** Credit passbook currency. */
        private String n520iFccPsbcre;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ExchangeRate {
        /** Currency pair used for the exchange-rate calculation. */
        private String n520iCcypair;
        /** Contract exchange rate supplied to BG3 when applicable. */
        private String n520iRtCtrR;
        /** Special exchange rate supplied to BG3 when applicable. */
        private String n520iRtSpecialR;
        /** Flag indicating whether a special exchange rate is used. */
        private String n520iFlgSpRate;
        /** Treasury reference associated with the exchange-rate quotation. */
        private String n520iTrsyRef;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class OtherDetails {
        /** Value date field used by BG3 when applicable. */
        private String n520iDatValue;
        /** Transfer narrative or remarks sent to BG3. */
        private String n520iNarrative;
        /** Third-party transfer indicator used by BG3 when applicable. */
        private String n520iTrfThdpty;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class OtherFields {
        /** Authorization code or authorization indicator used by BG3. */
        private String n520iAuthorize;
        /** Customer or identification code used by BG3. */
        private String n520iCodid;
        /** Collection reference used by BG3 when applicable. */
        private String n520iCollRef;
        /** BG3 transfer flag that identifies the transfer processing mode. */
        private String n520iFlgTrans;
        /** Identification type code used by BG3. */
        private String n520iTypid;
        /** Issuing-country code for the identification document. */
        private String n520iCodIssCtry;
        /** Customer number used by BG3 when applicable. */
        private String n520iNumCus;
        /** Debit-side operation code used by BG3. */
        private String n520iCodOperDeb;
        /** Credit-side operation code used by BG3. */
        private String n520iCodOperCre;
        /** First transaction reference line. */
        private String n520iTransRef1;
        /** Second transaction reference line. */
        private String n520iTransRef2;
        /** Third transaction reference line. */
        private String n520iTransRef3;
        /** Passbook reference used by BG3 when applicable. */
        private String n520iPassbookRef;
        /** MSOF link reference used by BG3 when applicable. */
        private String n520iMsofLinkRef;
        /** Payment-type flag used by BG3 when applicable. */
        private String n520iFlgPayType;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class TradeInfo {
        /** Trade indicator used by BG3 when the transfer has trade information. */
        private String n520iFlgTrade;
        /** Trade certification indicator used by BG3 when applicable. */
        private String n520iFlgTradeCertified;
    }
}
