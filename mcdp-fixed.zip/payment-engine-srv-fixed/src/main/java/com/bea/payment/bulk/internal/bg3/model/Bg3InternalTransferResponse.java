package com.bea.payment.bulk.internal.bg3.model;

/**
 * BG3 internal fund transfer 响应关键字段。
 *
 * <p>这里只保留 Worker 状态闭环和 MAIN 回写需要的字段。`e5002OutputMsg` 可能很长且可能包含敏感信息，
 * 当前 parser 会解析出来便于调试和后续评审，但首期是否落库仍由设计文档约束。</p>
 *
 * @param returnCode BG3 business return code; current confirmed success value is 00.
 * @param seqNumOut BG3 output sequence number returned for host-side correlation.
 * @param appErrorCode BG3 application error code returned when the business call is rejected.
 * @param appErrorMessage BG3 application error message returned with the error code.
 * @param appWarnCode1 first BG3 application warning code.
 * @param appWarnMessage1 first BG3 application warning message.
 * @param appWarnCode2 second BG3 application warning code.
 * @param appWarnMessage2 second BG3 application warning message.
 * @param outputMessage raw BG3 output message text used for troubleshooting and host correlation.
 */
public record Bg3InternalTransferResponse(
        String returnCode,
        String seqNumOut,
        String appErrorCode,
        String appErrorMessage,
        String appWarnCode1,
        String appWarnMessage1,
        String appWarnCode2,
        String appWarnMessage2,
        String outputMessage
) {

    /**
     * BG3 已确认 `00` 表示最终成功；warning 不改变成功结论。
     */
    public boolean success() {
        return "00".equals(returnCode);
    }
}
