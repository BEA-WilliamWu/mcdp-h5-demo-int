package com.bea.payment.bulk.internal.bg3.model;

import lombok.Data;

/**
 * BG3 internal transfer 响应 DTO。
 */
@Data
public class Bg3InternalTransferResponseEnvelope {

    /**
     * Top-level BG3 communication area wrapper.
     */
    private Dfhcommarea dfhcommarea;

    @Data
    public static class Dfhcommarea {
        /**
         * BG3 qxec5002 program response wrapper.
         */
        private Qxec5002 qxec5002;
    }

    @Data
    public static class Qxec5002 {
        /**
         * Common e5002 output returned by BG3 for the internal transfer call.
         */
        private E5002Output e5002Output;
    }

    @Data
    public static class E5002Output {
        /** BG3 business return code; current confirmed success value is 00. */
        private String e5002ReturnCode;
        /** BG3 output sequence number returned for host-side correlation. */
        private String e5002SeqNumOut;
        /** BG3 application error code returned when the business call is rejected. */
        private String e5002AppErrCod;
        /** BG3 application error message returned with the error code. */
        private String e5002AppErrMsg;
        /** First BG3 application warning code; warnings may accompany a successful return code. */
        private String e5002AppWarnCod1;
        /** First BG3 application warning message. */
        private String e5002AppWarnMsg1;
        /** Second BG3 application warning code. */
        private String e5002AppWarnCod2;
        /** Second BG3 application warning message. */
        private String e5002AppWarnMsg2;
        /** BG3 output parameter field reserved by the host contract. */
        private String e5002Parameter;
        /** Raw BG3 output message text, used for troubleshooting and host correlation. */
        private String e5002OutputMsg;
    }
}
