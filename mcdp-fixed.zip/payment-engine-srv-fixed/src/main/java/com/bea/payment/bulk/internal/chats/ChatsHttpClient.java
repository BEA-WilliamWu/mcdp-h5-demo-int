package com.bea.payment.bulk.internal.chats;

import com.bea.payment.bulk.internal.chats.model.ChatsHttpErrorType;
import com.bea.payment.bulk.internal.downstream.DownstreamTlsSupport;
import com.bea.payment.common.response.ApiResponse;
import feign.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.Objects;

/**
 * CHATS HTTP JSON call client.
 *
 * <p>Handles HTTP POST requests with JSON body and Basic authentication.
 * Does not build request DTOs, parse responses, or handle business logic.</p>
 */
public class ChatsHttpClient {

    private static final Logger log = LoggerFactory.getLogger(ChatsHttpClient.class);
    private static final String JSON_MEDIA_TYPE = "application/json";
    private static final HostnameVerifier LOCAL_TUNNEL_HOSTNAME_VERIFIER = (hostname, session) -> true;

    private final URI baseUri;
    private final Duration requestTimeout;
    private final boolean tlsHostnameVerificationEnabled;
    private final boolean tlsInsecureSkipVerify;
    private final String clientId;
    private final String clientSecret;

    /**
     * Create CHATS HTTP client.
     *
     * @param baseUrl CHATS base URL
     * @param requestTimeout single HTTP request timeout
     * @param tlsHostnameVerificationEnabled whether to enable HTTPS hostname verification
     * @param clientId API Connect client id
     * @param clientSecret API Connect client secret
     */
    public ChatsHttpClient(String baseUrl, Duration requestTimeout, boolean tlsHostnameVerificationEnabled,
                           String clientId, String clientSecret) {
        this(baseUrl, requestTimeout, tlsHostnameVerificationEnabled, false, clientId, clientSecret);
    }

    /**
     * Create CHATS HTTP client.
     *
     * @param baseUrl CHATS base URL
     * @param requestTimeout single HTTP request timeout
     * @param tlsHostnameVerificationEnabled whether to enable HTTPS hostname verification
     * @param tlsInsecureSkipVerify whether to skip HTTPS certificate chain and hostname verification
     * @param clientId API Connect client id
     * @param clientSecret API Connect client secret
     */
    public ChatsHttpClient(String baseUrl, Duration requestTimeout, boolean tlsHostnameVerificationEnabled,
                           boolean tlsInsecureSkipVerify, String clientId, String clientSecret) {
        this.baseUri = normalizeBaseUri(baseUrl);
        this.requestTimeout = Objects.requireNonNull(requestTimeout, "requestTimeout must not be null");
        this.tlsHostnameVerificationEnabled = tlsHostnameVerificationEnabled;
        this.tlsInsecureSkipVerify = tlsInsecureSkipVerify;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        DownstreamTlsSupport.warnIfInsecureTlsEnabled("CHATS", tlsInsecureSkipVerify);
    }

    /**
     * Send HTTP POST with JSON body to the specified endpoint.
     *
     * @param endpointPath endpoint path, e.g. `/ebzhtc02.v1`
     * @param jsonBody JSON request body
     * @return response body string
     */
    public ApiResponse<String> postJson(String endpointPath, String jsonBody) {
        URI endpointUri = resolveEndpoint(endpointPath);
        byte[] requestBytes = Objects.requireNonNull(jsonBody, "jsonBody must not be null")
                .getBytes(StandardCharsets.UTF_8);
        HttpURLConnection connection = null;

        try {
            connection = openConnection(endpointUri);
            connection.setRequestMethod(Request.HttpMethod.POST.name());
            connection.setConnectTimeout(toTimeoutMillis(requestTimeout));
            connection.setReadTimeout(toTimeoutMillis(requestTimeout));
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", JSON_MEDIA_TYPE + "; charset=UTF-8");
            connection.setRequestProperty("Accept", JSON_MEDIA_TYPE);
            connection.setFixedLengthStreamingMode(requestBytes.length);

            // Add Basic authentication
            String auth = clientId + ":" + clientSecret;
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
            connection.setRequestProperty("Authorization", "Basic " + encodedAuth);

            try (OutputStream outputStream = connection.getOutputStream()) {
                outputStream.write(requestBytes);
            }
            int statusCode = connection.getResponseCode();
            String responseBody = readResponseBody(connection, statusCode);
            log.info("[CHATS] Response status={} for endpoint={}", statusCode, endpointUri);

            if (statusCode < 200 || statusCode >= 300) {
                throw new ChatsHttpException(ChatsHttpErrorType.HTTP_STATUS, statusCode, responseBody,
                        "CHATS returned HTTP status " + statusCode);
            }

            return ApiResponse.normalResponse(statusCode + "",responseBody);
        } catch (SocketTimeoutException e) {
            log.warn("[CHATS] Request timed out for endpoint={}", endpointUri, e);
            throw new ChatsHttpException(ChatsHttpErrorType.TIMEOUT, "CHATS HTTP request timed out", e);
        } catch (IOException e) {
            log.warn("[CHATS] Request failed for endpoint={}", endpointUri, e);
            throw new ChatsHttpException(ChatsHttpErrorType.IO_ERROR, "CHATS HTTP request failed", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private URI resolveEndpoint(String endpointPath) {
        String normalizedPath = Objects.requireNonNull(endpointPath, "endpointPath must not be null");
        if (normalizedPath.isBlank()) {
            throw new IllegalArgumentException("endpointPath must not be blank");
        }
        if (normalizedPath.startsWith("/")) {
            normalizedPath = normalizedPath.substring(1);
        }
        return baseUri.resolve(normalizedPath);
    }

    private static URI normalizeBaseUri(String baseUrl) {
        String value = Objects.requireNonNull(baseUrl, "baseUrl must not be null");
        if (value.isBlank()) {
            throw new IllegalArgumentException("baseUrl must not be blank");
        }
        if (!value.endsWith("/")) {
            value = value + "/";
        }
        return URI.create(value);
    }

    private HttpURLConnection openConnection(URI endpointUri) throws IOException {
        URLConnection urlConnection = endpointUri.toURL().openConnection();
        if (!(urlConnection instanceof HttpURLConnection connection)) {
            throw new IOException("CHATS endpoint is not an HTTP URL: " + endpointUri);
        }
        if (connection instanceof HttpsURLConnection httpsConnection) {
            if (tlsInsecureSkipVerify) {
                // Temporary debug path before SIT certificate is loaded into JDK truststore:
                // skip both certificate chain validation and hostname verification.
                httpsConnection.setSSLSocketFactory(DownstreamTlsSupport.insecureTrustAllSocketFactory());
                httpsConnection.setHostnameVerifier(DownstreamTlsSupport.insecureHostnameVerifier());
            } else if (!tlsHostnameVerificationEnabled) {
                httpsConnection.setHostnameVerifier(LOCAL_TUNNEL_HOSTNAME_VERIFIER);
            }
        }
        return connection;
    }

    private static String readResponseBody(HttpURLConnection connection, int statusCode) throws IOException {
        InputStream responseStream = statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (responseStream == null) {
            return "";
        }
        try (InputStream inputStream = responseStream) {
            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static int toTimeoutMillis(Duration timeout) {
        long millis = timeout.toMillis();
        if (millis <= 0 || millis > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("requestTimeout must be between 1ms and " + Integer.MAX_VALUE + "ms");
        }
        return (int) millis;
    }
}
