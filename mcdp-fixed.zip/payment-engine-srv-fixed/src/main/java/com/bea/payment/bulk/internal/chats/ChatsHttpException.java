package com.bea.payment.bulk.internal.chats;

import lombok.Getter;

import com.bea.payment.bulk.internal.chats.model.ChatsHttpErrorType;

/**
 * CHATS HTTP call exception.
 *
 * <p>Retains failure type, HTTP status code and response body for state update,
 * retry decision and audit logging. statusCode is -1 when there is no HTTP response.</p>
 */
@Getter
public class ChatsHttpException extends RuntimeException {

    private final ChatsHttpErrorType errorType;
    private final int statusCode;
    private final String responseBody;

    public ChatsHttpException(ChatsHttpErrorType errorType, String message, Throwable cause) {
        this(errorType, -1, null, message, cause);
    }

    public ChatsHttpException(ChatsHttpErrorType errorType, int statusCode, String responseBody, String message) {
        this(errorType, statusCode, responseBody, message, null);
    }

    private ChatsHttpException(ChatsHttpErrorType errorType, int statusCode, String responseBody,
                               String message, Throwable cause) {
        super(message, cause);
        this.errorType = errorType;
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

}
