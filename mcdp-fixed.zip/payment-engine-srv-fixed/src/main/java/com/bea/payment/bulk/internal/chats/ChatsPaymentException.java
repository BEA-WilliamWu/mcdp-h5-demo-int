package com.bea.payment.bulk.internal.chats;

import lombok.Getter;

/**
 * CHATS payment orchestration business exception.
 *
 * <p>Represents "HTTP succeeded but CHATS business result does not allow further processing".
 * Technical call failures are expressed by `ChatsHttpException` to avoid mixing business
 * and network failures.</p>
 */
@Getter
public class ChatsPaymentException extends RuntimeException {

    private final String stage;

    public ChatsPaymentException(String stage, String message) {
        super(message);
        this.stage = stage;
    }

    /**
     * Returns the stage where the failure occurred, e.g. CONFIRM, for state classification.
     */
}
