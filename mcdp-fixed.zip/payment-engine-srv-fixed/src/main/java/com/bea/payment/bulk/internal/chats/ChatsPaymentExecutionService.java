package com.bea.payment.bulk.internal.chats;

import com.bea.payment.bulk.constants.DownstreamSystemEnum;
import com.bea.payment.bulk.constants.ErrorSourceEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.constants.PaymentTxnEventTypeEnum;
import com.bea.payment.bulk.constants.StatusReasonEnum;
import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.chats.config.ChatsProperties;
import com.bea.payment.bulk.internal.chats.model.ChatsConfirmTransferResponse;
import com.bea.payment.bulk.internal.chats.model.ChatsHttpErrorType;
import com.bea.payment.bulk.model.dto.PaymentTxnMainConvertDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.service.PaymentExecutionPersistenceService;
import com.bea.payment.bulk.service.PaymentTxnMainService;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.ApiResponse;
import com.bea.payment.common.response.StandardResultCode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;

import java.util.Date;
import java.util.Objects;

/**
 * CHATS payment execution service.
 *
 * <p>Responsibilities:
 * 1. Load complete transaction data from MAIN table by transactionId;
 * 2. Validate whether the transaction belongs to CHT/CHATS processing scope;
 * 3. Call `ChatsPaymentOrchestrator` to complete CHATS HTTP orchestration;
 * 4. Update MAIN with CHATS response fields, final status, or technical errors.</p>
 *
 * <p>Note: This service does not declare transactions. CHATS is an external HTTP call,
 * and slow downstream calls cannot be wrapped in database transactions.
 * Each execution performs one MAIN update; real Worker ACK/NACK boundaries will be added later.</p>
 */
@Service
@ConditionalOnExpression("'${pe.downstream.ebk.base-url:}'.trim().length() > 0")
public class ChatsPaymentExecutionService {

    private static final Logger log = LoggerFactory.getLogger(ChatsPaymentExecutionService.class);
    private static final String SUCCESS_CODE = "00";

    private final PaymentTxnMainService txnMainService;
    private final ChatsPaymentOrchestrator orchestrator;
    private final PaymentExecutionPersistenceService persistenceService;
    private final ChatsProperties chatsProperties;
    private final ObjectMapper objectMapper;

    public ChatsPaymentExecutionService(PaymentTxnMainService txnMainService,
                                        ChatsPaymentOrchestrator orchestrator,
                                        PaymentExecutionPersistenceService persistenceService,
                                        ChatsProperties chatsProperties,
                                        ObjectMapper objectMapper) {
        this.txnMainService = Objects.requireNonNull(txnMainService, "txnMainService must not be null");
        this.orchestrator = Objects.requireNonNull(orchestrator, "orchestrator must not be null");
        this.persistenceService = Objects.requireNonNull(persistenceService,
                "persistenceService must not be null");
        this.chatsProperties = Objects.requireNonNull(chatsProperties, "chatsProperties must not be null");
        this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper must not be null");
    }

    /**
     * Execute a settled CHATS confirm transfer.
     *
     * <p>CHATS timeout/IO cannot determine if the transaction was posted,
     * so unknown results are moved to MANUAL_REVIEW and must never be auto-retried.
     * HTTP non-2xx is still treated as clear technical failure.</p>
     */
    public String execute(String transactionId) {
        log.info("[CHATS-EXEC] Start executing CHATS confirm transfer for transactionId={}", transactionId);
        PaymentTxnMainConvertDTO txnMainConvertDTO = txnMainService.loadTxn(transactionId);
        PaymentTxnMainEntity txn = txnMainConvertDTO.getPaymentTxnMainEntity();
        PaymentTxnEventEntity event1 = txnMainConvertDTO.getPaymentTxnEventEntity();
        assertChetTransaction(txn);
        txn.setLastDownstreamSystem(DownstreamSystemEnum.CHATS.getCode());

        try {
            // 1. Orchestrator builds JSON, POSTs CHATS, parses response, does not touch DB
            ApiResponse<String> executeResponse = orchestrator.execute(txn,event1,chatsProperties.getConfirmUrl());

            // 2. Execution service handles state closure and MAIN update
            PaymentTxnEventEntity event2 = newChatsEvent("RESPONSE");
            applyChatsResponse(txn, event2,executeResponse.getData());
            persistenceService.save(txn, event2);
            log.info("[CHATS-EXEC] Successfully updated transaction status to {} for transactionId={}",
                    txn.getPaymentStatus(), transactionId);
            return executeResponse.getData();
        } catch (ChatsPaymentException e) {
            // 3. CHATS business rejection; save error and mark as failed
            markBusinessRejected(txn, e);
            PaymentTxnEventEntity event = newChatsEvent("REJECTED");
            applyErrorEvent(event, txn, txn.getLastErrorCode(), "CHATS business rejection");
            persistenceService.save(txn, event);
            log.warn("[CHATS-EXEC] Business rejected at stage={} for transactionId={}",
                    e.getStage(), transactionId);
            return null;
        } catch (ChatsHttpException e) {
            // 4. CHATS timeout/IO/interrupted becomes manual review;
            // HTTP non-2xx is clear technical failure
            applyHttpFailure(txn, e);
            PaymentTxnEventEntity event = newChatsEvent("ERROR");
            applyErrorEvent(event, txn, txn.getLastErrorCode(), "CHATS transport failure");
            persistenceService.save(txn, event);
            log.warn("[CHATS-EXEC] HTTP failure with errorType={} for transactionId={}, status={}",
                    e.getErrorType(), transactionId, txn.getPaymentStatus());
            return null;
        }
    }



    /**
     * Current CHATS execution service only handles CHT transactions.
     */
    private void assertChetTransaction(PaymentTxnMainEntity txn) {
        if (!TransactionTypeEnum.CHATS.getCode().equalsIgnoreCase(txn.getTransactionType())) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "CHATS execution only supports CHATS transaction");
        }
    }

    /**
     * Save CHATS business response and map to final payment status.
     *
     * <p>Success: ebzwk00oHdrRespCode=00 → COMPLETED.
     * Failure: non-00 return code → FAILED.</p>
     */
    private void applyChatsResponse(PaymentTxnMainEntity txn, PaymentTxnEventEntity event2, String responseJson) {
        try {
            ChatsConfirmTransferResponse response = objectMapper.readValue(responseJson, ChatsConfirmTransferResponse.class);
            log.debug("[CHATS-EXEC] Parsed CHATS response for transactionId={}", txn.getTransactionId());

            // Extract header and HTC02 blocks
            ChatsConfirmTransferResponse.Ebzwk00oArea ebzwk00oArea = response.getDfhcommarea() != null
                    ? response.getDfhcommarea().getEbzwk00wArea() != null
                        ? response.getDfhcommarea().getEbzwk00wArea().getEbzwk00oArea() : null : null;

            if (ebzwk00oArea == null) {
                log.warn("[CHATS-EXEC] CHATS response missing ebzwk00oArea for transactionId={}", txn.getTransactionId());
                txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
                txn.setLastErrorCode("CHATS_RESPONSE_STRUCTURE_ERROR");
                txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
                txn.setErrorSource(ErrorSourceEnum.CHATS.getCode());
                txn.setExecutionEndTime(new Date());
                applyErrorEvent(event2, txn, txn.getLastErrorCode(),
                        "CHATS response structure is invalid");
                return;
            }

            ChatsConfirmTransferResponse.Ebzwk00oHeader header = ebzwk00oArea.getEbzwk00oHeader();
            ChatsConfirmTransferResponse.Ebzwk00oHtc02 htc02 = ebzwk00oArea.getEbzwk00oHtc02();

            // Map response code to payment status
            String respCode = header != null ? header.getEbzwk00oHdrRespCode() : null;
            if (SUCCESS_CODE.equals(respCode)) {
                txn.setPaymentStatus(PaymentStatusEnum.COMPLETED.getCode());
                txn.setLastErrorCode(null);
                txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_SUCCESS.getCode());
                txn.setErrorSource(null);
            } else {
                txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
                txn.setLastErrorCode("CHATS_RESP_" + (respCode != null ? respCode : "UNKNOWN"));
                txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
                txn.setErrorSource(ErrorSourceEnum.CHATS.getCode());
            }
            txn.setExecutionEndTime(new Date());
            event2.setResultStatus(txn.getPaymentStatus());
            event2.setResultCode(respCode);
            event2.setErrorCode(txn.getLastErrorCode());

            // Map header fields to event
            if (header != null) {
                event2.setHdrMessageId(header.getEbzwk00oHdrMessageId());
                event2.setHdrTxPostDate(header.getEbzwk00oHdrTxPostDate());
                event2.setHdrTxnNumber(header.getEbzwk00oHdrTxnNumber());
                event2.setHdrCibAcProdCode(header.getEbzwk00oHdrCibAcProdCode());
                event2.setHdrTxnType(header.getEbzwk00oHdrTxnType());
                event2.setHdrSpecRateFlg(header.getEbzwk00oHdrSpecRateFlg());
                event2.setHdrMediaCode(header.getEbzwk00oHdrMediaCode());
                txn.setReferenceNo(header.getEbzwk00oHdrTxnNumber());
//                txn.setReferenceNo("CDC" + header.getEbzwk00oHdrTxnNumber()//todo下游返回的txn太长了，可能还没开发好
//                        + LocalDate.now().format(DateTimeFormatter.ofPattern("yyMMdd")));
            }

            // Map HTC02 fields to event and txn
            if (htc02 != null) {
                // Event fields
                event2.setRelCompCode(htc02.getEbzwk00oHtc02RelCompCode());
                event2.setRelAcSeq(htc02.getEbzwk00oHtc02RelAcSeq() != null
                        ? String.valueOf(htc02.getEbzwk00oHtc02RelAcSeq()) : null);
                event2.setRelAcCcy(htc02.getEbzwk00oHtc02RelAcCcy());
                event2.setRelAcStatus(htc02.getEbzwk00oHtc02RelAcStatus());
                event2.setRelAcNoFmt(htc02.getEbzwk00oHtc02RelAcNoFmt());

                event2.setChatAcNo(htc02.getEbzwk00oHtc02ChatAcNo());
                event2.setChatAcTpCode(htc02.getEbzwk00oHtc02ChatAcTpCode());

                event2.setPaymentDetail1(htc02.getEbzwk00oHtc02PaymentDtl1());
                event2.setPaymentDetail2(htc02.getEbzwk00oHtc02PaymentDtl2());
                event2.setPaymentDetail3(htc02.getEbzwk00oHtc02PaymentDtl3());
                event2.setPaymentDetail4(htc02.getEbzwk00oHtc02PaymentDtl4());

                event2.setPrntAdvInd(htc02.getEbzwk00oHtc02PrntAdvInd());
                event2.setResendFlag(htc02.getEbzwk00oHtc02ResendFlag());
                event2.setTransStatus(htc02.getEbzwk00oHtc02TransStatus());
                event2.setSweepType(htc02.getEbzwk00oHtc02SweepType());
                event2.setPriority(htc02.getEbzwk00oHtc02Priority());
                event2.setLmInd(htc02.getEbzwk00oHtc02LmInd());
                event2.setLmInstrNum(htc02.getEbzwk00oHtc02LmInstrNum());

                event2.setDepositAccountName1(htc02.getEbzwk00oHtc02DepAcName1());
                event2.setDepositAccountName2(htc02.getEbzwk00oHtc02DepAcName2());
                event2.setDepositAccountName3(htc02.getEbzwk00oHtc02DepAcName3());
                event2.setDepositAccountName4(htc02.getEbzwk00oHtc02DepAcName4());

                event2.setOurChargeBearerInd(htc02.getEbzwk00oHtc02OvrChrgInd());
                event2.setOurChargeBearerCcy(htc02.getEbzwk00oHtc02OvrChrgCcy());
                event2.setOurChargeBearerAmt(htc02.getEbzwk00oHtc02OvrChrgAmt() != null
                        ? String.valueOf(htc02.getEbzwk00oHtc02OvrChrgAmt()) : null);

                // Set decimal fields
                if (htc02.getEbzwk00oHtc02ChrgDiscRate() != null) {
                    event2.setChrgDiscRate(java.math.BigDecimal.valueOf(htc02.getEbzwk00oHtc02ChrgDiscRate()));
                }
                if (htc02.getEbzwk00oHtc02SweepTrigAmt() != null) {
                    event2.setSweepTrigAmt(java.math.BigDecimal.valueOf(htc02.getEbzwk00oHtc02SweepTrigAmt()));
                }
                if (htc02.getEbzwk00oHtc02SweepAmt() != null) {
                    event2.setSweepAmt(java.math.BigDecimal.valueOf(htc02.getEbzwk00oHtc02SweepAmt()));
                }

                // Txn main fields - set hkd equivalent and fx rate from response
                if (htc02.getEbzwk00oHtc02DbAmtHkd() != null) {
                    txn.setHkdEquivalentAmount(java.math.BigDecimal.valueOf(htc02.getEbzwk00oHtc02DbAmtHkd()));
                }
                if (htc02.getEbzwk00oHtc02BookRate() != null) {
                    txn.setFxRate(java.math.BigDecimal.valueOf(htc02.getEbzwk00oHtc02BookRate()));
                }
            }

            log.info("[CHATS-EXEC] Successfully applied CHATS response for transactionId={}, respCode={}, status={}",
                    txn.getTransactionId(), respCode, txn.getPaymentStatus());

        } catch (JsonProcessingException | IllegalArgumentException e) {
            log.error("[CHATS-EXEC] Failed to parse CHATS response for transactionId={}: {}",
                    txn.getTransactionId(), e.getMessage(), e);
            txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
            txn.setLastErrorCode("CHATS_RESPONSE_PARSE_ERROR");
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
            txn.setErrorSource(ErrorSourceEnum.CHATS.getCode());
            txn.setExecutionEndTime(new Date());
            applyErrorEvent(event2, txn, txn.getLastErrorCode(), "CHATS response cannot be parsed");
        }
    }

    /**
     * Save CHATS HTTP/network failure result.
     *
     * <p>timeout/IO/interrupted → unknown result, move to MANUAL_REVIEW.
     * HTTP non-2xx → clear technical failure, mark FAILED.</p>
     */
    private void applyHttpFailure(PaymentTxnMainEntity txn, ChatsHttpException e) {
        String errorCode = "Chats_" + e.getErrorType().name();
        txn.setLastErrorCode(errorCode);
        txn.setErrorSource(ErrorSourceEnum.CHATS.getCode());
        if (ChatsHttpErrorType.HTTP_STATUS == e.getErrorType()) {
            txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_HTTP_STATUS.getCode());
            txn.setExecutionEndTime(new Date());
        } else {
            // The payment may already have reached CHATS. Do not retry an ambiguous transfer.
            txn.setPaymentStatus(PaymentStatusEnum.MANUAL_REVIEW.getCode());
            txn.setStatusReason(StatusReasonEnum.MANUAL_REVIEW.getCode());
            txn.setManualReviewReason(errorCode);
            txn.setManualReviewDetailMessage("CHATS outcome is unknown after a transport failure");
            txn.setManualReviewTime(new Date());
            txn.setExecutionEndTime(new Date());
        }
    }

    /**
     * Save CHATS business rejection result.
     */
    private void markBusinessRejected(PaymentTxnMainEntity txn, ChatsPaymentException e) {
        txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
        txn.setLastErrorCode("Chats_" + e.getStage() + "_REJECTED");
        txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
        txn.setErrorSource(ErrorSourceEnum.CHATS.getCode());
        txn.setExecutionEndTime(new Date());
    }

    private PaymentTxnEventEntity newChatsEvent(String stage) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.CHATS.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.CHATS_TRANSFER.name());
        event.setEventStage(stage);
        event.setStartTime(new Date());
        return event;
    }

    private void applyErrorEvent(PaymentTxnEventEntity event, PaymentTxnMainEntity txn,
            String errorCode, String message) {
        event.setResultStatus(txn.getPaymentStatus());
        event.setErrorCode(errorCode);
        event.setErrorMessage(message);
    }
}
