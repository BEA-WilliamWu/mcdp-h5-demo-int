package com.bea.payment.bulk.internal.chats;

import com.bea.payment.bulk.constants.ChatsFieldsStatic;
import com.bea.payment.bulk.internal.chats.model.ChatsConfirmTransferRequest;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.common.response.ApiResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.text.SimpleDateFormat;

import static com.bea.payment.common.util.StringUtil.getPart;


/**
 * CHATS payment call orchestrator.
 *
 * <p>Responsibility: orchestrates a single CHT transaction's CHATS call chain.
 * Does not access database, update MAIN, handle MQ ACK/NACK, or map final PaymentStatus.
 * Execution service calls this class outside transaction boundary, then updates MAIN
 * based on response.</p>
 */
public class ChatsPaymentOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(ChatsPaymentOrchestrator.class);
    private static final String STAGE_CONFIRM = "CONFIRM";

    private final ChatsHttpClient httpClient;
    private final ObjectMapper objectMapper;

    /**
     * Create CHATS payment orchestrator.
     *
     * @param httpClient configured HTTP client with baseUrl and timeout
     * @param objectMapper JSON serializer/deserializer
     */
    public ChatsPaymentOrchestrator(ChatsHttpClient httpClient,
                                    ObjectMapper objectMapper) {
        this.httpClient = Objects.requireNonNull(httpClient, "httpClient must not be null");
        this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper must not be null");
    }

    /**
     * Execute a CHATS confirm transfer call.
     *
     * <p>Main flow:
     * 1. Build confirm transfer request DTO from MAIN fields;
     * 2. POST to confirm endpoint;
     * 3. Parse response and return to caller.</p>
     *
     * @param txn                 payment transaction entity
     * @param confirmEndpointPath
     * @return response body string from CHATS
     */
    public ApiResponse<String> execute(PaymentTxnMainEntity txn,PaymentTxnEventEntity event, String confirmEndpointPath) {
        Objects.requireNonNull(txn, "txn must not be null");

        String transactionId = txn.getTransactionId();
        log.info("[CHATS] Start executing CHATS confirm transfer for transactionId={}", transactionId);

        // 1. Build request JSON from transaction fields
        String requestJson = buildConfirmRequest(txn,event);
        log.debug("[CHATS-CONFIRM] Request prepared for transactionId={}", transactionId);

        // 2. Call CHATS confirm endpoint
        ApiResponse<String> responseJson = httpClient.postJson(confirmEndpointPath, requestJson);
        log.info("[CHATS-CONFIRM] Response received for transactionId={}", transactionId);

        // 3. Return raw response; final status mapping left to execution service
        log.info("[CHATS] Completed CHATS confirm transfer execution for transactionId={}", transactionId);
        return responseJson;
    }

    /**
     * Build confirm transfer request JSON from transaction entity.
     *
     * <p>Maps MAIN table fields to CHATS API request structure per ebzhtc02.v1.json schema.
     * Field mapping rules should be documented per CHATS API spec.</p>
     */
    private String buildConfirmRequest(PaymentTxnMainEntity txn,PaymentTxnEventEntity event) {
        try {
            ChatsConfirmTransferRequest request = ChatsConfirmTransferRequest.builder()
                    .dfhcommarea(
                            ChatsConfirmTransferRequest.Dfhcommarea.builder()
                                    .ebzwk00wArea(
                                            ChatsConfirmTransferRequest.Ebzwk00wArea.builder()
                                                    .ebzwk00iArea(
                                                            ChatsConfirmTransferRequest.Ebzwk00iArea.builder()
                                                                    .ebzwk00iHeader(buildHeader(event))
                                                                    .ebzwk00iHtc02(buildHtc02(txn,event))
                                                                    .build()
                                                    )
                                                    .build()
                                    )
                                    .build()
                    )
                    .build();
            return objectMapper.writeValueAsString(request);
        } catch (JsonProcessingException e) {
            throw new ChatsPaymentException(STAGE_CONFIRM, "Failed to build CHATS confirm request: " + e.getMessage());
        }
    }

    /**
     * Build the ebzwk00iHeader from transaction entity fields.
     */
    private ChatsConfirmTransferRequest.Ebzwk00iHeader buildHeader(PaymentTxnEventEntity event) {
        return ChatsConfirmTransferRequest.Ebzwk00iHeader.builder()
//                .ebzwk00iHdrHostTermNo(event.getHdrHostTermNo())
                .ebzwk00iHdrHostStrArea(
                        ChatsConfirmTransferRequest.Ebzwk00iHdrHostStrArea.builder()
                                .ebzwk00iHdrHostSessId(event.getHdrHostSessId())
                                .ebzwk00iHdrChSrcInd(event.getHdrChSrcInd())
                                .ebzwk00iHdr01(null)
                                .build()
                )
                .ebzwk00iHdrMessageId(ChatsFieldsStatic.HDR_MESSAGE_ID_HTC02)
                .ebzwk00iHdrOpt(event.getHdrOpt())
                .ebzwk00iHdrBankCode(event.getHdrBankCode())
                .ebzwk00iHdrIntBankCode(event.getHdrIntBankCode())
                .ebzwk00iHdrMediaCode(event.getHdrMediaCode())
                .ebzwk00iHdrCibCustId(
                        ChatsConfirmTransferRequest.Ebzwk00iHdrCibCustId.builder()
                                .ebzwk00iHdrCibExtAcno(event.getHdrCibCustId())
                                .build()
                )
                .ebzwk00iHdrCibIntAcNo(event.getHdrCibIntAcNo())
                .ebzwk00iHdrRtTimeoutFlg(event.getHdrRtTimeoutFlg())
//                .ebzwk00iHdrTxPostDate(event.getHdrTxPostDate())
                .ebzwk00iHdrTxMatchKey(event.getHdrTxMatchKey())
                .ebzwk00iHdrSubOpt(event.getHdrSubOpt())
                .ebzwk00iHdrCompCode(event.getHdrCompCode())
                .ebzwk00iHdrCibAccessLvl(event.getHdrCibAccessLvl())
                .ebzwk00iHdrPublicKeyInd(event.getHdrPublicKeyInd())
                .ebzwk00iHdrInputUserId(event.getHdrInputUserId())
                .ebzwk00iHdrInputDate(event.getHdrInputDate())
                .ebzwk00iHdrInputTime(event.getHdrInputTime())
                .ebzwk00iHdrAprvlUserId(event.getHdrAprvlUserId())
                .ebzwk00iHdrAprvlDate(event.getHdrAprvlDate())
                .ebzwk00iHdrAprvlTime(event.getHdrAprvlTime())
                .ebzwk00iHdrIntCcbbbdd(event.getHdrIntCcbbbdd())
                .ebzwk00iHdrTxnNumber(event.getHdrTxnNumber())
                .ebzwk00iHdrDialupBkupInd(event.getHdrDialupBkupInd())
                .ebzwk00iHdrSusIpFlg(event.getHdrSusIpFlg())
                .ebzwk00iHdrCibAcProdCode(event.getHdrCibAcProdCode())
                .ebzwk00iHdrRiskInd(event.getHdrRiskInd())
                .ebzwk00iHdrSpecRateFlg(event.getHdrSpecRateFlg())
                .ebzwk00iHdrTxnType(event.getHdrTxnType())
                .ebzwk00iHdrOmbFlag(event.getHdrOmbFlag())
                .build();
    }

    /**
     * Build the ebzwk00iHtc02 transfer detail block from transaction entity fields.
     */
    private ChatsConfirmTransferRequest.Ebzwk00iHtc02 buildHtc02(PaymentTxnMainEntity txn,PaymentTxnEventEntity event) {
        return ChatsConfirmTransferRequest.Ebzwk00iHtc02.builder()
                .ebzwk00iHtc02RelCompCode(event.getRelCompCode())
                .ebzwk00iHtc02RelAcSeq(Integer.valueOf(event.getRelAcSeq()))
                .ebzwk00iHtc02RelAcPrdCode(formatRelAcPrdCode(event.getRelAcProdCode()))
                .ebzwk00iHtc02RelAcCcy(event.getRelAcCcy())
                .ebzwk00iHtc02RelAcStatus(event.getRelAcStatus())
                .ebzwk00iHtc02RelAcNo(txn.getPayerAccountNo())
                .ebzwk00iHtc02RelAcNoFmt(event.getRelAcNoFmt())
                .ebzwk00iHtc02DbAmtCcy(txn.getDebitAmountCcy())
                .ebzwk00iHtc02DbAmt(txn.getDebitAmount().doubleValue())
                .ebzwk00iHtc02ChatAcNo(event.getChatAcNo())
                .ebzwk00iHtc02ChatAcTpCode(event.getChatAcTpCode())
                .ebzwk00iHtc02ChatAcName1(getPart(txn.getPayeeName(),1))
                .ebzwk00iHtc02ChatAcName2(getPart(txn.getPayeeName(),2))
                .ebzwk00iHtc02ChatAcName3(getPart(txn.getPayeeName(),3))
                .ebzwk00iHtc02ChatAcName4(getPart(txn.getPayeeName(),4))
                .ebzwk00iHtc02PaymentDtl1(event.getPaymentDetail1())
                .ebzwk00iHtc02PaymentDtl2(event.getPaymentDetail2())
                .ebzwk00iHtc02PaymentDtl3(event.getPaymentDetail3())
                .ebzwk00iHtc02PaymentDtl4(event.getPaymentDetail4())
                .ebzwk00iHtc02PrntAdvInd(event.getPrntAdvInd())
                .ebzwk00iHtc02ServiceCcy(txn.getDebitAmountCcy())
                .ebzwk00iHtc02ServiceAmt(null != txn.getServiceChargeAmount() ? txn.getServiceChargeAmount().doubleValue() : 0.0)
                .ebzwk00iHtc02ExeDate(toDateNumber(txn.getExecutionDate()))
                .ebzwk00iHtc02ResendFlag(event.getResendFlag())
                .ebzwk00iHtc02TransStatus(event.getTransStatus())
                .ebzwk00iHtc02ChrgDiscRate(event.getChrgDiscRate() != null ? event.getChrgDiscRate().doubleValue() : 0.0)
                .ebzwk00iHtc02SweepType(event.getSweepType())
                .ebzwk00iHtc02SweepTrigAmt(event.getSweepTrigAmt() != null ? event.getSweepTrigAmt().doubleValue() : null)
                .ebzwk00iHtc02SweepAmt(event.getSweepAmt() != null ? event.getSweepAmt().doubleValue() : null)
                .ebzwk00iHtc02Priority(event.getPriority())
                .ebzwk00iHtc02LmInd(event.getLmInd())
                .ebzwk00iHtc02DepAcName1(event.getDepositAccountName1())
                .ebzwk00iHtc02DepAcName2(event.getDepositAccountName2())
                .ebzwk00iHtc02DepAcName3(event.getDepositAccountName3())
                .ebzwk00iHtc02DepAcName4(event.getDepositAccountName4())
                .ebzwk00iHtc02LmInstrNum(event.getLmInstrNum())
                .ebzwk00iHtc02OvrChrgInd(event.getOurChargeBearerInd())
                .build();
    }

    private static Integer toDateNumber(java.util.Date date) {
        if (date == null) {
            return null;
        }
        return Integer.valueOf(new SimpleDateFormat("yyyyMMdd").format(date));
    }


    /**
     * Format related account product code (Integer -> String).
     */
    private static String formatRelAcPrdCode(Integer relAcProdCode) {
        if (relAcProdCode == null) {
            return null;
        }
        return String.valueOf(relAcProdCode);
    }

}
