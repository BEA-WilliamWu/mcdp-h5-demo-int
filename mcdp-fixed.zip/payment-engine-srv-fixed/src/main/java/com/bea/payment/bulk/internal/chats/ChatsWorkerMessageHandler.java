package com.bea.payment.bulk.internal.chats;

import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.flow.mq.MqMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * Lightweight message handler for CHATS before Worker integration.
 *
 * <p>This class deliberately does not depend on IBM MQ SDK and does not handle ACK/NACK:
 * The real Worker only needs to pass the deserialized `MqMessage` to this class,
 * and this class determines whether the message should enter the CHATS execution chain.</p>
 */
@Component
@ConditionalOnExpression("'${pe.downstream.ebk.base-url:}'.trim().length() > 0")
public class ChatsWorkerMessageHandler {

    private static final Logger log = LoggerFactory.getLogger(ChatsWorkerMessageHandler.class);
    private final ChatsPaymentExecutionService executionService;

    public ChatsWorkerMessageHandler(ChatsPaymentExecutionService executionService) {
        this.executionService = Objects.requireNonNull(executionService, "executionService must not be null");
    }

    /**
     * Handle a Worker message.
     *
     * <p>Logic steps:
     * 1. Check if message is null;
     * 2. Non-CHATS messages do not belong to CHATS transfer chain, skip directly;
     * 3. CHATS messages only take transactionId, complete transaction params are still
     *    read from MAIN table by execution service;
     * 4. Exceptions thrown by execution service are not swallowed here,
     *    let the future MQ layer decide ACK, NACK or manual handling.</p>
     */
    public void handle(MqMessage message) {
        Objects.requireNonNull(message, "message must not be null");

        String transactionId = message.getTransactionId();

        if (!TransactionTypeEnum.CHATS.getCode().equalsIgnoreCase(message.getTransactionType())) {
            log.debug("[CHATS-HANDLER] Skipping non-CHATS message: transactionId={}, txType={}",
                    transactionId, message.getTransactionType());
            return;
        }

        log.info("[CHATS-HANDLER] Handling CHATS transaction: transactionId={}", transactionId);

        try {
            executionService.execute(transactionId);
            log.info("[CHATS-HANDLER] Successfully executed CHATS transfer: transactionId={}", transactionId);
        } catch (Exception e) {
            log.error("[CHATS-HANDLER] Failed to execute CHATS transfer: transactionId={}, error={}",
                    transactionId, e.getMessage(), e);
            throw e;
        }
    }
}
