package com.bea.payment.bulk.internal.chats.config;

import com.bea.payment.bulk.internal.chats.ChatsHttpClient;
import com.bea.payment.bulk.internal.chats.ChatsPaymentOrchestrator;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * CHATS Spring assembly configuration.
 *
 * <p>Only creates `ChatsPaymentOrchestrator` when `pe.downstream.ebk.base-url` is configured,
 * avoiding accidental calls when local or test environment lacks real CHATS address.</p>
 */
@Configuration
@EnableConfigurationProperties(ChatsProperties.class)
public class ChatsClientConfiguration {

    /**
     * Create CHATS HTTP client.
     *
     * <p>Only enabled when `pe.downstream.ebk.base-url` is configured.
     * baseUrl has no real default value to avoid accidental connections to production CHATS.</p>
     */
    @Bean
    @ConditionalOnExpression("'${pe.downstream.ebk.base-url:}'.trim().length() > 0")
    public ChatsHttpClient chatsHttpClient(ChatsProperties properties) {
        return new ChatsHttpClient(
                properties.getBaseUrl(),
                properties.getTimeout(),
                properties.isTlsHostnameVerificationEnabled(),
                properties.isTlsInsecureSkipVerify(),
                properties.getXIbmClientId(),
                properties.getXIbmClientSecret());
    }

    /**
     * Create CHATS payment orchestrator.
     *
     * <p>Orchestrator reuses the same HTTP client and reads endpoint path from configuration.
     * ExecutionService only depends on this orchestrator, not concerned with endpoint details.</p>
     */
    @Bean
    @ConditionalOnExpression("'${pe.downstream.ebk.base-url:}'.trim().length() > 0")
    public ChatsPaymentOrchestrator chatsPaymentOrchestrator(
            ChatsHttpClient chatsHttpClient) {
        return new ChatsPaymentOrchestrator(
                chatsHttpClient,
                new ObjectMapper());
    }
}
