package com.bea.payment.bulk.internal.chats.config;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

/**
 * CHATS (CHT) downstream interface configuration.
 *
 * <p>Stores connection parameters for the CHATS API without any real secrets or
 * environment-sensitive values. baseUrl has no default to avoid accidental calls.</p>
 */
@ConfigurationProperties(prefix = "pe.downstream.ebk")
@Getter
@Setter
public class ChatsProperties {

    /**
     * CHATS base URL, e.g. QA3 or UAT endpoint. No default to avoid accidental connections.
     */
    private String baseUrl;


    private String perCheckUrl;
    /**
     * CHATS confirm transfer endpoint path.
     */
    private String confirmUrl;

    /**
     * API Connect client id. Real value must not be committed to codebase.
     */
    private String xIbmClientId;

    /**
     * API Connect client secret. Real value must not be committed to codebase.
     */
    private String xIbmClientSecret;

    /**
     * Single CHATS HTTP request timeout.
     */
    private Duration timeout = Duration.ofSeconds(10);

    /**
     * Whether to enable HTTPS hostname verification.
     *
     * <p>Enabled by default. Only disable for local SSH tunnel scenarios with localhost
     * where the certificate hostname is the real CHATS domain.</p>
     */
    private boolean tlsHostnameVerificationEnabled = true;

    /**
     * Whether to skip HTTPS certificate chain and hostname verification entirely.
     *
     * <p>This disables both certificate chain validation and hostname verification.
     * Must only be used temporarily before the SIT certificate is loaded into the JDK truststore.
     * Takes precedence over tlsHostnameVerificationEnabled when enabled.</p>
     */
    private boolean tlsInsecureSkipVerify = false;

    /**
     * Query compensation configuration.
     */
    private Query query = new Query();

    @Getter
    @Setter
    public static class Query {

        /**
         * Whether CHATS status query compensation is enabled.
         */
        private boolean enabled = false;

        /**
         * Fixed delay between query cycles (milliseconds).
         */
        private long fixedDelay = 60000;

        /**
         * Interval between individual queries within a cycle (milliseconds).
         */
        private long intervalBetweenQueries = 3000;

        /**
         * Delay before a transaction becomes eligible for query compensation (milliseconds).
         * Default: 1 hour (3600000ms).
         */
        private long queryEligibleDelayMs = 3600000;

        /**
         * Maximum number of queries per scheduler run.
         */
        private int maxQueryPerRun = 50;

        /**
         * Maximum query attempts per transaction.
         */
        private int maxQueryAttempts = 1;
    }
}
