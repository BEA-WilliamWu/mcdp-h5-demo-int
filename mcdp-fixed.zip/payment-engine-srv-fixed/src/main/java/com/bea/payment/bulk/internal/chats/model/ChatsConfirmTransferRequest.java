package com.bea.payment.bulk.internal.chats.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CHATS confirm transfer request DTO.
 *
 * <p>Field names model the CHATS JSON contract from ebzhtc02.v1.json,
 * avoiding manual string-map construction in the call layer.</p>
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatsConfirmTransferRequest {

    /**
     * Top-level BG3 communication area wrapper.
     */
    private Dfhcommarea dfhcommarea;

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Dfhcommarea {
        /**
         * CHATS ebzwk00wArea wrapper.
         */
        private Ebzwk00wArea ebzwk00wArea;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00wArea {
        /**
         * CHATS ebzwk00iArea wrapper.
         */
        private Ebzwk00iArea ebzwk00iArea;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iArea {
        /**
         * CHATS message header.
         */
        private Ebzwk00iHeader ebzwk00iHeader;
        /**
         * CHATS HTC02 transfer detail block.
         */
        private Ebzwk00iHtc02 ebzwk00iHtc02;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHeader {
        /** Host terminal number. */
//        private String ebzwk00iHdrHostTermNo;
        /** Host session information area. */
        private Ebzwk00iHdrHostStrArea ebzwk00iHdrHostStrArea;
        /** Message identifier. */
        private String ebzwk00iHdrMessageId;
        /** Operation code. */
        private String ebzwk00iHdrOpt;
        /** Bank code. */
        private String ebzwk00iHdrBankCode;
        /** Internal bank code. */
        private String ebzwk00iHdrIntBankCode;
        /** Media code. */
        private String ebzwk00iHdrMediaCode;
        /** CIB customer information area. */
        private Ebzwk00iHdrCibCustId ebzwk00iHdrCibCustId;
        /** Internal CIB account number. */
        private String ebzwk00iHdrCibIntAcNo;
        /** RT timeout flag. */
        private String ebzwk00iHdrRtTimeoutFlg;
        /** Transaction posting date. */
//        private String ebzwk00iHdrTxPostDate;
        /** Transaction match key. */
        private String ebzwk00iHdrTxMatchKey;
        /** Sub-operation code. */
        private String ebzwk00iHdrSubOpt;
        /** Component code. */
        private Integer ebzwk00iHdrCompCode;
        /** CIB access level. */
        private String ebzwk00iHdrCibAccessLvl;
        /** Public key indicator. */
        private String ebzwk00iHdrPublicKeyInd;
        /** Input user ID. */
        private String ebzwk00iHdrInputUserId;
        /** Input date (format: yyyyddmm). */
        private String ebzwk00iHdrInputDate;
        /** Input time. */
        private String ebzwk00iHdrInputTime;
        /** Approval user ID. */
        private String ebzwk00iHdrAprvlUserId;
        /** Approval date. */
        private String ebzwk00iHdrAprvlDate;
        /** Approval time. */
        private String ebzwk00iHdrAprvlTime;
        /** Internal CCB bank-date-bank. */
        private String ebzwk00iHdrIntCcbbbdd;
        /** Transaction number. */
        private String ebzwk00iHdrTxnNumber;
        /** Dialup backup indicator. */
        private String ebzwk00iHdrDialupBkupInd;
        /** Suspicious IP flag. */
        private String ebzwk00iHdrSusIpFlg;
        /** CIB account product code. */
        private String ebzwk00iHdrCibAcProdCode;
        /** Risk indicator. */
        private String ebzwk00iHdrRiskInd;
        /** Special rate flag. */
        private String ebzwk00iHdrSpecRateFlg;
        /** Transaction type. */
        private String ebzwk00iHdrTxnType;
        /** OMB flag. */
        private String ebzwk00iHdrOmbFlag;
        /** Header filler field. */
        private String fillerHdr02;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHdrHostStrArea {
        /** Host session ID. */
        private String ebzwk00iHdrHostSessId;
        /** Host source indicator. */
        private String ebzwk00iHdrChSrcInd;
        /** Header field 01. */
        private String ebzwk00iHdr01;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHdrCibCustId {
        /** External account number. */
        private String ebzwk00iHdrCibExtAcno;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHtc02 {
        /** Release component code. */
        private Integer ebzwk00iHtc02RelCompCode;
        /** Release account sequence. */
        private Integer ebzwk00iHtc02RelAcSeq;
        /** Release account product code. */
        private String ebzwk00iHtc02RelAcPrdCode;
        /** Release account currency. */
        private String ebzwk00iHtc02RelAcCcy;
        /** Release account status. */
        private Integer ebzwk00iHtc02RelAcStatus;
        /** Release account number. */
        private String ebzwk00iHtc02RelAcNo;
        /** Release account number formatted. */
        private String ebzwk00iHtc02RelAcNoFmt;
        /** Debit amount currency. */
        private String ebzwk00iHtc02DbAmtCcy;
        /** Debit amount. */
        private Double ebzwk00iHtc02DbAmt;
        /** Exchange rate currency. */
        private String ebzwk00iHtc02ExRateCcy;//get from htc01 response
        /** Exchange rate unit. */
        private String ebzwk00iHtc02ExRateUnit;//get from htc01 response
        /** Bank buy rate. */
        private Double ebzwk00iHtc02BankBuyRate;//get from htc01 response
        /** Bank sell rate. */
        private Double ebzwk00iHtc02BankSellRate;//get from htc01 response
        /** Book rate. */
        private Double ebzwk00iHtc02BookRate;//get from htc01 response
        /** Debit amount HKD. */
        private Double ebzwk00iHtc02DbAmtHkd;
        /** CHATS account number. */
        private String ebzwk00iHtc02ChatAcNo;
        /** CHATS account type code. */
        private String ebzwk00iHtc02ChatAcTpCode;
        /** CHATS account name line 1. */
        private String ebzwk00iHtc02ChatAcName1;
        /** CHATS account name line 2. */
        private String ebzwk00iHtc02ChatAcName2;
        /** CHATS account name line 3. */
        private String ebzwk00iHtc02ChatAcName3;
        /** CHATS account name line 4. */
        private String ebzwk00iHtc02ChatAcName4;
        /** Payment detail line 1. */
        private String ebzwk00iHtc02PaymentDtl1;
        /** Payment detail line 2. */
        private String ebzwk00iHtc02PaymentDtl2;
        /** Payment detail line 3. */
        private String ebzwk00iHtc02PaymentDtl3;
        /** Payment detail line 4. */
        private String ebzwk00iHtc02PaymentDtl4;
        /** Print advice indicator. */
        private String ebzwk00iHtc02PrntAdvInd;
        /** Service currency. */
        private String ebzwk00iHtc02ServiceCcy;
        /** Service amount. */
        private Double ebzwk00iHtc02ServiceAmt;
        /** Service exchange rate. */
        private Double ebzwk00iHtc02SrvcExchRate;
        /** Execution date. */
        private Integer ebzwk00iHtc02ExeDate;
        /** Resend flag. */
        private String ebzwk00iHtc02ResendFlag;
        /** Transaction status. */
        private String ebzwk00iHtc02TransStatus;
        /** Charge/discount rate. */
        private Double ebzwk00iHtc02ChrgDiscRate;
        /** Sweep type. */
        private String ebzwk00iHtc02SweepType;
        /** Sweep trigger amount. */
        private Double ebzwk00iHtc02SweepTrigAmt;
        /** Sweep amount. */
        private Double ebzwk00iHtc02SweepAmt;
        /** Priority. */
        private String ebzwk00iHtc02Priority;
        /** Limit indicator. */
        private String ebzwk00iHtc02LmInd;
        /** Deposit account name line 1. */
        private String ebzwk00iHtc02DepAcName1;
        /** Deposit account name line 2. */
        private String ebzwk00iHtc02DepAcName2;
        /** Deposit account name line 3. */
        private String ebzwk00iHtc02DepAcName3;
        /** Deposit account name line 4. */
        private String ebzwk00iHtc02DepAcName4;
        /** Limit instruction number. */
        private String ebzwk00iHtc02LmInstrNum;
        /** Over charge indicator. */
        private String ebzwk00iHtc02OvrChrgInd;
        /** Over charge currency. */
        private String ebzwk00iHtc02OvrChrgCcy;
        /** Over charge amount. */
        private Double ebzwk00iHtc02OvrChrgAmt;
    }
}
