package com.bea.payment.bulk.internal.chats.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CHATS confirm transfer response DTO.
 *
 * <p>Models the CHATS JSON response structure from ebzhtc02.v1.json schema.
 * Contains header (ebzwk00oHeader) and transfer detail (ebzwk00oHtc02) blocks.</p>
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatsConfirmTransferResponse {

    /**
     * Top-level CHATS communication area wrapper.
     */
    private Dfhcommarea dfhcommarea;

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Dfhcommarea {
        /**
         * CHATS ebzwk00wArea wrapper.
         */
        private Ebzwk00wArea ebzwk00wArea;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00wArea {
        /**
         * CHATS ebzwk00oArea wrapper.
         */
        private Ebzwk00oArea ebzwk00oArea;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oArea {
        /**
         * CHATS message header.
         */
        private Ebzwk00oHeader ebzwk00oHeader;
        /**
         * CHATS HTC02 transfer detail block.
         */
        private Ebzwk00oHtc02 ebzwk00oHtc02;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oHeader {
        /** Message identifier. */
        private String ebzwk00oHdrMessageId;
        /** Response code. */
        private String ebzwk00oHdrRespCode;
        /** Display code. */
        private String ebzwk00oHdrDispCode;
        /** Transaction date (format: yyyyMMdd). */
        private String ebzwk00oHdrTxDate;
        /** Transaction time (format: HHmmss). */
        private String ebzwk00oHdrTxTime;
        /** Transaction reference number. */
        private String ebzwk00oHdrTxRefNo;
        /** Transaction posting date (format: yyyyMMdd). */
        private String ebzwk00oHdrTxPostDate;
        /** CIB internal account number. */
        private String ebzwk00oHdrCibIntAcNo;
        /** Display flag. */
        private String ebzwk00oHdrDispFlg;
        /** Display message. */
        private Ebzwk00oHdrDispMsg ebzwk00oHdrDispMsg;
        /** Transaction match key. */
        private String ebzwk00oHdrTxMatchKey;
        /** Public key processing mode. */
        private String ebzwk00oHdrPbkProcMode;
        /** Transaction number. */
        private String ebzwk00oHdrTxnNumber;
        /** BM code. */
        private String ebzwk00oHdrBmCode;
        /** CHATS transaction HHmmss and task number. */
        private Ebzwk00oHdrHbbTx ebzwk00oHdrHbbTx;
        /** Territory flags (15 fields). */
        private Ebzwk00oHdrTerrFlags ebzwk00oHdrTerrFlags;
        /** CIB account product code. */
        private String ebzwk00oHdrCibAcProdCode;
        /** Alert limit flag. */
        private String ebzwk00oHdrAlertLmtFlg;
        /** Special rate flag. */
        private String ebzwk00oHdrSpecRateFlg;
        /** Transaction type. */
        private String ebzwk00oHdrTxnType;
        /** Media code. */
        private String ebzwk00oHdrMediaCode;
        /** Header field 01. */
        private String ebzwk00oHdr01;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oHdrDispMsg {
        /** Display message first 16 characters. */
        private String ebzwk00oHdrDispMsgF16;
        /** Display message last 24 characters. */
        private String ebzwk00oHdrDispMsgL24;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oHdrHbbTx {
        /** Transaction HHmmss (integer 0-999999). */
        private Integer ebzwk00oHdrHbbTxHhmmss;
        /** Transaction task number (integer 0-9999999). */
        private Integer ebzwk00oHdrHbbTxTaskno;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oHdrTerrFlags {
        /** Territory flag 1. */
        private Integer ebzwk00oHdrTerrFlg1;
        /** Territory flag 2. */
        private Integer ebzwk00oHdrTerrFlg2;
        /** Territory flag 3. */
        private Integer ebzwk00oHdrTerrFlg3;
        /** Territory flag 4. */
        private Integer ebzwk00oHdrTerrFlg4;
        /** Territory flag 5. */
        private Integer ebzwk00oHdrTerrFlg5;
        /** Territory flag 6. */
        private Integer ebzwk00oHdrTerrFlg6;
        /** Territory flag 7. */
        private Integer ebzwk00oHdrTerrFlg7;
        /** Territory flag 8. */
        private Integer ebzwk00oHdrTerrFlg8;
        /** Territory flag 9. */
        private Integer ebzwk00oHdrTerrFlg9;
        /** Territory flag 10. */
        private Integer ebzwk00oHdrTerrFlg10;
        /** Territory flag 11. */
        private Integer ebzwk00oHdrTerrFlg11;
        /** Territory flag 12. */
        private Integer ebzwk00oHdrTerrFlg12;
        /** Territory flag 13. */
        private Integer ebzwk00oHdrTerrFlg13;
        /** Territory flag 14. */
        private Integer ebzwk00oHdrTerrFlg14;
        /** Territory flag 15. */
        private Integer ebzwk00oHdrTerrFlg15;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oHtc02 {
        /** Release component code. */
        private Integer ebzwk00oHtc02RelCompCode;
        /** Release account sequence. */
        private Integer ebzwk00oHtc02RelAcSeq;
        /** Release account product code. */
        private String ebzwk00oHtc02RelAcPrdCode;
        /** Release account currency. */
        private String ebzwk00oHtc02RelAcCcy;
        /** Release account status. */
        private Integer ebzwk00oHtc02RelAcStatus;
        /** Release account number. */
        private String ebzwk00oHtc02RelAcNo;
        /** Release account number formatted. */
        private String ebzwk00oHtc02RelAcNoFmt;
        /** Release account name. */
        private String ebzwk00oHtc02RelAcName;
        /** Debit amount currency. */
        private String ebzwk00oHtc02DbAmtCcy;
        /** Debit amount. */
        private Double ebzwk00oHtc02DbAmt;
        /** Exchange rate currency. */
        private String ebzwk00oHtc02ExRateCcy;
        /** Exchange rate unit. */
        private String ebzwk00oHtc02ExRateUnit;
        /** Bank buy rate. */
        private Double ebzwk00oHtc02BankBuyRate;
        /** Bank sell rate. */
        private Double ebzwk00oHtc02BankSellRate;
        /** Book rate. */
        private Double ebzwk00oHtc02BookRate;
        /** Debit amount HKD. */
        private Double ebzwk00oHtc02DbAmtHkd;
        /** CHATS account number. */
        private String ebzwk00oHtc02ChatAcNo;
        /** CHATS account type code. */
        private String ebzwk00oHtc02ChatAcTpCode;
        /** CHATS account name line 1. */
        private String ebzwk00oHtc02ChatAcName1;
        /** CHATS account name line 2. */
        private String ebzwk00oHtc02ChatAcName2;
        /** CHATS account name line 3. */
        private String ebzwk00oHtc02ChatAcName3;
        /** CHATS account name line 4. */
        private String ebzwk00oHtc02ChatAcName4;
        /** CHATS bank name. */
        private String ebzwk00oHtc02ChatBankName;
        /** CHATS branch name. */
        private String ebzwk00oHtc02ChatBrchName;
        /** Payment detail line 1. */
        private String ebzwk00oHtc02PaymentDtl1;
        /** Payment detail line 2. */
        private String ebzwk00oHtc02PaymentDtl2;
        /** Payment detail line 3. */
        private String ebzwk00oHtc02PaymentDtl3;
        /** Payment detail line 4. */
        private String ebzwk00oHtc02PaymentDtl4;
        /** Print advice indicator. */
        private String ebzwk00oHtc02PrntAdvInd;
        /** Service currency. */
        private String ebzwk00oHtc02ServiceCcy;
        /** Service amount. */
        private Double ebzwk00oHtc02ServiceAmt;
        /** Service exchange rate. */
        private Double ebzwk00oHtc02SrvcExchRate;
        /** Execution date. */
        private Integer ebzwk00oHtc02ExeDate;
        /** Charge/discount rate. */
        private Double ebzwk00oHtc02ChrgDiscRate;
        /** Resend flag. */
        private String ebzwk00oHtc02ResendFlag;
        /** Transaction status. */
        private String ebzwk00oHtc02TransStatus;
        /** Sweep type. */
        private String ebzwk00oHtc02SweepType;
        /** Sweep trigger amount. */
        private Double ebzwk00oHtc02SweepTrigAmt;
        /** Sweep amount. */
        private Double ebzwk00oHtc02SweepAmt;
        /** Debit account balance before. */
        private Double ebzwk00oHtc02DrAcBalBef;
        /** Debit account balance after. */
        private Double ebzwk00oHtc02DrAcBalAft;
        /** Priority. */
        private String ebzwk00oHtc02Priority;
        /** Limit indicator. */
        private String ebzwk00oHtc02LmInd;
        /** Deposit account name line 1. */
        private String ebzwk00oHtc02DepAcName1;
        /** Deposit account name line 2. */
        private String ebzwk00oHtc02DepAcName2;
        /** Deposit account name line 3. */
        private String ebzwk00oHtc02DepAcName3;
        /** Deposit account name line 4. */
        private String ebzwk00oHtc02DepAcName4;
        /** Limit instruction number. */
        private String ebzwk00oHtc02LmInstrNum;
        /** Over charge indicator. */
        private String ebzwk00oHtc02OvrChrgInd;
        /** Over charge currency. */
        private String ebzwk00oHtc02OvrChrgCcy;
        /** Over charge amount. */
        private Double ebzwk00oHtc02OvrChrgAmt;
        /** Operator reference. */
        private Ebzwk00oHtc02OpyRef ebzwk00oHtc02OpyRef;
        /** Remitter extended name. */
        private String ebzwk00oHtc02RmtLongEName;
        /** Remitter extended address line 1. */
        private String ebzwk00oHtc02RmtExtAdrL1;
        /** Remitter extended address line 2. */
        private String ebzwk00oHtc02RmtExtAdrL2;
        /** Remitter extended address line 3. */
        private String ebzwk00oHtc02RmtExtAdrL3;
        /** Remitter extended address line 4. */
        private String ebzwk00oHtc02RmtExtAdrL4;
        /** Remitter extended address line 5. */
        private String ebzwk00oHtc02RmtExtAdrL5;
        /** BIC code. */
        private String ebzwk00oHtc02BicCode;
        /** Filler field. */
        private String ebzwk00oHtc02Filler;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00oHtc02OpyRef {
        /** Operator reference date (format: yyyyMMdd). */
        private String ebzwk00oHtc02Date;
        /** CDC account number. */
        private String ebzwk00oHtc02CdcAcNo;
        /** TT or CHATS indicator. */
        private String ebzwk00oHtc02TtOrChats;
        /** Electronic bank reference number. */
        private String ebzwk00oHtc02EbkRefNo;
        /** Operator reference type. */
        private String ebzwk00oHtc02Type;
        /** Operator reference time (format: HHmmss). */
        private String ebzwk00oHtc02Time;
        /** System ID. */
        private String ebzwk00oHtc02SysId;
    }
}
