package com.bea.payment.bulk.internal.chats.model;

/**
 * CHATS HTTP error classification.
 *
 * <p>Categorizes HTTP/network failures to determine whether the result is unknown
 * (timeout, IO, interrupted) or clearly failed (non-2xx status).</p>
 */
public enum ChatsHttpErrorType {
    /**
     * HTTP status code is not 2xx.
     */
    HTTP_STATUS,

    /**
     * Request timeout. Result is unknown.
     */
    TIMEOUT,

    /**
     * IO error during request. Result is unknown.
     */
    IO_ERROR,

    /**
     * Thread interrupted during request. Result is unknown.
     */
    INTERRUPTED
}
