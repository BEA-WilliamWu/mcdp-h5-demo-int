package com.bea.payment.bulk.internal.chats.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * CHATS internal transfer request DTO.
 *
 * <p>Field names model the CHATS JSON contract from ebzhtcc1.v1.json,
 * avoiding manual string-map construction in the call layer.</p>
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatsPerCheckTransferRequest {

    /**
     * Top-level BG3 communication area wrapper.
     */
    private Dfhcommarea dfhcommarea;

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Dfhcommarea {
        /**
         * CHATS ebzwk00wArea wrapper.
         */
        private Ebzwk00wArea ebzwk00wArea;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00wArea {
        /**
         * CHATS ebzwk00iArea wrapper.
         */
        private Ebzwk00iArea ebzwk00iArea;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iArea {
        /**
         * CHATS message header.
         */
        private Ebzwk00iHeader ebzwk00iHeader;
        /**
         * CHATS HTCC1 transfer detail block.
         */
        private Ebzwk00iHtcc1 ebzwk00iHtcc1;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHeader {
        /** Host terminal number. */
//        private String ebzwk00iHdrHostTermNo;
        /** Host session information area. */
        private Ebzwk00iHdrHostStrArea ebzwk00iHdrHostStrArea;
        /** Message identifier. */
        private String ebzwk00iHdrMessageId;
        /** Operation code. */
        private String ebzwk00iHdrOpt;
        /** Bank code. */
        private String ebzwk00iHdrBankCode;
        /** Internal bank code. */
        private String ebzwk00iHdrIntBankCode;
        /** Media code. */
        private String ebzwk00iHdrMediaCode;
        /** CIB customer information area. */
        private Ebzwk00iHdrCibCustId ebzwk00iHdrCibCustId;
        /** Internal CIB account number. */
        private String ebzwk00iHdrCibIntAcNo;
        /** RT timeout flag. */
        private String ebzwk00iHdrRtTimeoutFlg;
        /** Transaction posting date. */
//        private String ebzwk00iHdrTxPostDate;
        /** Transaction match key. */
//        private String ebzwk00iHdrTxMatchKey;
        /** Sub-operation code. */
        private String ebzwk00iHdrSubOpt;
        /** Component code. */
        private Integer ebzwk00iHdrCompCode;
        /** CIB access level. */
//        private String ebzwk00iHdrCibAccessLvl;
        /** Public key indicator. */
//        private String ebzwk00iHdrPublicKeyInd;
        /** Input user ID. */
        private String ebzwk00iHdrInputUserId;
        /** Input date (format: yyyyddmm). */
//        private String ebzwk00iHdrInputDate;
        /** Input time. */
//        private String ebzwk00iHdrInputTime;
        /** Approval user ID. */
//        private String ebzwk00iHdrAprvlUserId;
        /** Approval date. */
//        private String ebzwk00iHdrAprvlDate;
        /** Approval time. */
//        private String ebzwk00iHdrAprvlTime;
        /** Internal CCB bank-date-bank. */
//        private String ebzwk00iHdrIntCcbbbdd;
        /** Transaction number. */
        private String ebzwk00iHdrTxnNumber;
        /** Dialup backup indicator. */
//        private String ebzwk00iHdrDialupBkupInd;
        /** Suspicious IP flag. */
//        private String ebzwk00iHdrSusIpFlg;
        /** CIB account product code. */
//        private String ebzwk00iHdrCibAcProdCode;
        /** Risk indicator. */
//        private String ebzwk00iHdrRiskInd;
        /** Special rate flag. */
//        private String ebzwk00iHdrSpecRateFlg;
        /** Transaction type. */
//        private String ebzwk00iHdrTxnType;
        /** OMB flag. */
//        private String ebzwk00iHdrOmbFlag;
        /** Header filler field. */
        private String fillerHdr02;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHdrHostStrArea {
        /** Host session ID. */
//        private String ebzwk00iHdrHostSessId;
        /** Host source indicator. */
        private String ebzwk00iHdrChSrcInd;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHdrCibCustId {
        /** External account number. */
        private String ebzwk00iHdrCibExtAcno;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHtcc1 {
        /** Release component code. */
        private Integer ebzwk00iHtcc1RelCompCode;
        /** Release account sequence. */
        private Integer ebzwk00iHtcc1RelAcSeq;
        /** Release account product code. */
        private String ebzwk00iHtcc1RelAcPrdCode;
        /** Release account currency. */
        private String ebzwk00iHtcc1RelAcCcy;
        /** Release account status. */
        private Integer ebzwk00iHtcc1RelAcStatus;
        /** Release account number. */
        private String ebzwk00iHtcc1RelAcNo;
        /** Release account number formatted. */
        private String ebzwk00iHtcc1RelAcNoFmt;
        /** Debit amount currency. */
        private String ebzwk00iHtcc1DbAmtCcy;
        /** Debit amount. */
        private BigDecimal ebzwk00iHtcc1DbAmt;
        /** CHATS account number. */
        private String ebzwk00iHtcc1ChatAcNo;
        /** CHATS account type code. */
        private String ebzwk00iHtcc1ChatAcTpCode;
        /** CHATS account name line 1. */
        private String ebzwk00iHtcc1ChatAcName1;
        /** CHATS account name line 2. */
        private String ebzwk00iHtcc1ChatAcName2;
        /** CHATS account name line 3. */
        private String ebzwk00iHtcc1ChatAcName3;
        /** CHATS account name line 4. */
        private String ebzwk00iHtcc1ChatAcName4;
        /** Payment detail line 1. */
        private String ebzwk00iHtcc1PaymentDtl1;
        /** Payment detail line 2. */
        private String ebzwk00iHtcc1PaymentDtl2;
        /** Payment detail line 3. */
        private String ebzwk00iHtcc1PaymentDtl3;
        /** Payment detail line 4. */
        private String ebzwk00iHtcc1PaymentDtl4;
        /** Print advice indicator. */
        private String ebzwk00iHtcc1PrntAdvInd;
        /** Service currency. */
        private String ebzwk00iHtcc1ServiceCcy;
        /** Service amount. */
        private BigDecimal ebzwk00iHtcc1ServiceAmt;
        /** Execution date. */
        private Integer ebzwk00iHtcc1ExeDate;
        /** Resend flag. */
        private String ebzwk00iHtcc1ResendFlag;
        /** Transaction status. */
//        private String ebzwk00iHtcc1TransStatus;
        /** Charge/discount rate. */
        private BigDecimal ebzwk00iHtcc1ChrgDiscRate;
        /** PIN count. */
        private Integer ebzwk00iHtcc1PinCnt;
        /** PIN list area. */
        private Ebzwk00iHtcc1PinListArea ebzwk00iHtcc1PinListArea;
        /** MAC area. */
        private Ebzwk00iHtcc1MacArea ebzwk00iHtcc1MacArea;
        /** Sweep type. */
//        private String ebzwk00iHtcc1SweepType;
        /** Sweep trigger amount. */
//        private BigDecimal ebzwk00iHtcc1SweepTrigAmt;
        /** Sweep amount. */
//        private BigDecimal ebzwk00iHtcc1SweepAmt;
        /** Priority. */
//        private String ebzwk00iHtcc1Priority;
        /** Limit indicator. */
        private String ebzwk00iHtcc1LmInd;
        /** Deposit account name line 1. */
        private String ebzwk00iHtcc1DepAcName1;
        /** Deposit account name line 2. */
        private String ebzwk00iHtcc1DepAcName2;
        /** Deposit account name line 3. */
        private String ebzwk00iHtcc1DepAcName3;
        /** Deposit account name line 4. */
        private String ebzwk00iHtcc1DepAcName4;
        /** Limit instruction number. */
//        private String ebzwk00iHtcc1LmInstrNum;
        /** Over charge indicator. */
        private String ebzwk00iHtcc1OvrChrgInd;
        /** Filler field. */
        private String ebzwk00iHtcc1Filler;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHtcc1PinListArea {
        /** List of PIN entries. */
        private List<Ebzwk00iHtcc1PinList> ebzwk00iHtcc1PinList;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHtcc1PinList {
        /** Primary key indicator. */
//        private String ebzwk00iHtcc1PkeyInd;
        /** Agent ID. */
        private String ebzwk00iHtcc1AgentId;
        /** DES key. */
//        private String ebzwk00iHtcc1DesKey;
        /** PIN block. */
//        private String ebzwk00iHtcc1PinBlock;
    }

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Ebzwk00iHtcc1MacArea {
        /** MAC primary key indicator. */
        private String ebzwk00iHtcc1MacPkeyInd;
        /** MAC code. */
        private String ebzwk00iHtcc1MacCode;
        /** MAC DES key. */
        private String ebzwk00iHtcc1MacDesKey;
        /** MAC PIN block. */
        private String ebzwk00iHtcc1MacPinBlock;
    }
}
