package com.bea.payment.bulk.internal.downstream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

/**
 * 下游 HTTPS TLS 工具。
 *
 * <p>仅用于 SIT 证书流程未完成时的临时联调开关。默认配置必须保持关闭，正式信任链就绪后应恢复
 * JDK truststore 校验。</p>
 */
public final class DownstreamTlsSupport {

    private static final Logger log = LoggerFactory.getLogger(DownstreamTlsSupport.class);
    private static final SSLSocketFactory INSECURE_TRUST_ALL_SOCKET_FACTORY = createInsecureTrustAllSocketFactory();
    private static final HostnameVerifier INSECURE_HOSTNAME_VERIFIER = (hostname, session) -> true;

    private DownstreamTlsSupport() {
    }

    /**
     * 输出跳过 TLS 校验的启动告警。
     */
    public static void warnIfInsecureTlsEnabled(String downstreamName, boolean insecureSkipVerify) {
        if (insecureSkipVerify) {
            log.warn("[{}-TLS] HTTPS certificate and hostname verification are disabled. "
                    + "This must only be used temporarily before the SIT JDK truststore is ready.",
                    downstreamName);
        }
    }

    /**
     * 返回信任所有服务端证书的 socket factory。
     */
    public static SSLSocketFactory insecureTrustAllSocketFactory() {
        return INSECURE_TRUST_ALL_SOCKET_FACTORY;
    }

    /**
     * 返回放行所有 HTTPS 主机名的 verifier。
     */
    public static HostnameVerifier insecureHostnameVerifier() {
        return INSECURE_HOSTNAME_VERIFIER;
    }

    private static SSLSocketFactory createInsecureTrustAllSocketFactory() {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{new TrustAllX509TrustManager()}, new SecureRandom());
            return sslContext.getSocketFactory();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Failed to initialize insecure downstream TLS context", e);
        }
    }

    private static final class TrustAllX509TrustManager implements X509TrustManager {

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
}