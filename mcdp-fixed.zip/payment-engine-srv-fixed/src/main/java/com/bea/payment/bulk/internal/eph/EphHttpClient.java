package com.bea.payment.bulk.internal.eph;

import com.bea.payment.bulk.internal.downstream.DownstreamTlsSupport;
import com.bea.payment.bulk.internal.eph.model.EphHttpErrorType;
import com.bea.payment.bulk.internal.eph.model.EphHttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.SocketTimeoutException;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Objects;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;

/**
 * EPH HTTP XML 调用客户端。
 *
 * <p>当前类只解决“把 XML 通过 HTTP POST 发出去并拿回原始 XML 响应”的问题：
 * 不负责组装 XML、不负责解析 XML、不负责业务状态映射，也不内置真实环境地址。
 * 这样后续接 I005/I006 编排时，可以按职责把 builder、client、parser 串起来。</p>
 */
public class EphHttpClient {

    private static final Logger log = LoggerFactory.getLogger(EphHttpClient.class);
    private static final String XML_MEDIA_TYPE = "application/xml";
    private static final HostnameVerifier LOCAL_TUNNEL_HOSTNAME_VERIFIER = (hostname, session) -> true;

    private final URI baseUri;
    private final Duration requestTimeout;
    private final boolean tlsHostnameVerificationEnabled;
    private final boolean tlsInsecureSkipVerify;

    /**
     * 创建 EPH HTTP 客户端。
     *
     * @param baseUrl EPH 基础地址，例如 mock server 或 UAT endpoint；末尾是否带 `/` 都可以
     * @param requestTimeout 单次 HTTP 请求超时时间
     */
    public EphHttpClient(String baseUrl, Duration requestTimeout) {
        this(baseUrl, requestTimeout, true);
    }

    /**
     * 创建 EPH HTTP 客户端。
     *
     * @param baseUrl EPH 基础地址，例如 mock server 或 UAT endpoint；末尾是否带 `/` 都可以
     * @param requestTimeout 单次 HTTP 请求超时时间
     * @param tlsHostnameVerificationEnabled 是否启用 HTTPS 主机名校验
     */
    public EphHttpClient(String baseUrl, Duration requestTimeout, boolean tlsHostnameVerificationEnabled) {
        this(baseUrl, requestTimeout, tlsHostnameVerificationEnabled, false);
    }

    /**
     * 创建 EPH HTTP 客户端。
     *
     * @param baseUrl EPH 基础地址，例如 mock server 或 UAT endpoint；末尾是否带 `/` 都可以
     * @param requestTimeout 单次 HTTP 请求超时时间
     * @param tlsHostnameVerificationEnabled 是否启用 HTTPS 主机名校验
     * @param tlsInsecureSkipVerify 是否跳过 HTTPS 证书链和主机名校验
     */
    public EphHttpClient(String baseUrl, Duration requestTimeout, boolean tlsHostnameVerificationEnabled,
            boolean tlsInsecureSkipVerify) {
        this.baseUri = normalizeBaseUri(baseUrl);
        this.requestTimeout = Objects.requireNonNull(requestTimeout, "requestTimeout must not be null");
        this.tlsHostnameVerificationEnabled = tlsHostnameVerificationEnabled;
        this.tlsInsecureSkipVerify = tlsInsecureSkipVerify;
        DownstreamTlsSupport.warnIfInsecureTlsEnabled("EPH", tlsInsecureSkipVerify);
    }

    /**
     * 以 HTTP POST 方式发送 XML 报文。
     *
     * <p>调用方传入具体接口路径，例如 `/i005` 或 `/i006`。方法只返回 HTTP 层原始响应，
     * 如果 HTTP 状态码不是 2xx，则抛出带状态码和响应体的异常。</p>
     */
    public EphHttpResponse postXml(String endpointPath, String xmlBody) {
        URI endpointUri = resolveEndpoint(endpointPath);
        byte[] requestBytes = Objects.requireNonNull(xmlBody, "xmlBody must not be null")
                .getBytes(StandardCharsets.UTF_8);
        HttpURLConnection connection = null;

        try {
            // 1. 同步发送请求。Worker 后续可以在外层决定线程池、重试和状态更新策略。
            connection = openConnection(endpointUri);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(toTimeoutMillis(requestTimeout));
            connection.setReadTimeout(toTimeoutMillis(requestTimeout));
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", XML_MEDIA_TYPE + "; charset=UTF-8");
            connection.setRequestProperty("Accept", XML_MEDIA_TYPE);
            connection.setFixedLengthStreamingMode(requestBytes.length);

            try (OutputStream outputStream = connection.getOutputStream()) {
                outputStream.write(requestBytes);
            }

            // 2. HTTP 非 2xx 属于调用层失败，保留原始响应体供审计和排障使用。
            int statusCode = connection.getResponseCode();
            String responseBody = readResponseBody(connection, statusCode);
            if (statusCode < 200 || statusCode >= 300) {
                log.error("[EPH-HTTP] HTTP status={} endpoint={}", statusCode, endpointUri);
                throw new EphHttpException(EphHttpErrorType.HTTP_STATUS, statusCode, responseBody,
                        "EPH returned HTTP status " + statusCode);
            }

            // 3. 2xx 响应不在这里解析 XML，交给 EphXmlParser 处理。
            return new EphHttpResponse(statusCode, responseBody);
        } catch (SocketTimeoutException e) {
            log.error("[EPH-HTTP] Request timed out endpoint={}, message={}", endpointUri, e.getMessage(), e);
            throw new EphHttpException(EphHttpErrorType.TIMEOUT, "EPH HTTP request timed out", e);
        } catch (IOException e) {
            log.error("[EPH-HTTP] Request failed endpoint={}, message={}", endpointUri, e.getMessage(), e);
            throw new EphHttpException(EphHttpErrorType.IO_ERROR, "EPH HTTP request failed", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /**
     * 解析接口路径，兼容 `/i005` 和 `i005` 两种写法。
     */
    private URI resolveEndpoint(String endpointPath) {
        String normalizedPath = Objects.requireNonNull(endpointPath, "endpointPath must not be null");
        if (normalizedPath.isBlank()) {
            throw new IllegalArgumentException("endpointPath must not be blank");
        }
        if (normalizedPath.startsWith("/")) {
            normalizedPath = normalizedPath.substring(1);
        }
        return baseUri.resolve(normalizedPath);
    }

    /**
     * 规范化基础地址，确保 URI.resolve 能按相对路径拼接 endpoint。
     */
    private static URI normalizeBaseUri(String baseUrl) {
        String value = Objects.requireNonNull(baseUrl, "baseUrl must not be null");
        if (value.isBlank()) {
            throw new IllegalArgumentException("baseUrl must not be blank");
        }
        if (!value.endsWith("/")) {
            value = value + "/";
        }
        return URI.create(value);
    }

    private HttpURLConnection openConnection(URI endpointUri) throws IOException {
        URLConnection urlConnection = endpointUri.toURL().openConnection();
        if (!(urlConnection instanceof HttpURLConnection connection)) {
            throw new IOException("EPH endpoint is not an HTTP URL: " + endpointUri);
        }
        if (connection instanceof HttpsURLConnection httpsConnection) {
            if (tlsInsecureSkipVerify) {
                // SIT 证书未进入 Pod JDK truststore 前的临时联调路径：证书链和主机名都放行。
                httpsConnection.setSSLSocketFactory(DownstreamTlsSupport.insecureTrustAllSocketFactory());
                httpsConnection.setHostnameVerifier(DownstreamTlsSupport.insecureHostnameVerifier());
            } else if (!tlsHostnameVerificationEnabled) {
                httpsConnection.setHostnameVerifier(LOCAL_TUNNEL_HOSTNAME_VERIFIER);
            }
        }
        return connection;
    }

    private static String readResponseBody(HttpURLConnection connection, int statusCode) throws IOException {
        InputStream responseStream = statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (responseStream == null) {
            return "";
        }
        try (InputStream inputStream = responseStream) {
            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static int toTimeoutMillis(Duration timeout) {
        long millis = timeout.toMillis();
        if (millis <= 0 || millis > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("requestTimeout must be between 1ms and " + Integer.MAX_VALUE + "ms");
        }
        return (int) millis;
    }
}
