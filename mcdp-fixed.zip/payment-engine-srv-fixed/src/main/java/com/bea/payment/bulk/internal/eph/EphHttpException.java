package com.bea.payment.bulk.internal.eph;

import lombok.Getter;

import com.bea.payment.bulk.internal.eph.model.EphHttpErrorType;

/**
 * EPH HTTP 调用异常。
 *
 * <p>异常中保留失败类型、HTTP 状态码和响应体，方便 Worker 后续做状态更新、
 * 重试判断和审计落库。没有 HTTP 响应的失败，statusCode 固定为 -1。</p>
 */
@Getter
public class EphHttpException extends RuntimeException {

    private final EphHttpErrorType errorType;
    private final int statusCode;
    private final String responseBody;

    public EphHttpException(EphHttpErrorType errorType, String message, Throwable cause) {
        this(errorType, -1, null, message, cause);
    }

    public EphHttpException(EphHttpErrorType errorType, int statusCode, String responseBody, String message) {
        this(errorType, statusCode, responseBody, message, null);
    }

    private EphHttpException(EphHttpErrorType errorType, int statusCode, String responseBody,
            String message, Throwable cause) {
        super(message, cause);
        this.errorType = errorType;
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

}
