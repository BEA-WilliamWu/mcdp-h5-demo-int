package com.bea.payment.bulk.internal.eph;


import lombok.Getter;
/**
 * EPH 支付编排层业务异常。
 *
 * <p>这个异常表达“HTTP 已经通了，但 I005/I006 业务结果不满足继续处理条件”。
 * 技术调用失败仍由 `EphHttpException` 表达，避免业务失败和网络失败混在一起。</p>
 */
@Getter
public class EphPaymentException extends RuntimeException {

    private final String stage;
    private final String downstreamErrorCode;
    private final String downstreamErrorMessage;

    public EphPaymentException(String stage, String message) {
        this(stage, message, null, null);
    }

    public EphPaymentException(String stage, String message, String downstreamErrorCode,
            String downstreamErrorMessage) {
        super(message);
        this.stage = stage;
        this.downstreamErrorCode = downstreamErrorCode;
        this.downstreamErrorMessage = downstreamErrorMessage;
    }

    /**
     * 返回失败发生在哪个阶段，例如 I005 或 I006，方便 Worker 后续分类更新状态。
     */

}
