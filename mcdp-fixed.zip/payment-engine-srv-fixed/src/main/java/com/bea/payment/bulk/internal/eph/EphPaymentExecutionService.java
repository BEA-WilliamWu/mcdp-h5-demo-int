package com.bea.payment.bulk.internal.eph;

import com.bea.payment.bulk.constants.*;
import com.bea.payment.bulk.internal.eph.model.EphHttpErrorType;
import com.bea.payment.bulk.internal.eph.model.EphPaymentResult;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.PaymentTxnMainConvertDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.service.PaymentBatchStatusService;
import com.bea.payment.bulk.service.PaymentTxnEventService;
import com.bea.payment.bulk.service.PaymentTxnMainService;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.StandardResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;


/**
 * EPH 支付执行服务。
 *
 * <p>职责边界：
 * 1. 根据 transactionId 从 MAIN 表读取完整交易资料；
 * 2. 校验当前交易是否属于跨行 FPS/EPH 处理范围；
 * 3. 调用 `EphPaymentOrchestrator` 完成 I005 -> I006 编排；
 * 4. 将 EPH 返回字段、最终状态或错误码更新回 MAIN。</p>
 *
 * <p>注意：本服务不声明事务。原因是 I005/I006 属于外部 HTTP 调用，不能把慢下游调用包在数据库事务里。
 * 当前每次执行只做一次 MAIN 更新，后续 Worker 接入 ACK/NACK 时再统一确认更细的事务和重试边界。</p>
 */
@Service
@ConditionalOnExpression("'${pe.downstream.eph.base-url:}'.trim().length() > 0 || "
        + "('${pe.downstream.eph.i005-url:}'.trim().length() > 0 && "
        + "'${pe.downstream.eph.i006-url:}'.trim().length() > 0)")
public class EphPaymentExecutionService {

    private static final Logger log = LoggerFactory.getLogger(EphPaymentExecutionService.class);
    private static final String I006_ACCEPTED_STATUS = "ACSC";
    private static final String I006_REJECTED_STATUS = "RJCT";

    private final PaymentTxnMainMapper txnMainMapper;
    private final EphPaymentOrchestrator orchestrator;
    private final PaymentBatchStatusService batchStatusService;
    private final PaymentTxnEventService eventService;
    private final PaymentTxnMainService txnMainService;


    public EphPaymentExecutionService(PaymentTxnMainMapper txnMainMapper,
                                      EphPaymentOrchestrator orchestrator,
                                      PaymentBatchStatusService batchStatusService,
                                      PaymentTxnEventService eventService, PaymentTxnMainService txnMainService) {
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.orchestrator = Objects.requireNonNull(orchestrator, "orchestrator must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService, "batchStatusService must not be null");
        this.eventService = Objects.requireNonNull(eventService, "eventService must not be null");
        this.txnMainService = Objects.requireNonNull(txnMainService, "txnMainService must not be null");
    }

    /** EPH I037 查询补偿延迟（毫秒），默认 30 分钟 */
    private static final long DEFAULT_QUERY_ELIGIBLE_DELAY_MS = 1800000L;

    @Value("${pe.downstream.eph.query.query-eligible-delay-ms:" + DEFAULT_QUERY_ELIGIBLE_DELAY_MS + "}")
    private long queryEligibleDelayMs = DEFAULT_QUERY_ELIGIBLE_DELAY_MS;
    /**
     * 执行一笔已落库的 EPH 支付。
     *
     * <p>返回值当前只供测试或后续审计扩展使用；调用方主要依赖 MAIN 表状态变化判断处理结果。</p>
     */
    public EphPaymentResult execute(String transactionId) {
        log.info("[EPH-EXEC] Start executing EPH payment for transactionId={}", transactionId);
        PaymentTxnMainConvertDTO txnMainConvertDTO = txnMainService.loadTxn(transactionId);
        PaymentTxnMainEntity txn = txnMainConvertDTO.getPaymentTxnMainEntity();
        PaymentTxnEventEntity event1 = txnMainConvertDTO.getPaymentTxnEventEntity();
        assertFpsTransaction(txn);
        txn.setLastDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        markDownstreamCalling(txn);

        try {
            // 1. 编排器负责 I005/I006 HTTP 调用和 EPH 返回字段写回内存对象。
            EphPaymentResult result = orchestrator.execute(txn,event1,queryEligibleDelayMs);

            // 2. 只有 I006 明确 ACSC 才认为支付完成；非终态保持 PROCESSING 并标记查询补偿。
            applyI006Status(txn,result);
            persistProcessingResult(txn);
            batchStatusService.refreshIfBatchTerminal(txn.getBatchId());
            log.info("[EPH-EXEC] Successfully updated transaction status to {} for transactionId={}",
                    txn.getPaymentStatus(), transactionId);
            return result;
        } catch (EphPaymentException e) {
            // 3. I005 业务拒绝会在编排器内抛出；此时 I005 解析结果已写入 txn，需要保存下来供排查。
            recordEphRejectedEvent(txn, e);
            markBusinessRejected(txn, e);
            persistProcessingResult(txn);
            batchStatusService.refreshIfBatchTerminal(txn.getBatchId());
            log.warn("[EPH-EXEC] Business rejected at stage={} for transactionId={}, errorCode={}",
                    e.getStage(), transactionId, txn.getLastErrorCode());
            return null;
        } catch (EphHttpException e) {
            // 4. HTTP 失败按可确定性分层：非 2xx 是明确失败；timeout/IO 是未知结果，保存错误后交给 Worker 决定 ACK/NACK。
            applyHttpFailure(txn, event1, e);
            persistProcessingResult(txn);
            batchStatusService.refreshIfBatchTerminal(txn.getBatchId());
            log.error("[EPH-EXEC] HTTP failure with errorType={} for transactionId={}, httpStatus={}, status={}",
                    e.getErrorType(), transactionId, e.getStatusCode(), txn.getPaymentStatus(), e);
            return null;
        }
    }

    /**
     * 当前 EPH 执行服务只处理 FPS 交易。
     */
    private void assertFpsTransaction(PaymentTxnMainEntity txn) {
        if (!TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(txn.getTransactionType())) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "EPH execution only supports FPS transaction");
        }
    }

    /**
     * 根据 I006 返回状态映射内部支付状态。
     *
     * <p>终态判定：
     * ACSC → COMPLETED（成功）、RJCT → FAILED（明确拒绝）。
     * 非终态 ACSP/ACCP/PDNG → 保持 PROCESSING，标记需要补偿查询。</p>
     */
    private void applyI006Status(PaymentTxnMainEntity txn,EphPaymentResult result) {
        if (result != null
                && result.i006Response() != null
                && I006_ACCEPTED_STATUS.equalsIgnoreCase(result.i006Response().transactionStatus())) {
            txn.setPaymentStatus(PaymentStatusEnum.COMPLETED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_SUCCESS.getCode());
            txn.setErrorSource(null);
            txn.setLastErrorCode(null);
            txn.setManualReviewReason(null);
            txn.setManualReviewTime(null);
            txn.setExecutionEndTime(new Date());
            return;
        }

        String txStatus = result != null && result.i006Response() != null
                ? result.i006Response().transactionStatus() : null;
        String i006ErrorCode = result != null && result.i006Response() != null
                ? result.i006Response().errorCode() : null;
        String i006ReasonCode = result != null && result.i006Response() != null
                ? result.i006Response().reasonCode() : null;

        if (txStatus != null && I006_REJECTED_STATUS.equalsIgnoreCase(txStatus)) {
            // 终态拒绝
            txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
            txn.setErrorSource(ErrorSourceEnum.EPH_I006.getCode());
            txn.setLastErrorCode(firstText(i006ErrorCode, i006ReasonCode, "EPH_I006_REJECTED"));
            txn.setManualReviewReason(null);
            txn.setManualReviewTime(null);
            txn.setExecutionEndTime(new Date());
            return;
        }

        // 非终态（ACSP/ACCP/PDNG）或未知状态：
        // 保持当前 PROCESSING 不变，记录中间态错误码和查询标记，等待后续补偿查询。
        // 不能标 FAILED：非终态不等于明确失败，误标会影响上游对账和批次汇总。
        txn.setStatusReason(StatusReasonEnum.EPH_QUERY_PENDING.getCode());
        txn.setErrorSource(ErrorSourceEnum.EPH_I006.getCode());
        txn.setLastErrorCode(firstText(i006ErrorCode, "EPH_I006_NON_TERMINAL"));
    }

    /**
     * 保存 I005/I006 业务拒绝结果。
     */
    private void markBusinessRejected(PaymentTxnMainEntity txn, EphPaymentException e) {
        txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
        txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
        if ("I005".equalsIgnoreCase(e.getStage())) {
            txn.setErrorSource(ErrorSourceEnum.EPH_I005.getCode());
            txn.setLastErrorCode(firstText(e.getDownstreamErrorCode(), "EPH_I005_REJECTED"));
        } else {
            txn.setErrorSource(ErrorSourceEnum.EPH_I006.getCode());
            txn.setLastErrorCode(firstText(e.getDownstreamErrorCode(), "EPH_PAYMENT_REJECTED"));
        }
        txn.setManualReviewReason(null);
        txn.setManualReviewTime(null);
        txn.setExecutionEndTime(new Date());
    }

    /**
     * 保存 HTTP 调用失败结果。
     *
     * <p>timeout/IO/interrupted 属于结果未知，标记需要后续查询补偿；
     * HTTP 非 2xx 是明确失败，不需要查询。</p>
     */
    private void applyHttpFailure(PaymentTxnMainEntity txn, PaymentTxnEventEntity intakeEvent,
            EphHttpException e) {
        String errorCode = "EPH_" + e.getErrorType().name();
        recordEphHttpFailureEvent(txn, intakeEvent, e, errorCode);
        txn.setLastErrorCode(errorCode);
        if (EphHttpErrorType.HTTP_STATUS == e.getErrorType()) {
            txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_HTTP_STATUS.getCode());
            txn.setErrorSource(ErrorSourceEnum.EPH_HTTP.getCode());
            txn.setManualReviewReason(null);
            txn.setManualReviewTime(null);
            txn.setExecutionEndTime(new Date());
        } else {
            // timeout/IO/interrupted → 结果未知，标记需要补偿查询
            txn.setStatusReason(StatusReasonEnum.EPH_QUERY_PENDING.getCode());
            txn.setErrorSource(ErrorSourceEnum.EPH_HTTP.getCode());
        }
    }

    /**
     * 标记该交易需要后续补偿查询 EPH 交易最终状态。
     *
     * <p>设置 EPH_NEEDS_STATUS_QUERY='Y'，EPH_QUERY_ELIGIBLE_TIME=当前时间+30分钟。
     * 后续定时任务会在 30 分钟后扫描这些交易并调用 EPH I037 查询接口。</p>
     */
    private void markNeedsStatusQuery(PaymentTxnEventEntity event) {
        event.setEphNeedsStatusQuery("Y");
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(cal.getTimeInMillis() + queryEligibleDelayMs);
        event.setEphQueryEligibleTime(cal.getTime());
    }

    private void markDownstreamCalling(PaymentTxnMainEntity txn) {
        PaymentTxnMainEntity update = new PaymentTxnMainEntity();
        update.setStatusReason(StatusReasonEnum.DOWNSTREAM_CALLING.getCode());
        int updated = txnMainMapper.update(update,
                new com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<PaymentTxnMainEntity>()
                        .eq(PaymentTxnMainEntity::getTxnId, txn.getTxnId())
                        .eq(PaymentTxnMainEntity::getIsDeleted, "N")
                        .eq(PaymentTxnMainEntity::getPaymentStatus,
                                PaymentStatusEnum.PROCESSING.getCode()));
        if (updated != 1) {
            throw new IllegalStateException("EPH transaction is no longer PROCESSING: "
                    + txn.getTransactionId());
        }
        txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_CALLING.getCode());
    }

    private void persistProcessingResult(PaymentTxnMainEntity txn) {
        int updated = txnMainMapper.update(txn,
                new com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<PaymentTxnMainEntity>()
                        .eq(PaymentTxnMainEntity::getTxnId, txn.getTxnId())
                        .eq(PaymentTxnMainEntity::getIsDeleted, "N")
                        .eq(PaymentTxnMainEntity::getPaymentStatus,
                                PaymentStatusEnum.PROCESSING.getCode()));
        if (updated != 1) {
            throw new IllegalStateException("EPH result was not persisted because the state changed: "
                    + txn.getTransactionId());
        }
    }



    private void recordEphRejectedEvent(PaymentTxnMainEntity txn, EphPaymentException e) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType("I005".equalsIgnoreCase(e.getStage())
                ? PaymentTxnEventTypeEnum.EPH_I005.name()
                : PaymentTxnEventTypeEnum.EPH_I006.name());
        event.setEventStage("REJECTED");
        event.setResultStatus("REJECTED");
        event.setErrorCode(firstText(e.getDownstreamErrorCode(),
                "I005".equalsIgnoreCase(e.getStage()) ? "EPH_I005_REJECTED" : "EPH_PAYMENT_REJECTED"));
        event.setErrorMessage(firstText(e.getDownstreamErrorMessage(), e.getMessage()));
        event.setResponseSummary(firstText(e.getDownstreamErrorMessage(), e.getMessage()));
        eventService.record(txn, event);
    }

    private void recordEphHttpFailureEvent(PaymentTxnMainEntity txn, PaymentTxnEventEntity intakeEvent,
            EphHttpException e, String errorCode) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_HTTP.name());
        event.setEventStage("ERROR");
        event.setResultStatus(EphHttpErrorType.HTTP_STATUS == e.getErrorType() ? "FAILED" : "UNKNOWN");
        event.setErrorCode(errorCode);
        event.setErrorMessage(e.getMessage());
        event.setResponseSummary("EPH HTTP failure, status=" + e.getStatusCode());
        event.setEphPaymentSource(intakeEvent.getEphPaymentSource());
        event.setEphQueryCount(0);

        if (EphHttpErrorType.HTTP_STATUS == e.getErrorType()) {
        } else {
            markNeedsStatusQuery(event);
        }

        eventService.record(txn, event);
    }

    private static String firstText(String... values) {
        if (values == null) {
            return null;
        }
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return null;
    }

}
