package com.bea.payment.bulk.internal.eph;

import com.bea.payment.bulk.constants.DownstreamSystemEnum;
import com.bea.payment.bulk.constants.PayeeTypeEnum;
import com.bea.payment.bulk.constants.PaymentTxnEventTypeEnum;
import com.bea.payment.bulk.internal.eph.model.EphHttpResponse;
import com.bea.payment.bulk.internal.eph.model.EphI005Response;
import com.bea.payment.bulk.internal.eph.model.EphI006Response;
import com.bea.payment.bulk.internal.eph.model.EphPaymentResult;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.service.PaymentTxnEventService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.Calendar;
import java.util.Objects;


/**
 * EPH 支付调用编排器。
 *
 * <p>职责边界：本类只串联一次交易的 I005 和 I006 调用链，不做数据库提交、不做 MQ ACK、
 * 不做最终 PaymentStatus 映射。后续 Worker 可以在事务边界外调用本类，再根据返回结果更新 MAIN。</p>
 */
public class EphPaymentOrchestrator {


    private static final Logger log = LoggerFactory.getLogger(EphPaymentOrchestrator.class);
    private static final String STAGE_I005 = "I005";
    private static final String STAGE_I006 = "I006";
    private static final String CUSTOMER_ID_TYPE = "CUST";


    private final EphHttpClient httpClient;
    private final String i005EndpointPath;
    private final String i006EndpointPath;
    private final String i005InterfaceId;
    private final String i006InterfaceId;
    private final boolean i005Enabled;
    private final PaymentTxnEventService eventService;


    /**
     * 创建 EPH 支付编排器。
     *
     * @param httpClient 已配置 baseUrl 和 timeout 的 HTTP client
     * @param i005EndpointPath I005 endpoint path，例如 `/i005`
     * @param i006EndpointPath I006 endpoint path，例如 `/i006`
     * @param i005InterfaceId I005 interface id，由 IPE 配置提供
     * @param i006InterfaceId I006 interface id，由 IPE 配置提供
     */
    public EphPaymentOrchestrator(EphHttpClient httpClient, String i005EndpointPath, String i006EndpointPath,
                                  String i005InterfaceId, String i006InterfaceId, PaymentTxnEventService eventService) {
        this(httpClient, i005EndpointPath, i006EndpointPath, i005InterfaceId, i006InterfaceId, true, eventService);
    }


    /**
     * 创建 EPH 支付编排器。
     *
     * @param httpClient 已配置 baseUrl 和 timeout 的 HTTP client
     * @param i005EndpointPath I005 endpoint path，例如 `/i005`
     * @param i006EndpointPath I006 endpoint path，例如 `/i006`
     * @param i005InterfaceId I005 interface id，由 IPE 配置提供
     * @param i006InterfaceId I006 interface id，由 IPE 配置提供
     * @param i005Enabled 是否先调用 I005 addressing enquiry
     */
    public EphPaymentOrchestrator(EphHttpClient httpClient, String i005EndpointPath, String i006EndpointPath,
                                  String i005InterfaceId, String i006InterfaceId, boolean i005Enabled, PaymentTxnEventService eventService) {
        this.httpClient = Objects.requireNonNull(httpClient, "httpClient must not be null");
        this.i005EndpointPath = requireText(i005EndpointPath, "i005EndpointPath");
        this.i006EndpointPath = requireText(i006EndpointPath, "i006EndpointPath");
        this.i005InterfaceId = requireText(i005InterfaceId, "i005InterfaceId");
        this.i006InterfaceId = requireText(i006InterfaceId, "i006InterfaceId");
        this.i005Enabled = i005Enabled;
        this.eventService = Objects.requireNonNull(eventService, "eventService must not be null");
    }


    /**
     * 执行一笔跨行 EPH 支付。
     *
     * <p>默认流程为 I005 -> I006。调试开关关闭 I005 时，直接使用 MAIN 当前字段构建 I006，
     * 不对 I005 派生字段做前置校验。</p>
     */
    public EphPaymentResult execute(PaymentTxnMainEntity txn, PaymentTxnEventEntity event1, long queryEligibleDelayMs) {
        Objects.requireNonNull(txn, "txn must not be null");


        String transactionId = txn.getTransactionId();
        log.info("[EPH] Start executing EPH payment for transactionId={}", transactionId);


        EphI005Response i005Response = executeI005IfEnabled(txn,event1, transactionId);
        recordEphI005Event(txn, event1, i005Response);


        // I005 关闭时不做字段预校验，直接使用 MAIN 当前字段构建 I006，便于联调暴露下游错误。
        String i006RequestXml = EphXmlBuilder.buildI006Request(txn,event1, i006InterfaceId);
        log.debug("[EPH-I006] Request prepared for transactionId={}", transactionId);


        EphHttpResponse i006HttpResponse = httpClient.postXml(i006EndpointPath, i006RequestXml);
        log.info("[EPH-I006] Response status={} for transactionId={}", i006HttpResponse.statusCode(), transactionId);


        EphI006Response i006Response = EphXmlParser.parseI006Response(i006HttpResponse.body());
        log.info("[EPH-I006] Parsed response: transactionStatus={}, extStatus={}, fpsReference={} for transactionId={}",
                i006Response.transactionStatus(), i006Response.extensionStatus(),
                i006Response.fpsReference(), transactionId);
        recordEphI006Event(txn, event1, i006Response, queryEligibleDelayMs);


        // 3. 编排层只返回原始业务响应；最终状态映射留给 Worker/状态机层处理。
        log.info("[EPH] Completed EPH payment execution for transactionId={}", transactionId);
        return new EphPaymentResult(i005Response, i006Response);
    }


    private EphI005Response executeI005IfEnabled(PaymentTxnMainEntity txn, PaymentTxnEventEntity event1, String transactionId) {
        if (!i005Enabled) {
            log.warn("[EPH-I005] I005 disabled by configuration, skip addressing enquiry for transactionId={}",
                    transactionId);
            return null;
        }


        // 先查询 EPH addressing。I006 的收款行和 credit MOP 通常依赖 I005 返回。
        String i005RequestXml = EphXmlBuilder.buildI005AllRequest(txn,event1, i005InterfaceId);
        log.debug("[EPH-I005] Request prepared for transactionId={}", transactionId);


        EphHttpResponse i005HttpResponse = httpClient.postXml(i005EndpointPath, i005RequestXml);
        log.info("[EPH-I005] Response status={} for transactionId={}", i005HttpResponse.statusCode(), transactionId);


        EphI005Response i005Response = EphXmlParser.parseI005Response(i005HttpResponse.body());


        applyI005Response(txn,event1, i005Response);
        log.info("[EPH-I005] Parsed response: responseStatus={}, addressStatus={}, selectedBankCode={}, creditMop={} for transactionId={}",
                i005Response.responseStatus(), i005Response.addressStatus(),
                i005Response.selectedBankCode(), i005Response.creditMop(), transactionId);


        assertI005AllowsCreditTransfer(txn, i005Response);
        return i005Response;
    }


    /**
     * 将 I005 关键返回字段写回交易对象。
     *
     * <p>注意：大部分 I005 派生字段已迁移至 IPE_PAYMENT_TXN_EVENT 表，
     * 本方法仅保留仍存在于 MAIN 表的字段更新。</p>
     */
    private void applyI005Response(PaymentTxnMainEntity txn, PaymentTxnEventEntity event1, EphI005Response response) {
        // Note: ephSelectedBankCode, ephSelectedBankName, ephCreditMop,
        // ephPayeeCustomerId, ephPayeeCustomerIdType, ephPayeeCustomerIdCategory,
        // customerType have been moved to PaymentTxnEventEntity and are no longer set here.
        // Only payeeBankCode remains in MAIN.
        txn.setPayeeBankCode(response.payeeBankCode());


        event1.setEphSelectedBankCode(response.selectedBankCode());
        event1.setEphSelectedBankName(response.selectedBankName());
        event1.setEphCreditMop(response.creditMop());
        if (isProxyPayee(txn)) {
            event1.setEphPayeeCustomerId(response.customerId());
            event1.setEphPayeeCustomerIdType(hasText(response.customerId()) ? CUSTOMER_ID_TYPE : null);
            event1.setEphPayeeCustomerIdCategory(customerIdCategory(response.customerType()));
        } else {
            event1.setEphPayeeCustomerId(null);
            event1.setEphPayeeCustomerIdType(null);
            event1.setEphPayeeCustomerIdCategory(null);
        }


    }


    /**
     * 校验 I005 是否满足继续调用 I006 的最低条件。
     *
     * <p>Proxy 模式要求 `RespSts=Success` 且 addressing `Sts=ACCT`。
     * Account 模式的 fee enquiry 不返回 addressing status，只要求 `RespSts=Success`
     * 并且已拿到收款银行和 credit MOP。</p>
     */
    private void assertI005AllowsCreditTransfer(PaymentTxnMainEntity txn, EphI005Response response) {
        if (!"Success".equalsIgnoreCase(response.responseStatus())) {
            throw new EphPaymentException(STAGE_I005,
                    "I005 response does not allow I006: responseStatus=" + response.responseStatus()
                            + ", addressStatus=" + response.addressStatus(),
                    response.errorCode(),
                    response.errorMessage());
        }
        if (isProxyPayee(txn) && !"ACCT".equalsIgnoreCase(response.addressStatus())) {
            throw new EphPaymentException(STAGE_I005,
                    "I005 proxy response does not allow I006: responseStatus=" + response.responseStatus()
                            + ", addressStatus=" + response.addressStatus(),
                    response.errorCode(),
                    response.errorMessage());
        }
        if (isBlank(response.selectedBankCode()) || isBlank(response.creditMop())) {
            throw new EphPaymentException(STAGE_I005,
                    "I005 response missing selectedBankCode or creditMop",
                    response.errorCode(),
                    response.errorMessage());
        }
    }


    private static boolean isProxyPayee(PaymentTxnMainEntity txn) {
        return PayeeTypeEnum.PROXY.getCode().equalsIgnoreCase(txn.getPayeeType());
    }


    private void recordEphI005Event(PaymentTxnMainEntity txn, PaymentTxnEventEntity event1,
            EphI005Response response) {
        if (response == null) {
            return;
        }
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_I005.name());
        event.setEventStage("i005");
        event.setMessageId(response.msgId());
        event.setResultStatus(response.responseStatus());
        event.setResultCode(response.addressStatus());
        event.setErrorCode(response.errorCode());
        event.setErrorMessage(response.errorMessage());
        event.setResponseSummary(firstText(response.displayName(), response.selectedBankCode()));


        // Populate Eph-specific fields moved from PaymentTxnMainEntity
        event.setEphSelectedBankCode(response.selectedBankCode());
        event.setEphSelectedBankName(response.selectedBankName());
        event.setEphCreditMop(response.creditMop());
        event.setEphPaymentSource(event1.getEphPaymentSource());


        if (PayeeTypeEnum.PROXY.getCode().equalsIgnoreCase(txn.getPayeeType())) {
            event.setEphPayeeCustomerId(response.customerId());
            event.setEphPayeeCustomerIdType(hasText(response.customerId()) ? "CUST" : null);
            event.setEphPayeeCustomerIdCategory(customerIdCategory(response.customerType()));
        } else {
            event.setEphPayeeCustomerId(null);
            event.setEphPayeeCustomerIdType(null);
            event.setEphPayeeCustomerIdCategory(null);
        }
        event.setCustomerType(response.customerType());
        eventService.record(txn, event);
    }


    private void recordEphI006Event(PaymentTxnMainEntity txn, PaymentTxnEventEntity intakeEvent,
            EphI006Response response, long queryEligibleDelayMs) {
        if (response == null) {
            return;
        }
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_I006.name());
        event.setEventStage("i006");
        event.setMessageId(response.msgId());
        event.setDownstreamReference(response.fpsReference());
        event.setResultStatus(response.transactionStatus());
        event.setResultCode(response.extensionStatus());
        event.setErrorCode(firstText(response.errorCode(), response.reasonCode()));
        event.setErrorMessage(response.errorMessage());
        event.setResponseSummary(firstText(response.errorMessage(), response.fpsReference()));
        event.setEphPaymentSource(intakeEvent.getEphPaymentSource());


        boolean terminal = "ACSC".equalsIgnoreCase(response.transactionStatus())
                || "RJCT".equalsIgnoreCase(response.transactionStatus());
        event.setEphNeedsStatusQuery(terminal ? "N" : "Y");
        event.setEphQueryCount(0);
        if (!terminal) {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(cal.getTimeInMillis() + queryEligibleDelayMs);
            event.setEphQueryEligibleTime(cal.getTime());
        }


        eventService.record(txn, event);
    }


    private static String customerIdCategory(String customerType) {
        if ("CORP".equalsIgnoreCase(customerType)) {
            return "ORG";
        }
        if ("PERS".equalsIgnoreCase(customerType)) {
            return "PRIVATE";
        }
        return null;
    }


    private static String requireText(String value, String fieldName) {
        if (isBlank(value)) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
        return value;
    }


    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }


    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }




    private static String firstText(String... values) {
        if (values == null) {
            return null;
        }
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return null;
    }


}
