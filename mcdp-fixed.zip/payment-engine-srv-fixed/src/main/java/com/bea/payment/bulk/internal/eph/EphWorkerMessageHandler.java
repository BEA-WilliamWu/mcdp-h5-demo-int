package com.bea.payment.bulk.internal.eph;

import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.flow.mq.MqMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * Worker 接入 EPH 前的轻量消息处理器。
 *
 * <p>当前类刻意不依赖 IBM MQ SDK，也不处理 ACK/NACK：
 * 真实 Worker 后续只需要把反序列化后的 `MqMessage` 交给本类，
 * 本类负责判断这条消息是否应进入 EPH 执行链路。</p>
 */
@Component
@ConditionalOnExpression("'${pe.downstream.eph.base-url:}'.trim().length() > 0 || "
        + "('${pe.downstream.eph.i005-url:}'.trim().length() > 0 && "
        + "'${pe.downstream.eph.i006-url:}'.trim().length() > 0)")
public class EphWorkerMessageHandler {

    private static final Logger log = LoggerFactory.getLogger(EphWorkerMessageHandler.class);
    private final EphPaymentExecutionService executionService;

    public EphWorkerMessageHandler(EphPaymentExecutionService executionService) {
        this.executionService = Objects.requireNonNull(executionService, "executionService must not be null");
    }

    /**
     * 处理一条 Worker 消息。
     *
     * <p>逻辑步骤：
     * 1. 检查消息是否为空；
     * 2. 非 FPS 消息不属于 EPH 跨行支付链路，直接跳过；
     * 3. FPS 消息只取 transactionId，完整交易参数仍由执行服务从 MAIN 表读取；
     * 4. 执行服务抛出的异常不在这里吞掉，交给未来 MQ 层决定 ACK、NACK 或重投。</p>
     */
    public void handle(MqMessage message) {
        Objects.requireNonNull(message, "message must not be null");

        String transactionId = message.getTransactionId();
        
        if (!TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(message.getTransactionType())) {
            log.debug("[EPH-HANDLER] Skipping non-FPS message: transactionId={}, txType={}",
                    transactionId, message.getTransactionType());
            return;
        }

        log.info("[EPH-HANDLER] Handling FPS transaction: transactionId={}", transactionId);
        
        try {
            executionService.execute(transactionId);
            log.info("[EPH-HANDLER] Successfully executed EPH payment: transactionId={}", transactionId);
        } catch (Exception e) {
            log.error("[EPH-HANDLER] Failed to execute EPH payment: transactionId={}, error={}",
                    transactionId, e.getMessage(), e);
            throw e;
        }
    }
}
