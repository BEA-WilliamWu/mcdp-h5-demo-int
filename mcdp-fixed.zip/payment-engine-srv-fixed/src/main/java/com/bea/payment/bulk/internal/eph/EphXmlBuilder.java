package com.bea.payment.bulk.internal.eph;

import com.bea.payment.bulk.constants.PayeeTypeEnum;
import com.bea.payment.bulk.internal.eph.xml.EphI005RequestXml;
import com.bea.payment.bulk.internal.eph.xml.EphI006RequestXml;
import com.bea.payment.bulk.internal.eph.xml.EphXmlSerializer;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * EPH XML 报文构建器。
 *
 * <p>本类只负责把已经落库到 MAIN 的字段映射成 EPH XML DTO，再交给 Jackson XML 序列化。
 * 不读取数据库、不做字段校验、不调用 HTTP，Worker 可以按“查 MAIN -> build XML -> HTTP -> parse XML -> 更新 MAIN”的链路组合。</p>
 */
public final class EphXmlBuilder {

    private EphXmlBuilder() {}

    /**
     * 构建 I005 请求报文 with event fields.
     *
     * <p>Proxy 收款沿用 addressing enquiry；account 收款按 EPH 要求使用成员行号做 FEE enquiry。</p>
     */
    public static String buildI005AllRequest(PaymentTxnMainEntity txn, PaymentTxnEventEntity event, String interfaceId) {
        EphI005RequestXml.AdrSchme adrSchme = i005AddressScheme(txn, event);

        EphI005RequestXml.ProcessingPersistentInfo processingInfo = getProcessingPersistentInfo(txn, event);

        EphI005RequestXml message = new EphI005RequestXml(
                new EphI005RequestXml.AdrSmryReq(adrSchme),
                new EphI005RequestXml.Extn(
                        new EphI005RequestXml.InterfaceElement(interfaceId),
                        processingInfo));

        return EphXmlSerializer.serialize(message);
    }

    private static EphI005RequestXml.AdrSchme i005AddressScheme(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        if (isAccountPayee(txn)) {
            return new EphI005RequestXml.AdrSchme(
                    new EphI005RequestXml.Agent(
                            new EphI005RequestXml.FinancialInstitutionId(
                                    new EphI005RequestXml.ClearingSystemMemberId(event.getPayeeMemberId()))));
        }
        return new EphI005RequestXml.AdrSchme(
                payeeIdentification(txn),
                event.getEphPayeeIdentificationType() ,
                "Yes");
    }
    private static EphI005RequestXml.ProcessingPersistentInfo getProcessingPersistentInfo(
            PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        // Prefer event fields for EPH-specific data (migration in progress)
        String payerInternalAcct = event != null && event.getDebitInternalAccount() != null
                ? event.getDebitInternalAccount() : txn.getPayerInternalAccountNo();
        String payerAcct = txn.getPayerAccountNo();
        String paymentSource = event.getEphPaymentSource();
        String enquiryType = event.getEphEnquiryType();

        EphI005RequestXml.DebitSide debitSide = new EphI005RequestXml.DebitSide(
                i005FeeCode(txn, event),
                amount(txn.getDebitAmount()),
                firstCurrency(txn),
                payerAcct,
                txn.getPayerAccountType());

        EphI005RequestXml.CategoryPurpose purpose = new EphI005RequestXml.CategoryPurpose(getPurpose(txn, event));

        EphI005RequestXml.ProcessingPersistentInfo processingInfo =
                new EphI005RequestXml.ProcessingPersistentInfo(
                        payerInternalAcct,
                        payerAcct,
                        paymentSource,
                        txn.getTransactionId(),
                        i005EnquiryType(txn, event),
                        debitSide,
                        purpose);
        return processingInfo;
    }

    private static String i005EnquiryType(PaymentTxnMainEntity txn) {
        return i005EnquiryType(txn, null);
    }

    private static String i005EnquiryType(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        if (isAccountPayee(txn)) {
            return "FEE";
        }
        if (event != null && event.getEphEnquiryType() != null) {
            return event.getEphEnquiryType();
        }
        return event.getEphEnquiryType();
    }

    private static String i005FeeCode(PaymentTxnMainEntity txn) {
        return i005FeeCode(txn, null);
    }

    private static String i005FeeCode(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        if (isAccountPayee(txn)) {
            return "EP8";
        }
        if (event != null && event.getEphFeeCode() != null) {
            return event.getEphFeeCode();
        }
        return event.getEphFeeCode();
    }

    private static String getPurpose(PaymentTxnMainEntity txn) {
        return getPurpose(txn, null);
    }

    private static String getPurpose(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        String purpose = null;
        if (event != null && event.getPurposeCode() != null) {
            purpose = event.getPurposeCode();
        }
        if (StringUtils.isBlank(purpose) && event != null && StringUtils.isNotBlank(event.getPurposeProprietary())) {
            purpose = event.getPurposeProprietary();
        }
        if (StringUtils.isBlank(purpose)) {
            purpose = event.getPurposeCode();
            if (StringUtils.isBlank(purpose)) {
                purpose = event.getPurposeProprietary();
            }
        }
        return purpose;
    }

    private static String firstCurrency(PaymentTxnMainEntity txn) {
        if (txn != null && txn.getDebitAmountCcy() != null) {
            return txn.getDebitAmountCcy();
        }
        return txn.getChargeCurrency();
    }

    /**
     * 构建 I006 Credit Transfer 请求报文。
     *
     * <p>I006 依赖 I005 结果，ephSelectedBankCode 用作收款行 member id，ephCreditMop 用作 credit side MOP。</p>
     */
    public static String buildI006Request(PaymentTxnMainEntity txn, PaymentTxnEventEntity event, String interfaceId) {
        EphI006RequestXml.CreditTransferTransaction transaction =
                new EphI006RequestXml.CreditTransferTransaction();
        transaction.paymentIdentification = new EphI006RequestXml.PaymentIdentification(
                optionalText(event.getInstructionId()),
                event.getEphEndToEndId(),
                txn.getTransactionId());
        transaction.paymentTypeInformation = new EphI006RequestXml.PaymentTypeInformation(
                new EphI006RequestXml.ProprietaryValue(event.getEphAccountVerificationOption()),
                new EphI006RequestXml.ProprietaryValue(getPurpose(txn,event)));
        transaction.interbankSettlementAmount = new EphI006RequestXml.CurrencyAmount(
                txn.getDebitAmountCcy(),
                amount(txn.getDebitAmount()));
        transaction.interbankSettlementDate = settlementDate(txn.getExecutionDate());
        transaction.chargeBearer = event.getChargeBearer();
        transaction.chargesInformation = chargesInformation(txn);
        transaction.debtor = debtor(txn);
        // TODO 账户类型从哪里取值待确认；为空时暂设 BBAN。
        transaction.debtorAccount = account(txn.getPayerAccountNo(), "BBAN");
        transaction.debtorAgent = agent(txn.getPayerBicCode(), event.getEphDebtorMemberId());
        transaction.creditorAgent = agent(txn.getPayeeBicCode(), event.getEphSelectedBankCode());
        transaction.creditor = creditor(txn,event);
        transaction.creditorAccount = account(payeeIdentification(txn), event.getEphPayeeIdentificationType());
        transaction.purpose = purpose(txn,event);
        transaction.remittanceInformation = remittanceInformation(txn, event);

        EphI006RequestXml.FIToFICstmrCdtTrf body = new EphI006RequestXml.FIToFICstmrCdtTrf(
                groupHeader(event),
                transaction);

        EphI006RequestXml message = new EphI006RequestXml(
                body,
                new EphI006RequestXml.Extn(
                        new EphI006RequestXml.InterfaceElement(interfaceId),
                        processingInfo(txn,event)));

        return EphXmlSerializer.serialize(message);
    }

    private static EphI006RequestXml.GroupHeader groupHeader(PaymentTxnEventEntity event) {
        EphI006RequestXml.ClearingSystem clearingSystem = hasText(event.getClearingSystem())
                ? new EphI006RequestXml.ClearingSystem(event.getClearingSystem())
                : null;
        return new EphI006RequestXml.GroupHeader(
                "1",
                new EphI006RequestXml.SettlementInformation(
                        optionalText(event.getSettlementMethod()),
                        clearingSystem));
    }

    private static EphI006RequestXml.ChargesInformation chargesInformation(PaymentTxnMainEntity txn) {
        if (txn.getServiceChargeAmount() == null) {
            return null;
        }
        return new EphI006RequestXml.ChargesInformation(
                new EphI006RequestXml.CurrencyAmount(
                        txn.getChargeCurrency(),
                        amount(txn.getServiceChargeAmount())));
    }

    private static EphI006RequestXml.Party debtor(PaymentTxnMainEntity txn) {
        return new EphI006RequestXml.Party(
                txn.getPayerName(),
                null,
                null);
    }

    private static EphI006RequestXml.Party creditor(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        List<EphI006RequestXml.PartyIdentification> identifications = new ArrayList<>();
        if (PayeeTypeEnum.PROXY.getCode().equalsIgnoreCase(txn.getPayeeType())) {
            addPartyIdentification(identifications,
                    event.getEphPayeeCustomerIdCategory(),
                    event.getEphPayeeCustomerId(),
                    event.getEphPayeeCustomerIdType());
        }
//        addPartyIdentification(identifications,
//                txn.getEphPayerCustomerIdCategory(),
//                txn.getEphPayerCustomerId(),
//                txn.getEphPayerCustomerIdType());

        return new EphI006RequestXml.Party(
                txn.getPayeeName(),
                identifications.isEmpty() ? null : identifications,
                null);
    }

    private static void addPartyIdentification(List<EphI006RequestXml.PartyIdentification> identifications,
            String category, String customerId, String type) {
        if (hasText(category) && hasText(customerId) && hasText(type)) {
            identifications.add(EphI006RequestXml.PartyIdentification.of(category, customerId, type));
        }
    }

    private static EphI006RequestXml.ContactDetails contactDetails(String mobileNo, String emailAddress) {
        if (!hasText(mobileNo) && !hasText(emailAddress)) {
            return null;
        }
        return new EphI006RequestXml.ContactDetails(optionalText(mobileNo), optionalText(emailAddress));
    }

    /**
     * 生成 ISO20022 账号结构：Acct/Id/Othr/Id + SchmeNm/Prtry。
     */
    private static EphI006RequestXml.Account account(String accountId, String scheme) {
        return new EphI006RequestXml.Account(
                new EphI006RequestXml.AccountId(
                        new EphI006RequestXml.OtherIdentification(
                                accountId,
                                EphI006RequestXml.SchemeName.proprietary(scheme))));
    }

    /**
     * 生成付款行或收款行的 BIC 和 clearing member id。
     */
    private static EphI006RequestXml.Agent agent(String bicCode, String memberId) {
        EphI006RequestXml.ClearingSystemMemberId clearingSystemMemberId = hasText(memberId)
                ? new EphI006RequestXml.ClearingSystemMemberId(memberId)
                : null;
        return new EphI006RequestXml.Agent(
                new EphI006RequestXml.FinancialInstitutionId(optionalText(bicCode), clearingSystemMemberId));
    }

    private static EphI006RequestXml.Purpose purpose(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        if (!hasText(event.getPurposeCode()) && !hasText(event.getPurposeProprietary())) {
            return null;
        }
        if (hasText(event.getPurposeCode())) {
            return EphI006RequestXml.Purpose.code(event.getPurposeCode());
        }
        return EphI006RequestXml.Purpose.proprietary(event.getPurposeProprietary());
    }

    private static EphI006RequestXml.RemittanceInformation remittanceInformation(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        if (!hasText(event.getPaymentDetail1()+event.getPaymentDetail2()+event.getPaymentDetail3()+event.getPaymentDetail4())) {
            return null;
        }
        return new EphI006RequestXml.RemittanceInformation(event.getPaymentDetail1());
    }

    private static EphI006RequestXml.ProcessingPersistentInfo processingInfo(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        EphI006RequestXml.ProcessingPersistentInfo processingInfo =
                new EphI006RequestXml.ProcessingPersistentInfo();
        processingInfo.officeId = optionalText(event.getOfficeId());
        processingInfo.paymentSource = event.getEphPaymentSource();
        processingInfo.invoiceNumber = optionalText(event.getInvoiceNumber());
        processingInfo.costCenterCode = event.getEphCostCenterCode();
        processingInfo.alnovaLimitCheckInd = event.getEphAlnovaLmtChkInd();
        processingInfo.transactionType = event.getEphTxType();
        processingInfo.customerType = optionalText(event.getCustomerType());
        processingInfo.vipInd = optionalText(event.getVipInd());
        processingInfo.creditSide = new EphI006RequestXml.CreditSide(
                event.getEphCreditMop(),
                optionalText(event.getCreditInternalAccount()));
        processingInfo.debitSide = new EphI006RequestXml.DebitSide(
                event.getEphDebitMop(),
                optionalText(event.getDebitInternalAccount()),
                txn.getPayerInternalAccountNo(),
                txn.getPayerAccountNo(),
                optionalText(event.getProductType()));
        processingInfo.feeCode = event.getEphFeeCode();
        processingInfo.operationDate = settlementDate(txn.getExecutionDate());
        return processingInfo;
    }

    private static String payeeIdentification(PaymentTxnMainEntity txn) {
        // 代理模式三选一：proxyId、mobile、email。
        if (PayeeTypeEnum.PROXY.getCode().equalsIgnoreCase(txn.getPayeeType())) {
            String identification = txn.getPayeeProxyId();
            if (StringUtils.isBlank(identification)) {
                identification = txn.getPayeeMobileNo();
            }
            if (StringUtils.isBlank(identification)) {
                identification = txn.getPayeeEmailAddress();
            }
            return identification;
        }
        // 账号模式取收款账号。
        return txn.getPayeeAccountNo();
    }

    private static boolean isAccountPayee(PaymentTxnMainEntity txn) {
        return !PayeeTypeEnum.PROXY.getCode().equalsIgnoreCase(txn.getPayeeType());
    }

    private static String amount(BigDecimal value) {
        return value == null ? null : value.setScale(2, RoundingMode.UNNECESSARY).toPlainString();
    }

    private static String settlementDate(Date executionDate) {
        if (executionDate == null) {
            return LocalDate.now().toString();
        }
        if (executionDate instanceof java.sql.Date sqlDate) {
            return sqlDate.toLocalDate().toString();
        }
        return executionDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toString();
    }

    private static String defaultIfBlank(String value, String defaultValue) {
        return hasText(value) ? value : defaultValue;
    }

    private static String optionalText(String value) {
        return hasText(value) ? value : null;
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
