package com.bea.payment.bulk.internal.eph;

import com.bea.payment.bulk.internal.eph.model.EphI005Response;
import com.bea.payment.bulk.internal.eph.model.EphI006Response;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.math.BigDecimal;

/**
 * EPH XML 响应解析器。
 *
 * <p>当前只解析 Worker 状态闭环需要的关键字段：消息 ID、状态、错误信息、
 * I005 选中的银行/MOP，以及 I006 FPS reference。完整字段可在后续按场景继续扩展。</p>
 */
public final class EphXmlParser {

    private EphXmlParser() {}

    /**
     * 解析 I005 响应。
     *
     * <p>I005 样例中存在原始文档拍照导致的标签问题，因此这里按可解析的正式 XML 结构处理；
     * 对无法解析的非良构 XML，直接抛出 IllegalArgumentException，避免静默吞错。</p>
     */
    public static EphI005Response parseI005Response(String xml) {
        Document doc = parse(xml);
        Element adrScheme = firstElement(doc, "AdrSchme");
        Element debitSide = firstElement(doc, "DebitSide");
        Element bankReceiveMode = firstElement(doc, "BankReceiveMode");
        Element addressSummary = firstElement(doc, "Smry");

        // 1. ISO 主体取寻址状态、地址数量和默认/第一条寻址记录。
        // 2. Extn/DebitSide 取服务费、币种和收款行 MOP。
        return new EphI005Response(
                text(firstElement(doc, "GrpHdr"), "MsgId"),
                text(doc, "RespSts"),
                text(adrScheme, "Sts"),
                integer(text(debitSide, "NoOfAdr"), integer(text(adrScheme, "NoOfAdr"), null)),
                text(bankReceiveMode, "BankCd", nestedText(addressSummary, "MmbId")),
                text(bankReceiveMode, "BankNm"),
                nestedText(addressSummary, "DispNm"),
                nestedText(addressSummary, "CusId"),
                nestedText(addressSummary, "CusTp"),
                decimal(text(debitSide, "ServiceCharge")),
                text(debitSide, "ServiceChargeCCY"),
                text(bankReceiveMode, "ReceiveMode"),
                text(doc, "Cd"),
                text(doc, "Msg"),
                text(bankReceiveMode, "BankCd"));
    }

    /**
     * 解析 I006 响应。
     *
     * <p>ISO `TxSts` 和 EPH 扩展 `Sts` 都保留：前者用于支付清算状态，
     * 后者用于 EPH 扩展层接受/拒绝状态。</p>
     */
    public static EphI006Response parseI006Response(String xml) {
        Document doc = parse(xml);
        Element txInfAndSts = firstElement(doc, "TxInfAndSts");
        Element extn = firstElement(doc, "Extn");
        Element err = firstElement(doc, "Err");

        return new EphI006Response(
                text(firstElement(doc, "GrpHdr"), "MsgId"),
                text(txInfAndSts, "TxSts"),
                text(extn, "Sts"),
                nestedText(txInfAndSts, "Prtry"),
                text(txInfAndSts, "ClrSysRef"),
                text(txInfAndSts, "AccptncDtTm"),
                text(err, "ErrTp"),
                text(err, "ErrCd"),
                text(err, "ErrMsg"));
    }

    /**
     * 安全创建 DOM Document。
     *
     * <p>关闭外部实体和 DTD，避免 XML 外部实体类风险；EPH 报文本身不需要这些能力。</p>
     */
    private static Document parse(String xml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(false);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            return factory.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid EPH XML", e);
        }
    }

    private static Element firstElement(Document doc, String tagName) {
        NodeList nodes = doc.getElementsByTagName(tagName);
        if (nodes.getLength() == 0) {
            return null;
        }
        Node node = nodes.item(0);
        return node instanceof Element element ? element : null;
    }

    private static String text(Document doc, String tagName) {
        return text(doc.getDocumentElement(), tagName);
    }

    private static String text(Element parent, String tagName) {
        return text(parent, tagName, null);
    }

    private static String text(Element parent, String tagName, String defaultValue) {
        if (parent == null) {
            return defaultValue;
        }
        NodeList nodes = parent.getElementsByTagName(tagName);
        if (nodes.getLength() == 0) {
            return defaultValue;
        }
        String value = nodes.item(0).getTextContent();
        if (value == null) {
            return defaultValue;
        }
        value = value.trim();
        return value.isEmpty() ? defaultValue : value;
    }

    private static String nestedText(Element parent, String tagName) {
        return text(parent, tagName);
    }

    private static BigDecimal decimal(String value) {
        return value == null ? null : new BigDecimal(value);
    }

    private static Integer integer(String value, Integer defaultValue) {
        return value == null ? defaultValue : Integer.valueOf(value);
    }
}
