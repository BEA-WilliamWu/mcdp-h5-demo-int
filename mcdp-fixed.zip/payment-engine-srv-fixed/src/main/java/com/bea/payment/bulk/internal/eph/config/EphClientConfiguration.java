package com.bea.payment.bulk.internal.eph.config;

import com.bea.payment.bulk.internal.eph.EphHttpClient;
import com.bea.payment.bulk.internal.eph.EphPaymentOrchestrator;
import com.bea.payment.bulk.service.PaymentTxnEventService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * EPH 调用链 Spring 装配配置。
 *
 * <p>设计边界：
 * 1. 配置层只负责把下游地址、路径和超时时间组装成 Bean；
 * 2. XML 组包、HTTP 调用、I005/I006 编排仍由各自业务类负责；
 * 3. 未配置 baseUrl 时不创建可调用 Bean，避免本地启动或测试环境误连真实 EPH。</p>
 */
@Configuration
@EnableConfigurationProperties(EphProperties.class)
public class EphClientConfiguration {

    /**
     * 创建 EPH HTTP client。
     *
     * <p>只有配置了 `pe.downstream.eph.base-url` 才启用。baseUrl 不提供默认真实值，
     * 调用环境必须显式选择 mock、UAT 或生产 endpoint。</p>
     */
    @Bean
    @ConditionalOnExpression("'${pe.downstream.eph.base-url:}'.trim().length() > 0 || "
            + "('${pe.downstream.eph.i005-url:}'.trim().length() > 0 && "
            + "'${pe.downstream.eph.i006-url:}'.trim().length() > 0)")
    public EphHttpClient ephHttpClient(EphProperties properties) {
        return new EphHttpClient(properties.resolveHttpClientBaseUrl(), properties.getTimeout(),
                properties.isTlsHostnameVerificationEnabled(), properties.isTlsInsecureSkipVerify());
    }

    /**
     * 创建 EPH 支付编排器。
     *
     * <p>编排器复用同一个 HTTP client，并从配置读取 I005/I006 路径。
     * 后续 ExecutionService 只依赖该编排器，不再关心 endpoint 拼接细节。</p>
     */
    @Bean
    @ConditionalOnExpression("'${pe.downstream.eph.base-url:}'.trim().length() > 0 || "
            + "('${pe.downstream.eph.i005-url:}'.trim().length() > 0 && "
            + "'${pe.downstream.eph.i006-url:}'.trim().length() > 0)")
    public EphPaymentOrchestrator ephPaymentOrchestrator(EphHttpClient ephHttpClient, EphProperties properties,
                                                         PaymentTxnEventService eventService) {
        return new EphPaymentOrchestrator(ephHttpClient, properties.resolveI005Endpoint(), properties.resolveI006Endpoint(),
                properties.getI005InterfaceId(), properties.getI006InterfaceId(), properties.isI005Enabled(),eventService);
    }
}
