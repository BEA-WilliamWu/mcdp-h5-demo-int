package com.bea.payment.bulk.internal.eph.config;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

/**
 * EPH 下游接口配置。
 *
 * <p>这里仅保存连接 EPH 所需的协议参数，不保存任何真实账号、密钥或环境敏感值。
 * baseUrl 不设置默认值，避免在未确认环境时误连真实 EPH。</p>
 */
@ConfigurationProperties(prefix = "pe.downstream.eph")
@Getter
@Setter
public class EphProperties {

    /**
     * EPH HTTP 基础地址，例如 UAT 或 mock server 地址。
     */
    private String baseUrl;

    /**
     * I005 addressing enquiry 完整 URL。用于 I005/I006 不同 host 或 port 的联调场景。
     */
    private String i005Url;

    /**
     * I006 credit transfer 完整 URL。用于 I005/I006 不同 host 或 port 的联调场景。
     */
    private String i006Url;

    /**
     * I005 addressing enquiry 接口路径。
     */
    private String i005Path = "/i005";

    /**
     * I006 credit transfer 接口路径。
     */
    private String i006Path = "/i006";

    /**
     * I005 interface id。由 IPE 配置提供，不再由上游 API 入参传入。
     */
    private String i005InterfaceId = "EPHI005";

    /**
     * 是否调用 I005 addressing enquiry。
     *
     * <p>默认开启。调试时可关闭以跳过 I005，直接发送 I006；关闭后不会预校验 I006 依赖字段。</p>
     */
    private boolean i005Enabled = true;

    /**
     * I006 interface id。由 IPE 配置提供，不再由上游 API 入参传入。
     */
    private String i006InterfaceId = "EPHI006";

    /**
     * 单次 EPH HTTP 请求超时时间。
     */
    private Duration timeout = Duration.ofSeconds(10);

    /**
     * 是否启用 HTTPS 主机名校验。
     *
     * <p>默认开启。只有本地通过 PuTTY/SSH tunnel 使用 localhost 转发真实 EPH HTTPS 端口，
     * 且证书主机名仍是真实 EPH 域名时，才允许在本机环境变量中关闭。</p>
     */
    private boolean tlsHostnameVerificationEnabled = true;

    /**
     * 是否跳过 EPH HTTPS 证书链和主机名校验。
     *
     * <p>默认关闭。仅用于 SIT Pod JDK truststore 尚未导入 EPH 证书时的临时联调，
     * 开启后会覆盖 {@link #tlsHostnameVerificationEnabled} 的主机名校验行为。</p>
     */
    private boolean tlsInsecureSkipVerify = false;

    /**
     * EPH I005/I006 control fields owned by IPE.
     */
    private Control control = new Control();

    public String resolveHttpClientBaseUrl() {
        if (hasText(baseUrl)) {
            return baseUrl;
        }
        if (hasText(i005Url)) {
            return baseOf(i005Url);
        }
        if (hasText(i006Url)) {
            return baseOf(i006Url);
        }
        return baseUrl;
    }

    public String resolveI005Endpoint() {
        return hasText(i005Url) ? i005Url : i005Path;
    }

    public String resolveI006Endpoint() {
        return hasText(i006Url) ? i006Url : i006Path;
    }

    private static String baseOf(String endpointUrl) {
        java.net.URI uri = java.net.URI.create(endpointUrl);
        StringBuilder base = new StringBuilder();
        base.append(uri.getScheme()).append("://").append(uri.getAuthority()).append("/");
        return base.toString();
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    @Getter
    @Setter
    public static class Control {

        /**
         * EPH I006 transaction type. EPH confirmed TOB for current FPS transfer.
         */
        private String transactionType = "TOB";

        /**
         * Account verification option confirmed by EPH.
         */
        private String accountVerificationOption = "PERFORM_PYE_VRF";

        /**
         * Settlement method confirmed by EPH.
         */
        private String settlementMethod = "CLRG";

        /**
         * Clearing system is optional for current EPH confirmation and is omitted by default.
         */
        private String clearingSystem;

        /**
         * Debtor clearing system member ID confirmed by EPH.
         */
        private String debtorMemberId = "015";

        /**
         * Charge bearer confirmed by EPH.
         */
        private String chargeBearer = "SLEV";

        /**
         * Debit mode of payment confirmed by EPH.
         */
        private String debitMop = "BOOK";

        /**
         * Customer type confirmed by EPH for the current corporate payment flow.
         */
        private String customerType = "CORP";
    }
}
