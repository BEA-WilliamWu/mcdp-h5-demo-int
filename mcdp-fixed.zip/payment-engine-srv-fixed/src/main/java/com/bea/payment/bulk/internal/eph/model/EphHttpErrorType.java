package com.bea.payment.bulk.internal.eph.model;

/**
 * EPH HTTP 调用失败分类。
 *
 * <p>这里先只表达调用层能稳定识别的技术失败，不把 EPH 业务返回码混进来。
 * EPH XML 业务失败会在 XML parser / Worker 编排层再映射。</p>
 */
public enum EphHttpErrorType {
    /** EPH 返回了非 2xx HTTP 状态码。 */
    HTTP_STATUS,
    /** 请求在配置超时时间内没有拿到响应。 */
    TIMEOUT,
    /** 建连、发送、读响应等底层 I/O 失败。 */
    IO_ERROR,
    /** 当前线程被中断，调用被迫停止。 */
    INTERRUPTED
}
