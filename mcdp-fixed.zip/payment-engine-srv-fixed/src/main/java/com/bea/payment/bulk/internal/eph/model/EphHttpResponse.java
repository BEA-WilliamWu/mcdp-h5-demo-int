package com.bea.payment.bulk.internal.eph.model;

/**
 * EPH HTTP 原始响应。
 *
 * <p>HTTP client 只负责返回状态码和响应体。响应体里的 I005/I006 业务字段，
 * 由 XML parser 负责解析，避免 HTTP 层和报文业务层耦合。</p>
 */
public record EphHttpResponse(int statusCode, String body) {
}
