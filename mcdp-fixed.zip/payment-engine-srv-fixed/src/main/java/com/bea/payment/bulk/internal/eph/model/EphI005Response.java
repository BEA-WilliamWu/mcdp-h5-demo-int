package com.bea.payment.bulk.internal.eph.model;

import java.math.BigDecimal;

/**
 * Parsed EPH I005 addressing enquiry response.
 *
 * @param msgId response message identifier assigned by EPH/HKICL.
 * @param responseStatus transaction-level response status, for example Success or Fail.
 * @param addressStatus addressing-scheme status, for example accepted or rejected.
 * @param addressCount number of addressing records associated with the proxy identification.
 * @param selectedBankCode selected payee participant clearing code used by the following I006 request.
 * @param selectedBankName selected payee participant bank name when returned by EPH.
 * @param displayName masked or display customer name returned by the addressing enquiry.
 * @param customerId customer identifier returned by the addressing enquiry.
 * @param customerType customer type returned by the addressing enquiry, such as CORP or PERS.
 * @param serviceChargeAmount service-charge amount returned by the fee enquiry.
 * @param serviceChargeCurrency service-charge currency returned by the fee enquiry.
 * @param creditMop credit mode of payment returned by I005 BankReceiveMode.
 * @param errorCode error code returned by EPH or HKICL when the enquiry fails.
 * @param errorMessage error message returned by EPH or HKICL when the enquiry fails.
 */
public record EphI005Response(
        String msgId,
        String responseStatus,
        String addressStatus,
        Integer addressCount,
        String selectedBankCode,
        String selectedBankName,
        String displayName,
        String customerId,
        String customerType,
        BigDecimal serviceChargeAmount,
        String serviceChargeCurrency,
        String creditMop,
        String errorCode,
        String errorMessage,
        String payeeBankCode) {
}
