package com.bea.payment.bulk.internal.eph.model;

/**
 * Parsed EPH I006 credit transfer response.
 *
 * @param msgId response message identifier assigned by EPH/HKICL.
 * @param transactionStatus ISO transaction status, such as ACSC, RJCT, ACSP, ACCP, or PDNG.
 * @param extensionStatus EPH extension status where A means accepted and R means rejected.
 * @param reasonCode proprietary rejection or status reason code from the ISO status block.
 * @param fpsReference FPS clearing-system reference assigned after validation or settlement.
 * @param acceptanceDateTime FPS acceptance or settlement date-time when returned.
 * @param errorType EPH extension error type, such as EPH, ALNOVA, or ICL.
 * @param errorCode EPH extension error code.
 * @param errorMessage EPH extension error message.
 */
public record EphI006Response(
        String msgId,
        String transactionStatus,
        String extensionStatus,
        String reasonCode,
        String fpsReference,
        String acceptanceDateTime,
        String errorType,
        String errorCode,
        String errorMessage) {
}
