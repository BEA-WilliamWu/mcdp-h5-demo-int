package com.bea.payment.bulk.internal.eph.model;

/**
 * EPH 一次支付调用链的执行结果。
 *
 * <p>一次跨行 EPH 支付必须先 I005，再 I006。这个结果对象把两段响应都保留下来，
 * 后续 Worker 可以据此决定如何更新内部状态、审计日志或回调上游。</p>
 */
public record EphPaymentResult(EphI005Response i005Response, EphI006Response i006Response) {
}
