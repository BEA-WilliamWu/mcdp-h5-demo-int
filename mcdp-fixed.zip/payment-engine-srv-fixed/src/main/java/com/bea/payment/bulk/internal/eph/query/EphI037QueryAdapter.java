package com.bea.payment.bulk.internal.eph.query;

import com.bea.payment.bulk.internal.downstream.DownstreamTlsSupport;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;

/**
 * HTTP/XML adapter for EPH I037 status query.
 */
public class EphI037QueryAdapter implements EphQueryPort {

    private static final Logger log = LoggerFactory.getLogger(EphI037QueryAdapter.class);
    private static final String XML_MEDIA_TYPE = "application/xml";
    private static final int DEFAULT_TIMEOUT_MILLIS = 10000;
    private static final HostnameVerifier LOCAL_TUNNEL_HOSTNAME_VERIFIER = (hostname, session) -> true;

    private final EphQueryProperties properties;
    private final EphI037XmlBuilder builder;
    private final EphI037XmlParser parser;

    public EphI037QueryAdapter(EphQueryProperties properties,
            EphI037XmlBuilder builder,
            EphI037XmlParser parser) {
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.builder = Objects.requireNonNull(builder, "builder must not be null");
        this.parser = Objects.requireNonNull(parser, "parser must not be null");
        DownstreamTlsSupport.warnIfInsecureTlsEnabled("EPH-I037", properties.isTlsInsecureSkipVerify());
    }

    @Override
    public EphQueryResponse queryTransaction(EphQueryRequest request) {
        if (StringUtils.isBlank(properties.getUrl())) {
            throw new EphQueryException("EPH I037 query URL is not configured");
        }
        String xml = builder.build(request);
        try {
            String responseBody = postXml(properties.getUrl(), xml, request.getTransactionIds());
            return parser.parse(responseBody, request.getTransactionIds());
        } catch (EphQueryException e) {
            throw e;
        } catch (Exception e) {
            throw new EphQueryException("EPH I037 query failed", e);
        }
    }

    private String postXml(String url, String xml, List<String> transactionIds) throws IOException {
        HttpURLConnection connection = null;
        try {
            log.debug("[EPH-I037] Request prepared for {} transaction(s)", transactionIds.size());
            connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
            configureHttpsConnection(connection);
            byte[] requestBytes = xml.getBytes(StandardCharsets.UTF_8);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(DEFAULT_TIMEOUT_MILLIS);
            connection.setReadTimeout(DEFAULT_TIMEOUT_MILLIS);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", XML_MEDIA_TYPE + "; charset=UTF-8");
            connection.setRequestProperty("Accept", XML_MEDIA_TYPE);
            connection.setFixedLengthStreamingMode(requestBytes.length);
            try (OutputStream outputStream = connection.getOutputStream()) {
                outputStream.write(requestBytes);
            }
            int statusCode = connection.getResponseCode();
            String responseBody = readResponseBody(connection, statusCode);
            log.info("[EPH-I037] Response status={} for transactionIds={}", statusCode, transactionIds);
            log.debug("[EPH-I037] Response received for {} transaction(s)", transactionIds.size());
            if (statusCode < 200 || statusCode >= 300) {
                throw new EphQueryException("EPH I037 returned HTTP status " + statusCode);
            }
            return responseBody;
        } catch (SocketTimeoutException e) {
            throw new EphQueryException("EPH I037 query timed out", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private void configureHttpsConnection(HttpURLConnection connection) {
        if (connection instanceof HttpsURLConnection httpsConnection) {
            if (properties.isTlsInsecureSkipVerify()) {
                // SIT 证书未进入 JDK truststore 前的临时联调路径：证书链和主机名都放行。
                httpsConnection.setSSLSocketFactory(DownstreamTlsSupport.insecureTrustAllSocketFactory());
                httpsConnection.setHostnameVerifier(DownstreamTlsSupport.insecureHostnameVerifier());
            } else if (!properties.isTlsHostnameVerificationEnabled()) {
                httpsConnection.setHostnameVerifier(LOCAL_TUNNEL_HOSTNAME_VERIFIER);
            }
        }
    }

    private String readResponseBody(HttpURLConnection connection, int statusCode) throws IOException {
        InputStream inputStream = statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (inputStream == null) {
            return "";
        }
        try (InputStream stream = inputStream) {
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
