package com.bea.payment.bulk.internal.eph.query;

import com.bea.payment.bulk.internal.eph.xml.EphI037RequestXml;
import com.bea.payment.bulk.internal.eph.xml.EphXmlSerializer;

import java.util.List;
import java.util.Objects;

/**
 * Builds EPH I037 transaction status query XML.
 */
public class EphI037XmlBuilder {

    private static final int MAX_TX_IDS = 10;

    public String build(EphQueryRequest request) {
        Objects.requireNonNull(request, "request must not be null");
        List<String> transactionIds = request.getTransactionIds();
        if (transactionIds.isEmpty()) {
            throw new IllegalArgumentException("transactionIds must not be empty");
        }
        if (transactionIds.size() > MAX_TX_IDS) {
            throw new IllegalArgumentException("transactionIds must not exceed " + MAX_TX_IDS);
        }
        for (String transactionId : transactionIds) {
            if (transactionId == null || transactionId.isBlank()) {
                throw new IllegalArgumentException("transactionId must not be blank");
            }
        }

        EphI037RequestXml message = new EphI037RequestXml(
                new EphI037RequestXml.TxnDbSmryEnqReq(
                        request.getQueryTimestamp(),
                        request.getPaymentSource(),
                        new EphI037RequestXml.TxIds(transactionIds),
                        new EphI037RequestXml.InterfaceElement(request.getInterfaceId())));
        return EphXmlSerializer.serialize(message);
    }
}
