package com.bea.payment.bulk.internal.eph.query;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Parses EPH I037 transaction status query XML responses.
 */
public class EphI037XmlParser {

    public EphQueryResponse parse(String xml, List<String> requestedTransactionIds) {
        try {
            Document document = parseDocument(xml);
            NodeList resultNodes = document.getElementsByTagName("Rslt");
            Map<String, EphQueryResponse.TransactionResult> results = new LinkedHashMap<>();
            for (int i = 0; i < resultNodes.getLength(); i++) {
                Node node = resultNodes.item(i);
                if (!(node instanceof Element resultElement)) {
                    continue;
                }
                String txId = childText(resultElement, "TxId");
                if (txId == null || txId.isBlank()) {
                    String text = resultElement.getTextContent();
                    if (text != null && !text.isBlank()) {
                        return new EphQueryResponse(Map.of(), true,
                                "EPH_QUERY_VALIDATION_FAILED", text.trim());
                    }
                    continue;
                }
                results.put(txId, new EphQueryResponse.TransactionResult(
                        txId,
                        blankToNull(childText(resultElement, "TxnStts")),
                        blankToNull(childText(resultElement, "AddtnlInf"))));
            }
            return new EphQueryResponse(results, false, null, null);
        } catch (Exception e) {
            throw new EphQueryException("Failed to parse EPH I037 response", e);
        }
    }

    private Document parseDocument(String xml) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setExpandEntityReferences(false);
        return factory.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
    }

    private static String childText(Element parent, String tagName) {
        NodeList nodes = parent.getElementsByTagName(tagName);
        if (nodes.getLength() == 0) {
            return null;
        }
        String text = nodes.item(0).getTextContent();
        return text == null ? null : text.trim();
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }
}
