package com.bea.payment.bulk.internal.eph.query;

import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.notification.ManualReviewEmailService;
import com.bea.payment.bulk.service.PaymentBatchStatusService;
import com.bea.payment.bulk.service.PaymentTxnEventService;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Objects;

/**
 * EPH 状态查询补偿 Spring 配置。
 *
 * <p>组装查询补偿所需的 Bean。通过 {@code pe.downstream.eph.query.enabled=true} 启用。</p>
 */
@Configuration
@EnableConfigurationProperties(EphQueryProperties.class)
@ConditionalOnProperty(prefix = "pe.downstream.eph.query", name = "enabled", havingValue = "true")
public class EphQueryConfiguration {

    private static final Logger log = LoggerFactory.getLogger(EphQueryConfiguration.class);

    private final PaymentTxnMainMapper txnMainMapper;
    private final EphQueryProperties properties;
    private final RedissonClient redisson;
    private final PaymentBatchStatusService batchStatusService;

    public EphQueryConfiguration(PaymentTxnMainMapper txnMainMapper,
            EphQueryProperties properties,
            RedissonClient redisson,
            PaymentBatchStatusService batchStatusService) {
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.redisson = Objects.requireNonNull(redisson, "redisson must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService, "batchStatusService must not be null");
    }

    @Bean
    public EphQueryPort ephI037QueryPort() {
        return new EphI037QueryAdapter(properties, new EphI037XmlBuilder(), new EphI037XmlParser());
    }

    /**
     * EPH 状态查询服务。
     */
    @Bean
    public EphStatusQueryService ephStatusQueryService(PaymentTxnEventMapper eventMapper,
            EphQueryPort queryPort,
            ManualReviewEmailService emailService,
            PaymentTxnEventService eventService,
            TransactionTemplate transactionTemplate) {
        return new EphStatusQueryService(txnMainMapper, eventMapper, queryPort, properties, batchStatusService,
                emailService, eventService, transactionTemplate);
    }

    /**
     * EPH 状态查询调度器。
     */
    @Bean
    public EphStatusQueryScheduler ephStatusQueryScheduler(EphStatusQueryService queryService) {
        return new EphStatusQueryScheduler(redisson, queryService);
    }
}
