package com.bea.payment.bulk.internal.eph.query;

/**
 * EPH 查询调用本身失败时的异常。
 *
 * <p>与 EPH 业务拒绝区分：业务拒绝通过 {@link EphQueryResponse.TransactionResult#transactionStatus()} 表达；
 * 本异常只表示查询接口调用失败（网络超时、IO 错误等）。</p>
 */
public class EphQueryException extends RuntimeException {

    public EphQueryException(String message, Throwable cause) {
        super(message, cause);
    }

    public EphQueryException(String message) {
        super(message);
    }
}
