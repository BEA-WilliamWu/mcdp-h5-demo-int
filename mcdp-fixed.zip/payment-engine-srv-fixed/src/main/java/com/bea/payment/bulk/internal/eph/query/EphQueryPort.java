package com.bea.payment.bulk.internal.eph.query;

/**
 * EPH 交易状态查询端口。
 *
 * <p>定义“查询一笔 EPH 交易的最新状态”的输入输出契约。
 * 当前为 stub 实现，等待 EPH 团队提供正式查询接口协议后再替换为真实 adapter。</p>
 *
 * <p><b>EPH 约束：</b>每笔交易最多只能调用一次查询接口。</p>
 */
public interface EphQueryPort {

    /**
     * 查询一笔 EPH 交易的当前状态。
     *
     * @param request 查询请求，包含交易标识和 EPH 所需查询键
     * @return 查询响应，包含当前交易状态和附加信息
     * @throws EphQueryException 查询调用本身失败（网络、超时等），非 EPH 业务拒绝
     */
    EphQueryResponse queryTransaction(EphQueryRequest request);
}
