package com.bea.payment.bulk.internal.eph.query;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * EPH 状态查询补偿定时任务配置。
 *
 * <p>配置前缀：{@code pe.downstream.eph.query}</p>
 */
@ConfigurationProperties(prefix = "pe.downstream.eph.query")
@Getter
@Setter
public class EphQueryProperties {

    /** I037 endpoint URL. */
    private String url;

    /** I037 interface id. */
    private String interfaceId = "I037";

    /**
     * 是否启用 HTTPS 主机名校验。
     */
    private boolean tlsHostnameVerificationEnabled = true;

    /**
     * 是否跳过 I037 HTTPS 证书链和主机名校验。
     *
     * <p>默认关闭。仅用于 SIT truststore 尚未导入 EPH 证书时的临时联调。</p>
     */
    private boolean tlsInsecureSkipVerify = false;

    /** 查询补偿定时任务的固定间隔（毫秒），默认 60 秒 */
    private long fixedDelay = 60000L;

    /** 每笔查询之间的间隔（毫秒），默认 3 秒 */
    private long intervalBetweenQueries = 3000L;

    /** 非终态/timeout 后多久可以开始查询（毫秒），默认 30 分钟 */
    private long queryEligibleDelayMs = 1800000L;

    /**
     * 每笔交易生命周期最多查询次数，默认 1。
     *
     * <p>当前契约为单次 I037 查询，默认值固定为 1。</p>
     */
    private int maxQueryAttempts = 1;

    /** 每次调度最多查询多少笔交易，默认 50，防止一次调度扫描太多 */
    private int maxQueryPerRun = 50;

}
