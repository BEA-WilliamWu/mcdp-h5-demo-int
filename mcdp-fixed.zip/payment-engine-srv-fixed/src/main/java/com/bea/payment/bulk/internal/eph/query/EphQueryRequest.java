package com.bea.payment.bulk.internal.eph.query;

import lombok.Getter;

import java.util.List;
import java.util.Objects;

/**
 * EPH I037 交易状态查询请求。
 *
 * <p>单次请求包含 1 至 10 个交易 ID、查询发起时间、payment source 和固定接口 ID。</p>
 */
@Getter
public class EphQueryRequest {

    /** IPE 交易 ID 列表，作为 EPH 侧关联键。 */
    private final List<String> transactionIds;

    /** 查询发起时间 */
    private final String queryTimestamp;

    /** EPH payment source，来自 MAIN.EPH_PAYMENT_SOURCE */
    private final String paymentSource;

    /** I037 interface id. */
    private final String interfaceId;

    public EphQueryRequest(List<String> transactionIds, String queryTimestamp,
            String paymentSource, String interfaceId) {
        this.transactionIds = List.copyOf(Objects.requireNonNull(transactionIds,
                "transactionIds must not be null"));
        this.queryTimestamp = Objects.requireNonNull(queryTimestamp, "queryTimestamp must not be null");
        this.paymentSource = paymentSource;
        this.interfaceId = Objects.requireNonNull(interfaceId, "interfaceId must not be null");
    }

    public String getTransactionId() {
        return transactionIds.isEmpty() ? null : transactionIds.get(0);
    }

}
