package com.bea.payment.bulk.internal.eph.query;


import lombok.Getter;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
/**
 * EPH 交易状态查询响应。
 *
 * <p>用于承载 I037 响应中按交易 ID 返回的 {@code TxnStts} 和 {@code AddtnlInf}。</p>
 */
@Getter
public class EphQueryResponse {

    private final Map<String, TransactionResult> results;

    private final boolean queryFailed;

    /** EPH 返回的错误码（如有） */
    private final String errorCode;

    /** EPH 返回的错误信息（如有） */
    private final String errorMessage;

    public EphQueryResponse(Map<String, TransactionResult> results, boolean queryFailed,
            String errorCode, String errorMessage) {
        this.results = new LinkedHashMap<>(Objects.requireNonNull(results, "results must not be null"));
        this.queryFailed = queryFailed;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public Optional<TransactionResult> resultFor(String transactionId) {
        return Optional.ofNullable(results.get(transactionId));
    }

    public record TransactionResult(String transactionId, String transactionStatus, String additionalInfo) {
    }

}
