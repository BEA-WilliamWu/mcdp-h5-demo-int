package com.bea.payment.bulk.internal.eph.query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * EPH 状态查询补偿定时任务入口。
 *
 * <p>与 {@link EphQueryConfiguration} 分离，使用已注入的 {@link EphStatusQueryScheduler} bean，
 * 不在 {@code @Scheduled} 方法里手动调用 {@code @Bean} 工厂方法。</p>
 */
@Component
@ConditionalOnBean(EphStatusQueryScheduler.class)
public class EphQuerySchedulerRunner {

    private static final Logger log = LoggerFactory.getLogger(EphQuerySchedulerRunner.class);
    private final EphStatusQueryScheduler scheduler;

    public EphQuerySchedulerRunner(EphStatusQueryScheduler scheduler) {
        this.scheduler = Objects.requireNonNull(scheduler, "scheduler must not be null");
    }

    /**
     * 定时任务入口，按配置间隔触发。
     */
    @Scheduled(fixedDelayString = "${pe.downstream.eph.query.fixed-delay:60000}")
    public void runScheduled() {
        log.debug("[EPH-QUERY-RUNNER] Triggering status query cycle");
        scheduler.executeOnce();
    }
}
