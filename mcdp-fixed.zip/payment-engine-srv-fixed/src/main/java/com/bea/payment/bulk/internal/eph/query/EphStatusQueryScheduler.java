package com.bea.payment.bulk.internal.eph.query;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * EPH 交易状态查询补偿定时任务调度器。
 *
 * <p>职责：</p>
 * <ul>
 *   <li>通过 Redisson 分布式锁 {@code lock:eph:status-query} 保证同一时刻只有一个 Pod 执行</li>
 *   <li>计算查询时间窗口并委托 {@link EphStatusQueryService} 执行</li>
 *   <li>每轮调度只执行一次，避免同一 Pod 内并发</li>
 * </ul>
 */
public class EphStatusQueryScheduler {

    private static final Logger log = LoggerFactory.getLogger(EphStatusQueryScheduler.class);
    private static final String QUERY_LOCK_KEY = "lock:eph:status-query";

    private final RedissonClient redisson;
    private final EphStatusQueryService queryService;

    public EphStatusQueryScheduler(RedissonClient redisson, EphStatusQueryService queryService) {
        this.redisson = Objects.requireNonNull(redisson, "redisson must not be null");
        this.queryService = Objects.requireNonNull(queryService, "queryService must not be null");
    }

    /**
     * 执行一次查询补偿。
     *
     * <p>先获取分布式锁，锁内计算 eligibleCutoff（当前时间）并调用查询服务。</p>
     *
     * @return 本轮查询的交易数量
     */
    public int executeOnce() {
        log.debug("[EPH-QUERY-SCHEDULER] Attempting to acquire query lock: {}", QUERY_LOCK_KEY);
        RLock queryLock = redisson.getLock(QUERY_LOCK_KEY);
        if (!tryLock(queryLock)) {
            log.debug("[EPH-QUERY-SCHEDULER] Failed to acquire query lock, another pod may be querying");
            return 0;
        }

        try {
            log.info("[EPH-QUERY-SCHEDULER] Query lock acquired, starting status query cycle");
            int queried = queryService.executeQueryCycle(new Date());
            log.info("[EPH-QUERY-SCHEDULER] Query cycle completed, queried={}", queried);
            return queried;
        } finally {
            unlockIfHeld(queryLock);
            log.debug("[EPH-QUERY-SCHEDULER] Query lock released");
        }
    }

    private boolean tryLock(RLock lock) {
        try {
            return lock.tryLock(0, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private void unlockIfHeld(RLock lock) {
        if (lock.isHeldByCurrentThread()) {
            lock.unlock();
        }
    }
}
