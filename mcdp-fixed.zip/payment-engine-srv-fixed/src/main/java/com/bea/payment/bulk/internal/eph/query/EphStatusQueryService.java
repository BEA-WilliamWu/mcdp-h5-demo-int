package com.bea.payment.bulk.internal.eph.query;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.*;
import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.PaymentTxnMainEventDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.notification.ManualReviewEmailService;
import com.bea.payment.bulk.service.PaymentBatchStatusService;
import com.bea.payment.bulk.service.PaymentTxnEventService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.support.TransactionTemplate;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


/**
 * EPH 交易状态查询补偿服务。
 *
 * <p>职责：扫描需要查询 EPH 交易状态的候选交易，按 I037 单次最多 10 笔分组调用查询端口，并按结果更新 MAIN 状态。</p>
 *
 * <p><b>关键约束：</b></p>
 * <ul>
 *   <li>查询次数由 maxQueryAttempts 控制（默认 1，工程保守策略，非 EPH 已确认契约，见 OQ-EPH-009）</li>
 *   <li>只查询已到达查询时间窗口（默认 30 分钟）的交易</li>
 *   <li>不包含事务：外部 HTTP 调用不能包在数据库事务里</li>
 *   <li>不包含分布式锁：锁由调度器外层控制</li>
 *   <li>查询返回终态后才更新 paymentStatus</li>
 *   <li>查询失败不得自动重发 I006 付款请求</li>
 * </ul>
 */
public class EphStatusQueryService {


    private static final Logger log = LoggerFactory.getLogger(EphStatusQueryService.class);
    private static final String NOT_DELETED = "N";
    private static final String NEEDS_QUERY = "Y";
    private static final String TRANSACTION_TYPE_FPS = "FPS";
    private static final int I037_MAX_TX_IDS = 10;
    private static final String DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
    private static final int RESULT_CODE_MAX_LENGTH = 64;
    private static final int LAST_ERROR_CODE_MAX_LENGTH = 200;
    private static final int EVENT_TEXT_MAX_LENGTH = 1000;


    private final PaymentTxnMainMapper txnMainMapper;
    private final PaymentTxnEventMapper eventMapper;
    private final EphQueryPort queryPort;
    private final EphQueryProperties properties;
    private final PaymentBatchStatusService batchStatusService;
    private final ManualReviewEmailService emailService;
    private final PaymentTxnEventService eventService;
    private final TransactionTemplate transactionTemplate;


    public EphStatusQueryService(PaymentTxnMainMapper txnMainMapper,
            PaymentTxnEventMapper eventMapper,
            EphQueryPort queryPort,
            EphQueryProperties properties,
            PaymentBatchStatusService batchStatusService,
            ManualReviewEmailService emailService,
            PaymentTxnEventService eventService,
            TransactionTemplate transactionTemplate) {
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.eventMapper = Objects.requireNonNull(eventMapper, "eventMapper must not be null");
        this.queryPort = Objects.requireNonNull(queryPort, "queryPort must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService, "batchStatusService must not be null");
        this.emailService = Objects.requireNonNull(emailService, "emailService must not be null");
        this.eventService = Objects.requireNonNull(eventService, "eventService must not be null");
        this.transactionTemplate = Objects.requireNonNull(transactionTemplate,
                "transactionTemplate must not be null");
    }


    /**
     * 执行一次查询补偿扫描。
     *
     * @param eligibleCutoff 查询时间截止点，只查询 EPH_QUERY_ELIGIBLE_TIME <= cutoff 的记录。
     *                       由调用方传入当前时间，方便测试。
     * @return 本轮查询的交易数量
     */
    public int executeQueryCycle(Date eligibleCutoff) {
        Objects.requireNonNull(eligibleCutoff, "eligibleCutoff must not be null");
        List<PaymentTxnMainEventDTO> candidates = selectQueryCandidates(eligibleCutoff);
        if (candidates.isEmpty()) {
            log.debug("[EPH-QUERY] No candidates eligible for status query");
            return 0;
        }


        log.info("[EPH-QUERY] Found {} candidates for status query", candidates.size());
        int queried = 0;


        for (List<PaymentTxnMainEventDTO> chunk : chunks(candidates, I037_MAX_TX_IDS)) {
            List<PaymentTxnMainEventDTO> claimed = new ArrayList<>();
            for (PaymentTxnMainEventDTO txn : chunk) {
                // 1. CAS: 递增查询次数，防止并发重复查询
                if (!tryClaimQuery(txn)) {
                    log.debug("[EPH-QUERY] Query slot already claimed for transactionId={}, skipped",
                            txn.getTransactionId());
                    continue;
                }
                claimed.add(txn);
            }
            if (claimed.isEmpty()) {
                continue;
            }


            // 2. 调用 EPH I037 查询接口
            EphQueryRequest request = buildQueryRequest(claimed);
            EphQueryResponse response = null;
            EphQueryException queryException = null;
            try {
                log.info("[EPH-QUERY] Querying EPH I037 status for {} transactions", claimed.size());
                response = queryPort.queryTransaction(request);
            } catch (EphQueryException e) {
                queryException = e;
                log.error("[EPH-QUERY] I037 query call failed for {} transactions: {}",
                        claimed.size(), e.getMessage(), e);
            } catch (Exception e) {
                queryException = new EphQueryException("EPH_QUERY_UNEXPECTED", e);
                log.error("[EPH-QUERY] Unexpected error during I037 query for {} transactions",
                        claimed.size(), e);
            }


            for (PaymentTxnMainEventDTO txn : claimed) {
                if (queryException != null) {
                    markQueryFailed(txn, queryException);
                } else {
                    applyQueryResponse(txn, response);
                }
                if (updateClaimedTransaction(txn)) {
                    notifyIfManualReview(txn);
                    batchStatusService.refreshIfBatchTerminal(txn.getBatchId());
                    queried++;
                } else {
                    log.warn("[EPH-QUERY] Skipped final status update because transaction is no longer eligible, "
                                    + "transactionId={}, targetStatus={}",
                            txn.getTransactionId(), txn.getPaymentStatus());
                }
            }


            if (queried < candidates.size()) {
                sleepBetweenQueries();
            }
        }


        log.info("[EPH-QUERY] Query cycle completed: queried={}/{}", queried, candidates.size());
        return queried;
    }


    private List<List<PaymentTxnMainEventDTO>> chunks(List<PaymentTxnMainEventDTO> candidates, int size) {
        List<List<PaymentTxnMainEventDTO>> chunks = new ArrayList<>();
        for (int start = 0; start < candidates.size(); start += size) {
            chunks.add(candidates.subList(start, Math.min(start + size, candidates.size())));
        }
        return chunks;
    }


    /**
     * 扫描当前需要补偿查询的交易。
     *
     * <p>使用 {@link PaymentTxnMainMapper#selectQueryCandidates} 的 JOIN 查询，
     * 直接返回 {@link PaymentTxnMainEventDTO}，包含来自事件表的 ephPayeeIdentificationType。</p>
     */
    private List<PaymentTxnMainEventDTO> selectQueryCandidates(Date eligibleCutoff) {
        return txnMainMapper.selectQueryCandidates(
                NOT_DELETED,
                TRANSACTION_TYPE_FPS,
                PaymentStatusEnum.PROCESSING.getCode(),
                NEEDS_QUERY,
                eligibleCutoff,
                properties.getMaxQueryAttempts(),
                properties.getMaxQueryPerRun());
    }


    /**
     * CAS 更新查询次数：currentCount → currentCount + 1。
     *
     * <p>使用数据库乐观锁，WHERE 条件包含 EPH_QUERY_COUNT = 当前值，
     * 保证只有第一个到达的线程更新成功，且不超出 maxQueryAttempts 限制。</p>
     *
     * <p>注意：EPH 字段已迁移到 EVENT 表，使用 UpdateWrapper 直接操作数据库列。</p>
     */
    private boolean tryClaimQuery(PaymentTxnMainEventDTO txn) {
        int currentCount = txn.getEphQueryCount() != null ? txn.getEphQueryCount() : 0;
        Date claimTime = new Date();
        Boolean claimed = transactionTemplate.execute(status -> {
            PaymentTxnEventEntity eventUpdate = new PaymentTxnEventEntity();
            eventUpdate.setEphQueryCount(currentCount + 1);
            eventUpdate.setEphLastQueryTime(claimTime);
            int eventRows = eventMapper.update(eventUpdate,
                    new LambdaUpdateWrapper<PaymentTxnEventEntity>()
                            .eq(PaymentTxnEventEntity::getEventId, txn.getEventId())
                            .eq(PaymentTxnEventEntity::getEphNeedsStatusQuery, NEEDS_QUERY)
                            .apply("NVL(EPH_QUERY_COUNT, 0) = {0}", currentCount)
                            .apply("NVL(EPH_QUERY_COUNT, 0) < {0}", properties.getMaxQueryAttempts())
                            .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED));
            if (eventRows != 1) {
                return false;
            }

            PaymentTxnMainEntity mainUpdate = new PaymentTxnMainEntity();
            mainUpdate.setStatusReason(StatusReasonEnum.EPH_QUERYING.getCode());
            mainUpdate.setErrorSource(ErrorSourceEnum.EPH_QUERY.getCode());
            int mainRows = txnMainMapper.update(mainUpdate,
                    new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                            .eq(PaymentTxnMainEntity::getTransactionId, txn.getTransactionId())
                            .eq(PaymentTxnMainEntity::getPaymentStatus,
                                    PaymentStatusEnum.PROCESSING.getCode())
                            .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED));
            if (mainRows != 1) {
                status.setRollbackOnly();
                return false;
            }
            return true;
        });
        if (!Boolean.TRUE.equals(claimed)) {
            return false;
        }
        txn.setEphQueryCount(currentCount + 1);
        txn.setEphLastQueryTime(claimTime);
        txn.setStatusReason(StatusReasonEnum.EPH_QUERYING.getCode());
        txn.setErrorSource(ErrorSourceEnum.EPH_QUERY.getCode());
        return true;
    }


    private boolean updateClaimedTransaction(PaymentTxnMainEventDTO txn) {
        Boolean updated = transactionTemplate.execute(status -> {
            PaymentTxnMainEntity mainUpdate = new PaymentTxnMainEntity();
            mainUpdate.setPaymentStatus(txn.getPaymentStatus());
            mainUpdate.setStatusReason(txn.getStatusReason());
            mainUpdate.setErrorSource(txn.getErrorSource());
            mainUpdate.setLastErrorCode(txn.getLastErrorCode());
            mainUpdate.setManualReviewReason(txn.getManualReviewReason());
            mainUpdate.setManualReviewDetailMessage(txn.getManualReviewDetailMessage());
            mainUpdate.setManualReviewTime(txn.getManualReviewTime());
            mainUpdate.setExecutionEndTime(txn.getExecutionEndTime());
            int mainRows = txnMainMapper.update(mainUpdate,
                    new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                            .eq(PaymentTxnMainEntity::getTransactionId, txn.getTransactionId())
                            .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                            .eq(PaymentTxnMainEntity::getPaymentStatus,
                                    PaymentStatusEnum.PROCESSING.getCode()));
            if (mainRows != 1) {
                return false;
            }

            PaymentTxnEventEntity eventUpdate = new PaymentTxnEventEntity();
            eventUpdate.setEphNeedsStatusQuery(txn.getEphNeedsStatusQuery());
            int eventRows = eventMapper.update(eventUpdate,
                    new LambdaUpdateWrapper<PaymentTxnEventEntity>()
                            .eq(PaymentTxnEventEntity::getEventId, txn.getEventId())
                            .eq(PaymentTxnEventEntity::getEphNeedsStatusQuery, NEEDS_QUERY)
                            .eq(PaymentTxnEventEntity::getEphQueryCount, txn.getEphQueryCount())
                            .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED));
            if (eventRows != 1) {
                status.setRollbackOnly();
                return false;
            }
            return true;
        });
        return Boolean.TRUE.equals(updated);
    }


    /**
     * 根据 MAIN 构建 EPH I037 查询请求。
     */
    private EphQueryRequest buildQueryRequest(List<PaymentTxnMainEventDTO> txns) {
        List<String> transactionIds = txns.stream()
                .map(PaymentTxnMainEventDTO::getTransactionId)
                .toList();
        String paymentSource = txns.stream()
                .map(PaymentTxnMainEventDTO::getEphPaymentSource)
                .filter(value -> value != null && !value.isBlank())
                .findFirst()
                .orElse(null);
        return new EphQueryRequest(
                transactionIds,
                new SimpleDateFormat(DATE_PATTERN).format(new Date()),
                paymentSource,
                properties.getInterfaceId());
    }


    /**
     * 根据 EPH I037 查询响应更新 MAIN 内存对象。
     */
    void applyQueryResponse(PaymentTxnMainEventDTO txn, EphQueryResponse response) {
        if (response == null) {
            recordI037QuerySyntheticErrorEvent(txn, "EPH_QUERY_EMPTY_RESPONSE");
            markManualReview(txn, StatusReasonEnum.EPH_QUERY_FAILED.getCode(),
                    "EPH_QUERY_EMPTY_RESPONSE");
            return;
        }
        if (response.isQueryFailed()) {
            recordI037QueryFailedResponseEvent(txn, response);
            markManualReview(txn, StatusReasonEnum.EPH_QUERY_FAILED.getCode(),
                    firstText(response.getErrorMessage(), response.getErrorCode(), "EPH_QUERY_FAILED"),
                    firstText(response.getErrorCode(), response.getErrorMessage(), "EPH_QUERY_FAILED"));
            return;
        }


        EphQueryResponse.TransactionResult result = response.resultFor(txn.getTransactionId()).orElse(null);
        if (result == null) {
            recordI037QuerySyntheticErrorEvent(txn, "EPH_QUERY_RESULT_MISSING");
            markManualReview(txn, StatusReasonEnum.EPH_QUERY_NON_TERMINAL.getCode(), "EPH_QUERY_RESULT_MISSING");
            return;
        }


        recordI037Event(txn, result);


        String status = result.transactionStatus();
        String additionalInfo = result.additionalInfo();
        if ("SUCCESS".equalsIgnoreCase(status) && startsWithIgnoreCase(additionalInfo, "COMPLETE")) {
            txn.setEphNeedsStatusQuery("N");
            txn.setPaymentStatus(PaymentStatusEnum.COMPLETED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_SUCCESS.getCode());
            txn.setErrorSource(null);
            txn.setLastErrorCode(null);
            txn.setManualReviewReason(null);
            txn.setManualReviewTime(null);
            txn.setExecutionEndTime(new Date());
            return;
        }


        if ("FAILED".equalsIgnoreCase(status)
                && (startsWithIgnoreCase(additionalInfo, "REJECTED")
                || startsWithIgnoreCase(additionalInfo, "CANCELLED"))) {
            txn.setEphNeedsStatusQuery("N");
            txn.setPaymentStatus(PaymentStatusEnum.FAILED.getCode());
            txn.setStatusReason(StatusReasonEnum.DOWNSTREAM_REJECTED.getCode());
            txn.setErrorSource(ErrorSourceEnum.EPH_QUERY.getCode());
            txn.setLastErrorCode(truncate(firstText(additionalInfo, "EPH_QUERY_REJECTED"),
                    LAST_ERROR_CODE_MAX_LENGTH));
            txn.setManualReviewReason(null);
            txn.setManualReviewTime(null);
            txn.setExecutionEndTime(new Date());
            return;
        }


        markManualReview(txn, StatusReasonEnum.EPH_QUERY_NON_TERMINAL.getCode(),
                firstText(additionalInfo, status));
    }


    private void markManualReview(PaymentTxnMainEventDTO txn, String reason, String detail) {
        markManualReview(txn, reason, detail, firstText(detail, reason));
    }


    private void markManualReview(PaymentTxnMainEventDTO txn, String reason, String detail,
            String lastErrorCode) {
        txn.setEphNeedsStatusQuery("N");
        txn.setPaymentStatus(PaymentStatusEnum.MANUAL_REVIEW.getCode());
        txn.setStatusReason(reason);
        txn.setErrorSource(ErrorSourceEnum.EPH_QUERY.getCode());
        txn.setLastErrorCode(truncate(firstText(lastErrorCode, detail, reason),
                LAST_ERROR_CODE_MAX_LENGTH));
        txn.setManualReviewReason(reason);
        txn.setManualReviewDetailMessage(firstText(detail, lastErrorCode, reason));
        txn.setManualReviewTime(new Date());
        txn.setExecutionEndTime(new Date());
    }


    private void notifyIfManualReview(PaymentTxnMainEventDTO txn) {
        if (PaymentStatusEnum.MANUAL_REVIEW.getCode().equals(txn.getPaymentStatus())) {
            PaymentTxnEventEntity event = loadEventForTransaction(txn.getTransactionId());
            emailService.notifyManualReview(txn, event, "EPH", txn.getManualReviewReason(),
                    firstText(txn.getManualReviewDetailMessage(), txn.getLastErrorCode(),
                            txn.getManualReviewReason()));
        }
    }


    /**
     * Load the immutable intake event that contains the payee details used for notifications.
     */
    private PaymentTxnEventEntity loadEventForTransaction(String transactionId) {
        LambdaQueryWrapper<PaymentTxnEventEntity> query = new LambdaQueryWrapper<PaymentTxnEventEntity>()
                .eq(PaymentTxnEventEntity::getTransactionId, transactionId)
                .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnEventEntity::getEventType,
                        PaymentTxnEventTypeEnum.PAYMENT_ACCEPTED.name())
                .eq(PaymentTxnEventEntity::getOrderId, 1)
                .last("FETCH FIRST 1 ROWS ONLY");
        return eventMapper.selectOne(query);
    }


    /**
     * 查询调用失败：记录错误码，不重试。
     */
    private void markQueryFailed(PaymentTxnMainEventDTO txn, EphQueryException e) {
        recordI037QueryFailureEvent(txn, e);
        markManualReview(txn, StatusReasonEnum.EPH_QUERY_FAILED.getCode(), e.getMessage());
    }


    private void recordI037Event(PaymentTxnMainEventDTO txn, EphQueryResponse.TransactionResult result) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_I037.name());
        event.setEventStage("RESPONSE");
        event.setResultStatus(result.transactionStatus());
        event.setResultCode(shortCodeOrNull(result.additionalInfo()));
        event.setResponseSummary(truncate(result.additionalInfo(), EVENT_TEXT_MAX_LENGTH));
        if ("FAILED".equalsIgnoreCase(result.transactionStatus())) {
            event.setErrorMessage(truncate(result.additionalInfo(), EVENT_TEXT_MAX_LENGTH));
        }
        eventService.record(txn, event);
    }


    private void recordI037QueryFailedResponseEvent(PaymentTxnMainEventDTO txn, EphQueryResponse response) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_I037.name());
        event.setEventStage("ERROR");
        event.setResultStatus("FAILED");
        event.setErrorCode(response.getErrorCode());
        event.setErrorMessage(truncate(response.getErrorMessage(), EVENT_TEXT_MAX_LENGTH));
        event.setResponseSummary(truncate(firstText(response.getErrorMessage(), response.getErrorCode()),
                EVENT_TEXT_MAX_LENGTH));
        eventService.record(txn, event);
    }


    private void recordI037QuerySyntheticErrorEvent(PaymentTxnMainEventDTO txn, String errorCode) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_I037.name());
        event.setEventStage("ERROR");
        event.setResultStatus("FAILED");
        event.setErrorCode(errorCode);
        event.setErrorMessage(errorCode);
        event.setResponseSummary(errorCode);
        eventService.record(txn, event);
    }


    private void recordI037QueryFailureEvent(PaymentTxnMainEventDTO txn, EphQueryException e) {
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        event.setDownstreamSystem(DownstreamSystemEnum.EPH.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.EPH_I037.name());
        event.setEventStage("ERROR");
        event.setResultStatus("FAILED");
        event.setErrorCode("EPH_QUERY_CALL_FAILED");
        event.setErrorMessage(truncate(e.getMessage(), 300));
        event.setResponseSummary(truncate(e.getMessage(), 300));
        eventService.record(txn, event);
    }


    private void sleepBetweenQueries() {
        try {
            Thread.sleep(properties.getIntervalBetweenQueries());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("[EPH-QUERY] Query interval sleep interrupted");
        }
    }


    private static boolean startsWithIgnoreCase(String value, String prefix) {
        return value != null && prefix != null
                && value.regionMatches(true, 0, prefix, 0, prefix.length());
    }


    private static String firstText(String... values) {
        if (values == null) {
            return null;
        }
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return null;
    }


    private static String truncate(String value, int maxLen) {
        if (value == null) return null;
        return value.length() <= maxLen ? value : value.substring(0, maxLen);
    }


    private static String shortCodeOrNull(String value) {
        if (value == null || value.isBlank() || value.length() > RESULT_CODE_MAX_LENGTH) {
            return null;
        }
        return value;
    }
}
