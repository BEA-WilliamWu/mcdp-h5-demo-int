package com.bea.payment.bulk.internal.eph.xml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/**
 * EPH I005 enquiry request XML DTO.
 */
@JacksonXmlRootElement(localName = "Document", namespace = "http://www.bea.com/perform_txnPreCheck_Req")
@JsonPropertyOrder({"adrSmryReq", "extn"})
public class EphI005RequestXml {

    public static final String NAMESPACE = "http://www.bea.com/perform_txnPreCheck_Req";

    /** I005 addressing summary request body. */
    @JacksonXmlProperty(localName = "AdrSmryReq")
    public AdrSmryReq adrSmryReq;

    /** I005 extension block carrying BEA/EPH processing information. */
    @JacksonXmlProperty(localName = "Extn")
    public Extn extn;

    public EphI005RequestXml() {}

    public EphI005RequestXml(AdrSmryReq adrSmryReq, Extn extn) {
        this.adrSmryReq = adrSmryReq;
        this.extn = extn;
    }

    @JsonPropertyOrder({"adrSchme"})
    public static class AdrSmryReq {
        /** Proxy addressing scheme to be enquired in EPH/HKICL. */
        @JacksonXmlProperty(localName = "AdrSchme")
        public AdrSchme adrSchme;

        public AdrSmryReq() {}

        public AdrSmryReq(AdrSchme adrSchme) {
            this.adrSchme = adrSchme;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonPropertyOrder({"id", "type", "agent", "mrchInfIndc"})
    public static class AdrSchme {
        /** Proxy identifier, such as mobile number, email address, or FPS identifier. */
        @JacksonXmlProperty(localName = "Id")
        public String id;

        /** Proxy identifier type used by the addressing enquiry. */
        @JacksonXmlProperty(localName = "Tp")
        public String type;

        /** Creditor agent used by account-based I005 fee enquiry. */
        @JacksonXmlProperty(localName = "Agt")
        public Agent agent;

        /** Merchant information indicator used by the addressing scheme when applicable. */
        @JacksonXmlProperty(localName = "MrchInfIndc")
        public String mrchInfIndc;

        public AdrSchme() {}

        public AdrSchme(String id, String type, String mrchInfIndc) {
            this.id = id;
            this.type = type;
            this.mrchInfIndc = mrchInfIndc;
        }

        public AdrSchme(Agent agent) {
            this.agent = agent;
        }
    }

    @JsonPropertyOrder({"financialInstitutionId"})
    public static class Agent {
        /** Financial institution identification. */
        @JacksonXmlProperty(localName = "FinInstnId")
        public FinancialInstitutionId financialInstitutionId;

        public Agent() {}

        public Agent(FinancialInstitutionId financialInstitutionId) {
            this.financialInstitutionId = financialInstitutionId;
        }
    }

    @JsonPropertyOrder({"clearingSystemMemberId"})
    public static class FinancialInstitutionId {
        /** Clearing system member identification. */
        @JacksonXmlProperty(localName = "ClrSysMmbId")
        public ClearingSystemMemberId clearingSystemMemberId;

        public FinancialInstitutionId() {}

        public FinancialInstitutionId(ClearingSystemMemberId clearingSystemMemberId) {
            this.clearingSystemMemberId = clearingSystemMemberId;
        }
    }

    @JsonPropertyOrder({"memberId"})
    public static class ClearingSystemMemberId {
        /** Clearing member ID. */
        @JacksonXmlProperty(localName = "MmbId")
        public String memberId;

        public ClearingSystemMemberId() {}

        public ClearingSystemMemberId(String memberId) {
            this.memberId = memberId;
        }
    }

    @JsonPropertyOrder({"interfaceElement", "processingPersistentInfo"})
    public static class Extn {
        /** EPH interface identifier block. */
        @JacksonXmlProperty(localName = "Interface")
        public InterfaceElement interfaceElement;

        /** BEA/EPH processing fields required by the I005 enquiry. */
        @JacksonXmlProperty(localName = "ProcessingPersistentInfo")
        public ProcessingPersistentInfo processingPersistentInfo;

        public Extn() {}

        public Extn(InterfaceElement interfaceElement, ProcessingPersistentInfo processingPersistentInfo) {
            this.interfaceElement = interfaceElement;
            this.processingPersistentInfo = processingPersistentInfo;
        }
    }

    @JsonPropertyOrder({"id"})
    public static class InterfaceElement {
        /** Interface ID for I005, for example EPHI005. */
        @JacksonXmlProperty(localName = "ID")
        public String id;

        public InterfaceElement() {}

        public InterfaceElement(String id) {
            this.id = id;
        }
    }

    @JsonPropertyOrder({"cybAccIntNo", "cybAccExtNo", "paymentSrc", "txnId", "enqTp", "debitSide", "categoryPurpose"})
    public static class ProcessingPersistentInfo {
        /** Cyber account internal number used by EPH for the debit-side account. */
        @JacksonXmlProperty(localName = "CybAccIntNo")
        public String cybAccIntNo;

        /** Cyber account external number used by EPH for the debit-side account. */
        @JacksonXmlProperty(localName = "CybAccExtNo")
        public String cybAccExtNo;

        /** Payment source used by EPH to identify the originating source system. */
        @JacksonXmlProperty(localName = "PaymentSrc")
        public String paymentSrc;

        /** BEA transaction ID used to link the enquiry to the payment request. */
        @JacksonXmlProperty(localName = "TxnId")
        public String txnId;

        /** I005 enquiry type, such as ALL, FEE, BEA, or TGT. */
        @JacksonXmlProperty(localName = "EnqTp")
        public String enqTp;

        /** Debit-side fee enquiry information. */
        @JacksonXmlProperty(localName = "DebitSide")
        public DebitSide debitSide;

        /** Category purpose used when the I005 request needs a purpose value. */
        @JacksonXmlProperty(localName = "CtgyPurp")
        public CategoryPurpose categoryPurpose;

        public ProcessingPersistentInfo() {}

        public ProcessingPersistentInfo(String cybAccIntNo, String cybAccExtNo, String paymentSrc,
                String txnId, String enqTp, DebitSide debitSide, CategoryPurpose categoryPurpose) {
            this.cybAccIntNo = cybAccIntNo;
            this.cybAccExtNo = cybAccExtNo;
            this.paymentSrc = paymentSrc;
            this.txnId = txnId;
            this.enqTp = enqTp;
            this.debitSide = debitSide;
            this.categoryPurpose = categoryPurpose;
        }
    }

    @JsonPropertyOrder({"feeCd", "amt", "serviceChargeCcy", "acctNo", "prodCd"})
    public static class DebitSide {
        /** Fee code used by Alnova/EPH to enquire service charge. */
        @JacksonXmlProperty(localName = "FeeCd")
        public String feeCd;

        /** Transaction amount used for fee-related enquiry. */
        @JacksonXmlProperty(localName = "Amt")
        public String amt;

        /** Service-charge currency used for the fee enquiry. */
        @JacksonXmlProperty(localName = "ServiceChargeCCY")
        public String serviceChargeCcy;

        /** Debit account number used by the fee enquiry. */
        @JacksonXmlProperty(localName = "AcctNo")
        public String accountNo;

        /** Debit-side product code used by the fee enquiry. */
        @JacksonXmlProperty(localName = "ProdCd")
        public String prodCd;

        public DebitSide() {}

        public DebitSide(String feeCd, String amt, String serviceChargeCcy, String accountNo, String prodCd) {
            this.feeCd = feeCd;
            this.amt = amt;
            this.serviceChargeCcy = serviceChargeCcy;
            this.accountNo = accountNo;
            this.prodCd = prodCd;
        }
    }

    @JsonPropertyOrder({"prtry"})
    public static class CategoryPurpose {
        /** Proprietary category purpose value for the I005 request. */
        @JacksonXmlProperty(localName = "Prtry")
        public String prtry;

        public CategoryPurpose() {}

        public CategoryPurpose(String prtry) {
            this.prtry = prtry;
        }
    }
}
