package com.bea.payment.bulk.internal.eph.xml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

import java.util.List;

/**
 * EPH I006 credit transfer request XML DTO.
 */
@JacksonXmlRootElement(localName = "Document", namespace = "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.06")
@JsonPropertyOrder({"fiToFiCstmrCdtTrf", "extn"})
public class EphI006RequestXml {

    public static final String NAMESPACE = "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.06";

    /** ISO 20022 FIToFICustomerCreditTransfer message body. */
    @JacksonXmlProperty(localName = "FIToFICstmrCdtTrf")
    public FIToFICstmrCdtTrf fiToFiCstmrCdtTrf;

    /** EPH extension block carrying BEA processing information for I006. */
    @JacksonXmlProperty(localName = "Extn")
    public Extn extn;

    public EphI006RequestXml() {}

    public EphI006RequestXml(FIToFICstmrCdtTrf fiToFiCstmrCdtTrf, Extn extn) {
        this.fiToFiCstmrCdtTrf = fiToFiCstmrCdtTrf;
        this.extn = extn;
    }

    @JsonPropertyOrder({"groupHeader", "creditTransferTransaction"})
    public static class FIToFICstmrCdtTrf {
        /** Group header containing message-level settlement information. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "GrpHdr")
        public GroupHeader groupHeader;

        /** Credit transfer transaction information for this I006 payment. */
        @JacksonXmlProperty(localName = "CdtTrfTxInf")
        public CreditTransferTransaction creditTransferTransaction;

        public FIToFICstmrCdtTrf() {}

        public FIToFICstmrCdtTrf(GroupHeader groupHeader, CreditTransferTransaction creditTransferTransaction) {
            this.groupHeader = groupHeader;
            this.creditTransferTransaction = creditTransferTransaction;
        }
    }

    @JsonPropertyOrder({"nbOfTxs", "settlementInformation"})
    public static class GroupHeader {
        /** Number of individual transactions contained in the message. */
        @JacksonXmlProperty(localName = "NbOfTxs")
        public String nbOfTxs;

        /** Settlement method and clearing system information. */
        @JacksonXmlProperty(localName = "SttlmInf")
        public SettlementInformation settlementInformation;

        public GroupHeader() {}

        public GroupHeader(String nbOfTxs, SettlementInformation settlementInformation) {
            this.nbOfTxs = nbOfTxs;
            this.settlementInformation = settlementInformation;
        }
    }

    @JsonPropertyOrder({"settlementMethod", "clearingSystem"})
    public static class SettlementInformation {
        /** Settlement method; I006 documentation lists CLRG for FPS clearing. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "SttlmMtd")
        public String settlementMethod;

        /** Clearing system used to settle the payment instruction. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "ClrSys")
        public ClearingSystem clearingSystem;

        public SettlementInformation() {}

        public SettlementInformation(String settlementMethod, ClearingSystem clearingSystem) {
            this.settlementMethod = settlementMethod;
            this.clearingSystem = clearingSystem;
        }
    }

    @JsonPropertyOrder({"proprietary"})
    public static class ClearingSystem {
        /** Proprietary clearing system code, for example FPS. */
        @JacksonXmlProperty(localName = "Prtry")
        public String proprietary;

        public ClearingSystem() {}

        public ClearingSystem(String proprietary) {
            this.proprietary = proprietary;
        }
    }

    @JsonPropertyOrder({
            "paymentIdentification",
            "paymentTypeInformation",
            "interbankSettlementAmount",
            "interbankSettlementDate",
            "chargeBearer",
            "chargesInformation",
            "debtor",
            "debtorAccount",
            "debtorAgent",
            "creditorAgent",
            "creditor",
            "creditorAccount",
            "purpose",
            "remittanceInformation"
    })
    public static class CreditTransferTransaction {
        /** Payment identifiers including instruction, end-to-end, and transaction IDs. */
        @JacksonXmlProperty(localName = "PmtId")
        public PaymentIdentification paymentIdentification;

        /** Payment type information such as account verification option and category purpose. */
        @JacksonXmlProperty(localName = "PmtTpInf")
        public PaymentTypeInformation paymentTypeInformation;

        /** Amount settled between debtor and creditor agents. */
        @JacksonXmlProperty(localName = "IntrBkSttlmAmt")
        public CurrencyAmount interbankSettlementAmount;

        /** Interbank settlement date assigned for the FPS payment. */
        @JacksonXmlProperty(localName = "IntrBkSttlmDt")
        public String interbankSettlementDate;

        /** Charge bearer code specifying which party bears charges. */
        @JacksonXmlProperty(localName = "ChrgBr")
        public String chargeBearer;

        /** Charges to be paid by the charge bearer. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "ChrgsInf")
        public ChargesInformation chargesInformation;

        /** Debtor end-customer information. */
        @JacksonXmlProperty(localName = "Dbtr")
        public Party debtor;

        /** Debtor account identification. */
        @JacksonXmlProperty(localName = "DbtrAcct")
        public Account debtorAccount;

        /** Debtor participant agent information. */
        @JacksonXmlProperty(localName = "DbtrAgt")
        public Agent debtorAgent;

        /** Creditor participant agent information. */
        @JacksonXmlProperty(localName = "CdtrAgt")
        public Agent creditorAgent;

        /** Creditor end-customer information. */
        @JacksonXmlProperty(localName = "Cdtr")
        public Party creditor;

        /** Creditor account or proxy identification. */
        @JacksonXmlProperty(localName = "CdtrAcct")
        public Account creditorAccount;

        /** Payment purpose, either ISO code or proprietary value. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "Purp")
        public Purpose purpose;

        /** Remittance information supplied for matching or reconciliation. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "RmtInf")
        public RemittanceInformation remittanceInformation;

        public CreditTransferTransaction() {}
    }

    @JsonPropertyOrder({"instructionId", "endToEndId", "transactionId"})
    public static class PaymentIdentification {
        /** Optional point-to-point instruction identifier. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "InstrId")
        public String instructionId;

        /** End-to-end identifier assigned by the payer and passed unchanged. */
        @JacksonXmlProperty(localName = "EndToEndId")
        public String endToEndId;

        /** Transaction identifier assigned to unambiguously identify the payment. */
        @JacksonXmlProperty(localName = "TxId")
        public String transactionId;

        public PaymentIdentification() {}

        public PaymentIdentification(String instructionId, String endToEndId, String transactionId) {
            this.instructionId = instructionId;
            this.endToEndId = endToEndId;
            this.transactionId = transactionId;
        }
    }

    @JsonPropertyOrder({"localInstrument", "categoryPurpose"})
    public static class PaymentTypeInformation {
        /** Local instrument proprietary value, used for account verification option. */
        @JacksonXmlProperty(localName = "LclInstrm")
        public ProprietaryValue localInstrument;

        /** Category purpose proprietary value for the FPS payment. */
        @JacksonXmlProperty(localName = "CtgyPurp")
        public ProprietaryValue categoryPurpose;

        public PaymentTypeInformation() {}

        public PaymentTypeInformation(ProprietaryValue localInstrument, ProprietaryValue categoryPurpose) {
            this.localInstrument = localInstrument;
            this.categoryPurpose = categoryPurpose;
        }
    }

    @JsonPropertyOrder({"proprietary"})
    public static class ProprietaryValue {
        /** Proprietary code value for the containing element. */
        @JacksonXmlProperty(localName = "Prtry")
        public String proprietary;

        public ProprietaryValue() {}

        public ProprietaryValue(String proprietary) {
            this.proprietary = proprietary;
        }
    }

    @JsonPropertyOrder({"currency", "value"})
    public static class CurrencyAmount {
        /** ISO currency code carried as the amount currency attribute. */
        @JacksonXmlProperty(localName = "Ccy", isAttribute = true)
        public String currency;

        /** Decimal amount value for the containing amount element. */
        @JacksonXmlText
        public String value;

        public CurrencyAmount() {}

        public CurrencyAmount(String currency, String value) {
            this.currency = currency;
            this.value = value;
        }
    }

    @JsonPropertyOrder({"amount"})
    public static class ChargesInformation {
        /** Charge amount and currency. */
        @JacksonXmlProperty(localName = "Amt")
        public CurrencyAmount amount;

        public ChargesInformation() {}

        public ChargesInformation(CurrencyAmount amount) {
            this.amount = amount;
        }
    }

    @JsonPropertyOrder({"name", "identifications", "contactDetails"})
    public static class Party {
        /** End-customer name. */
        @JacksonXmlProperty(localName = "Nm")
        public String name;

        /** Organisation or private customer identifications. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlElementWrapper(useWrapping = false)
        @JacksonXmlProperty(localName = "Id")
        public List<PartyIdentification> identifications;

        /** Contact details such as mobile number or email address. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "CtctDtls")
        public ContactDetails contactDetails;

        public Party() {}

        public Party(String name, List<PartyIdentification> identifications, ContactDetails contactDetails) {
            this.name = name;
            this.identifications = identifications;
            this.contactDetails = contactDetails;
        }
    }

    @JsonPropertyOrder({"organisationId", "privateId"})
    public static class PartyIdentification {
        /** Organisation identification of the debtor or creditor. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "OrgId")
        public CustomerIdentification organisationId;

        /** Private-person identification of the debtor or creditor. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "PrvtId")
        public CustomerIdentification privateId;

        public PartyIdentification() {}

        public static PartyIdentification of(String category, String customerId, String type) {
            CustomerIdentification identification = new CustomerIdentification(
                    new OtherIdentification(customerId, new SchemeName(type)));
            PartyIdentification partyIdentification = new PartyIdentification();
            if ("ORG".equalsIgnoreCase(category)) {
                partyIdentification.organisationId = identification;
            } else {
                partyIdentification.privateId = identification;
            }
            return partyIdentification;
        }
    }

    @JsonPropertyOrder({"other"})
    public static class CustomerIdentification {
        /** Other identification value and scheme name. */
        @JacksonXmlProperty(localName = "Othr")
        public OtherIdentification other;

        public CustomerIdentification() {}

        public CustomerIdentification(OtherIdentification other) {
            this.other = other;
        }
    }

    @JsonPropertyOrder({"id", "schemeName"})
    public static class OtherIdentification {
        /** Identification value, such as account number, customer ID, or proxy ID. */
        @JacksonXmlProperty(localName = "Id")
        public String id;

        /** Scheme name describing the identification type. */
        @JacksonXmlProperty(localName = "SchmeNm")
        public SchemeName schemeName;

        public OtherIdentification() {}

        public OtherIdentification(String id, SchemeName schemeName) {
            this.id = id;
            this.schemeName = schemeName;
        }
    }

    @JsonPropertyOrder({"code", "proprietary"})
    public static class SchemeName {
        /** ISO or documented code value for the identification scheme. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "Cd")
        public String code;

        /** Proprietary value for the identification scheme, such as BBAN, SVID, or EMAL. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "Prtry")
        public String proprietary;

        public SchemeName() {}

        public SchemeName(String code) {
            this.code = code;
        }

        public static SchemeName proprietary(String proprietary) {
            SchemeName schemeName = new SchemeName();
            schemeName.proprietary = proprietary;
            return schemeName;
        }
    }

    @JsonPropertyOrder({"mobileNumber", "emailAddress"})
    public static class ContactDetails {
        /** Mobile number used for notification or party contact details. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "MobNb")
        public String mobileNumber;

        /** Email address used for notification or party contact details. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "EmailAdr")
        public String emailAddress;

        public ContactDetails() {}

        public ContactDetails(String mobileNumber, String emailAddress) {
            this.mobileNumber = mobileNumber;
            this.emailAddress = emailAddress;
        }
    }

    @JsonPropertyOrder({"id"})
    public static class Account {
        /** Account identification wrapper. */
        @JacksonXmlProperty(localName = "Id")
        public AccountId id;

        public Account() {}

        public Account(AccountId id) {
            this.id = id;
        }
    }

    @JsonPropertyOrder({"other"})
    public static class AccountId {
        /** Other account identification value and scheme. */
        @JacksonXmlProperty(localName = "Othr")
        public OtherIdentification other;

        public AccountId() {}

        public AccountId(OtherIdentification other) {
            this.other = other;
        }
    }

    @JsonPropertyOrder({"financialInstitutionId"})
    public static class Agent {
        /** Financial institution identification for the participant agent. */
        @JacksonXmlProperty(localName = "FinInstnId")
        public FinancialInstitutionId financialInstitutionId;

        public Agent() {}

        public Agent(FinancialInstitutionId financialInstitutionId) {
            this.financialInstitutionId = financialInstitutionId;
        }
    }

    @JsonPropertyOrder({"bicFi", "clearingSystemMemberId"})
    public static class FinancialInstitutionId {
        /** BIC of the participant financial institution. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "BICFI")
        public String bicFi;

        /** Clearing-system member identification for the participant. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "ClrSysMmbId")
        public ClearingSystemMemberId clearingSystemMemberId;

        public FinancialInstitutionId() {}

        public FinancialInstitutionId(String bicFi, ClearingSystemMemberId clearingSystemMemberId) {
            this.bicFi = bicFi;
            this.clearingSystemMemberId = clearingSystemMemberId;
        }
    }

    @JsonPropertyOrder({"memberId"})
    public static class ClearingSystemMemberId {
        /** Clearing code or member ID of the participant. */
        @JacksonXmlProperty(localName = "MmbId")
        public String memberId;

        public ClearingSystemMemberId() {}

        public ClearingSystemMemberId(String memberId) {
            this.memberId = memberId;
        }
    }

    @JsonPropertyOrder({"code", "proprietary"})
    public static class Purpose {
        /** ISO external purpose code. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "Cd")
        public String code;

        /** Proprietary purpose value when no ISO code is supplied. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "Prtry")
        public String proprietary;

        public Purpose() {}

        public static Purpose code(String code) {
            Purpose purpose = new Purpose();
            purpose.code = code;
            return purpose;
        }

        public static Purpose proprietary(String proprietary) {
            Purpose purpose = new Purpose();
            purpose.proprietary = proprietary;
            return purpose;
        }
    }

    @JsonPropertyOrder({"unstructured"})
    public static class RemittanceInformation {
        /** Unstructured remittance information supplied by the payer. */
        @JacksonXmlProperty(localName = "Ustrd")
        public String unstructured;

        public RemittanceInformation() {}

        public RemittanceInformation(String unstructured) {
            this.unstructured = unstructured;
        }
    }

    @JsonPropertyOrder({"interfaceElement", "processingPersistentInfo"})
    public static class Extn {
        /** EPH interface identifier block. */
        @JacksonXmlProperty(localName = "Interface")
        public InterfaceElement interfaceElement;

        /** BEA/EPH processing fields required by the I006 transfer. */
        @JacksonXmlProperty(localName = "ProcessingPersistentInfo")
        public ProcessingPersistentInfo processingPersistentInfo;

        public Extn() {}

        public Extn(InterfaceElement interfaceElement, ProcessingPersistentInfo processingPersistentInfo) {
            this.interfaceElement = interfaceElement;
            this.processingPersistentInfo = processingPersistentInfo;
        }
    }

    @JsonPropertyOrder({"id"})
    public static class InterfaceElement {
        /** Interface ID for I006, for example EPHI006. */
        @JacksonXmlProperty(localName = "ID")
        public String id;

        public InterfaceElement() {}

        public InterfaceElement(String id) {
            this.id = id;
        }
    }

    @JsonPropertyOrder({
            "officeId",
            "paymentSource",
            "invoiceNumber",
            "costCenterCode",
            "alnovaLimitCheckInd",
            "transactionType",
            "customerType",
            "vipInd",
            "creditSide",
            "debitSide",
            "feeCode",
            "operationDate"
    })
    public static class ProcessingPersistentInfo {
        /** BEA office ID associated with the payment. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "POffice")
        public String officeId;

        /** Payment source used by EPH to identify the originating source system. */
        @JacksonXmlProperty(localName = "PPmntSrc")
        public String paymentSource;

        /** Invoice number of the transaction when provided by the channel. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "InvoiceNum")
        public String invoiceNumber;

        /** BEA cost center code used by EPH processing. */
        @JacksonXmlProperty(localName = "CostCenterCode")
        public String costCenterCode;

        /** Indicator controlling whether ALNOVA limit checking is performed. */
        @JacksonXmlProperty(localName = "AlnovaLmtChkInd")
        public String alnovaLimitCheckInd;

        /** EPH transaction type, such as transfer to other bank. */
        @JacksonXmlProperty(localName = "TxTp")
        public String transactionType;

        /** Customer type, such as personal or corporate. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "CusTp")
        public String customerType;

        /** VIP indicator for the customer. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "VipInd")
        public String vipInd;

        /** Credit-side processing information. */
        @JacksonXmlProperty(localName = "CreditSide")
        public CreditSide creditSide;

        /** Debit-side processing information. */
        @JacksonXmlProperty(localName = "DebitSide")
        public DebitSide debitSide;

        /** Fee code used by EPH; documentation allows NOFEE for no fee. */
        @JacksonXmlProperty(localName = "FeeCd")
        public String feeCode;

        /** Operation date for EPH processing when supplied. */
        @JacksonXmlProperty(localName = "OperationDate")
        public String operationDate;

        public ProcessingPersistentInfo() {}
    }

    @JsonPropertyOrder({"creditMop", "internalAccount"})
    public static class CreditSide {
        /** Credit mode of payment; normally derived from I005 BankReceiveMode. */
        @JacksonXmlProperty(localName = "PCdtMop")
        public String creditMop;

        /** Credit-side internal account number when applicable. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "InternalAcc")
        public String internalAccount;

        public CreditSide() {}

        public CreditSide(String creditMop, String internalAccount) {
            this.creditMop = creditMop;
            this.internalAccount = internalAccount;
        }
    }

    @JsonPropertyOrder({"debitMop", "internalAccount", "cybInternalAccount", "cybExternalAccount", "productType"})
    public static class DebitSide {
        /** Debit mode of payment. */
        @JacksonXmlProperty(localName = "PDbtMop")
        public String debitMop;

        /** Debit-side internal account number when applicable. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "InternalAcc")
        public String internalAccount;

        /** Channel debit internal account number. */
        @JacksonXmlProperty(localName = "CybInternalAcc")
        public String cybInternalAccount;

        /** Channel debit external account number. */
        @JacksonXmlProperty(localName = "CybExternalAcc")
        public String cybExternalAccount;

        /** Debit-side product type or deposit account type. */
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JacksonXmlProperty(localName = "ProductTp")
        public String productType;

        public DebitSide() {}

        public DebitSide(String debitMop, String internalAccount, String cybInternalAccount,
                String cybExternalAccount, String productType) {
            this.debitMop = debitMop;
            this.internalAccount = internalAccount;
            this.cybInternalAccount = cybInternalAccount;
            this.cybExternalAccount = cybExternalAccount;
            this.productType = productType;
        }
    }
}
