package com.bea.payment.bulk.internal.eph.xml;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import java.util.List;

/**
 * EPH I037 transaction database status enquiry request XML DTO.
 */
@JacksonXmlRootElement(localName = "Document", namespace = EphI037RequestXml.NAMESPACE)
@JsonPropertyOrder({"txnDbSmryEnqReq"})
public class EphI037RequestXml {

    public static final String NAMESPACE = "http://www.bea.com/query_TransactionDBStatus_Req";

    /** I037 transaction database summary enquiry request body. */
    @JacksonXmlProperty(localName = "TxnDbSmryEnqReq")
    public TxnDbSmryEnqReq txnDbSmryEnqReq;

    public EphI037RequestXml() {}

    public EphI037RequestXml(TxnDbSmryEnqReq txnDbSmryEnqReq) {
        this.txnDbSmryEnqReq = txnDbSmryEnqReq;
    }

    @JsonPropertyOrder({"createDate", "paymentSource", "transactionIds", "interfaceElement"})
    public static class TxnDbSmryEnqReq {
        /** Request creation date time, formatted as yyyy-MM-dd HH:mm:ss. */
        @JacksonXmlProperty(localName = "CrtDt")
        public String createDate;

        /** Payment source, such as CYB, CCB, or MBK. */
        @JacksonXmlProperty(localName = "PymntSrc")
        public String paymentSource;

        /** Transaction ID list wrapper. */
        @JacksonXmlProperty(localName = "TxIds")
        public TxIds transactionIds;

        /** EPH interface identifier block. */
        @JacksonXmlProperty(localName = "Interface")
        public InterfaceElement interfaceElement;

        public TxnDbSmryEnqReq() {}

        public TxnDbSmryEnqReq(String createDate, String paymentSource,
                TxIds transactionIds, InterfaceElement interfaceElement) {
            this.createDate = createDate;
            this.paymentSource = paymentSource;
            this.transactionIds = transactionIds;
            this.interfaceElement = interfaceElement;
        }
    }

    @JsonPropertyOrder({"transactionIds"})
    public static class TxIds {
        /** IPE transaction IDs to query in one I037 request. */
        @JacksonXmlElementWrapper(useWrapping = false)
        @JacksonXmlProperty(localName = "TxId")
        public List<String> transactionIds;

        public TxIds() {}

        public TxIds(List<String> transactionIds) {
            this.transactionIds = transactionIds;
        }
    }

    @JsonPropertyOrder({"id"})
    public static class InterfaceElement {
        /** Interface ID for I037. */
        @JacksonXmlProperty(localName = "ID")
        public String id;

        public InterfaceElement() {}

        public InterfaceElement(String id) {
            this.id = id;
        }
    }
}
