package com.bea.payment.bulk.internal.eph.xml;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;

/**
 * EPH XML 序列化工具。
 *
 * <p>只负责把已经组好的 XML DTO 输出为报文文本，不承载字段来源和业务默认值。</p>
 */
public final class EphXmlSerializer {

    private static final XmlMapper XML_MAPPER = XmlMapper.builder()
            .configure(ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true)
            .build();

    private EphXmlSerializer() {}

    public static String serialize(Object message) {
        try {
            return XML_MAPPER.writeValueAsString(message)
                    .replace(" xmlns=\"\"", "");
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Failed to build EPH XML", e);
        }
    }
}
