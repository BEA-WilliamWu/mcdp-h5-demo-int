package com.bea.payment.bulk.internal.flow.cache;


import com.bea.payment.bulk.internal.flow.model.FlowRule;
import com.bea.payment.common.util.DateTimeUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Redis 版流控配置快照组件。
 *
 * <p>运行期流控规则以 Redis 为统一事实来源。本类不保存 JVM 本地快照；
 * 每次读取都会访问 Redis，快照缺失或不可读时由上层同步逻辑 fail-closed。</p>
 */
public class FlowControlConfigCache {

    public static final String RULE_SNAPSHOT_KEY = "flow:config:rules";
    private static final String SOURCE_DB = "DB";

    private final RedissonClient redisson;
    private final ObjectMapper objectMapper;

    /**
     * 注入 Redisson 和 Jackson。这里不创建本地集合缓存，避免多 Pod 之间出现配置漂移。
     */
    public FlowControlConfigCache(RedissonClient redisson, ObjectMapper objectMapper) {
        this.redisson = redisson;
        this.objectMapper = objectMapper;
    }

    /**
     * 用最新 DB 加载结果整体替换 Redis 规则快照。
     *
     * <p>采用单 key 整体 JSON 快照，避免按字段或按交易类型拆分后出现局部更新成功、
     * 局部更新失败的中间状态。写入失败直接抛出，由 Loader 记录错误并保留 Redis
     * 中最后一次成功快照。</p>
     */
    public void replaceAll(Map<String, List<FlowRule>> newSnapshot) {
        List<StoredFlowRule> rules = new ArrayList<>();
        if (newSnapshot != null) {
            for (List<FlowRule> group : newSnapshot.values()) {
                if (group == null) {
                    continue;
                }
                for (FlowRule rule : group) {
                    rules.add(StoredFlowRule.from(rule));
                }
            }
        }
        // 固定排序让 Redis 中的 JSON 内容稳定，便于排障比对，也避免不同 JVM Map 顺序造成噪音。
        rules.sort(Comparator
                .comparing(StoredFlowRule::txType, Comparator.nullsLast(String::compareTo))
                .thenComparing(StoredFlowRule::priority, Comparator.nullsLast(Integer::compareTo))
                .thenComparing(StoredFlowRule::profileId, Comparator.nullsLast(Long::compareTo)));

        RuleSnapshot snapshot = new RuleSnapshot(
                Instant.now().toString(),
                SOURCE_DB,
                rules.size(),
                rules
        );
        try {
            // Redisson bucket 的一次 set 是整份快照替换；读侧要么看到旧快照，要么看到新快照。
            bucket().set(objectMapper.writeValueAsString(snapshot));
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Unable to serialize flow control Redis rule snapshot", ex);
        }
    }

    /**
     * 从 Redis 规则快照中读取指定交易类型的规则。
     *
     * <p>该方法刻意不使用 JVM 缓存。Redis 不可用、快照缺失或 JSON 损坏会抛出异常，
     * 由 `RatePolicySync` 转为 disabled policy，确保不会因配置不可读而放行下游。</p>
     */
    public List<FlowRule> getRulesByTxType(String txType) {
        RuleSnapshot snapshot = readSnapshot();
        return snapshot.rules().stream()
                .filter(rule -> txType != null && txType.equals(rule.txType()))
                .map(StoredFlowRule::toFlowRule)
                .sorted(Comparator.comparing(FlowRule::getPriority))
                .toList();
    }

    /**
     * 返回 Redis 快照中包含的交易类型数量，主要用于监控或临时诊断。
     */
    public int size() {
        return (int) readSnapshot().rules().stream()
                .map(StoredFlowRule::txType)
                .distinct()
                .count();
    }

    /**
     * 读取并校验 Redis 快照。
     *
     * <p>这里不把异常吞掉或返回空列表，因为空列表代表“确实没有规则”，而快照缺失
     * 代表配置同步链路不可用；两者都 fail-closed，但日志和策略原因需要区分。</p>
     */
    private RuleSnapshot readSnapshot() {
        String value = bucket().get();
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Flow control Redis rule snapshot is missing: key="
                    + RULE_SNAPSHOT_KEY);
        }
        try {
            RuleSnapshot snapshot = objectMapper.readValue(value, RuleSnapshot.class);
            if (snapshot.rules() == null) {
                throw new IllegalStateException("Flow control Redis rule snapshot has no rules list: key="
                        + RULE_SNAPSHOT_KEY);
            }
            return snapshot;
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Unable to read flow control Redis rule snapshot: key="
                    + RULE_SNAPSHOT_KEY, ex);
        }
    }

    /**
     * 获取保存规则快照的 Redis bucket。
     */
    private RBucket<String> bucket() {
        return redisson.getBucket(RULE_SNAPSHOT_KEY);
    }

    /**
     * Redis 中保存的整份规则快照。
     *
     * @param loadedAt 快照写入时间，便于排查配置滞后
     * @param source   来源标识，当前固定为 DB
     * @param ruleCount 规则数量，便于快速观察快照大小
     * @param rules    具体规则列表
     */
    private record RuleSnapshot(
            String loadedAt,
            String source,
            int ruleCount,
            List<StoredFlowRule> rules
    ) {
    }

    /**
     * Redis 存储用规则 DTO。
     *
     * <p>用字符串保存星期和时间，避免直接依赖 Jackson 对 `DayOfWeek`、`LocalTime`
     * 的序列化细节；读出时再转换回 `FlowRule` 供匹配逻辑使用。</p>
     */
    private record StoredFlowRule(
            Long profileId,
            String txType,
            List<String> applicableDays,
            String startTime,
            String endTime,
            Integer priority,
            Map<String, String> params
    ) {

        /**
         * 将运行期 `FlowRule` 转成 Redis 友好的存储结构。
         */
        private static StoredFlowRule from(FlowRule rule) {
            List<String> days = rule.getApplicableDays() == null
                    ? List.of()
                    : rule.getApplicableDays().stream()
                            .map(DayOfWeek::name)
                            .sorted()
                            .toList();
            return new StoredFlowRule(
                    rule.getProfileId(),
                    rule.getTxType(),
                    days,
                    rule.getStartTime() == null ? null : rule.getStartTime().toString(),
                    rule.getEndTime() == null ? null : rule.getEndTime().toString(),
                    rule.getPriority(),
                    rule.getParams()
            );
        }

        /**
         * 将 Redis 存储结构还原成同步器使用的 `FlowRule`。
         */
        private FlowRule toFlowRule() {
            FlowRule rule = new FlowRule();
            rule.setProfileId(profileId);
            rule.setTxType(txType);
            rule.setApplicableDays(parseDays(applicableDays));
            rule.setStartTime(LocalTime.parse(startTime));
            rule.setEndTime(LocalTime.parse(endTime));
            rule.setPriority(priority);
            rule.setParams(params);
            return rule;
        }

        /**
         * 解析星期配置。非法星期会抛出异常，由上层按配置快照不可用处理并 fail-closed。
         */
        private Set<DayOfWeek> parseDays(List<String> days) {
            Set<DayOfWeek> result = EnumSet.noneOf(DayOfWeek.class);
            if (days == null) {
                return result;
            }
            for (String day : days) {
                result.add(DateTimeUtils.parseDayOfWeek(day));
            }
            return result;
        }
    }
}
