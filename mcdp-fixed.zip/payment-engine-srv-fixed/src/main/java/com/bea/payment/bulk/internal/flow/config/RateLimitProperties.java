package com.bea.payment.bulk.internal.flow.config;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

/**
 * 限流相关配置属性。
 */
@Component
@ConfigurationProperties(prefix = "pe.flow.rate-limit")
@Getter
@Setter
public class RateLimitProperties {

    /**
     * 支持的交易类型列表（用于限流校验）。
     */
    private List<String> supportedTxTypes = List.of("INTERNAL", "FPS");

    /**
     * 获取支持的交易类型集合（大写形式）。
     */
    public Set<String> getSupportedTxTypeSet() {
        return Set.copyOf(supportedTxTypes);
    }
}
