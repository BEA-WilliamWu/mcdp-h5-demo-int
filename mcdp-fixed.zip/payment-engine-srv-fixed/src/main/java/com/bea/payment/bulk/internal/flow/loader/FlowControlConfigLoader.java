package com.bea.payment.bulk.internal.flow.loader;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bea.payment.bulk.internal.flow.cache.FlowControlConfigCache;
import com.bea.payment.bulk.internal.flow.model.FlowRule;
import com.bea.payment.bulk.mapper.FlowControlParamMapper;
import com.bea.payment.bulk.mapper.FlowControlProfileMapper;
import com.bea.payment.bulk.model.entity.FlowControlParamEntity;
import com.bea.payment.bulk.model.entity.FlowControlProfileEntity;
import com.bea.payment.common.util.DateTimeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 流控配置加载器。
 *
 * <p>职责是把 Oracle 中的 ACTIVE profile/param 转换成运行期规则快照，
 * 并写入 Redis `flow:config:rules`。本类不保留 JVM 本地缓存。</p>
 */
@Component
public class FlowControlConfigLoader {

    private static final Logger log =
            LoggerFactory.getLogger(FlowControlConfigLoader.class);

    private final FlowControlProfileMapper profileMapper;
    private final FlowControlParamMapper paramMapper;
    private final FlowControlConfigCache cache;

    public FlowControlConfigLoader(
            FlowControlProfileMapper profileMapper,
            FlowControlParamMapper paramMapper,
            FlowControlConfigCache cache
    ) {
        this.profileMapper = profileMapper;
        this.paramMapper = paramMapper;
        this.cache = cache;
    }

    /**
     * 定时从 DB 加载配置并整体写入 Redis。
     *
     * <p>使用 fixedDelay，避免同一 Pod 内部并发执行。多 Pod 同时写入时，由于写入内容
     * 均来自 DB 的完整快照，最终 Redis 仍会收敛到某一次完整加载结果。</p>
     */
    @Scheduled(fixedDelay = 60_000)
    public void load() {
        try {
            log.debug("Start loading flow control configuration");

            // 没有 ACTIVE profile 也是一个明确配置状态：写入空快照，后续同步器会 fail-closed。
            List<FlowControlProfileEntity> profiles = loadProfiles();
            if (profiles.isEmpty()) {
                log.warn("No active flow control profile found, writing empty Redis rule snapshot");
                cache.replaceAll(Collections.emptyMap());
                return;
            }

            Map<Long, Map<String, String>> paramMap =
                    loadParams(profiles);

            Map<String, List<FlowRule>> snapshot =
                    buildSnapshot(profiles, paramMap);

            cache.replaceAll(snapshot);

            log.debug(
                    "Flow control configuration loaded successfully to Redis, ruleGroupSize={}",
                    snapshot.size()
            );

        } catch (Exception ex) {
            log.error("Failed to load flow control configuration into Redis", ex);
            // 不写 JVM fallback；Redis 中最后一次成功快照仍是运行期统一读取来源。
        }
    }

    /**
     * 查询所有当前启用且未删除的流控 profile。
     */
    private List<FlowControlProfileEntity> loadProfiles() {
        LambdaQueryWrapper<FlowControlProfileEntity> wrapper =
                new LambdaQueryWrapper<>();

        wrapper.eq(FlowControlProfileEntity::getStatus, "ACTIVE")
               .eq(FlowControlProfileEntity::getIsDeleted, "N");

        return profileMapper.selectList(wrapper);
    }

    /**
     * 查询并合并 profile 参数。
     *
     * <p>同一 `PROFILE_ID + PARAM_KEY` 可能存在多条版本记录，运行期只取
     * `OBJECT_VERSION_NUMBER` 最大的一条，保持与管理端查询展示口径一致。</p>
     */
    private Map<Long, Map<String, String>> loadParams(List<FlowControlProfileEntity> profiles) {

        if (profiles == null || profiles.isEmpty()) {
            return Collections.emptyMap();
        }

        List<Long> profileIds = profiles.stream()
                .map(FlowControlProfileEntity::getProfileId)
                .collect(Collectors.toList());

        List<FlowControlParamEntity> paramList =
                paramMapper.selectList(
                        new LambdaQueryWrapper<FlowControlParamEntity>()
                                .in(FlowControlParamEntity::getProfileId, profileIds)
                                .eq(FlowControlParamEntity::getStatus, "ACTIVE")
                                .eq(FlowControlParamEntity::getIsDeleted, "N")
                );

        // 第一层：按 PROFILE_ID 分组
        Map<Long, List<FlowControlParamEntity>> paramsByProfile =
                paramList.stream()
                        .collect(Collectors.groupingBy(
                                FlowControlParamEntity::getProfileId
                        ));

        Map<Long, Map<String, String>> result = new HashMap<>();

        for (Map.Entry<Long, List<FlowControlParamEntity>> profileEntry
                : paramsByProfile.entrySet()) {

            Long profileId = profileEntry.getKey();
            List<FlowControlParamEntity> params = profileEntry.getValue();

            // 第二层：同一 Profile 内，按 PARAM_KEY 合并
            Map<String, FlowControlParamEntity> latestParamByKey =
                    new HashMap<>();

            for (FlowControlParamEntity param : params) {
                String paramKey = param.getParamKey();
                FlowControlParamEntity existing =
                        latestParamByKey.get(paramKey);

                if (existing == null) {
                    latestParamByKey.put(paramKey, param);
                    continue;
                }

                long existingVersion =
                        Optional.ofNullable(
                                existing.getObjectVersionNumber()
                        ).orElse(0L);

                long currentVersion =
                        Optional.ofNullable(
                                param.getObjectVersionNumber()
                        ).orElse(0L);

                if (currentVersion > existingVersion) {
                    latestParamByKey.put(paramKey, param);
                }
            }

            // 第三层：转换为最终的 key-value 参数 Map
            Map<String, String> paramValueMap = new HashMap<>();
            for (FlowControlParamEntity latestParam
                    : latestParamByKey.values()) {
                paramValueMap.put(
                        latestParam.getParamKey(),
                        latestParam.getParamValue()
                );
            }

            result.put(profileId, paramValueMap);
        }

        return result;
    }

    /**
     * 将 DB profile 和参数 Map 组装成按交易类型分组的规则快照。
     *
     * <p>组装阶段只做结构转换和 priority 排序，不判断当前时间窗口；
     * 时间窗口命中由 `RatePolicySync` 在同步时按当前时钟执行。</p>
     */
    private Map<String, List<FlowRule>> buildSnapshot(
            List<FlowControlProfileEntity> profiles,
            Map<Long, Map<String, String>> paramMap
    ) {
        Map<String, List<FlowRule>> grouped =
                new HashMap<>();

        for (FlowControlProfileEntity p : profiles) {

            FlowRule rule = new FlowRule();
            rule.setProfileId(p.getProfileId());
            rule.setTxType(p.getTxType());
            rule.setApplicableDays(parseDays(p.getApplicableDays()));
            rule.setStartTime(LocalTime.parse(p.getStartTime()));
            rule.setEndTime(LocalTime.parse(p.getEndTime()));
            rule.setPriority(p.getPriority());
            rule.setParams(
                    paramMap.getOrDefault(
                            p.getProfileId(),
                            Collections.emptyMap()
                    )
            );

            grouped
                    .computeIfAbsent(p.getTxType(), k -> new ArrayList<>())
                    .add(rule);
        }

        // 按 priority 排序
        for (List<FlowRule> rules : grouped.values()) {
            rules.sort(Comparator.comparing(FlowRule::getPriority));
        }

        return grouped;
    }

    /**
     * 解析 profile 上配置的适用星期。
     */
    private Set<DayOfWeek> parseDays(String days) {
        String[] parts = days.split(",");
        Set<DayOfWeek> result = EnumSet.noneOf(DayOfWeek.class);
        for (String p : parts) {
            result.add(DateTimeUtils.parseDayOfWeek(p));
        }
        return result;
    }
}
