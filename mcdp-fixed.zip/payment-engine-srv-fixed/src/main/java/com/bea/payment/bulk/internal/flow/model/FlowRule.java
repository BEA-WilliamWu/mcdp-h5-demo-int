package com.bea.payment.bulk.internal.flow.model;

import lombok.Getter;
import lombok.Setter;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Map;
import java.util.Set;

/**
 * FlowRule
 *
 * 流控规则运行期模型。
 * 由 DB Profile + Param 在加载阶段转换而来，并通过 Redis 规则快照供同步器读取。
 *
 * 读取后按单次同步流程使用，不作为 JVM 本地缓存事实来源。
 */
@Getter
@Setter
public class FlowRule {

    private Long profileId;
    private String txType;

    private Set<DayOfWeek> applicableDays;
    private LocalTime startTime;
    private LocalTime endTime;

    private Integer priority;

    private Map<String, String> params;

    public FlowRule() {
    }

    /* ========= Getter / Setter ========= */

    /* ========= Helper ========= */

    /**
     * 判断当前时间是否命中该规则。
     */
    public boolean match(DayOfWeek dayOfWeek, LocalTime time) {
        if (!applicableDays.contains(dayOfWeek)) {
            return false;
        }
        return !time.isBefore(startTime) && time.isBefore(endTime);
    }
}
