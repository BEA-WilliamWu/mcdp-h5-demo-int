package com.bea.payment.bulk.internal.flow.mq;

import jakarta.jms.Message;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 一条已接收但尚未最终处理的 IBM MQ 消息。
 *
 * <p>该对象只暴露两种完成语义：{@link #ack()} 表示确认消息，{@link #close()}
 * 表示本地拒收并触发 JMS recover，让 IBM MQ 按重投和 BOQNAME 规则处理。</p>
 */
public class MqInboundDelivery implements AutoCloseable {

    private final String queueName;
    private final String messageId;
    private final String correlationId;
    private final MqMessage message;
    private final Message jmsMessage;
    private final DeliveryHandle deliveryHandle;
    private final AtomicBoolean completed = new AtomicBoolean(false);

    MqInboundDelivery(String queueName,
            String messageId,
            String correlationId,
            MqMessage message,
            Message jmsMessage,
            DeliveryHandle deliveryHandle) {
        this.queueName = Objects.requireNonNull(queueName, "queueName must not be null");
        this.messageId = messageId;
        this.correlationId = correlationId;
        this.message = Objects.requireNonNull(message, "message must not be null");
        this.jmsMessage = Objects.requireNonNull(jmsMessage, "jmsMessage must not be null");
        this.deliveryHandle = Objects.requireNonNull(deliveryHandle, "deliveryHandle must not be null");
    }

    public String getQueueName() {
        return queueName;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public MqMessage getMessage() {
        return message;
    }

    /**
     * 当前 delivery 是否已经通过 ACK 或 recover 完成。
     */
    public boolean isCompleted() {
        return completed.get();
    }

    /**
     * 显式 ACK IBM MQ 消息。
     *
     * <p>只能调用一次。ACK 成功后，底层队列消费者资源会继续保留给下一次轮询复用。</p>
     */
    public void ack() {
        if (!completed.compareAndSet(false, true)) {
            throw new IllegalStateException("IBM MQ delivery has already been completed: messageId=" + messageId);
        }
        deliveryHandle.acknowledge(jmsMessage, messageId);
    }

    /**
     * 不 ACK 当前消息，并显式触发 JMS recover。
     *
     * <p>该方法用于 Worker 本地门禁失败、限流失败、账户锁失败等 fail-closed 场景。
     * 调用后 MQ 可以进行重投；达到队列配置的 backout 阈值后由 MQ 移到 BOQNAME。</p>
     */
    @Override
    public void close() {
        if (completed.compareAndSet(false, true)) {
            deliveryHandle.recover(messageId);
        }
    }

    interface DeliveryHandle {

        void acknowledge(Message jmsMessage, String messageId);

        void recover(String messageId);
    }
}
