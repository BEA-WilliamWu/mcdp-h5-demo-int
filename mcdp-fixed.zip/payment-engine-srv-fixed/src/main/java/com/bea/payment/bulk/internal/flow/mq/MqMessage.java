package com.bea.payment.bulk.internal.flow.mq;

import lombok.Getter;
import lombok.Setter;

import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;

import java.math.BigDecimal;

/**
 * MQ 消息体，只传路由、幂等、账号锁所需字段。
 * Worker 使用 transactionId 查询 DB，获取完整交易数据后调用下游。
 */
@Getter
@Setter
public class MqMessage {

    private String batchId;
    private String transactionId;
    private Integer orderId;
    private String channel;
    private String transactionType;
    private String payerAccountNo;
    private BigDecimal debitAmount;
    private String debitAmountCcy;

    public MqMessage() {}

    /**
     * 从数据库实体构造 MQ 消息。
     *
     * <p>只拷贝路由、幂等、账号锁所需的核心字段，不包含审计字段。</p>
     */
    public static MqMessage from(PaymentTxnMainEntity txn) {
        MqMessage message = new MqMessage();
        message.setBatchId(txn.getBatchId());
        message.setTransactionId(txn.getTransactionId());
        message.setOrderId(txn.getOrderId());
        message.setChannel(txn.getChannel());
        message.setTransactionType(txn.getTransactionType());
        message.setPayerAccountNo(txn.getPayerAccountNo());
        message.setDebitAmount(txn.getDebitAmount());
        message.setDebitAmountCcy(txn.getDebitAmountCcy());
        return message;
    }

}
