package com.bea.payment.bulk.internal.flow.mq;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * IBM MQ 适配器基础指标。
 *
 * <p>指标标签只使用低基数字段，不把 transactionId、batchId、账号等敏感或高基数字段写入标签。</p>
 */
@Component
@ConditionalOnProperty(prefix = "pe.flow.mq", name = "enabled", havingValue = "true")
public class MqMetrics {

    public static final String RESULT_SUCCESS = "SUCCESS";
    public static final String RESULT_FAILED = "FAILED";
    public static final String RESULT_EMPTY = "EMPTY";

    public static final String ERROR_NONE = "NONE";
    public static final String ERROR_CONFIG = "CONFIG";
    public static final String ERROR_CONNECTION = "CONNECTION";
    public static final String ERROR_DESERIALIZATION = "DESERIALIZATION";
    public static final String ERROR_MESSAGE_FORMAT = "MESSAGE_FORMAT";
    public static final String ERROR_TECHNICAL = "TECHNICAL";

    public static final String WORKER_REASON_ROUTE_MISMATCH = "ROUTE_MISMATCH";
    public static final String WORKER_REASON_TRANSACTION_NOT_QUEUED = "TRANSACTION_NOT_QUEUED";
    public static final String WORKER_REASON_PROCESSING_REDELIVERY = "PROCESSING_REDELIVERY";
    public static final String WORKER_REASON_DB_MESSAGE_MISMATCH = "DB_MESSAGE_MISMATCH";
    public static final String WORKER_REASON_RATE_LIMITED = "RATE_LIMITED";
    public static final String WORKER_REASON_RATE_LIMITER_ERROR = "RATE_LIMITER_ERROR";
    public static final String WORKER_REASON_ACCOUNT_LOCKED = "ACCOUNT_LOCKED";
    public static final String WORKER_REASON_ACCOUNT_LOCK_ERROR = "ACCOUNT_LOCK_ERROR";
    public static final String WORKER_REASON_MARK_PROCESSING_CONFLICT = "MARK_PROCESSING_CONFLICT";
    public static final String WORKER_REASON_DOWNSTREAM_COMPLETED = "DOWNSTREAM_COMPLETED";
    public static final String WORKER_REASON_EXCEPTION = "EXCEPTION";

    private static final String UNKNOWN = "UNKNOWN";

    private final MeterRegistry registry;

    public MqMetrics(MeterRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry must not be null");
    }

    public void recordProducerSend(String queueName, String result, String errorType, Duration duration) {
        String safeQueueName = safeTag(queueName);
        String safeResult = safeTag(result);
        Counter.builder("pe_mq_producer_send_total")
                .tag("queueName", safeQueueName)
                .tag("result", safeResult)
                .tag("errorType", safeTag(errorType))
                .register(registry)
                .increment();
        Timer.builder("pe_mq_producer_send_duration_ms")
                .tag("queueName", safeQueueName)
                .tag("result", safeResult)
                .register(registry)
                .record(nonNegative(duration).toNanos(), TimeUnit.NANOSECONDS);
    }

    public void recordProducerSerializationFailure(String queueName, String errorCode) {
        Counter.builder("pe_mq_producer_serialization_failed_total")
                .tag("queueName", safeTag(queueName))
                .tag("errorCode", safeTag(errorCode))
                .register(registry)
                .increment();
    }

    public void recordConsumerReceive(String queueName, String result, String errorType, Duration duration) {
        String safeQueueName = safeTag(queueName);
        String safeResult = safeTag(result);
        Counter.builder("pe_mq_consumer_received_total")
                .tag("queueName", safeQueueName)
                .tag("result", safeResult)
                .tag("errorType", safeTag(errorType))
                .register(registry)
                .increment();
        Timer.builder("pe_mq_consumer_receive_duration_ms")
                .tag("queueName", safeQueueName)
                .tag("result", safeResult)
                .register(registry)
                .record(nonNegative(duration).toNanos(), TimeUnit.NANOSECONDS);
    }

    public void recordConsumerAck(String queueName, String result) {
        Counter.builder("pe_mq_consumer_ack_total")
                .tag("queueName", safeTag(queueName))
                .tag("result", safeTag(result))
                .register(registry)
                .increment();
    }

    public void recordWorkerDecision(String txType, String queueName, String result, String reason) {
        Counter.builder("pe_mq_worker_decision_total")
                .tag("txType", safeTag(txType))
                .tag("queueName", safeTag(queueName))
                .tag("result", safeTag(result))
                .tag("reason", safeTag(reason))
                .register(registry)
                .increment();
    }

    private Duration nonNegative(Duration duration) {
        if (duration == null || duration.isNegative()) {
            return Duration.ZERO;
        }
        return duration;
    }

    private String safeTag(String value) {
        return value == null || value.isBlank() ? UNKNOWN : value;
    }
}
