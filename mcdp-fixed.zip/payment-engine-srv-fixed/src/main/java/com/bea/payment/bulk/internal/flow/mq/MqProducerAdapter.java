package com.bea.payment.bulk.internal.flow.mq;

import com.bea.payment.common.exception.SystemException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Objects;
import java.util.Set;

/**
 * 基于 Spring JMS 的 IBM MQ 生产者。
 *
 * <p>本类只负责 MQ transport 发送。Scanner 仍负责投递顺序、数据库状态更新和指针推进。</p>
 */
@Service
@ConditionalOnProperty(prefix = "pe.flow.mq", name = "enabled", havingValue = "true")
public class MqProducerAdapter implements MqProducerService {

    private static final Logger log = LoggerFactory.getLogger(MqProducerAdapter.class);

    private final JmsTemplate jmsTemplate;
    private final ObjectMapper objectMapper;
    private final MqQueueProperties queueProperties;
    private final MqProperties mqProperties;
    private final MqMetrics metrics;

    public MqProducerAdapter(JmsTemplate jmsTemplate,
            ObjectMapper objectMapper,
            MqQueueProperties queueProperties,
            MqProperties mqProperties,
            MqMetrics metrics) {
        this.jmsTemplate = Objects.requireNonNull(jmsTemplate, "jmsTemplate must not be null");
        this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper must not be null");
        this.queueProperties = Objects.requireNonNull(queueProperties, "queueProperties must not be null");
        this.mqProperties = Objects.requireNonNull(mqProperties, "mqProperties must not be null");
        this.metrics = Objects.requireNonNull(metrics, "metrics must not be null");
    }

    @Override
    public void send(String queueName, MqMessage message) {
        validateQueueName(queueName);
        try {
            validateMessage(message);
        } catch (RuntimeException ex) {
            metrics.recordProducerSend(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONFIG,
                    Duration.ZERO);
            throw ex;
        }

        String transactionId = message.getTransactionId();
        String payload = serialize(queueName, message);
        long startNanos = System.nanoTime();
        try {
            log.info("[IBM-MQ-PRODUCER] Sending message: queueName={}, transactionId={}, batchId={}, txType={}",
                    queueName, transactionId, message.getBatchId(), message.getTransactionType());
            jmsTemplate.convertAndSend(queueName, payload, jmsMessage -> applyMetadata(jmsMessage, message));
            metrics.recordProducerSend(queueName, MqMetrics.RESULT_SUCCESS, MqMetrics.ERROR_NONE,
                    elapsedSince(startNanos));
        } catch (JmsException ex) {
            metrics.recordProducerSend(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONNECTION,
                    elapsedSince(startNanos));
            log.error("[IBM-MQ-PRODUCER] Send failed: queueName={}, transactionId={}",
                    queueName, transactionId, ex);
            throw new SystemException("Failed to send IBM MQ message: queueName=" + queueName
                    + ", transactionId=" + transactionId, ex);
        }
    }

    private String serialize(String queueName, MqMessage message) {
        try {
            return objectMapper.writeValueAsString(message);
        } catch (JsonProcessingException ex) {
            metrics.recordProducerSerializationFailure(queueName, "SERIALIZATION");
            throw new SystemException("Failed to serialize IBM MQ message: transactionId="
                    + message.getTransactionId(), ex);
        }
    }

    private Message applyMetadata(Message jmsMessage, MqMessage message) throws JMSException {
        jmsMessage.setJMSCorrelationID(message.getTransactionId());
        jmsMessage.setStringProperty("batchId", message.getBatchId());
        jmsMessage.setStringProperty("transactionId", message.getTransactionId());
        jmsMessage.setStringProperty("transactionType", message.getTransactionType());
        jmsMessage.setStringProperty("channel", message.getChannel());
        jmsMessage.setIntProperty("orderId", message.getOrderId());
        jmsMessage.setStringProperty("source", mqProperties.getSource());
        return jmsMessage;
    }

    private void validateQueueName(String queueName) {
        if (queueName == null || queueName.isBlank()) {
            metrics.recordProducerSend(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONFIG,
                    Duration.ZERO);
            throw new IllegalArgumentException("queueName must not be blank");
        }
        if (!mqProperties.isValidateQueueName()) {
            return;
        }
        Set<String> allowedQueues = queueProperties.getAllowedQueuesSet();
        if (!allowedQueues.contains(queueName)) {
            metrics.recordProducerSend(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONFIG,
                    Duration.ZERO);
            throw new IllegalArgumentException("Invalid IBM MQ queueName: " + queueName);
        }
    }

    private void validateMessage(MqMessage message) {
        Objects.requireNonNull(message, "message must not be null");
        requireText(message.getBatchId(), "message.batchId");
        requireText(message.getTransactionId(), "message.transactionId");
        requireText(message.getTransactionType(), "message.transactionType");
        requireText(message.getChannel(), "message.channel");
        Objects.requireNonNull(message.getOrderId(), "message.orderId must not be null");
    }

    private void requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
    }

    private Duration elapsedSince(long startNanos) {
        return Duration.ofNanos(System.nanoTime() - startNanos);
    }
}
