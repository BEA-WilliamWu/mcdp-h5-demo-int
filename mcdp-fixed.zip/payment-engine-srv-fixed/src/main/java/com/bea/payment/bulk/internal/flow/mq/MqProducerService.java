package com.bea.payment.bulk.internal.flow.mq;

/**
 * Scanner 使用的 MQ 生产者端口。
 *
 * <p>当前生产实现是基于 IBM MQ/JMS 的 {@link MqProducerAdapter}。
 * 测试中仍可以为该端口提供 mock。</p>
 */
public interface MqProducerService {

    /**
     * 发送一条支付消息到指定 IBM MQ 队列。
     *
     * @param queueName 目标队列名，例如 {@code IPE.PAYMENT.FPS.ONLINE}
     * @param message 消息体
     */
    void send(String queueName, MqMessage message);
}
