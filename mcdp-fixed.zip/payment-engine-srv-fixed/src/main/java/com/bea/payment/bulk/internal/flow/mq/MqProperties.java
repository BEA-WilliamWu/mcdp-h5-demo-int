package com.bea.payment.bulk.internal.flow.mq;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Payment Engine 自有的 MQ 适配器开关。
 *
 * <p>连接参数仍由 IBM MQ starter 的 {@code ibm.mq.*} 命名空间读取。
 * 本类只控制本服务是否发送、接收以及是否运行 Worker 轮询。</p>
 */
@Component
@ConfigurationProperties(prefix = "pe.flow.mq")
@Getter
@Setter
public class MqProperties {

    /**
     * 本地默认关闭，避免应用启动时误连真实 MQ。
     */
    private boolean enabled = false;

    /**
     * 写入 JMS 消息属性的生产方标识。
     */
    private String source = "payment-engine-srv";

    /**
     * 目标队列是否必须存在于 {@code pe.flow.mq.queues.allowed} 白名单中。
     */
    private boolean validateQueueName = true;

    private Consumer consumer = new Consumer();

    private Worker worker = new Worker();

    @Getter
    @Setter
    public static class Consumer {

        /**
         * 默认关闭，避免 UAT 行为确认前误消费真实 MQ。
         */
        private boolean enabled = false;

        /**
         * 单次 receive 的短超时时间，用于 ONLINE 优先、NORMAL 后查的轮询策略。
         */
        private Duration receiveTimeout = Duration.ofMillis(500);
    }

    @Getter
    @Setter
    public static class Worker {

        /**
         * 默认关闭，直到 UAT 与运维恢复规则确认后再打开。
         */
        private boolean enabled = false;

        /**
         * 控制默认处理器是否调用真实 BG3/EPH handler。
         */
        private boolean realProcessorEnabled = false;

        /**
         * 获取限流令牌的最大等待时间。默认不等待。
         */
        private Duration permitWait = Duration.ZERO;
    }
}
