package com.bea.payment.bulk.internal.flow.mq;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

/**
 * Payment Engine 流控模块维护的 MQ 队列名配置。
 */
@Component
@ConfigurationProperties(prefix = "pe.flow.mq.queues")
@Getter
@Setter
public class MqQueueProperties {

    private static final String INTERNAL_ONLINE_QUEUE = "IPE.PAYMENT.INTERNAL.ONLINE";
    private static final String INTERNAL_NORMAL_QUEUE = "IPE.PAYMENT.INTERNAL.NORMAL";
    private static final String FPS_ONLINE_QUEUE = "IPE.PAYMENT.FPS.ONLINE";
    private static final String FPS_NORMAL_QUEUE = "IPE.PAYMENT.FPS.NORMAL";
    private static final String CHATS_ONLINE_QUEUE = "IPE.PAYMENT.CHATS.ONLINE";
    private static final String CHATS_NORMAL_QUEUE = "IPE.PAYMENT.CHATS.NORMAL";

    /**
     * IBM MQ 适配器发送或接收前使用的队列白名单。
     */
    private List<String> allowed = List.of(
            INTERNAL_ONLINE_QUEUE,
            INTERNAL_NORMAL_QUEUE,
            FPS_ONLINE_QUEUE,
            FPS_NORMAL_QUEUE,
            CHATS_ONLINE_QUEUE,
            CHATS_NORMAL_QUEUE);

    private QueueNames internal = new QueueNames(INTERNAL_ONLINE_QUEUE, INTERNAL_NORMAL_QUEUE);

    private QueueNames fps = new QueueNames(FPS_ONLINE_QUEUE, FPS_NORMAL_QUEUE);

    private QueueNames chats = new QueueNames(CHATS_ONLINE_QUEUE, CHATS_NORMAL_QUEUE);

    public Set<String> getAllowedQueuesSet() {
        return allowed != null ? Set.copyOf(allowed) : Set.of();
    }

    public String getInternalPriorityQueue() {
        return internal.getPriority();
    }

    public String getInternalNormalQueue() {
        return internal.getNormal();
    }

    public String getFpsPriorityQueue() {
        return fps.getPriority();
    }

    public String getFpsNormalQueue() {
        return fps.getNormal();
    }

    public String getChatsPriorityQueue() {
        return chats.getPriority();
    }

    public String getChatsNormalQueue() {
        return chats.getNormal();
    }

    @Getter
    @Setter
    public static class QueueNames {

        private String priority;

        private String normal;

        public QueueNames() {
        }

        public QueueNames(String priority, String normal) {
            this.priority = priority;
            this.normal = normal;
        }
    }
}
