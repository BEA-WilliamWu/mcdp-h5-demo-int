package com.bea.payment.bulk.internal.flow.mq;

import com.bea.payment.common.exception.SystemException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PreDestroy;
import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * IBM MQ 同步接收客户端，使用 JMS CLIENT_ACKNOWLEDGE 模式。
 *
 * <p>每个队列懒加载并复用一组 {@link Connection}、{@link Session} 和
 * {@link MessageConsumer}，避免 Worker 定时轮询时反复创建和销毁 MQ 连接。
 * 业务拒收时通过 {@link Session#recover()} 显式触发 MQ 重投/BOQNAME 处理。</p>
 */
@Service
@ConditionalOnProperty(prefix = "pe.flow.mq", name = "enabled", havingValue = "true")
@ConditionalOnProperty(prefix = "pe.flow.mq.consumer", name = "enabled", havingValue = "true")
public class MqReceiveClient {

    private static final Logger log = LoggerFactory.getLogger(MqReceiveClient.class);

    private final ConnectionFactory connectionFactory;
    private final ObjectMapper objectMapper;
    private final MqQueueProperties queueProperties;
    private final MqProperties properties;
    private final MqMetrics metrics;

    /**
     * 按队列缓存 JMS 消费资源。
     *
     * <p>Worker 是定时轮询模型，如果每次轮询都创建/关闭 MQ 连接，UAT/生产 MQ 服务器会承受
     * 大量连接握手和通道资源抖动。这里按 queueName 复用消费者，每个队列最多保留一组
     * {@link Connection}、{@link Session} 和 {@link MessageConsumer}。</p>
     */
    private final Map<String, QueueConsumer> consumers = new ConcurrentHashMap<>();

    public MqReceiveClient(ConnectionFactory connectionFactory,
            ObjectMapper objectMapper,
            MqQueueProperties queueProperties,
            MqProperties properties,
            MqMetrics metrics) {
        this.connectionFactory = Objects.requireNonNull(connectionFactory, "connectionFactory must not be null");
        this.objectMapper = Objects.requireNonNull(objectMapper, "objectMapper must not be null");
        this.queueProperties = Objects.requireNonNull(queueProperties, "queueProperties must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.metrics = Objects.requireNonNull(metrics, "metrics must not be null");
    }

    public Optional<MqInboundDelivery> receiveOne(String queueName) {
        validateQueueName(queueName);

        // computeIfAbsent 保证同一队列只初始化一次 QueueConsumer。
        // 真正的 MQ 连接仍然在 QueueConsumer.ensureOpen() 中懒加载，避免应用启动时就连接 MQ。
        return consumers.computeIfAbsent(queueName, QueueConsumer::new).receiveOne();
    }

    /**
     * Spring 容器关闭时释放所有已打开的队列消费者资源。
     *
     * <p>正常轮询期间资源会被复用，不会在每次 receive 后关闭；因此应用停止时需要集中清理。
     * JVM 被强杀时该方法可能不会执行，此时 MQ 会在 TCP/JMS 连接断开后回收服务端资源。</p>
     */
    @PreDestroy
    public void shutdown() {
        consumers.values().forEach(QueueConsumer::closeResources);
        consumers.clear();
    }

    /**
     * 校验消息体是否具备 Worker 后续处理所需的最小字段。
     *
     * <p>这里不做业务状态判断，只做消息格式层面的 fail-fast。格式不合法的消息会在调用处
     * recover，让 MQ 根据 backout 阈值和 BOQNAME 配置处理。</p>
     */
    private void validateMessageBody(MqMessage mqMessage, String messageId) {
        try {
            Objects.requireNonNull(mqMessage, "message must not be null");
            requireText(mqMessage.getBatchId(), "message.batchId");
            requireText(mqMessage.getTransactionId(), "message.transactionId");
            requireText(mqMessage.getTransactionType(), "message.transactionType");
            requireText(mqMessage.getChannel(), "message.channel");
            Objects.requireNonNull(mqMessage.getOrderId(), "message.orderId must not be null");
        } catch (IllegalArgumentException | NullPointerException ex) {
            throw new InvalidMessageFormatException("Invalid IBM MQ message body: messageId=" + messageId
                    + ", reason=" + ex.getMessage(), ex);
        }
    }

    /**
     * 将 JMS 消息解析为业务 MQ 消息。
     *
     * <p>当前生产链路只支持 TextMessage + JSON。非 TextMessage 视为格式错误；
     * JSON 解析失败视为反序列化错误，都会由上层统一 recover。</p>
     */
    private MqMessage decodeMessage(Message jmsMessage) throws JMSException {
        if (!(jmsMessage instanceof TextMessage textMessage)) {
            throw new InvalidMessageFormatException("Unsupported IBM MQ message type: "
                    + jmsMessage.getClass().getName(), null);
        }
        try {
            return objectMapper.readValue(textMessage.getText(), MqMessage.class);
        } catch (JsonProcessingException ex) {
            throw new SystemException("Failed to deserialize IBM MQ message body: messageId="
                    + safeMessageId(jmsMessage), ex);
        }
    }

    /**
     * 安全读取 JMSMessageID。
     *
     * <p>异常路径也需要 messageId 参与日志和异常信息，因此这里不能让读取 messageId 的
     * JMSException 覆盖原始错误。</p>
     */
    private String safeMessageId(Message jmsMessage) {
        try {
            return jmsMessage.getJMSMessageID();
        } catch (JMSException ex) {
            return "UNKNOWN";
        }
    }

    /**
     * 读取单次 receive 的阻塞等待时间。
     *
     * <p>返回 0 表示非阻塞 receive。负数配置按 0 处理，避免定时任务线程长时间卡住。</p>
     */
    private long receiveTimeoutMillis() {
        Duration timeout = properties.getConsumer().getReceiveTimeout();
        if (timeout == null || timeout.isNegative()) {
            return 0L;
        }
        return timeout.toMillis();
    }

    /**
     * 校验调用方传入的队列名。
     *
     * <p>默认开启白名单校验，避免配置错误或代码 bug 让 Worker 连到未声明队列。
     * 如果临时排障需要绕过白名单，可通过配置关闭 {@code validateQueueName}。</p>
     */
    private void validateQueueName(String queueName) {
        if (queueName == null || queueName.isBlank()) {
            metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONFIG,
                    Duration.ZERO);
            throw new IllegalArgumentException("queueName must not be blank");
        }
        if (!properties.isValidateQueueName()) {
            return;
        }
        Set<String> allowedQueues = queueProperties.getAllowedQueuesSet();
        if (!allowedQueues.contains(queueName)) {
            metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONFIG,
                    Duration.ZERO);
            throw new IllegalArgumentException("Invalid IBM MQ queueName: " + queueName);
        }
    }

    /**
     * 要求字段为非空文本。
     */
    private void requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
    }

    /**
     * 关闭 JMS 资源时只记录日志，不再向外抛出异常。
     *
     * <p>该方法主要用于异常恢复和应用关闭阶段；关闭失败不应掩盖原始业务异常或阻断其他资源清理。</p>
     */
    private void closeQuietly(AutoCloseable closeable, String resourceName, String queueName) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        } catch (Exception ex) {
            log.warn("[IBM-MQ-CONSUMER] Failed to close JMS {} for queueName={}: {}",
                    resourceName, queueName, ex.getMessage());
        }
    }

    /**
     * 计算一次 receive 操作耗时，用于 Micrometer 指标。
     */
    private Duration elapsedSince(long startNanos) {
        return Duration.ofNanos(System.nanoTime() - startNanos);
    }

    /**
     * 表示消息格式不满足本系统约定。
     *
     * <p>单独区分该异常，方便指标中把 MESSAGE_FORMAT 与普通 JSON 反序列化失败拆开观察。</p>
     */
    private static class InvalidMessageFormatException extends SystemException {

        InvalidMessageFormatException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * 单个物理队列的同步消费者封装。
     *
     * <p>一个 QueueConsumer 绑定一个 queueName，并持有一组可复用的 JMS 资源。
     * 方法使用 synchronized，是因为 JMS Session 通常不应被多线程并发使用；即使将来调度线程池
     * 出现重入，也会被串行化到同一队列消费者上。</p>
     */
    private class QueueConsumer implements MqInboundDelivery.DeliveryHandle {

        private final String queueName;

        /**
         * 以下三项是该队列复用的 JMS 资源。
         *
         * <p>它们在首次 receive 时创建，在连接异常或应用关闭时释放。空队列不会释放资源。</p>
         */
        private Connection connection;
        private Session session;
        private MessageConsumer consumer;

        /**
         * 当前队列是否已有一条消息交给 Worker 但尚未 ACK/recover。
         *
         * <p>CLIENT_ACKNOWLEDGE 模式下，同一个 Session 上同时挂多条未确认消息会让 ACK/recover
         * 语义变复杂。当前业务每次 Worker 只处理一条，所以用该标志强制单队列单 in-flight。</p>
         */
        private boolean inFlight;

        QueueConsumer(String queueName) {
            this.queueName = queueName;
        }

        synchronized Optional<MqInboundDelivery> receiveOne() {
            if (inFlight) {
                // 调用方正常情况下会通过 ack()/close() 结束 delivery。
                // 如果未来代码漏掉终结动作，这里不会继续取新消息，避免同一 Session 混入多条未决消息。
                log.warn("[IBM-MQ-CONSUMER] Previous delivery is still in-flight: queueName={}", queueName);
                metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_EMPTY, MqMetrics.ERROR_NONE, Duration.ZERO);
                return Optional.empty();
            }

            long startNanos = System.nanoTime();
            try {
                ensureOpen();
                Message jmsMessage = consumer.receive(receiveTimeoutMillis());
                if (jmsMessage == null) {
                    // 空队列是正常情况，只记录 EMPTY 指标。资源继续保留给下一轮定时任务复用。
                    metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_EMPTY, MqMetrics.ERROR_NONE,
                            elapsedSince(startNanos));
                    return Optional.empty();
                }

                // 从这里开始，消息已离开 MQ 队列的可见位置但尚未 ACK。
                // 后续必须通过 delivery.ack() 或 delivery.close()/recover 结束生命周期。
                inFlight = true;
                return Optional.of(toDelivery(jmsMessage, startNanos));
            } catch (JMSException ex) {
                metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_CONNECTION,
                        elapsedSince(startNanos));
                closeResources();
                throw new SystemException("Failed to receive IBM MQ message: queueName=" + queueName, ex);
            }
        }

        /**
         * 确保该队列的 JMS 资源已经打开。
         *
         * <p>采用懒加载是为了让应用可以在 MQ 开关打开但 Worker 尚未实际轮询前完成启动；
         * 如果创建任一资源失败，会关闭已创建的部分资源，下一轮 receive 再重试创建。</p>
         */
        private void ensureOpen() throws JMSException {
            if (connection != null && session != null && consumer != null) {
                return;
            }
            try {
                connection = connectionFactory.createConnection();
                session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
                Queue queue = session.createQueue(queueName);
                consumer = session.createConsumer(queue);
                connection.start();
            } catch (JMSException ex) {
                closeResources();
                throw ex;
            }
        }

        /**
         * 将原始 JMS 消息包装成业务 delivery。
         *
         * <p>只有消息体解析成功且必填字段齐全时才返回 delivery。否则立即 recover 当前 Session，
         * 让 MQ 负责后续重投和 BOQNAME 移动，不把坏消息交给 Worker 主流程。</p>
         */
        private MqInboundDelivery toDelivery(Message jmsMessage, long startNanos) throws JMSException {
            String messageId = safeMessageId(jmsMessage);
            try {
                MqMessage mqMessage = decodeMessage(jmsMessage);
                String correlationId = jmsMessage.getJMSCorrelationID();
                validateMessageBody(mqMessage, messageId);
                log.info("[IBM-MQ-CONSUMER] Received message: queueName={}, messageId={}, correlationId={}, transactionId={}",
                        queueName, messageId, correlationId, mqMessage.getTransactionId());
                metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_SUCCESS, MqMetrics.ERROR_NONE,
                        elapsedSince(startNanos));
                return new MqInboundDelivery(queueName, messageId, correlationId, mqMessage,
                        jmsMessage, this);
            } catch (InvalidMessageFormatException ex) {
                // 格式错误通常表示上游消息构造或队列污染问题，不 ACK，交给 MQ backout 机制处理。
                metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_MESSAGE_FORMAT,
                        elapsedSince(startNanos));
                recoverInFlight(messageId);
                throw ex;
            } catch (RuntimeException ex) {
                // JSON 解析等运行时异常同样不 ACK，避免吞掉无法识别的消息。
                metrics.recordConsumerReceive(queueName, MqMetrics.RESULT_FAILED, MqMetrics.ERROR_DESERIALIZATION,
                        elapsedSince(startNanos));
                recoverInFlight(messageId);
                throw ex;
            }
        }

        /**
         * 确认当前消息。
         *
         * <p>Worker 只会在调用下游前一刻调用该方法。ACK 成功后消息不再由 MQ 重投；
         * ACK 失败则关闭当前队列资源，下一轮重新建连，且 Worker 不会继续调用下游。</p>
         */
        @Override
        public synchronized void acknowledge(Message jmsMessage, String messageId) {
            try {
                jmsMessage.acknowledge();
                metrics.recordConsumerAck(queueName, MqMetrics.RESULT_SUCCESS);
            } catch (JMSException ex) {
                metrics.recordConsumerAck(queueName, MqMetrics.RESULT_FAILED);
                closeResources();
                throw new SystemException("Failed to acknowledge IBM MQ message: messageId=" + messageId, ex);
            } finally {
                inFlight = false;
            }
        }

        /**
         * 拒收当前 in-flight 消息。
         *
         * <p>该方法由 {@link MqInboundDelivery#close()} 调用。若当前没有未决消息，说明该 delivery
         * 已经被 ACK/recover 或资源已重置，此时直接返回，保证 close 的幂等性。</p>
         */
        @Override
        public synchronized void recover(String messageId) {
            if (!inFlight) {
                return;
            }
            recoverInFlight(messageId);
        }

        /**
         * 对当前 Session 执行 JMS recover。
         *
         * <p>recover 会把本 Session 中未 ACK 的消息交还给 MQ，由 MQ 按 backout 次数决定重投或
         * 移动到 BOQNAME。recover 失败时说明本地连接状态可能已经不可信，因此关闭资源等待下轮重建。</p>
         */
        private void recoverInFlight(String messageId) {
            try {
                session.recover();
            } catch (JMSException ex) {
                log.warn("[IBM-MQ-CONSUMER] Failed to recover JMS session for messageId={}, queueName={}: {}",
                        messageId, queueName, ex.getMessage());
                closeResources();
            } finally {
                inFlight = false;
            }
        }

        /**
         * 关闭该队列持有的 JMS 资源，并清空本地引用。
         *
         * <p>该方法用于连接异常、应用关闭、recover 失败等场景。设置 {@code inFlight=false}
         * 是为了让下一轮轮询可以重新建连；未 ACK 消息会随连接/session 关闭回到 MQ 的重投链路。</p>
         */
        private synchronized void closeResources() {
            closeQuietly(consumer, "consumer", queueName);
            closeQuietly(session, "session", queueName);
            closeQuietly(connection, "connection", queueName);
            consumer = null;
            session = null;
            connection = null;
            inFlight = false;
        }
    }
}
