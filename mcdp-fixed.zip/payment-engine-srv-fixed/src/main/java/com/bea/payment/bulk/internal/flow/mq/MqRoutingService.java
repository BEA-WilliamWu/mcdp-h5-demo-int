package com.bea.payment.bulk.internal.flow.mq;

import com.bea.payment.bulk.constants.ChannelEnum;
import com.bea.payment.bulk.constants.TransactionTypeEnum;
import org.springframework.stereotype.Service;

/**
 * 根据交易类型和渠道解析目标 IBM MQ 队列。
 *
 * <p>路由规则：HTH 使用 ONLINE 队列，其他渠道使用 NORMAL 队列。
 * 队列名从 {@link MqQueueProperties} 读取。</p>
 */
@Service
public class MqRoutingService {

    private final MqQueueProperties queueProperties;

    public MqRoutingService(MqQueueProperties queueProperties) {
        this.queueProperties = queueProperties;
    }

    /**
     * 返回四个已配置业务队列之一。
     *
     * @param transactionType 交易类型，当前为 INTERNAL 或 FPS
     * @param channel 渠道代码，HTH 进入 ONLINE，其他渠道进入 NORMAL
     * @return 队列名，例如 {@code IPE.PAYMENT.FPS.ONLINE}
     */
    public String resolveQueue(String transactionType, String channel) {
        boolean isHth = ChannelEnum.HTH.getCode().equalsIgnoreCase(channel);

        if (TransactionTypeEnum.INTERNAL.getCode().equalsIgnoreCase(transactionType)) {
            return isHth ? queueProperties.getInternalPriorityQueue() : queueProperties.getInternalNormalQueue();
        } else if (TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(transactionType)) {
            return isHth ? queueProperties.getFpsPriorityQueue() : queueProperties.getFpsNormalQueue();
        } else if (TransactionTypeEnum.CHATS.getCode().equalsIgnoreCase(transactionType)) {
            return isHth ? queueProperties.getChatsPriorityQueue() : queueProperties.getChatsNormalQueue();
        } else {
            throw new IllegalArgumentException("Unsupported MQ transactionType: " + transactionType);
        }
    }
}
