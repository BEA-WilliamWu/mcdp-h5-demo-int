package com.bea.payment.bulk.internal.flow.ratelimit;

/**
 * 限流策略应用结果。
 *
 * <p>封装从配置规则解析后的最终限流决策，包含是否启用、速率、间隔等信息。</p>
 */
public record AppliedRatePolicy(
        Status status,
        Long profileId,
        Long ratePerHour,
        Long permitIntervalMs,
        String reason
) {

    public enum Status {
        ENABLED,
        DISABLED
    }

    /**
     * 创建启用的限流策略。
     */
    public static AppliedRatePolicy enabled(Long profileId, long ratePerHour, long permitIntervalMs) {
        return new AppliedRatePolicy(Status.ENABLED, profileId, ratePerHour, permitIntervalMs, null);
    }

    /**
     * 创建禁用的限流策略。
     */
    public static AppliedRatePolicy disabled(Long profileId, Long ratePerHour, String reason) {
        return new AppliedRatePolicy(Status.DISABLED, profileId, ratePerHour, null, reason);
    }

    /**
     * 判断限流是否启用。
     */
    public boolean isEnabled() {
        return status == Status.ENABLED;
    }
}
