package com.bea.payment.bulk.internal.flow.ratelimit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * 限流策略存储。
 *
 * <p>将应用后的限流策略存储在 Redis 中，确保所有 Worker 实例看到一致的启用/禁用状态。</p>
 */
@Component
public class RatePolicyStore {

    private static final String POLICY_KEY_PREFIX = "rate:policy:";

    private final RedissonClient redisson;
    private final ObjectMapper objectMapper;

    public RatePolicyStore(RedissonClient redisson, ObjectMapper objectMapper) {
        this.redisson = redisson;
        this.objectMapper = objectMapper;
    }

    /**
     * 查询指定交易类型的限流策略。
     *
     * @param txType 交易类型
     * @return 限流策略，不存在时返回 Optional.empty()
     */
    public Optional<AppliedRatePolicy> find(String txType) {
        String value = bucket(txType).get();
        if (value == null) {
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(value, AppliedRatePolicy.class));
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Unable to read active rate policy for txType=" + txType, ex);
        }
    }

    /**
     * 保存限流策略到 Redis。
     *
     * @param txType 交易类型
     * @param policy 限流策略
     */
    public void save(String txType, AppliedRatePolicy policy) {
        try {
            bucket(txType).set(objectMapper.writeValueAsString(policy));
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Unable to write active rate policy for txType=" + txType, ex);
        }
    }

    private RBucket<String> bucket(String txType) {
        return redisson.getBucket(POLICY_KEY_PREFIX + txType);
    }
}
