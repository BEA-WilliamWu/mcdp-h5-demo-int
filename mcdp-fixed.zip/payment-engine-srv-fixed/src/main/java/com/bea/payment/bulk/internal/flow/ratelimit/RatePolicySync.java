package com.bea.payment.bulk.internal.flow.ratelimit;

import com.bea.payment.bulk.internal.flow.cache.FlowControlConfigCache;
import com.bea.payment.bulk.internal.flow.config.RateLimitProperties;
import com.bea.payment.bulk.internal.flow.model.FlowRule;
import org.redisson.api.RLock;
import org.redisson.api.RRateLimiter;
import org.redisson.api.RateIntervalUnit;
import org.redisson.api.RateLimiterConfig;
import org.redisson.api.RateType;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 限流策略同步器。
 *
 * <p>定时从 Redis 配置快照读取时间窗口规则，计算当前生效策略，
 * 再同步到 Redis `rate:policy:{txType}` 和 Redisson `RRateLimiter`。</p>
 */
@Component
public class RatePolicySync {

    public static final String PARAM_RATE_PER_HOUR = "ratePerHour";
    public static final String CONFIG_LOCK_KEY_PREFIX = "lock:rate:config:";
    static final long ONE_HOUR_MILLIS = 3_600_000L;
    private static final String CONFIG_SNAPSHOT_UNAVAILABLE = "CONFIG_SNAPSHOT_UNAVAILABLE";

    private static final Logger log = LoggerFactory.getLogger(RatePolicySync.class);

    private final FlowControlConfigCache configCache;
    private final RedissonClient redisson;
    private final RatePolicyStore policyStore;
    private final Clock clock;
    private final RateLimitProperties rateLimitProperties;

    @Autowired
    public RatePolicySync(
            FlowControlConfigCache configCache,
            RedissonClient redisson,
            RatePolicyStore policyStore,
            RateLimitProperties rateLimitProperties
    ) {
        this(configCache, redisson, policyStore, rateLimitProperties, Clock.systemDefaultZone());
    }

    public RatePolicySync(
            FlowControlConfigCache configCache,
            RedissonClient redisson,
            RatePolicyStore policyStore,
            RateLimitProperties rateLimitProperties,
            Clock clock
    ) {
        this.configCache = configCache;
        this.redisson = redisson;
        this.policyStore = policyStore;
        this.clock = clock;
        this.rateLimitProperties = rateLimitProperties;
    }

    /**
     * 定时同步所有支持交易类型的限流策略（默认每 60 秒执行一次）。
     *
     * <p>单个交易类型失败不影响其他类型继续同步；失败类型会在自身流程中
     * 尽量写入 disabled policy，确保 Worker fail-closed。</p>
     */
    @Scheduled(fixedDelayString = "${pe.flow.rate-policy.sync-delay:60000}")
    public void sync() {
        LocalDateTime now = LocalDateTime.now(clock);
        for (String txType : rateLimitProperties.getSupportedTxTypes()) {
            try {
                syncTxType(txType, now);
            } catch (RuntimeException ex) {
                log.error("Failed to synchronize rate policy: txType={}", txType, ex);
            }
        }
    }

    /**
     * 同步指定交易类型的限流策略。
     *
     * <p>流程：从 Redis 规则快照解析期望策略 -> 获取配置锁 -> 应用策略。
     * 配置锁用于防止多 Pod 同时重配同一个 `RRateLimiter`，避免重复 `setRate`
     * 重置 Redisson 许可状态。</p>
     */
    public void syncTxType(String txType, LocalDateTime now) {
        AppliedRatePolicy desired = resolveDesiredPolicyOrDisable(txType, now);
        RLock lock = redisson.getLock(CONFIG_LOCK_KEY_PREFIX + txType);
        boolean locked = false;
        try {
            locked = lock.tryLock(0, TimeUnit.SECONDS);
            if (!locked) {
                log.debug("Rate policy synchronization skipped because config lock is busy: txType={}", txType);
                return;
            }
            // 只有拿到配置锁的 Pod 才允许写 policy 或重配 limiter，保证多 Pod 行为一致。
            applyPolicy(txType, desired);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            log.warn("Rate policy synchronization interrupted while acquiring config lock: txType={}", txType);
        } finally {
            if (locked && lock.isHeldByCurrentThread()) {
                lock.unlock();
            }
        }
    }

    /**
     * 解析当前应生效的策略；当 Redis 配置快照不可用时转成禁用策略。
     *
     * <p>这里不把异常继续抛到调度层，是为了在 Redis 仍可写的情况下把
     * `rate:policy:{txType}` 明确更新为 disabled，避免 Worker 继续使用旧启用策略。</p>
     */
    private AppliedRatePolicy resolveDesiredPolicyOrDisable(String txType, LocalDateTime now) {
        try {
            return resolveDesiredPolicy(txType, now);
        } catch (RuntimeException ex) {
            log.error("Rate policy disabled because Redis flow-control rule snapshot is unavailable: txType={}",
                    txType, ex);
            return AppliedRatePolicy.disabled(null, null, CONFIG_SNAPSHOT_UNAVAILABLE);
        }
    }

    /**
     * 根据当前时间从 Redis 规则快照中选出命中的规则，并转换为生效策略。
     *
     * <p>没有窗口命中、参数缺失、参数非法或非正速率都转成 disabled policy；
     * 只有正整数 `ratePerHour` 才会转换为可配置到 `RRateLimiter` 的许可间隔。</p>
     */
    private AppliedRatePolicy resolveDesiredPolicy(String txType, LocalDateTime now) {
        FlowRule rule = configCache.getRulesByTxType(txType).stream()
                .filter(candidate -> candidate.match(now.getDayOfWeek(), now.toLocalTime()))
                .findFirst()
                .orElse(null);

        if (rule == null) {
            return AppliedRatePolicy.disabled(null, null, "NO_MATCHING_RULE");
        }

        Map<String, String> params = rule.getParams();
        String rateValue = params == null ? null : params.get(PARAM_RATE_PER_HOUR);
        if (rateValue == null || rateValue.isBlank()) {
            log.warn("Rate policy disabled because ratePerHour is missing: txType={}, profileId={}",
                    txType, rule.getProfileId());
            return AppliedRatePolicy.disabled(rule.getProfileId(), null, "MISSING_RATE_PER_HOUR");
        }

        long ratePerHour;
        try {
            ratePerHour = Long.parseLong(rateValue);
        } catch (NumberFormatException ex) {
            log.warn("Rate policy disabled because ratePerHour is invalid: txType={}, profileId={}",
                    txType, rule.getProfileId());
            return AppliedRatePolicy.disabled(rule.getProfileId(), null, "INVALID_RATE_PER_HOUR");
        }

        if (ratePerHour < 0) {
            log.warn("Rate policy disabled because ratePerHour is negative: txType={}, profileId={}",
                    txType, rule.getProfileId());
            return AppliedRatePolicy.disabled(rule.getProfileId(), ratePerHour, "NEGATIVE_RATE_PER_HOUR");
        }
        if (ratePerHour == 0) {
            return AppliedRatePolicy.disabled(rule.getProfileId(), 0L, "CONFIGURED_ZERO_RATE");
        }

        long intervalMillis = divideRoundUp(ONE_HOUR_MILLIS, ratePerHour);
        return AppliedRatePolicy.enabled(rule.getProfileId(), ratePerHour, intervalMillis);
    }

    /**
     * 将期望策略应用到 Redis policy 和 Redisson 限流器。
     *
     * <p>启用策略才需要配置 `RRateLimiter`；禁用策略只写 policy，Worker 读取 disabled
     * 后不会调用 `tryAcquire`。当 limiter 实际配置已经匹配时，不重复 `setRate`。</p>
     */
    private void applyPolicy(String txType, AppliedRatePolicy desired) {
        if (desired.isEnabled()) {
            RRateLimiter limiter = redisson.getRateLimiter(
                    TransactionTypeRateLimiterService.LIMITER_KEY_PREFIX + txType);
            RateLimiterConfig actual = limiter.getConfig();
            if (!matches(actual, desired)) {
                // setRate 会影响 Redisson 内部许可状态，只能在配置确实变化时调用。
                limiter.setRate(RateType.OVERALL, 1, desired.permitIntervalMs(), RateIntervalUnit.MILLISECONDS);
            }
        }

        AppliedRatePolicy current = findCurrentPolicy(txType);
        if (!Objects.equals(current, desired)) {
            policyStore.save(txType, desired);
        }
    }

    /**
     * 读取当前已应用策略。
     *
     * <p>如果 Redis 中的 policy JSON 损坏，返回 null 让本轮 desired policy 覆盖写回；
     * 这样不会因为历史脏数据阻断后续同步。</p>
     */
    private AppliedRatePolicy findCurrentPolicy(String txType) {
        try {
            return policyStore.find(txType).orElse(null);
        } catch (RuntimeException ex) {
            log.warn("Current rate policy is unreadable and will be overwritten: txType={}", txType, ex);
            return null;
        }
    }

    /**
     * 判断 Redisson 当前限流器配置是否已经等于期望策略。
     */
    private boolean matches(RateLimiterConfig actual, AppliedRatePolicy desired) {
        return actual != null
                && actual.getRateType() == RateType.OVERALL
                && Long.valueOf(1).equals(actual.getRate())
                && desired.permitIntervalMs().equals(actual.getRateInterval());
    }

    /**
     * 向上取整，确保实际许可间隔不会小于配置速率要求。
     */
    private long divideRoundUp(long dividend, long divisor) {
        return dividend / divisor + (dividend % divisor == 0 ? 0 : 1);
    }
}
