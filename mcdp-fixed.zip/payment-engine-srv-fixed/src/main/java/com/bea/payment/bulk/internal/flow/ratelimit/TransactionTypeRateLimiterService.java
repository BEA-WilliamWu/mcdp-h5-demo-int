package com.bea.payment.bulk.internal.flow.ratelimit;

import com.bea.payment.bulk.internal.flow.config.RateLimitProperties;
import org.redisson.api.RRateLimiter;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * 基于交易类型的限流服务。
 *
 * <p>使用 Redisson RRateLimiter 实现令牌桶算法，控制下游接口的调用频率。</p>
 */
@Service
public class TransactionTypeRateLimiterService {

    public static final String LIMITER_KEY_PREFIX = "rate:downstream:";

    private static final Logger log = LoggerFactory.getLogger(TransactionTypeRateLimiterService.class);

    private final RedissonClient redisson;
    private final RatePolicyStore policyStore;
    private final RateLimitProperties rateLimitProperties;

    public TransactionTypeRateLimiterService(
            RedissonClient redisson,
            RatePolicyStore policyStore,
            RateLimitProperties rateLimitProperties
    ) {
        this.redisson = redisson;
        this.policyStore = policyStore;
        this.rateLimitProperties = rateLimitProperties;
    }

    /**
     * 尝试获取限流令牌。
     *
     * @param txType   交易类型
     * @param waitTime 等待时间
     * @param unit     时间单位
     * @return 是否获取成功
     */
    public boolean tryAcquire(String txType, long waitTime, TimeUnit unit) {
        String normalizedTxType = normalize(txType);
        // 1. 校验交易类型是否支持
        if (!rateLimitProperties.getSupportedTxTypeSet().contains(normalizedTxType)) {
            log.warn("Rate permit rejected for unsupported txType={}", txType);
            return false;
        }

        try {
            // 2. 查询限流策略
            AppliedRatePolicy policy = policyStore.find(normalizedTxType).orElse(null);
            if (policy == null || !policy.isEnabled()) {
                return false;
            }

            // 3. 尝试从 Redisson RateLimiter 获取令牌
            RRateLimiter limiter = redisson.getRateLimiter(LIMITER_KEY_PREFIX + normalizedTxType);
            return limiter.tryAcquire(waitTime, unit);
        } catch (RuntimeException ex) {
            // ⚠️ 风险：限流检查失败时拒绝请求，避免下游过载
            log.error("Rate permit check failed; downstream dispatch rejected: txType={}", normalizedTxType, ex);
            return false;
        }
    }

    public boolean tryAcquire(String txType) {
        return tryAcquire(txType, 0, TimeUnit.MILLISECONDS);
    }

    private String normalize(String txType) {
        return txType == null ? "" : txType.toUpperCase(Locale.ROOT);
    }
}
