package com.bea.payment.bulk.internal.flow.scanner;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.BatchStatusEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.constants.StatusReasonEnum;
import com.bea.payment.bulk.internal.flow.mq.MqMessage;
import com.bea.payment.bulk.internal.flow.mq.MqProducerService;
import com.bea.payment.bulk.internal.flow.mq.MqRoutingService;
import com.bea.payment.bulk.mapper.PaymentBatchHdrMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.entity.PaymentBatchHdrEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.service.PaymentBatchStatusService;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Scanner 负责把数据库中已到执行日的待处理交易投递到 IBM MQ。
 *
 * <p>ACK 和 MQ 重投是 Worker/consumer 侧职责；Scanner 只处理 DB 到 MQ 的投递边界。
 * 指针语义固定为“最后一条已成功投递并已完成 DB 入队标记的 orderId”。</p>
 */
@Service
@ConditionalOnProperty(prefix = "pe.flow.mq", name = "enabled", havingValue = "true")
@ConditionalOnProperty(prefix = "pe.flow.scanner", name = "enabled",
        havingValue = "true", matchIfMissing = true)
public class ScannerService {

    private static final Logger log = LoggerFactory.getLogger(ScannerService.class);
    private static final String NOT_DELETED = "N";
    private static final String SCANNER_LOCK_KEY = "lock:scanner";
    private static final int DISPATCHING_SCAN_LIMIT = 20;

    private final RedissonClient redisson;
    private final PaymentBatchHdrMapper batchHdrMapper;
    private final PaymentTxnMainMapper txnMainMapper;
    private final MqRoutingService routingService;
    private final MqProducerService producer;
    private final PaymentBatchStatusService batchStatusService;
    private final TransactionTemplate transactionTemplate;

    @Value("${pe.flow.scanner.max-transactions-per-run:20}")
    private int maxTransactionsPerRun = 20;

    public ScannerService(RedissonClient redisson,
            PaymentBatchHdrMapper batchHdrMapper,
            PaymentTxnMainMapper txnMainMapper,
            MqRoutingService routingService,
            MqProducerService producer,
            PaymentBatchStatusService batchStatusService,
            TransactionTemplate transactionTemplate) {
        this.redisson = Objects.requireNonNull(redisson, "redisson must not be null");
        this.batchHdrMapper = Objects.requireNonNull(batchHdrMapper, "batchHdrMapper must not be null");
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.routingService = Objects.requireNonNull(routingService, "routingService must not be null");
        this.producer = Objects.requireNonNull(producer, "producer must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService, "batchStatusService must not be null");
        this.transactionTemplate = Objects.requireNonNull(transactionTemplate, "transactionTemplate must not be null");
    }

    @Scheduled(fixedDelayString = "${pe.flow.scanner.fixed-delay:1000}")
    public void scanScheduled() {
        scanOnce();
    }

    /**
     * 执行一轮扫描。
     *
     * <p>核心流程：</p>
     * <ol>
     *   <li><b>获取分布式锁</b>：通过 Redisson 获取全局扫描锁 {@code lock:scanner}，确保同一时刻只有一个 Scanner 实例在执行，避免重复投递。</li>
     *   <li><b>选择批次</b>：优先选择状态为 {@code DISPATCHING}（投递中或等待断点恢复）的批次；若无，则选择状态为 {@code PENDING}（待投递）的批次并将其标记为 {@code DISPATCHING}。</li>
     *   <li><b>从指针位置开始投递</b>：根据批次的 {@code mqSendPointer} 确定最后成功投递的交易序号，查询该批次中所有序号大于指针且状态为 {@code PENDING} 的交易。</li>
     *   <li><b>逐笔发送 MQ</b>：对每笔待投递交易执行以下操作：
     *     <ul>
     *       <li>4.1 根据交易类型和渠道解析目标 MQ 队列名称</li>
     *       <li>4.2 调用 MQ Producer 发送消息</li>
     *       <li>4.3 将交易状态从 {@code PENDING} 更新为 {@code QUEUED}（已入队）</li>
     *       <li>4.4 推进批次的 {@code mqSendPointer} 到当前交易的 {@code orderId}</li>
     *     </ul>
     *   </li>
     *   <li><b>闭合 Scanner 阶段</b>：若该批次已无 {@code PENDING} 明细，将 HDR 状态从 {@code DISPATCHING} 推进到 {@code DISPATCHED}。</li>
     *   <li><b>释放锁</b>：无论成功或异常，最终释放分布式锁。</li>
     * </ol>
     *
     * @return 本轮成功发送 MQ 的交易数量
     */
    public int scanOnce() {
        log.debug("[SCANNER] Attempting to acquire scanner lock");
        RLock scannerLock = redisson.getLock(SCANNER_LOCK_KEY);
        if (!tryLock(scannerLock)) {
            log.debug("[SCANNER] Failed to acquire scanner lock, another instance may be scanning");
            return 0;
        }

        try {
            log.debug("[SCANNER] Scanner lock acquired, starting scan");
            int sent = scanLocked();
            if (sent > 0) {
                log.info("[SCANNER] Scan completed, sent {} messages", sent);
            } else {
                log.debug("[SCANNER] Scan completed, sent 0 messages");
            }
            return sent;
        } finally {
            unlockIfHeld(scannerLock);
            log.debug("[SCANNER] Scanner lock released");
        }
    }

    /**
     * 在持有分布式锁的前提下执行扫描逻辑。
     *
     * <p>流程步骤：</p>
     * <ol>
     *   <li>本轮建立全局 MAIN 投递额度，额度来自 {@code pe.flow.scanner.max-transactions-per-run}</li>
     *   <li>先查询一小批状态为 {@code DISPATCHING} 的批次（按创建时间和批次 ID 升序）</li>
     *   <li>逐个从 {@code mqSendPointer} 位置继续投递，并扣减本轮额度；若某个批次已无待投递明细，则刷新到终态或 {@code DISPATCHED} 后检查下一个批次</li>
     *   <li>若额度仍有剩余，再查询一批 {@code PENDING} 批次，逐个标记为 {@code DISPATCHING} 后投递</li>
     *   <li>若没有可投递批次或额度用尽，返回本轮发送数量</li>
     * </ol>
     *
     * @return 本轮成功发送的交易数量
     */
    private int scanLocked() {
        int remaining = normalizedMaxTransactionsPerRun();
        int totalSent = 0;

        List<PaymentBatchHdrEntity> dispatchingBatches =
                selectBatches(BatchStatusEnum.DISPATCHING, DISPATCHING_SCAN_LIMIT);
        for (PaymentBatchHdrEntity batch : dispatchingBatches) {
            if (remaining <= 0) {
                return totalSent;
            }
            log.info("[SCANNER] Found DISPATCHING batch: batchId={}, mqSendPointer={}",
                    batch.getBatchId(), batch.getMqSendPointer());
            int sent = dispatchFromPointer(batch, remaining);
            totalSent += sent;
            remaining -= sent;
            if (sent == 0) {
                log.debug("[SCANNER] DISPATCHING batch has no pending transactions, trying next batch: batchId={}",
                        batch.getBatchId());
            }
        }

        if (remaining <= 0) {
            return totalSent;
        }

        List<PaymentBatchHdrEntity> pendingBatches = selectBatches(BatchStatusEnum.PENDING, remaining);
        if (pendingBatches.isEmpty() && totalSent == 0) {
            log.debug("[SCANNER] No PENDING or DISPATCHING batches found");
            return 0;
        }

        for (PaymentBatchHdrEntity batch : pendingBatches) {
            if (remaining <= 0) {
                break;
            }
            log.info("[SCANNER] Found PENDING batch: batchId={}, marking as DISPATCHING", batch.getBatchId());
            if (!markDispatching(batch.getBatchId())) {
                log.warn("[SCANNER] Failed to mark batch as DISPATCHING, batch may have been changed: batchId={}",
                        batch.getBatchId());
                continue;
            }
            int sent = dispatchFromPointer(batch, remaining);
            totalSent += sent;
            remaining -= sent;
        }
        return totalSent;
    }

    private boolean tryLock(RLock lock) {
        try {
            return lock.tryLock(0, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private void unlockIfHeld(RLock lock) {
        if (lock.isHeldByCurrentThread()) {
            lock.unlock();
        }
    }

    private List<PaymentBatchHdrEntity> selectBatches(BatchStatusEnum status, int limit) {
        return batchHdrMapper.selectList(new LambdaQueryWrapper<PaymentBatchHdrEntity>()
                .eq(PaymentBatchHdrEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentBatchHdrEntity::getBatchStatus, status.getCode())
                // executionDate is stored as a DATE. A batch is due when its execution date is today or earlier
                // in the application default timezone; future LATER batches must not be scanned.
                .lt(PaymentBatchHdrEntity::getExecutionDate, startOfTomorrow())
                .orderByAsc(PaymentBatchHdrEntity::getCreationDate)
                .orderByAsc(PaymentBatchHdrEntity::getBatchId)
                .last("FETCH FIRST " + Math.max(limit, 1) + " ROWS ONLY"));
    }

    private Date startOfTomorrow() {
        return Date.from(LocalDate.now()
                .plusDays(1)
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant());
    }

    private boolean markDispatching(String batchId) {
        PaymentBatchHdrEntity update = new PaymentBatchHdrEntity();
        update.setBatchStatus(BatchStatusEnum.DISPATCHING.getCode());
        int updated = batchHdrMapper.update(update, new LambdaUpdateWrapper<PaymentBatchHdrEntity>()
                .eq(PaymentBatchHdrEntity::getBatchId, batchId)
                .eq(PaymentBatchHdrEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentBatchHdrEntity::getBatchStatus, BatchStatusEnum.PENDING.getCode()));
        return updated == 1;
    }

    private boolean markDispatchedIfNoPending(String batchId) {
        Long pendingCount = txnMainMapper.selectCount(new LambdaQueryWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnMainEntity::getBatchId, batchId)
                .eq(PaymentTxnMainEntity::getPaymentStatus, PaymentStatusEnum.PENDING.getCode()));
        if (pendingCount != null && pendingCount > 0) {
            log.debug("[SCANNER] Batch still has pending transactions, keeping DISPATCHING: batchId={}, pendingCount={}",
                    batchId, pendingCount);
            return false;
        }

        PaymentBatchHdrEntity update = new PaymentBatchHdrEntity();
        update.setBatchStatus(BatchStatusEnum.DISPATCHED.getCode());
        int updated = batchHdrMapper.update(update, new LambdaUpdateWrapper<PaymentBatchHdrEntity>()
                .eq(PaymentBatchHdrEntity::getBatchId, batchId)
                .eq(PaymentBatchHdrEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentBatchHdrEntity::getBatchStatus, BatchStatusEnum.DISPATCHING.getCode()));
        if (updated == 1) {
            log.info("[SCANNER] Batch dispatch stage completed: batchId={}, batchStatus={}",
                    batchId, BatchStatusEnum.DISPATCHED.getCode());
            return true;
        }
        log.debug("[SCANNER] Batch was not moved to DISPATCHED, status may have changed concurrently: batchId={}",
                batchId);
        return false;
    }

    /**
     * 从指定批次的指针位置开始，逐笔投递交易到 MQ。
     *
     * <p>详细步骤：</p>
     * <ol>
     *   <li>读取批次的 {@code mqSendPointer}，若为空则默认为 0（表示尚未成功发送任何交易）</li>
     *   <li>查询该批次中所有满足以下条件的交易：
     *     <ul>
     *       <li>{@code isDeleted = 'N'}</li>
     *       <li>{@code batchId} 匹配</li>
     *       <li>{@code paymentStatus = 'PENDING'}</li>
     *       <li>{@code orderId > pointer}（只处理指针之后的交易）</li>
     *     </ul>
     *     结果按 {@code orderId} 升序排列
     *   </li>
     *   <li>单轮最多读取 {@code pe.flow.scanner.max-transactions-per-run} 笔，避免大批次长时间持有 Scanner 锁</li>
     *   <li>遍历每笔交易，依次执行：
     *     <ul>
     *       <li>3.1 调用 {@link MqRoutingService#resolveQueue} 根据交易类型和渠道确定目标队列</li>
     *       <li>3.2 调用 {@link MqProducerService#send} 发送 MQ 消息</li>
     *       <li>3.3 调用 {@link #markQueued} 将交易状态从 {@code PENDING} 更新为 {@code QUEUED}，并校验必须更新 1 行</li>
     *       <li>3.4 调用 {@link #advancePointer} 将批次的 {@code mqSendPointer} 推进到当前交易的 {@code orderId}，并校验必须更新 1 行</li>
     *     </ul>
     *   </li>
     *   <li>若批次已无 {@code PENDING} 明细，则将 HDR 推进到 {@code DISPATCHED}</li>
     *   <li>返回成功发送的交易总数</li>
     * </ol>
     *
     * <p><b>数据一致性边界：</b></p>
     * <ol>
     *   <li><b>MQ 发送成功但状态更新失败</b>（步骤 3.2 成功，3.3 或 3.4 失败）
     *     <ul>
     *       <li><b>场景</b>：MQ 消息已发送，但更新交易状态为 {@code QUEUED} 或推进指针时数据库异常</li>
     *       <li><b>处理</b>：更新行数不是 1 时立即抛出异常并停止本轮扫描，指针不会静默推进；Worker 仍会校验 MAIN 状态，避免误处理未进入 {@code QUEUED} 的消息</li>
     *     </ul>
     *   </li>
     *   <li><b>指针推进与状态更新非原子操作</b>（步骤 3.3 和 3.4 之间失败）
     *     <ul>
     *       <li><b>场景</b>：交易状态已更新为 {@code QUEUED}，但指针未推进</li>
     *       <li><b>后果</b>：下次扫描会重复查询到这笔已入队的交易，但由于状态已是 {@code QUEUED}，不会被再次投递（有防护）</li>
     *       <li><b>影响</b>：指针滞后，但不影响正确性，只是效率略低</li>
     *     </ul>
     *   </li>
     *   <li><b>并发扫描导致重复投递</b>
     *     <ul>
     *       <li><b>场景</b>：虽然有 Redisson 分布式锁，但若锁超时时间设置不当或多实例部署时锁失效</li>
     *       <li><b>后果</b>：多个 Scanner 实例同时处理同一批次，可能重复投递</li>
     *       <li><b>解决方案</b>：
     *         <ul>
     *           <li>方案 A：确保锁的租约时间大于单次扫描最大耗时，并启用看门狗自动续期</li>
     *           <li>方案 B：在数据库层面增加唯一约束或版本号校验</li>
     *           <li>方案 C：Worker 消费端实现幂等性</li>
     *         </ul>
     *       </li>
     *       <li><b>目前采用 方案 A</b>：当前使用 {@code tryLock(0, TimeUnit.SECONDS)} 无超时参数，依赖 Redisson 默认看门狗机制；需压测验证锁稳定性</li>
     *     </ul>
     *   </li>
     *   <li><b>部分成功导致批次状态不一致</b>
     *     <ul>
     *       <li><b>场景</b>：批次中 10 笔交易，前 5 笔成功，第 6 笔失败抛出异常</li>
     *       <li><b>后果</b>：指针停留在第 5 笔，批次状态仍为 {@code DISPATCHING}，但未记录失败原因</li>
     *       <li><b>解决方案</b>：
     *         <ul>
     *           <li>方案 A：增加批次级别的失败计数器和错误日志表</li>
     *           <li>方案 B：实现重试机制，对失败交易单独标记并重试</li>
     *           <li>方案 C：引入补偿任务，定期扫描长时间处于 {@code DISPATCHING} 状态的批次</li>
     *         </ul>
     *       </li>
     *       <li><b>目前采用 方案 B</b>：只要有一笔投递 MQ 失败就停止，等待下一轮扫描重新投递</li>
     *     </ul>
     *   </li>
     * </ol>
     *
     * @param batch 批次实体
     * @return 成功发送的交易数量
     */
    private int dispatchFromPointer(PaymentBatchHdrEntity batch, int maxTransactions) {
        int pointer = batch.getMqSendPointer() == null ? 0 : batch.getMqSendPointer();
        List<PaymentTxnMainEntity> txns = selectPendingTransactions(batch.getBatchId(), pointer, maxTransactions);

        if (txns.isEmpty()) {
            log.debug("[SCANNER] No pending transactions for batchId={} from pointer={}",
                    batch.getBatchId(), pointer);
            boolean refreshed = batchStatusService.refreshIfBatchTerminal(batch.getBatchId());
            if (refreshed) {
                log.info("[SCANNER] Batch terminal status refreshed after empty dispatch scan: batchId={}",
                        batch.getBatchId());
            } else {
                markDispatchedIfNoPending(batch.getBatchId());
            }
            return 0;
        }

        log.info("[SCANNER] Found {} pending transactions for batchId={} from pointer={}",
                txns.size(), batch.getBatchId(), pointer);

        int sent = 0;
        int finalPointer = pointer;
        for (PaymentTxnMainEntity txn : txns) {
            try {
                String queueName = routingService.resolveQueue(txn.getTransactionType(), txn.getChannel());
                log.info("[SCANNER] Sending transaction to MQ: transactionId={}, orderId={}, queueName={}, txType={}",
                        txn.getTransactionId(), txn.getOrderId(), queueName, txn.getTransactionType());

                producer.send(queueName, MqMessage.from(txn));
                transactionTemplate.executeWithoutResult(status -> {
                    markQueued(txn.getTransactionId());
                    advancePointer(batch.getBatchId(), txn.getOrderId());
                });
                finalPointer = txn.getOrderId();
                sent++;

                log.debug("[SCANNER] Successfully sent transaction: transactionId={}, newPointer={}",
                        txn.getTransactionId(), txn.getOrderId());
            } catch (Exception e) {
                log.error("[SCANNER] Failed to send transaction: transactionId={}, orderId={}, error={}",
                        txn.getTransactionId(), txn.getOrderId(), e.getMessage(), e);
                throw e;
            }
        }

        log.info("[SCANNER] Batch dispatch completed: batchId={}, sent={}, finalPointer={}",
                batch.getBatchId(), sent, finalPointer);
        markDispatchedIfNoPending(batch.getBatchId());
        return sent;
    }

    private List<PaymentTxnMainEntity> selectPendingTransactions(String batchId, int pointer, int limit) {
        return txnMainMapper.selectList(new LambdaQueryWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnMainEntity::getBatchId, batchId)
                .eq(PaymentTxnMainEntity::getPaymentStatus, PaymentStatusEnum.PENDING.getCode())
                .gt(PaymentTxnMainEntity::getOrderId, pointer)
                .orderByAsc(PaymentTxnMainEntity::getOrderId)
                .last("FETCH FIRST " + Math.max(limit, 1) + " ROWS ONLY"));
    }

    private int normalizedMaxTransactionsPerRun() {
        return Math.max(maxTransactionsPerRun, 1);
    }

    private void markQueued(String transactionId) {
        PaymentTxnMainEntity update = new PaymentTxnMainEntity();
        update.setPaymentStatus(PaymentStatusEnum.QUEUED.getCode());
        update.setStatusReason(StatusReasonEnum.MQ_SENT.getCode());
        update.setLastDispatchTime(new Date());
        int updated = txnMainMapper.update(update, new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getTransactionId, transactionId)
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnMainEntity::getPaymentStatus, PaymentStatusEnum.PENDING.getCode()));
        if (updated != 1) {
            throw new IllegalStateException("Failed to mark transaction as QUEUED: transactionId=" + transactionId
                    + ", updatedRows=" + updated);
        }
    }

    private void advancePointer(String batchId, Integer orderId) {
        PaymentBatchHdrEntity update = new PaymentBatchHdrEntity();
        update.setMqSendPointer(orderId);
        int updated = batchHdrMapper.update(update, new LambdaUpdateWrapper<PaymentBatchHdrEntity>()
                .eq(PaymentBatchHdrEntity::getBatchId, batchId)
                .eq(PaymentBatchHdrEntity::getIsDeleted, NOT_DELETED));
        if (updated != 1) {
            throw new IllegalStateException("Failed to advance MQ send pointer: batchId=" + batchId
                    + ", orderId=" + orderId + ", updatedRows=" + updated);
        }
    }
}
