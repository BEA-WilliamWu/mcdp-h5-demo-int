package com.bea.payment.bulk.internal.flow.util;


import com.bea.payment.bulk.model.entity.FlowControlParamEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * FlowControlParamMergeUtils
 *
 * 参数合并工具类。
 *
 * 合并规则：
 * - 同一 PROFILE_ID + PARAM_KEY
 * - 取 OBJECT_VERSION_NUMBER 最大的一条
 */
public final class FlowControlParamMergeUtils {

    private FlowControlParamMergeUtils() {
    }

    public static Map<Long, Map<String, String>> mergeByProfile(
            List<FlowControlParamEntity> params
    ) {

        Map<Long, Map<String, FlowControlParamEntity>> temp = new HashMap<>();

        for (FlowControlParamEntity param : params) {

            Long profileId = param.getProfileId();
            String paramKey = param.getParamKey();

            temp.computeIfAbsent(profileId, k -> new HashMap<>());

            Map<String, FlowControlParamEntity> paramMap =
                    temp.get(profileId);

            FlowControlParamEntity existing = paramMap.get(paramKey);
            if (existing == null) {
                paramMap.put(paramKey, param);
                continue;
            }

            long existingVersion =
                    Optional.ofNullable(existing.getObjectVersionNumber())
                            .orElse(0L);
            long currentVersion =
                    Optional.ofNullable(param.getObjectVersionNumber())
                            .orElse(0L);

            if (currentVersion > existingVersion) {
                paramMap.put(paramKey, param);
            }
        }

        Map<Long, Map<String, String>> result = new HashMap<>();

        for (Map.Entry<Long, Map<String, FlowControlParamEntity>> entry
                : temp.entrySet()) {

            Map<String, String> valueMap = new HashMap<>();
            for (FlowControlParamEntity p : entry.getValue().values()) {
                valueMap.put(p.getParamKey(), p.getParamValue());
            }
            result.put(entry.getKey(), valueMap);
        }

        return result;
    }
}