package com.bea.payment.bulk.internal.flow.worker;

import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.bg3.Bg3WorkerMessageHandler;
import com.bea.payment.bulk.internal.chats.ChatsWorkerMessageHandler;
import com.bea.payment.bulk.internal.eph.EphWorkerMessageHandler;
import com.bea.payment.bulk.internal.flow.mq.MqMessage;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * MQ Worker delivery 的默认下游处理器。
 *
 * <p>该处理器只负责把本地已接受且已 ACK 的 MQ 消息路由到现有 BG3/EPH handler。
 * 业务状态持久化仍由下游执行服务负责。</p>
 */
@Service
@ConditionalOnProperty(prefix = "pe.flow.mq.worker", name = "real-processor-enabled", havingValue = "true")
public class MqDefaultTransactionProcessor implements MqTransactionProcessor {

    private final ObjectProvider<Bg3WorkerMessageHandler> bg3HandlerProvider;
    private final ObjectProvider<EphWorkerMessageHandler> ephHandlerProvider;
    private final ObjectProvider<ChatsWorkerMessageHandler> chatsHandlerProvider;

    public MqDefaultTransactionProcessor(ObjectProvider<Bg3WorkerMessageHandler> bg3HandlerProvider,
            ObjectProvider<EphWorkerMessageHandler> ephHandlerProvider,
            ObjectProvider<ChatsWorkerMessageHandler> chatsHandlerProvider) {
        this.bg3HandlerProvider = Objects.requireNonNull(bg3HandlerProvider, "bg3HandlerProvider must not be null");
        this.ephHandlerProvider = Objects.requireNonNull(ephHandlerProvider, "ephHandlerProvider must not be null");
        this.chatsHandlerProvider = Objects.requireNonNull(chatsHandlerProvider, "chatsHandlerProvider must not be null");
    }

    @Override
    public void process(String txType, MqMessage message) {
        Objects.requireNonNull(message, "message must not be null");
        if (TransactionTypeEnum.INTERNAL.getCode().equalsIgnoreCase(txType)) {
            processWith(message, bg3Handler()::handle);
            return;
        }
        if (TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(txType)) {
            processWith(message, ephHandler()::handle);
            return;
        }
        if (TransactionTypeEnum.CHATS.getCode().equalsIgnoreCase(txType)) {
            processWith(message, chatsHandler()::handle);
            return;
        }
        throw new IllegalArgumentException("Unsupported IBM MQ processor transactionType: " + txType);
    }

    private void processWith(MqMessage message, DownstreamHandler handler) {
        handler.handle(message);
    }

    private Bg3WorkerMessageHandler bg3Handler() {
        Bg3WorkerMessageHandler handler = bg3HandlerProvider.getIfAvailable();
        if (handler == null) {
            throw new IllegalStateException("BG3 handler is not available for IBM MQ processor");
        }
        return handler;
    }

    private EphWorkerMessageHandler ephHandler() {
        EphWorkerMessageHandler handler = ephHandlerProvider.getIfAvailable();
        if (handler == null) {
            throw new IllegalStateException("EPH handler is not available for IBM MQ processor");
        }
        return handler;
    }

    private ChatsWorkerMessageHandler chatsHandler() {
        ChatsWorkerMessageHandler handler = chatsHandlerProvider.getIfAvailable();
        if (handler == null) {
            throw new IllegalStateException("CHATS handler is not available for IBM MQ processor");
        }
        return handler;
    }

    @FunctionalInterface
    private interface DownstreamHandler {

        void handle(MqMessage message);
    }
}
