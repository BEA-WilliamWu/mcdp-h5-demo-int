package com.bea.payment.bulk.internal.flow.worker;

import com.bea.payment.bulk.internal.flow.mq.MqMessage;

/**
 * MQ Worker delivery 的下游处理端口。
 *
 * <p>Worker 调用该端口前已经 ACK MQ。实现类必须通过 DB 更新、查询补偿或人工处理
 * 闭合业务状态；这里抛出的异常不会触发 MQ 重投。</p>
 */
public interface MqTransactionProcessor {

    void process(String txType, MqMessage message);
}
