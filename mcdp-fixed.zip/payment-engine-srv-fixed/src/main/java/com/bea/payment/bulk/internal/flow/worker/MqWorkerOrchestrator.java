package com.bea.payment.bulk.internal.flow.worker;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.constants.StatusReasonEnum;
import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.internal.flow.mq.MqMessage;
import com.bea.payment.bulk.internal.flow.mq.MqQueueProperties;
import com.bea.payment.bulk.internal.flow.mq.MqRoutingService;
import com.bea.payment.bulk.internal.flow.mq.MqInboundDelivery;
import com.bea.payment.bulk.internal.flow.mq.MqMetrics;
import com.bea.payment.bulk.internal.flow.mq.MqProperties;
import com.bea.payment.bulk.internal.flow.mq.MqReceiveClient;
import com.bea.payment.bulk.internal.flow.ratelimit.TransactionTypeRateLimiterService;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * IBM MQ 生产 Worker 编排器。
 *
 * <p>ACK 边界位于调用下游前一刻。Worker 先完成所有本地门禁，将交易标记为
 * PROCESSING，随后 ACK MQ，最后才调用下游。如果 ACK 失败，则不会调用下游。</p>
 */
@Service
@ConditionalOnProperty(prefix = "pe.flow.mq", name = "enabled", havingValue = "true")
@ConditionalOnProperty(prefix = "pe.flow.mq.consumer", name = "enabled", havingValue = "true")
@ConditionalOnProperty(prefix = "pe.flow.mq.worker", name = "enabled", havingValue = "true")
public class MqWorkerOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(MqWorkerOrchestrator.class);

    private static final String NOT_DELETED = "N";

    private final RedissonClient redisson;
    private final MqReceiveClient receiveClient;
    private final PaymentTxnMainMapper txnMainMapper;
    private final TransactionTypeRateLimiterService rateLimiterService;
    private final MqQueueProperties queueProperties;
    private final MqRoutingService routingService;
    private final MqProperties mqProperties;
    private final MqMetrics metrics;
    private final MqTransactionProcessor transactionProcessor;

    public MqWorkerOrchestrator(RedissonClient redisson,
            MqReceiveClient receiveClient,
            PaymentTxnMainMapper txnMainMapper,
            TransactionTypeRateLimiterService rateLimiterService,
            MqQueueProperties queueProperties,
            MqRoutingService routingService,
            MqProperties mqProperties,
            MqMetrics metrics,
            MqTransactionProcessor transactionProcessor) {
        this.redisson = Objects.requireNonNull(redisson, "redisson must not be null");
        this.receiveClient = Objects.requireNonNull(receiveClient, "receiveClient must not be null");
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.rateLimiterService = Objects.requireNonNull(rateLimiterService, "rateLimiterService must not be null");
        this.queueProperties = Objects.requireNonNull(queueProperties, "queueProperties must not be null");
        this.routingService = Objects.requireNonNull(routingService, "routingService must not be null");
        this.mqProperties = Objects.requireNonNull(mqProperties, "mqProperties must not be null");
        this.metrics = Objects.requireNonNull(metrics, "metrics must not be null");
        this.transactionProcessor = Objects.requireNonNull(transactionProcessor,
                "transactionProcessor must not be null");
    }

    @Scheduled(fixedDelayString = "${pe.flow.worker.internal.fixed-delay:200}")
    public void consumeInternalScheduled() {
        consumeInternalOnce();
    }

    @Scheduled(fixedDelayString = "${pe.flow.worker.fps.fixed-delay:1000}")
    public void consumeFpsScheduled() {
        consumeFpsOnce();
    }

    @Scheduled(fixedDelayString = "${pe.flow.worker.ebk.fixed-delay:1000}")
    public void consumeChatsScheduled() {
        consumeChatsOnce();
    }

    public boolean consumeInternalOnce() {
        return consumeOne(TransactionTypeEnum.INTERNAL.getCode(),
                queueProperties.getInternalPriorityQueue(),
                queueProperties.getInternalNormalQueue());
    }

    public boolean consumeFpsOnce() {
        return consumeOne(TransactionTypeEnum.FPS.getCode(),
                queueProperties.getFpsPriorityQueue(),
                queueProperties.getFpsNormalQueue());
    }

    public boolean consumeChatsOnce() {
        return consumeOne(TransactionTypeEnum.CHATS.getCode(),
                queueProperties.getChatsPriorityQueue(),
                queueProperties.getChatsNormalQueue());
    }

    /**
     * 为单个交易类型最多消费一条消息。
     *
     * <p>返回值语义刻意保持很窄：{@code true} 表示本轮轮询中已有一条 delivery
     * 被接收并到达最终 Worker 决策；{@code false} 表示没有消息、交易类型锁被其他
     * Worker 持有，或收到的 delivery 在调用下游前被安全拒收，并交还 MQ 重投/BOQ 处理。</p>
     */
    boolean consumeOne(String txType, String priorityQueue, String normalQueue) {
        String normalizedTxType = normalize(txType);
        RLock executeLock = redisson.getLock("lock:worker:execute:" + normalizedTxType);
        if (!tryLock(executeLock)) {
            return false;
        }

        try {
            // ONLINE 是优先队列；只有 ONLINE 为空时才检查 NORMAL。
            Optional<MqInboundDelivery> delivery = receiveClient.receiveOne(priorityQueue);
            if (delivery.isEmpty()) {
                delivery = receiveClient.receiveOne(normalQueue);
            }
            if (delivery.isEmpty()) {
                return false;
            }
            MqInboundDelivery currentDelivery = delivery.get();
            try {
                return processDelivery(normalizedTxType, currentDelivery);
            } finally {
                closeUncompletedDelivery(currentDelivery);
            }
        } finally {
            unlockIfHeld(executeLock);
        }
    }

    /**
     * 最外层兜底保护，避免未来新增分支时忘记 ACK 或 recover，导致队列消费者一直停在 in-flight。
     */
    private void closeUncompletedDelivery(MqInboundDelivery delivery) {
        if (!delivery.isCompleted()) {
            delivery.close();
        }
    }

    /**
     * 对一条已接收 delivery 执行全部下游调用前门禁。
     *
     * <p>主流程按固定顺序推进：</p>
     *
     * <ol>
     *   <li>校验 MQ 实际队列与消息路由是否匹配，不匹配则 recover，不 ACK。</li>
     *   <li>读取 DB 交易状态。只有 {@code QUEUED} 继续；{@code PROCESSING} redelivery 转人工并 recover；
     *       其他状态或交易不存在直接 ACK 跳过。</li>
     *   <li>校验 DB 交易与 MQ 消息是否一致，不一致则 recover，不 ACK。</li>
     *   <li>申请交易类型限流许可。失败时保持 {@code QUEUED}，recover 交给 MQ 重投。</li>
     *   <li>获取付款账号锁。失败时保持 {@code QUEUED}，recover 交给 MQ 重投。</li>
     *   <li>CAS 将交易从 {@code QUEUED} 标记为 {@code PROCESSING}。</li>
     *   <li>CAS 成功后先 ACK MQ，再调用下游 processor；ACK 失败不会调用下游。</li>
     * </ol>
     *
     * <p>本方法只通过 {@link WorkerDecision} 表达最终动作，真正 ACK、recover 和下游调用统一在
     * {@link #completeDelivery(String, MqInboundDelivery, MqMessage, WorkerDecision)} 中执行。</p>
     */
    private boolean processDelivery(String txType, MqInboundDelivery delivery) {
        try {
            MqMessage message = delivery.getMessage();
            String transactionId = message.getTransactionId();

            // 第 1 步：先只看 MQ 消息和实际队列，挡住发错队列或交易类型不匹配的消息。
            WorkerDecision decision = routeDecision(txType, delivery, message, transactionId);
            if (decision.isFinal()) {
                return completeDelivery(txType, delivery, message, decision);
            }

            // 第 2 步：DB 是事实源。交易必须仍为 QUEUED，Worker 才能继续尝试执行。
            PaymentTxnMainEntity txn = findByTransactionId(transactionId);
            decision = currentStatusDecision(txn, transactionId);
            if (decision.isFinal()) {
                return completeDelivery(txType, delivery, message, decision);
            }

            // 第 3 步：交叉校验 MQ 消息与 DB 交易，避免消息污染导致调错下游或调错账号。
            decision = dbMessageConsistencyDecision(txType, delivery, message, txn, transactionId);
            if (decision.isFinal()) {
                return completeDelivery(txType, delivery, message, decision);
            }

            // 第 4 步：限流在账号锁和 PROCESSING 前执行；未获许可时交易仍保持 QUEUED。
            decision = ratePermitDecision(txType, transactionId);
            if (decision.isFinal()) {
                return completeDelivery(txType, delivery, message, decision);
            }

            // 第 5 步：同一付款账号不能并发调下游。锁 key 使用账号 hash，避免暴露原始账号。
            RLock accountLock = redisson.getLock("lock:account:" + payerAccountKey(txn.getPayerAccountNo()));
            decision = accountLockDecision(transactionId, accountLock);
            if (decision.isFinal()) {
                return completeDelivery(txType, delivery, message, decision);
            }

            try {
                // 第 6/7 步：声明 PROCESSING 执行权；成功后统一完成 ACK 并进入下游调用。
                return completeDelivery(txType, delivery, message, processingClaimDecision(transactionId));
            } finally {
                // 下游调用完成或抛错后释放账号锁；ACK 后异常不再依赖 MQ 重投闭环。
                unlockIfHeld(accountLock);
            }
        } catch (RuntimeException ex) {
            // 兜底异常：如果 ACK 尚未完成，close 会触发 recover；如果已 ACK，close 是 no-op。
            recordDecision(txType, delivery, MqMetrics.RESULT_FAILED,
                    MqMetrics.WORKER_REASON_EXCEPTION);
            delivery.close();
            throw ex;
        }
    }

    /**
     * 校验 Worker 是否从路由规则期望的队列收到消息。
     *
     * <p>这里只做 MQ 层路由判断，不查 DB。返回 {@code CONTINUE} 表示可以继续查库；
     * 返回 {@code RECOVER} 表示消息发错队列或交易类型不匹配，应保持未 ACK，交由 MQ backout/DLQ。</p>
     */
    private WorkerDecision routeDecision(String txType, MqInboundDelivery delivery,
            MqMessage message, String transactionId) {
        if (isExpectedRoute(txType, delivery, message)) {
            return WorkerDecision.continueProcessing();
        }
        log.error("[IBM-MQ-WORKER] Message route mismatch, delivery left unacked: "
                        + "queueName={}, transactionId={}, messageTxType={}, messageChannel={}, workerTxType={}",
                delivery.getQueueName(), transactionId, message.getTransactionType(),
                message.getChannel(), txType);
        return WorkerDecision.recover(MqMetrics.WORKER_REASON_ROUTE_MISMATCH);
    }

    /**
     * 根据当前 DB 状态决定是否继续执行、ACK 跳过，或 recover 交由 MQ backout/DLQ。
     *
     * <p>以当前代码行为为准：</p>
     *
     * <ul>
     *   <li>{@code QUEUED}：继续后续本地门禁。</li>
     *   <li>{@code PROCESSING}：视为 redelivery，标记人工核对后 recover，不重复调用下游。</li>
     *   <li>其他状态或交易不存在：ACK 并跳过，避免无意义反复重投。</li>
     * </ul>
     */
    private WorkerDecision currentStatusDecision(PaymentTxnMainEntity txn, String transactionId) {
        if (isQueued(txn)) {
            return WorkerDecision.continueProcessing();
        }

        if (txn == null || PaymentStatusEnum.PENDING.getCode().equals(txn.getPaymentStatus())) {
            // Scanner publishes before it can atomically persist QUEUED. Treat the short visibility window as
            // retryable instead of acknowledging and permanently losing the only dispatch trigger.
            log.info("[IBM-MQ-WORKER] Transaction is not visible as QUEUED yet; recovering delivery: "
                    + "transactionId={}, status={}", transactionId, txn == null ? "NOT_FOUND" : txn.getPaymentStatus());
            return WorkerDecision.recover(MqMetrics.WORKER_REASON_TRANSACTION_NOT_QUEUED);
        }

        if (isProcessing(txn)) {
            // Duplicate delivery is expected in an at-least-once dispatch design. The original execution owns
            // PROCESSING; stale executions are handled by ProcessingRecoveryService rather than this duplicate.
            log.info("[IBM-MQ-WORKER] Duplicate delivery for PROCESSING transaction; acking duplicate: "
                    + "transactionId={}", transactionId);
            return WorkerDecision.ackOnly(MqMetrics.WORKER_REASON_PROCESSING_REDELIVERY);
        }

        // 不存在的交易与非 QUEUED 交易处理方式一致：Worker 不能仅凭 MQ 消息创建或执行
        // 业务状态，因此 ACK 以避免反复噪音，并跳过下游调用。
        log.warn("[IBM-MQ-WORKER] Transaction not in QUEUED status, acking without downstream call: "
                        + "transactionId={}, status={}",
                transactionId, txn == null ? "NOT_FOUND" : txn.getPaymentStatus());
        return WorkerDecision.ackOnly(MqMetrics.WORKER_REASON_TRANSACTION_NOT_QUEUED);
    }

    /**
     * 在任何不可逆下游动作前，确保 MQ 消息元数据仍与数据库交易一致。
     *
     * <p>DB 和 MQ 必须在交易类型、渠道、队列路由上完全一致。任何不一致都不 ACK，
     * 因为这类消息可能是投递或数据污染问题，不能进入下游。</p>
     */
    private WorkerDecision dbMessageConsistencyDecision(String txType, MqInboundDelivery delivery,
            MqMessage message, PaymentTxnMainEntity txn, String transactionId) {
        if (isDbConsistentWithMessage(txType, delivery, message, txn)) {
            return WorkerDecision.continueProcessing();
        }
        log.error("[IBM-MQ-WORKER] Transaction data mismatch, delivery left unacked: "
                        + "queueName={}, transactionId={}, messageTxType={}, messageChannel={}, "
                        + "dbTxType={}, dbChannel={}, workerTxType={}",
                delivery.getQueueName(), transactionId, message.getTransactionType(),
                message.getChannel(), txn.getTransactionType(), txn.getChannel(), txType);
        return WorkerDecision.recover(MqMetrics.WORKER_REASON_DB_MESSAGE_MISMATCH);
    }

    /**
     * 在获取账户锁前，先预留一个交易类型级限流令牌。
     *
     * <p>限流失败不会修改 DB，也不会 ACK。交易保持 {@code QUEUED}，后续由 MQ redelivery 再尝试。</p>
     */
    private WorkerDecision ratePermitDecision(String txType, String transactionId) {
        String permitFailureReason = acquirePermitFailureReason(txType);
        if (permitFailureReason == null) {
            return WorkerDecision.continueProcessing();
        }
        log.warn("[IBM-MQ-WORKER] Rate limit permit unavailable, delivery left unacked: "
                        + "transactionId={}, txType={}, reason={}",
                transactionId, txType, permitFailureReason);
        return WorkerDecision.recover(permitFailureReason);
    }

    /**
     * 限流通过后获取付款账号锁。
     *
     * <p>账号锁只保护同账号下游调用不并发，不承担批次内全局排序职责。锁失败时不 ACK，
     * 让 MQ 在当前账号任务完成后重投。</p>
     */
    private WorkerDecision accountLockDecision(String transactionId, RLock accountLock) {
        String accountLockFailureReason = accountLockFailureReason(accountLock);
        if (accountLockFailureReason == null) {
            return WorkerDecision.continueProcessing();
        }
        log.warn("[IBM-MQ-WORKER] Account lock unavailable, delivery left unacked: "
                        + "transactionId={}, reason={}",
                transactionId, accountLockFailureReason);
        return WorkerDecision.recover(accountLockFailureReason);
    }

    /**
     * 调用下游前的最后一道本地门禁。
     *
     * <p>CAS 更新是数据库侧最后的所有权检查。成功后立即 ACK MQ，然后调用下游。
     * 如果 ACK 抛错，则不调用下游。如果 CAS 失败，表示已有其他执行方移动了交易状态，
     * 当前 delivery 会按重复/并发噪音 ACK。</p>
     *
     * <p>注意：本方法只返回决策，不直接 ACK，也不调用下游。</p>
     */
    private WorkerDecision processingClaimDecision(String transactionId) {
        if (!markProcessing(transactionId)) {
            log.warn("[IBM-MQ-WORKER] Failed to mark PROCESSING, acking duplicate/concurrent delivery: "
                    + "transactionId={}", transactionId);
            return WorkerDecision.ackOnly(MqMetrics.WORKER_REASON_MARK_PROCESSING_CONFLICT);
        }

        return WorkerDecision.ackThenProcess(MqMetrics.WORKER_REASON_DOWNSTREAM_COMPLETED);
    }

    /**
     * 执行最终 MQ 完成动作，并在需要时调用下游。
     *
     * <p>这是全类唯一集中执行 ACK/recover 的地方：</p>
     *
     * <ul>
     *   <li>{@code ACK_ONLY}：ACK MQ，不调用下游。</li>
     *   <li>{@code RECOVER}：不 ACK，调用 {@code delivery.close()} 触发 JMS recover。</li>
     *   <li>{@code ACK_THEN_PROCESS}：先 ACK MQ；ACK 成功后才调用下游 processor。</li>
     * </ul>
     *
     * <p>返回值沿用 {@code consumeOne} 的旧语义：ACK 或已进入下游处理返回 {@code true}；
     * fail-closed recover 返回 {@code false}。</p>
     */
    private boolean completeDelivery(String txType, MqInboundDelivery delivery,
            MqMessage message, WorkerDecision decision) {
        switch (decision.action()) {
            case CONTINUE -> throw new IllegalStateException("Worker decision is not final");
            case ACK_ONLY -> {
                // 消息已不需要执行或无法安全执行但可视为噪音，直接 ACK 跳过。
                delivery.ack();
                recordDecision(txType, delivery, MqMetrics.RESULT_SUCCESS, decision.reason());
                return true;
            }
            case RECOVER -> {
                // 本地门禁未通过：不 ACK，让 MQ 根据 redelivery/backout/BOQ 规则处理。
                recordDecision(txType, delivery, MqMetrics.RESULT_FAILED, decision.reason());
                delivery.close();
                return false;
            }
            case ACK_THEN_PROCESS -> {
                // ACK 边界：所有可提前检查的本地异常都已经检查完毕。
                // 只有 MQ 接受 ACK 后才调用下游。
                delivery.ack();
                transactionProcessor.process(txType, message);
                recordDecision(txType, delivery, MqMetrics.RESULT_SUCCESS, decision.reason());
                return true;
            }
        }
        throw new IllegalStateException("Unsupported worker decision action: " + decision.action());
    }

    /**
     * Worker 对当前 delivery 的最终动作。
     */
    private enum DeliveryAction {
        /**
         * 当前检查通过，继续执行下一道门禁。
         */
        CONTINUE,

        /**
         * ACK MQ，但不调用下游。用于终态、交易不存在、CAS 冲突等无需重投场景。
         */
        ACK_ONLY,

        /**
         * 不 ACK，触发 JMS recover。用于路由错误、DB/MQ 不一致、限流/账号锁失败等 fail-closed 场景。
         */
        RECOVER,

        /**
         * ACK MQ 后调用下游。只有本地门禁全部通过且 {@code QUEUED -> PROCESSING} CAS 成功才使用。
         */
        ACK_THEN_PROCESS
    }

    /**
     * 一条 delivery 在当前 Worker 中的处理决策。
     *
     * @param action 最终动作
     * @param reason 低基数 metrics 原因；{@code CONTINUE} 时为空
     */
    private record WorkerDecision(DeliveryAction action, String reason) {

        /**
         * 当前门禁通过，继续进入下一步。
         */
        private static WorkerDecision continueProcessing() {
            return new WorkerDecision(DeliveryAction.CONTINUE, null);
        }

        /**
         * ACK 后跳过下游。
         */
        private static WorkerDecision ackOnly(String reason) {
            return new WorkerDecision(DeliveryAction.ACK_ONLY, reason);
        }

        /**
         * 不 ACK，交还 MQ 重投或 BOQ/DLQ。
         */
        private static WorkerDecision recover(String reason) {
            return new WorkerDecision(DeliveryAction.RECOVER, reason);
        }

        /**
         * ACK 成功后调用下游。
         */
        private static WorkerDecision ackThenProcess(String reason) {
            return new WorkerDecision(DeliveryAction.ACK_THEN_PROCESS, reason);
        }

        /**
         * 是否已经形成最终动作；非最终动作表示主流程应继续下一道门禁。
         */
        private boolean isFinal() {
            return action != DeliveryAction.CONTINUE;
        }
    }

    /**
     * 按交易号读取 MAIN 交易行。
     *
     * <p>Worker 只相信 DB 事实源；MQ 消息只提供查库和路由校验所需的最小字段。</p>
     */
    private PaymentTxnMainEntity findByTransactionId(String transactionId) {
        return txnMainMapper.selectOne(new LambdaQueryWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getTransactionId, transactionId)
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .last("FETCH FIRST 1 ROWS ONLY"));
    }

    /**
     * 判断交易是否仍处于可执行的已入队状态。
     */
    private boolean isQueued(PaymentTxnMainEntity txn) {
        return txn != null && PaymentStatusEnum.QUEUED.getCode().equals(txn.getPaymentStatus());
    }

    /**
     * 判断交易是否已经被某个 Worker 置为处理中。
     */
    private boolean isProcessing(PaymentTxnMainEntity txn) {
        return txn != null && PaymentStatusEnum.PROCESSING.getCode().equals(txn.getPaymentStatus());
    }

    /**
     * 仅使用 MQ 消息元数据检查队列路由。DB 一致性会在读取交易行后单独检查。
     *
     * <p>检查内容包括：Worker 当前处理的交易类型是否等于消息交易类型，以及消息按路由规则
     * 应进入的队列是否等于当前实际接收队列。</p>
     */
    private boolean isExpectedRoute(String workerTxType, MqInboundDelivery delivery, MqMessage message) {
        String messageTxType = normalize(message.getTransactionType());
        if (!workerTxType.equals(messageTxType)) {
            return false;
        }
        String expectedQueue = routingService.resolveQueue(message.getTransactionType(), message.getChannel());
        return expectedQueue.equals(delivery.getQueueName());
    }

    /**
     * 交叉检查 DB 状态、MQ 消息体和实际队列，避免看似合法的消息因路由或数据 bug
     * 驱动到错误的下游链路。
     *
     * <p>这里故意重复检查交易类型、渠道和队列：MQ 是执行触发源，DB 是业务事实源，
     * 两边不一致时必须 fail closed。</p>
     */
    private boolean isDbConsistentWithMessage(String workerTxType, MqInboundDelivery delivery,
            MqMessage message, PaymentTxnMainEntity txn) {
        if (!workerTxType.equals(normalize(txn.getTransactionType()))) {
            return false;
        }
        if (!normalize(message.getTransactionType()).equals(normalize(txn.getTransactionType()))) {
            return false;
        }
        if (!normalize(message.getChannel()).equals(normalize(txn.getChannel()))) {
            return false;
        }
        String expectedQueue = routingService.resolveQueue(txn.getTransactionType(), txn.getChannel());
        return expectedQueue.equals(delivery.getQueueName());
    }

    /**
     * 通过 CAS 更新声明业务执行权。只有 QUEUED 交易可以移动到 PROCESSING，
     * 因此重复 delivery 或人工/运维侧状态变化不会被覆盖。
     *
     * <p>成功时同时写入 {@code WORKER_CLAIMED} 和执行开始时间，并递增执行尝试次数。</p>
     */
    private boolean markProcessing(String transactionId) {
        PaymentTxnMainEntity update = new PaymentTxnMainEntity();
        update.setPaymentStatus(PaymentStatusEnum.PROCESSING.getCode());
        update.setStatusReason(StatusReasonEnum.WORKER_CLAIMED.getCode());
        update.setExecutionStartTime(new Date());
        int updated = txnMainMapper.update(update, new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                .setSql("EXECUTION_ATTEMPT_COUNT = NVL(EXECUTION_ATTEMPT_COUNT, 0) + 1")
                .eq(PaymentTxnMainEntity::getTransactionId, transactionId)
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnMainEntity::getPaymentStatus, PaymentStatusEnum.QUEUED.getCode()));
        return updated == 1;
    }

    /**
     * 记录 Worker 决策指标。
     */
    private void recordDecision(String txType, MqInboundDelivery delivery, String result, String reason) {
        metrics.recordWorkerDecision(txType, delivery.getQueueName(), result, reason);
    }

    /**
     * 成功返回 null；失败返回低基数指标原因，用于说明为什么 delivery 需要保持未 ACK。
     *
     * <p>限流服务异常也按 fail-closed 处理，避免 Redis 或配置异常时继续压下游。</p>
     */
    private String acquirePermitFailureReason(String txType) {
        Duration wait = mqProperties.getWorker().getPermitWait();
        long waitMillis = wait == null || wait.isNegative() ? 0L : wait.toMillis();
        try {
            if (rateLimiterService.tryAcquire(txType, waitMillis, TimeUnit.MILLISECONDS)) {
                return null;
            }
            return MqMetrics.WORKER_REASON_RATE_LIMITED;
        } catch (RuntimeException ex) {
            log.error("[IBM-MQ-WORKER] Rate limiter check failed; delivery will remain unacked: txType={}",
                    txType, ex);
            return MqMetrics.WORKER_REASON_RATE_LIMITER_ERROR;
        }
    }

    /**
     * 成功返回 null；失败返回账号锁未命中或异常的指标原因。
     *
     * <p>中断时恢复线程中断标志，并返回锁异常原因，让上层 recover 当前 delivery。</p>
     */
    private String accountLockFailureReason(RLock accountLock) {
        try {
            if (accountLock.tryLock(0, TimeUnit.SECONDS)) {
                return null;
            }
            return MqMetrics.WORKER_REASON_ACCOUNT_LOCKED;
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return MqMetrics.WORKER_REASON_ACCOUNT_LOCK_ERROR;
        } catch (RuntimeException ex) {
            log.error("[IBM-MQ-WORKER] Account lock check failed; delivery will remain unacked", ex);
            return MqMetrics.WORKER_REASON_ACCOUNT_LOCK_ERROR;
        }
    }

    /**
     * 交易类型级 Worker 锁使用的非阻塞加锁方法。
     *
     * <p>拿不到锁表示同交易类型已经有 Worker 在消费，本轮直接返回空转，不 receive 消息。</p>
     */
    private boolean tryLock(RLock lock) {
        try {
            return lock.tryLock(0, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    /**
     * Redisson 解锁前需要判断当前线程是否持锁。fail-closed 分支可能在拿到锁前返回，
     * 中断或异常路径也不应再抛出第二个 unlock 异常。
     */
    private void unlockIfHeld(RLock lock) {
        if (lock.isHeldByCurrentThread()) {
            lock.unlock();
        }
    }

    /**
     * 将付款账号 hash 后再写入 Redis 锁 key，避免日志或 Redis key 扫描暴露原始账号。
     */
    private String payerAccountKey(String payerAccountNo) {
        String normalized = payerAccountNo == null ? "" : payerAccountNo.trim().toUpperCase(Locale.ROOT);
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return toHex(digest.digest(normalized.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 is not available", ex);
        }
    }

    /**
     * 将字节数组转换为小写十六进制字符串，用作账号锁 key 的稳定摘要。
     */
    private String toHex(byte[] bytes) {
        StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            builder.append(Character.forDigit((value >>> 4) & 0x0F, 16));
            builder.append(Character.forDigit(value & 0x0F, 16));
        }
        return builder.toString();
    }

    /**
     * 标准化交易类型和渠道等短代码，避免大小写差异影响比较。
     */
    private String normalize(String txType) {
        return txType == null ? "" : txType.toUpperCase(Locale.ROOT);
    }
}
