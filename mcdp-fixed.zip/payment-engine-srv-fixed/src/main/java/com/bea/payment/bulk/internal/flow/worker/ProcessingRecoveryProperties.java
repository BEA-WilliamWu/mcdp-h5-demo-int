package com.bea.payment.bulk.internal.flow.worker;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Configuration for operational marking of long-running PROCESSING transactions.
 */
@Component
@ConfigurationProperties(prefix = "pe.flow.processing-recovery")
@Getter
@Setter
public class ProcessingRecoveryProperties {

    /**
     * Enables the scheduled marker scan.
     */
    private boolean enabled = true;

    /**
     * A PROCESSING transaction older than this value is marked for manual review.
     */
    private Duration timeout = Duration.ofMinutes(30);

    /**
     * Maximum rows to inspect per run.
     */
    private int maxRowsPerRun = 100;
}
