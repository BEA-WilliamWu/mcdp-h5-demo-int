package com.bea.payment.bulk.internal.flow.worker;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.ErrorSourceEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.constants.StatusReasonEnum;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.service.PaymentBatchStatusService;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Marks stale PROCESSING transactions for operations review without replaying payment execution.
 */
@Service
@ConditionalOnProperty(prefix = "pe.flow.processing-recovery", name = "enabled",
        havingValue = "true", matchIfMissing = true)
public class ProcessingRecoveryService {

    public static final String PROCESSING_TIMEOUT_MANUAL_REVIEW = "PROCESSING_TIMEOUT_MANUAL_REVIEW";

    private static final Logger log = LoggerFactory.getLogger(ProcessingRecoveryService.class);
    private static final String NOT_DELETED = "N";
    private static final String RECOVERY_LOCK_KEY = "lock:worker:processing-recovery";

    private final RedissonClient redisson;
    private final PaymentTxnMainMapper txnMainMapper;
    private final ProcessingRecoveryProperties properties;
    private final PaymentBatchStatusService batchStatusService;

    public ProcessingRecoveryService(RedissonClient redisson,
            PaymentTxnMainMapper txnMainMapper,
            ProcessingRecoveryProperties properties,
            PaymentBatchStatusService batchStatusService) {
        this.redisson = Objects.requireNonNull(redisson, "redisson must not be null");
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService,
                "batchStatusService must not be null");
    }

    @Scheduled(fixedDelayString = "${pe.flow.processing-recovery.fixed-delay:60000}")
    public void markTimedOutProcessingScheduled() {
        markTimedOutProcessingOnce();
    }

    public int markTimedOutProcessingOnce() {
        RLock lock = redisson.getLock(RECOVERY_LOCK_KEY);
        if (!tryLock(lock)) {
            return 0;
        }
        try {
            return markTimedOutProcessingLocked();
        } catch (Exception e) {
            log.error("[PROCESSING-RECOVERY] Failed to mark stale transactions", e);
            return 0;
        } finally {
            unlockIfHeld(lock);
        }
    }

    private int markTimedOutProcessingLocked() {
        Date cutoff = cutoffTime();
        List<PaymentTxnMainEntity> candidates = txnMainMapper.selectList(
                new LambdaQueryWrapper<PaymentTxnMainEntity>()
                        .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                        .eq(PaymentTxnMainEntity::getPaymentStatus, PaymentStatusEnum.PROCESSING.getCode())
                        .le(PaymentTxnMainEntity::getExecutionStartTime, cutoff)
                        .orderByAsc(PaymentTxnMainEntity::getExecutionStartTime)
                        .last("FETCH FIRST " + positiveMaxRows() + " ROWS ONLY"));
        int marked = 0;
        for (PaymentTxnMainEntity txn : candidates) {
            if (txn.getLastErrorCode() == null || txn.getLastErrorCode().isBlank()) {
                PaymentTxnMainEntity update = new PaymentTxnMainEntity();
                update.setPaymentStatus(PaymentStatusEnum.MANUAL_REVIEW.getCode());
                update.setLastErrorCode(PROCESSING_TIMEOUT_MANUAL_REVIEW);
                update.setStatusReason(StatusReasonEnum.PROCESSING_TIMEOUT.getCode());
                update.setErrorSource(ErrorSourceEnum.OPS.getCode());
                update.setManualReviewReason(PROCESSING_TIMEOUT_MANUAL_REVIEW);
                update.setManualReviewTime(new Date());
                update.setExecutionEndTime(new Date());
                int updated = txnMainMapper.update(update, new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                        .eq(PaymentTxnMainEntity::getTxnId, txn.getTxnId())
                        .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                        .eq(PaymentTxnMainEntity::getPaymentStatus, PaymentStatusEnum.PROCESSING.getCode())
                        .le(PaymentTxnMainEntity::getExecutionStartTime, cutoff));
                if (updated == 1) {
                    marked++;
                    batchStatusService.refreshIfBatchTerminal(txn.getBatchId());
                    log.warn("[PROCESSING-RECOVERY] PROCESSING transaction requires operational review: "
                                    + "transactionId={}, batchId={}, txType={}, startedAt={}, lastErrorCode={}",
                            txn.getTransactionId(), txn.getBatchId(), txn.getTransactionType(),
                            txn.getExecutionStartTime(), PROCESSING_TIMEOUT_MANUAL_REVIEW);
                }
            }
        }
        if (marked > 0) {
            log.warn("[PROCESSING-RECOVERY] Marked {} stale PROCESSING transactions for manual review", marked);
        }
        return marked;
    }

    private Date cutoffTime() {
        Duration timeout = properties.getTimeout();
        if (timeout == null || timeout.isNegative() || timeout.isZero()) {
            timeout = Duration.ofMinutes(30);
        }
        return Date.from(Instant.now().minus(timeout));
    }

    private int positiveMaxRows() {
        return properties.getMaxRowsPerRun() <= 0 ? 100 : properties.getMaxRowsPerRun();
    }

    private boolean tryLock(RLock lock) {
        try {
            return lock.tryLock(0, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private void unlockIfHeld(RLock lock) {
        if (lock.isHeldByCurrentThread()) {
            lock.unlock();
        }
    }
}
