package com.bea.payment.bulk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
    public interface BatchIdSequenceMapper extends BaseMapper<Void> {
        @Select("SELECT SEQ_IPE_BATCH_ID.NEXTVAL FROM DUAL")
        long nextVal();
    }