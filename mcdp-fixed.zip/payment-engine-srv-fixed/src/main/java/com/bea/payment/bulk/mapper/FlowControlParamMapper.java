package com.bea.payment.bulk.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bea.payment.bulk.model.entity.FlowControlParamEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * Flow Control Parameter Mapper
 */
@Mapper
public interface FlowControlParamMapper
        extends BaseMapper<FlowControlParamEntity> {
}