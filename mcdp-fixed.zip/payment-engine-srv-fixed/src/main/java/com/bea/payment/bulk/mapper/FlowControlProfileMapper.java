package com.bea.payment.bulk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bea.payment.bulk.model.entity.FlowControlProfileEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * Flow Control Profile Mapper
 */
@Mapper
public interface FlowControlProfileMapper
        extends BaseMapper<FlowControlProfileEntity> {
}