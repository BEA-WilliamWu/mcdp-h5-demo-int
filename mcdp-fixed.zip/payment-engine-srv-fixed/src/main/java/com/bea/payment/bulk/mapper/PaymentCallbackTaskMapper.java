package com.bea.payment.bulk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bea.payment.bulk.model.entity.PaymentCallbackTaskEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;

@Mapper
public interface PaymentCallbackTaskMapper extends BaseMapper<PaymentCallbackTaskEntity> {

    /*
     * 多 Pod 领取 callback task 的核心 SQL：
     * - 只拿 PENDING/RETRY 到期任务，或超时的 IN_PROGRESS 任务；
     * - 已达到最大尝试次数的任务不再领取；
     * - EXISTS 再确认 MAIN 已终态，防止历史脏 task 空转；
     * - FOR UPDATE SKIP LOCKED 让多个 Pod 自动跳过彼此锁住的行。
     */
    @Select("""
            SELECT T.*
            FROM IPE_PAYMENT_CALLBACK_TASK T
            WHERE T.IS_DELETED = 'N'
              AND NVL(T.ATTEMPT_COUNT, 0) < NVL(T.MAX_ATTEMPTS, 1)
              AND (
                    (T.CALLBACK_STATUS IN ('PENDING', 'RETRY') AND T.NEXT_RETRY_TIME <= #{now})
                    OR
                    (T.CALLBACK_STATUS = 'IN_PROGRESS' AND T.LAST_ATTEMPT_TIME <= #{staleCutoff})
                  )
              AND EXISTS (
                    SELECT 1
                    FROM IPE_PAYMENT_TXN_MAIN M
                    WHERE M.TRANSACTION_ID = T.TRANSACTION_ID
                      AND M.IS_DELETED = 'N'
                      AND M.PAYMENT_STATUS IN ('COMPLETED', 'FAILED', 'MANUAL_REVIEW')
                  )
              AND ROWNUM = 1
            FOR UPDATE SKIP LOCKED
            """)
    PaymentCallbackTaskEntity selectOneDueTaskForUpdate(@Param("now") Date now,
            @Param("staleCutoff") Date staleCutoff);
}
