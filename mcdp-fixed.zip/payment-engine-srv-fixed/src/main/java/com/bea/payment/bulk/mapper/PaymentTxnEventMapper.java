package com.bea.payment.bulk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PaymentTxnEventMapper extends BaseMapper<PaymentTxnEventEntity> {
}
