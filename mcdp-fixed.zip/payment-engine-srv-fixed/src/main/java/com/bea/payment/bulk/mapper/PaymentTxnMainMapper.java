package com.bea.payment.bulk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bea.payment.bulk.model.dto.PaymentResultQueryResponse;
import com.bea.payment.bulk.model.dto.PaymentTxnMainEventDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

@Mapper
public interface PaymentTxnMainMapper extends BaseMapper<PaymentTxnMainEntity> {

    @Select("""
        select main.*, event.event_id as eventId,
               event.eph_payee_identification_type as ephPayeeIdentificationType,
               event.eph_payment_source as ephPaymentSource,
               event.eph_needs_status_query as ephNeedsStatusQuery,
               event.eph_query_eligible_time as ephQueryEligibleTime,
               event.eph_query_count as ephQueryCount,
               event.eph_last_query_time as ephLastQueryTime
        from IPE_PAYMENT_TXN_MAIN main
        join IPE_PAYMENT_TXN_EVENT event on event.event_id = (
            select max(candidate.event_id)
            from IPE_PAYMENT_TXN_EVENT candidate
            where candidate.transaction_id = main.transaction_id
              and candidate.is_deleted = #{isDeleted}
              and candidate.eph_needs_status_query = #{needsQuery}
        )
        where main.is_deleted = #{isDeleted}
          and main.transaction_type = #{transactionType}
          and main.payment_status = #{paymentStatus}
          and event.eph_needs_status_query = #{needsQuery}
          and event.eph_query_eligible_time <= #{eligibleCutoff}
          and NVL(event.eph_query_count, 0) < #{maxQueryAttempts}
        order by event.eph_query_eligible_time asc
        FETCH FIRST #{maxQueryPerRun} ROWS ONLY
        """)
    List<PaymentTxnMainEventDTO> selectQueryCandidates(
            @Param("isDeleted") String isDeleted,
            @Param("transactionType") String transactionType,
            @Param("paymentStatus") String paymentStatus,
            @Param("needsQuery") String needsQuery,
            @Param("eligibleCutoff") Date eligibleCutoff,
            @Param("maxQueryAttempts") int maxQueryAttempts,
            @Param("maxQueryPerRun") int maxQueryPerRun);

    @Select("""
        select main.*,
               event.customer_type as customerType,
               event.eph_needs_status_query as ephNeedsStatusQuery
        from IPE_PAYMENT_TXN_MAIN main
        left join IPE_PAYMENT_TXN_EVENT event on event.transaction_id = main.transaction_id
           and event.order_id = #{eventOrderId}
           and event.event_type = 'PAYMENT_ACCEPTED'
           and event.is_deleted = 'N'
        where main.batch_id = #{batchId}
          and main.is_deleted = 'N'
        order by main.order_id
        """)
    List<PaymentTxnMainEventDTO> selectPaymentResultQueryList(@Param("batchId") String batchId,
                                                                  @Param("eventOrderId") Integer eventOrderId);

}
