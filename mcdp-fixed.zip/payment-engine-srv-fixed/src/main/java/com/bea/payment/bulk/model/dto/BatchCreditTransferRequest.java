package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.util.List;

@Schema(name = "BatchCreditTransferRequest",
        description = "Batch credit transfer submission request; a successful response means acceptance and persistence only, not downstream payment completion")
@Getter
@Setter
public class BatchCreditTransferRequest {

    @Schema(description = "Channel code", example = "BCO", allowableValues = {"BCO", "HTH"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String channel;

    @Schema(description = "Unique batch identifier, format CHANNEL(3)+yyyyMMddHHmmss(14)+sequence(6)", example = "BCO20260527103025000001", minLength = 23, maxLength = 23, requiredMode = Schema.RequiredMode.REQUIRED)
    private String batchId;

    @Schema(description = "Channel-side reference", example = "PAYROLL-20260527", maxLength = 64)
    private String channelReference;

    @Schema(description = "Transaction type for the entire batch. FPS requires fps on every detail; INTERNAL enters BG3 and must omit fps", example = "FPS", allowableValues = {"FPS", "CHATS", "INTERNAL"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String transactionType;

    @Schema(description = "Transfer timing; executionDate is required for LATER", example = "NOW", allowableValues = {"NOW", "LATER"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String timeOfTransfer;

    @Schema(description = "Scheduled execution date in yyyy-MM-dd format", example = "2026-05-28", format = "date")
    private String executionDate;

    @Schema(description = "Total transaction count, matching transactions size", example = "2", minimum = "1", requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer totalCount;

    @Schema(description = "Total amount, matching sum of transaction hkdEquivalentAmount values", example = "30000.00", requiredMode = Schema.RequiredMode.REQUIRED)
    private BigDecimal totalAmount;

    @Schema(description = "Total service charge amount", example = "20.00")
    private BigDecimal serviceChargeAmount;

    @Schema(description = "Customer remarks", example = "Monthly payroll", maxLength = 256)
    private String customerRemarks;

//    @Schema(description = "Optional upstream callback endpoint for outward HTH online transactions. Use only placeholder values in shared examples; real endpoints and credentials must be configured outside source control.",
//            example = "https://upstream.example.com/payment/callback", maxLength = 512)
//    private String callbackUrl;

    @ArraySchema(
            schema = @Schema(implementation = TransactionDetailRequest.class),
            arraySchema = @Schema(description = "Transaction detail list; must not be empty; EPH/FPS fields are carried in each detail fps object", requiredMode = Schema.RequiredMode.REQUIRED)
    )
    private List<TransactionDetailRequest> transactions;

}
