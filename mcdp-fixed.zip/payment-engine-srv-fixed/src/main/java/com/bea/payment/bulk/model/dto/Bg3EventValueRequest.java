package com.bea.payment.bulk.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Schema(name = "Bg3EventValueRequest", description = "BG3 e5002EventValue item")
@Getter
@Setter
public class Bg3EventValueRequest {

    /**
     * BG3 event identifier in one e5002EventValue entry.
     */
    @Schema(description = "BG3 event identifier in one e5002EventValue entry", example = "CHKBOOK")
    private String e5002EventId;

    /**
     * BG3 comparison switch paired with the event identifier.
     */
    @Schema(description = "BG3 comparison switch paired with the event identifier", example = "Y")
    private String e5002SwCmp;
}
