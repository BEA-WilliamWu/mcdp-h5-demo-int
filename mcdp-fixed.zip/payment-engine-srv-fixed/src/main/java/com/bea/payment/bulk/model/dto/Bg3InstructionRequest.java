package com.bea.payment.bulk.model.dto;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Schema(name = "Bg3InstructionRequest",
        description = "BG3-specific optional fields for INTERNAL transfer")
@Getter
@Setter
public class Bg3InstructionRequest {

    /**
     * Optional BG3 event values. The BG3 request must contain 10 entries; missing entries are padded as empty values.
     */
    @ArraySchema(arraySchema = @Schema(description = "BG3 e5002EventValue items; at most 10 items, missing items are padded as empty values for BG3"),
            schema = @Schema(implementation = Bg3EventValueRequest.class))
    private List<Bg3EventValueRequest> eventValues;

}
