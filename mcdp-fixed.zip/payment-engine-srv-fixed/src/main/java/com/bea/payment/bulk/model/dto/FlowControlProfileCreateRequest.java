package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * 新增 Flow Control Profile 请求
 */
@Getter
@Setter
public class FlowControlProfileCreateRequest {

    private String profileName;

    private String txType;

    /**
     * 生效星期，例如：
     * MON,TUE,WED,THU,FRI
     */
    private String applicableDays;

    /**
     * HH:mm
     */
    private String startTime;

    /**
     * HH:mm
     */
    private String endTime;

    private Integer priority;

    /**
     * 参数键值对
     */
    private Map<String, String> params;

}