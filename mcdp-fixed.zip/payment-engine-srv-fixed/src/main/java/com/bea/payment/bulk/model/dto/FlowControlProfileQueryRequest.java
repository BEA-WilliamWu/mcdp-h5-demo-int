package com.bea.payment.bulk.model.dto;


import lombok.Getter;
import lombok.Setter;
/**
 * Flow Control Profile 查询请求
 */
@Getter
@Setter
public class FlowControlProfileQueryRequest {

    /**
     * 交易类型：
     * ON_US / OFF_US
     */
    private String txType;

    /**
     * 状态：
     * ACTIVE / INACTIVE
     */
    private String status;

    /**
     * 是否包含逻辑删除数据
     */
    private Boolean includeDeleted;

}