package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * Flow Control Profile 返回对象
 */
@Getter
@Setter
public class FlowControlProfileResponse {

    private Long profileId;
    private String profileName;
    private String txType;
    private String applicableDays;
    private String startTime;
    private String endTime;
    private Integer priority;
    private String status;
    private Long objectVersionNumber;

    /**
     * 参数集合
     */
    private Map<String, String> params;

}
