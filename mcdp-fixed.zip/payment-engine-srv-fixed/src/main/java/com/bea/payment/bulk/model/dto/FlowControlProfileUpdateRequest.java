package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * 修改 Flow Control Profile 请求
 */
@Getter
@Setter
public class FlowControlProfileUpdateRequest {

    private Long profileId;
    private String profileName;
    private Integer priority;
    private String status;

    /**
     * 版本号 (乐观锁)
     */
    private Long objectVersionNumber;

    /**
     * 需要修改的参数
     */
    private Map<String, String> params;

}