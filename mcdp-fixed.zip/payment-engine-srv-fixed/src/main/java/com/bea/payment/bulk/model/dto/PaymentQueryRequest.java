package com.bea.payment.bulk.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Schema(name = "PaymentQueryRequest",
        description = "Request for upstream payment enquiry.")
@Getter
@Setter
public class PaymentQueryRequest {

    @Schema(description = "Unique end-to-end transaction reference")
    private String ipeReferenceId;

    @Schema(description = "Transaction type. FPS requires fps on every detail; INTERNAL enters BG3 and must omit fps", example = "FPS", allowableValues = {"FPS", "CHATS", "INTERNAL"})
    private String transactionType;

}
