package com.bea.payment.bulk.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Schema(name = "PaymentResultQueryResponse",
        description = "Simplified payment enquiry response for one transaction.")
@Getter
@Setter
public class  PaymentQueryResponse {


    @Schema(description = "Unique end-to-end transaction reference")
    private String ipeReferenceId;

    @Schema(description = "Transaction type. FPS requires fps on every detail; INTERNAL enters BG3 and must omit fps", example = "FPS")
    private String transactionType;

    @Schema(description = "Transaction status. FPS requires fps on every detail; INTERNAL enters BG3 and must omit fps", example = "Complete")
    private String TransactionStatus;

    @Schema(description = "Channel code.", example = "BCO")
    private String channel;

    @Schema(description = "Channel-side payment reference.", example = "PAY-REF-000001")
    private String channelReference;

    @Schema(description = "External-facing payment status.",
            example = "PROCESSING",
            allowableValues = {"PROCESSING", "SUCCESS", "FAILED"})
    private String status;

    @Schema(description = "Whether the result is final and no further polling is needed.", example = "false")
    private Boolean terminal;

    @Schema(description = "Payment amount.", example = "10000.50")
    private BigDecimal amount;

    @Schema(description = "Payment currency in ISO 4217.", example = "HKD")
    private String currency;

    @Schema(description = "External-safe error code, present only when available.", example = "EPH_TIMEOUT")
    private String errorCode;

    @Schema(description = "External-safe error message, present only when available.",
            example = "EPH request timed out")
    private String errorMessage;

    @Schema(description = "Last known update time for this transaction.", format = "date-time")
    private Date lastUpdatedAt;

}
