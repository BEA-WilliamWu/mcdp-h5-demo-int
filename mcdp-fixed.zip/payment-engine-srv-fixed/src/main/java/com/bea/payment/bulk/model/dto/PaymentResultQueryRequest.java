package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "PaymentResultQueryRequest",
        description = "Request for upstream payment result enquiry. Query by transactionId or batchId.")
@Getter
@Setter
public class PaymentResultQueryRequest {

    @Schema(description = "Batch identifier. Used only when transactionId is not provided.",
            example = "BCO20260604103025000001",
            minLength = 23,
            maxLength = 23)
    private String batchId;

    @Schema(description = "Transaction identifier. When both transactionId and batchId are provided, transactionId wins.",
            example = "BCO20260604103025000002",
            minLength = 23,
            maxLength = 23)
    private String transactionId;

}
