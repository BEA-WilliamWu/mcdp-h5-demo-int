package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.util.Date;

@Schema(name = "PaymentResultQueryResponse",
        description = "Simplified payment result enquiry response for one transaction.")
@Getter
@Setter
public class PaymentResultQueryResponse {

    @Schema(description = "Transaction identifier.", example = "BCO20260604103025000002")
    private String transactionId;

    @Schema(description = "IPE-generated UUIDv7 reference for this transaction.",
            example = "018f6a12-6f7b-7a91-9c2d-8e3f4a5b6c7d")
    private String ipeReferenceId;

    @Schema(description = "Batch identifier.", example = "BCO20260604103025000001")
    private String batchId;

    @Schema(description = "Batch aggregate status derived from transactions.",
            example = "DISPATCHED",
            allowableValues = {"PENDING", "DISPATCHING", "DISPATCHED", "COMPLETED",
                    "ALL_FAILED", "PARTIAL_SUCCESS", "UNKNOWN", "MANUAL_REVIEW"})
    private String batchStatus;

    @Schema(description = "Whether every transaction in the batch has reached a final status.", example = "false")
    private Boolean batchTerminal;

    @Schema(description = "Channel code.", example = "BCO")
    private String channel;

    @Schema(description = "Channel-side payment reference.", example = "PAY-REF-000001")
    private String channelReference;

    @Schema(description = "Payee bank code.", example = "672")
    private String payeeBankCode;

    @Schema(description = "Customer Type.", example = "PERS")
    private String customerType;

    @Schema(description = "Transaction type.", example = "FPS", allowableValues = {"FPS", "INTERNAL"})
    private String transactionType;

    @Schema(description = "External-facing payment status.",
            example = "PROCESSING",
            allowableValues = {"PROCESSING", "SUCCESS", "FAILED", "MANUAL_REVIEW"})
    private String status;

    @Schema(description = "Whether the result is final and no further polling is needed.", example = "false")
    private Boolean terminal;

    @Schema(description = "Reason or stage detail for the current payment status.", example = "MQ_SENT")
    private String statusReason;

    @Schema(description = "Whether operations manual review is required.", example = "false")
    private Boolean manualReviewRequired;

    @Schema(description = "Manual review reason, if available.", example = "BG3_HTTP_STATUS")
    private String manualReviewReason;

    @Schema(description = "Payment amount.", example = "10000.50")
    private BigDecimal amount;

    @Schema(description = "Payment currency in ISO 4217.", example = "HKD")
    private String currency;

    @Schema(description = "Downstream system responsible for the transaction.", example = "EPH",
            allowableValues = {"EPH", "BG3"})
    private String downstreamSystem;

    @Schema(description = "External-safe downstream payment reference, if available.",
            example = "FPS-REF-202606040001")
    private String downstreamReference;

    @Schema(description = "Downstream system result status",
            example = "ACSC/RJCT/ACSP/ACCP/PDNG")
    private String downstreamStatus;

    @Schema(description = "Original downstream error code when available; otherwise an internal technical fallback code.",
            example = "EADRE0003")
    private String errorCode;

    @Schema(description = "Source of the latest error, if available.", example = "BG3")
    private String errorSource;

    @Schema(description = "Original downstream error message when available; otherwise an internal technical summary.",
            example = "UNEXPECTED_VALUE,Precheck..pProxy.Tp")
    private String errorMessage;

    @Schema(description = "Last known update time for this transaction.", format = "date-time")
    private Date lastUpdatedAt;
}
