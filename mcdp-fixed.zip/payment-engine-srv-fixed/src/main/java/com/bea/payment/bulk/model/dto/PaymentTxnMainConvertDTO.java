package com.bea.payment.bulk.model.dto;

import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class PaymentTxnMainConvertDTO {

    private PaymentTxnMainEntity paymentTxnMainEntity = new PaymentTxnMainEntity();

    private PaymentTxnEventEntity paymentTxnEventEntity = new PaymentTxnEventEntity();

}
