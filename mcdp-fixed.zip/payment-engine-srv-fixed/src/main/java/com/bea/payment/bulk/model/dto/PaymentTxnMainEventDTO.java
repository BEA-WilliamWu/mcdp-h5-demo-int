package com.bea.payment.bulk.model.dto;

import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * DTO that extends PaymentTxnMainEntity with additional EPH-specific fields from the event table.
 *
 * <p>This DTO is used for EPH query results that join IPE_PAYMENT_TXN_MAIN with
 * IPE_PAYMENT_TXN_EVENT. The ephPayeeIdentificationType comes from the event table via LEFT JOIN.</p>
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class PaymentTxnMainEventDTO extends PaymentTxnMainEntity {

    /** Event row that owns the status-query claim fields. */
    private Long eventId;

    /**
     * EPH payee identification type, loaded from IPE_PAYMENT_TXN_EVENT.eph_payee_identification_type.
     */
    private String ephPayeeIdentificationType;

    /**
     * EPH payment source, loaded from IPE_PAYMENT_TXN_EVENT.eph_payment_source.
     */
    private String ephPaymentSource;

    /**
     * EPH needs status query flag, loaded from IPE_PAYMENT_TXN_EVENT.eph_needs_status_query.
     */
    private String ephNeedsStatusQuery;

    /**
     * EPH query eligible time, loaded from IPE_PAYMENT_TXN_EVENT.eph_query_eligible_time.
     */
    private java.util.Date ephQueryEligibleTime;

    /**
     * EPH 已补偿查询次数。
     */
    private Integer ephQueryCount;

    /**
     * EPH 最近一次补偿查询时间。
     */
    private Date ephLastQueryTime;

    private String customerType;


}
