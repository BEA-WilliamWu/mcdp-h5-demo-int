package com.bea.payment.bulk.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Schema(name = "RequestRemittanceCreditTransferRequest",
        description = "Transaction detail of HTCC1&HTC02")
@Getter
@Setter
public class RequestRemittanceCreditTransferRequest {

//    @Schema(description = "Host term no / Request Header")
//    private String hdrHostTermNo;
//    @Schema(description = "Host Session Id")
//    private String hdrHostSessId;
    @Schema(description = "Channel Source Indicator",hidden = true)
    private String hdrChSrcInd = "I";
    @Schema(description = "Message ID",hidden = true)
    private String hdrMessageId;
//    @Schema(description = "Tx. option code")
    private String hdrOpt;//TBC with EBK
    @Schema(description = "External Bank code",hidden = true)
    private String hdrBankCode = "015";
    @Schema(description = "Internal Bank Code",hidden = true)
    private String hdrIntBankCode = "01";
    @Schema(description = "Media Code",hidden = true)
    private String hdrMediaCode = "CDC";
//    @Schema(description = "CIB Customer ID")
    private String hdrCibCustId;//TBC with HTH
    @Schema(description = "CIB internal a/c #")
    private String hdrCibIntAcNo;//TBC with HTH
    @Schema(description = "Time-out flag",hidden = true)
    private String hdrRtTimeoutFlg = "0";
//    @Schema(description = "Transaction Posting Date")
//    private String hdrTxPostDate;
//    @Schema(description = "Transaction Match Key Area")
//    private String hdrTxMatchKey; get value from precheck into confirm
    @Schema(description = "Tx. Sub option code")
    private String hdrSubOpt;//TBC with EBK
    @Schema(description = "Company code",hidden = true)
    private Integer hdrCompCode = 0001;
//    @Schema(description = "Corporate a/c access level")
//    private String hdrCibAccessLvl;
//    @Schema(description = "Public Key Indicator")
//    private String hdrPublicKeyInd;
    @Schema(description = "Input user ID",hidden = true)
    private String hdrInputUserId = " ";
//    @Schema(description = "Input date")
//    private String hdrInputDate;
//    @Schema(description = "Input time")
//    private String hdrInputTime;
//    @Schema(description = "Approval user ID")
//    private String hdrAprvlUserId;
//    @Schema(description = "Approval date")
//    private String hdrAprvlDate;
//    @Schema(description = "Approval time")
//    private String hdrAprvlTime;
//    @Schema(description = " Internal bank/branch/Department code")
//    private String hdrIntCcbbbdd;
    @Schema(description = "Transaction Number",hidden = true)
    private String hdrTxnNumber = "00000000000000000000000000000000000";
//    @Schema(description = "Dial-up Backup Indicator")
//    private String hdrDialupBkupInd;
//    @Schema(description = "Suspicious IP Indicator")
//    private String hdrSusIpFlg;
//    @Schema(description = "CIB A/C product code")
//    private Integer hdrCibAcProdCode;
//    @Schema(description = "Risk Indicator")
//    private String hdrRiskInd;
//    @Schema(description = "Special Rate flag")
//    private String hdrSpecRateFlg;
//    @Schema(description = "Transaction Type")
//    private String hdrTxnType;
//    @Schema(description = "One Man Bank flag")
//    private String hdrOmbFlag;


    @Schema(description = "Related a/c company code",maxLength = 4,requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer relCompCode;
    @Schema(description = "Related a/c seq, hardcode 00", maxLength = 2,hidden = true)
    private String relAcSeq = "00";
    @Schema(description = "Related a/c product  code", maxLength = 4,requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer relAcProdCode;
    @Schema(description = "Related a/c cur. Code",maxLength = 3,requiredMode = Schema.RequiredMode.REQUIRED)
    private String relAcCcy;
    @Schema(description = "Related a/c status", maxLength = 2,hidden = true)
    private Integer relAcStatus =00;
    @Schema(description = "Formatted related a/c ", maxLength = 20)
    private String relAcNoFmt;
    @Schema(description = "TRD other bank a/c #", maxLength = 34,requiredMode = Schema.RequiredMode.REQUIRED)
    private String chatAcNo;
    @Schema(description = "Designated CHATS a/c type code(Save in BCO DB,Hard code value (TBC with HTH)", maxLength = 2)
    private String chatAcTpCode;
    @Schema(description = "Print advise indicator",example = "‘Y’ – print advise (default) , ‘N’ – not print", maxLength = 1)
    private String prntAdvInd;
    @Schema(description = "Service charge exchange rate(TBC with EBK)", maxLength = 13)
    private BigDecimal srvcExchRate;
    @Schema(description = "Re-send flag", maxLength = 1,hidden = true)
    private String resendFlag = "1";
//    @Schema(description = "Transaction status ,used by BM only", example = "‘C’–confirm,‘R’–reject,‘P’-print",maxLength = 1)
//    private String transStatus;
    @Schema(description = "Service charge discount rate(TBC with EBK)", maxLength = 4,hidden = true)
    private BigDecimal chrgDiscRate = BigDecimal.ZERO;
//    @Schema(description = "Sweep type", maxLength = 2)
//    private String sweepType;
//    @Schema(description = "Sweep trigger amount", maxLength = 15)
//    private BigDecimal sweepTrigAmt;
//    @Schema(description = "Sweep amount", maxLength = 15)
//    private BigDecimal sweepAmt;
//    @Schema(description = "Priority", maxLength = 2)
//    private String priority;
    @Schema(description = "Sweep transaction indicator , Input if transaction triggered by LM setting (for CDC only)",maxLength = 1)
    private String lmInd;
//    @Schema(description = "LM instruction number,Input if transaction triggered by LM setting (for CDC only)",maxLength = 30)
//    private String lmInstrNum;
    @Schema(description = "Deposit account name1",maxLength = 35)
    private String depositAccountName1;
    @Schema(description = "Deposit account name2",maxLength = 35)
    private String depositAccountName2;
    @Schema(description = "Deposit account name3",maxLength = 35)
    private String depositAccountName3;
    @Schema(description = "Deposit account name4",maxLength = 35)
    private String depositAccountName4;
    @Schema(description = "OVR CHARGE IND,if ‘O’ then EBK will call SO3 to retrieve the fee currency&amount, then return in HTCC1 response;" +
            "If ‘S’ then EBK won’t charge this fee, and return SPACE&ZERO in the response.",example = "S - ‘SHA’ , O - ‘OUR’(pending EBK checking)",maxLength = 1)
    private String ourChargeBearerInd;
    @Schema(description = "OVR CHARGE CCY",example = "SHA",maxLength = 3)
    private String ourChargeBearerCcy;
    @Schema(description = "OVR CHARGE AMT",maxLength = 7)
    private String ourChargeBearerAmt;
    @Schema(description = "Counter of PIN structure",maxLength = 2)
    private Integer pinCnt;
    @Schema(description = "List of PIN structure , Must occur 3 times ")
    private List<PinListArea> pinListArea;
    @Schema(description = "MAC structure")
    private MacArea macArea;

    @Data
    public static class PinListArea {
//        @Schema(description = "Related",maxLength = 3)
//        private String pkeyInd;
        @Schema(description = "Related",maxLength = 3)
        private String agentId;
//        @Schema(description = "Encrypted DES Key (by Public Key)",maxLength = 128)
//        private String desKey;
//        @Schema(description = "Related",maxLength = 16)
//        private String pinBlock;
    }

    @Data
    public static class MacArea {
        @Schema(description = "Related",maxLength = 8)
        private String macCode;
        @Schema(description = "Related", maxLength = 3)
        private String agentId;
        @Schema(description = "Encrypted DES Key (by Public Key)",maxLength = 128)
        private String desKey;
        @Schema(description = "Related",maxLength = 16)
        private String pinBlock;
    }

}
