package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

@Schema(name = "SingleCreditTransferRequest",
        description = "Single credit transfer submission request; a successful response means acceptance and persistence only, not downstream payment completion")
@Getter
@Setter
public class SingleCreditTransferRequest {

    @Schema(description = "Channel code", example = "BCO", allowableValues = {"BCO", "HTH"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String channel;
    @Schema(description = "Unique transaction identifier, format CHANNEL(3)+yyyyMMddHHmmss(14)+sequence(6)", example = "BCO20260527103025000001", minLength = 23, maxLength = 23, requiredMode = Schema.RequiredMode.REQUIRED)
    private String transactionId;
    @Schema(description = "Channel-side reference", example = "PAY-REF-000001", maxLength = 64)
    private String channelReference;
    @Schema(description = "Transaction type. FPS is processed through EPH and requires fps; INTERNAL enters BG3 and must omit fps", example = "FPS", allowableValues = {"FPS", "CHATS", "INTERNAL"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String transactionType;
    @Schema(description = "Transfer timing; executionDate is required for LATER", example = "NOW", allowableValues = {"NOW", "LATER"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String timeOfTransfer;
    @Schema(description = "Scheduled execution date in yyyy-MM-dd format", example = "2026-05-28", format = "date")
    private String executionDate;
    @Schema(description = "Payment amount; must be greater than zero", example = "10000.50", requiredMode = Schema.RequiredMode.REQUIRED)
    private BigDecimal debitAmount;
    @Schema(description = "Debit amount currency in ISO 4217", example = "HKD", minLength = 3, maxLength = 3, requiredMode = Schema.RequiredMode.REQUIRED)
    private String debitAmountCcy;
    @Schema(description = "Settlement currency; defaults to debitAmountCcy", example = "HKD", minLength = 3, maxLength = 3)
    private String settlementCurrency;
    @Schema(description = "HKD equivalent amount; optional, must be greater than zero when provided", example = "10000.50")
    private BigDecimal hkdEquivalentAmount;
    @Schema(description = "Service charge amount", example = "10.00")
    private BigDecimal serviceChargeAmount;
    @Schema(description = "Charge currency; required when serviceChargeAmount is greater than zero; required for FPS/EPH as I005 ServiceChargeCCY", example = "HKD", minLength = 3, maxLength = 3)
    private String chargeCurrency;
    @Schema(description = "Payment details", example = "Invoice payment", maxLength = 140)
    private String paymentDetails;
    @Schema(description = "Exchange currency pair for downstream transfer", example = "HKDUSD", maxLength = 7)
    private String exchangeCurrencyPair;
    @Schema(description = "Contract exchange rate for downstream transfer", example = "00000781234", maxLength = 11)
    private String exchangeContractRate;
    @Schema(description = "Special exchange rate for downstream transfer", example = "00000781234", maxLength = 11)
    private String exchangeSpecialRate;
    @Schema(description = "Special exchange rate flag", example = "Y", maxLength = 1)
    private String exchangeSpecialRateFlag;
    @Schema(description = "Treasury reference for downstream transfer", example = "TRS0001", maxLength = 7)
    private String treasuryReference;
    /**
     * Payment source used by I005 PaymentSrc and I006 PPmntSrc to identify the originating source system.
     */
    @Schema(description = "Payment source used by I005 PaymentSrc and I006 PPmntSrc", example = "CCB", maxLength = 16, requiredMode = Schema.RequiredMode.REQUIRED)
    private String paymentSource;
    /**
     * I005 enquiry type controlling which EPH enquiry is performed for proxy payees.
     */
    @Schema(description = "I005 enquiry type for PROXY payee. ACCOUNT payee is sent to EPH as FEE regardless of this input", example = "ALL", maxLength = 8, requiredMode = Schema.RequiredMode.REQUIRED)
    private String enquiryType;
    /**
     * BEA cost center code passed to I006 ProcessingPersistentInfo/CostCenterCode.
     */
    @Schema(description = "EPH cost center code used by I006 CostCenterCode", example = "CYB", maxLength = 20, requiredMode = Schema.RequiredMode.REQUIRED)
    private String costCenterCode;
    /**
     * Fee code used by I005 fee enquiry and I006 processing.
     */
    @Schema(description = "EPH fee code used by I005/I006 FeeCd", example = "SHA", maxLength = 20, requiredMode = Schema.RequiredMode.REQUIRED)
    private String feeCode;
    /**
     * Payee identification type used by I005 proxy type and I006 creditor account scheme.
     */
    @Schema(description = "Payee identification type used by I005 Tp and I006 creditor account type", example = "BBAN, SVID", maxLength = 16, requiredMode = Schema.RequiredMode.REQUIRED)
    private String payeeIdentificationType;
    /**
     * Indicator controlling whether ALNOVA limit checking is performed.
     */
    @Schema(description = "Alnova limit check indicator", example = "Y", maxLength = 8, requiredMode = Schema.RequiredMode.REQUIRED)
    private String alnovaLimitCheckInd;
    /**
     * Optional instruction identifier passed to I006 PmtId/InstrId.
     */
    @Schema(description = "I006 instruction id passed to PmtId/InstrId", example = "INS20260519143025000001", maxLength = 64)
    private String instructionId;
    /**
     * Optional clearing system code passed to I006 GrpHdr/SttlmInf/ClrSys/Prtry.
     */
    @Schema(description = "I006 clearing system proprietary code. Omitted from I006 when blank", example = "FPS", maxLength = 16)
    private String clearingSystem;
    /**
     * ISO payment purpose code passed to I006 Purp/Cd.
     */
    @Schema(description = "Purpose code passed to Purp/Cd; mutually exclusive with purposeProprietary", example = "CXBSNS", maxLength = 8)
    private String purposeCode;
    /**
     * Proprietary payment purpose value passed to I006 Purp/Prtry.
     */
    @Schema(description = "Proprietary purpose passed to Purp/Prtry; mutually exclusive with purposeCode", example = "PAYROLL", maxLength = 35)
    private String purposeProprietary;
    /**
     * BEA office ID passed to I006 ProcessingPersistentInfo/POffice.
     */
    @Schema(description = "EPH office id passed to ProcessingPersistentInfo/POffice", example = "001", maxLength = 3)
    private String officeId;
    /**
     * Invoice number passed to I006 ProcessingPersistentInfo/InvoiceNum.
     */
    @Schema(description = "Invoice number passed to ProcessingPersistentInfo/InvoiceNum", example = "INV202605190001", maxLength = 35)
    private String invoiceNumber;
    /**
     * VIP indicator passed to I006 ProcessingPersistentInfo/VipInd.
     */
    @Schema(description = "VIP indicator passed to ProcessingPersistentInfo/VipInd", example = "N", allowableValues = {"Y", "N"}, maxLength = 1)
    private String vipIndicator;
    /**
     * Credit-side internal account passed to I006 CreditSide/InternalAcc.
     */
    @Schema(description = "Credit internal account passed to CreditSide/InternalAcc", example = "987654321098765", maxLength = 35)
    private String creditInternalAccount;
    /**
     * Debit-side internal account passed to I006 DebitSide/InternalAcc.
     */
    @Schema(description = "Debit internal account passed to DebitSide/InternalAcc", example = "123456789012345", maxLength = 35)
    private String debitInternalAccount;
    /**
     * Debit-side product type or deposit account type passed to I006 DebitSide/ProductTp.
     */
    @Schema(description = "Product type passed to DebitSide/ProductTp", example = "8805", maxLength = 4)
    private String productType;


    @Schema(description = "BG3-specific instruction fields; only used by BG3/internal transfer")
    private Bg3InstructionRequest bg3;

    @Schema(description = "Payer type", example = "CORPORATE", allowableValues = {"INDIVIDUAL", "CORPORATE"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String payerType;
    @Schema(description = "Payer account number", example = "1234567890", maxLength = 34, requiredMode = Schema.RequiredMode.REQUIRED)
    private String payerAccountNo;
    @Schema(description = "Payer internal account number; required for FPS/EPH as I005 CybAccIntNo", example = "000123456789", maxLength = 34)
    private String payerInternalAccountNo;
    @Schema(description = "Payer BIC/SWIFT code", example = "BEAHHKHXXX", maxLength = 11)
    private String payerBicCode;
    @Schema(description = "Payer account type", example = "6805", requiredMode = Schema.RequiredMode.REQUIRED)
    private String payerAccountType;
    @Schema(description = "Payer account currency in ISO 4217", example = "HKD", minLength = 3, maxLength = 3)
    private String payerAccountCurrency;
    @Schema(description = "Payer name", example = "ABC COMPANY LIMITED", maxLength = 140)
    private String payerName;
    @Schema(description = "Payer address line 1", example = "1 QUEENS ROAD CENTRAL", maxLength = 70)
    private String payerAddressLine1;
    @Schema(description = "Payer address line 2", maxLength = 70)
    private String payerAddressLine2;
    @Schema(description = "Payer address line 3", maxLength = 70)
    private String payerAddressLine3;
    @Schema(description = "Payer address line 4", maxLength = 70)
    private String payerAddressLine4;
    @Schema(description = "Payer town name", example = "HONG KONG", maxLength = 70)
    private String payerTownName;
    @Schema(description = "Payer country code, ISO 3166-1 alpha-2", example = "HK", minLength = 2, maxLength = 2)
    private String payerCountryCode;

    @Schema(description = "Payee type; defaults to account payment when omitted. Use PROXY for FPS/EPH proxy payment", example = "ACCOUNT", allowableValues = {"ACCOUNT", "PROXY"})
    private String payeeType;
    @Schema(description = "Payee name; optional for generic submission, conditionally required for FPS/EPH as I006 creditor name", example = "BENEFICIARY LIMITED", maxLength = 140)
    private String payeeName;
    @Schema(description = "Payee account number; required when payeeType is ACCOUNT or omitted", example = "9876543210", maxLength = 34)
    private String payeeAccountNo;
    @Schema(description = "Payee account currency in ISO 4217; downstream may fall back to settlementCurrency or debitAmountCcy when omitted", example = "HKD", minLength = 3, maxLength = 3)
    private String payeeAccountCurrency;
    @Schema(description = "Payee proxy identifier; required when payeeType is PROXY", example = "+85291234567", maxLength = 64)
    private String payeeProxyId;
    @Schema(description = "Payee mobile number", example = "+85291234567", maxLength = 32)
    private String payeeMobileNo;
    @Schema(description = "Payee email address", example = "payee@example.com", maxLength = 128)
    private String payeeEmailAddress;
    @Schema(description = "Payee bank code", example = "015", maxLength = 16)
    private String payeeBankCode;
    @Schema(description = "Payee clearing member ID; required for FPS/EPH ACCOUNT payee and mapped to I005 MmbId", example = "004", maxLength = 16)
    private String memberId;
    @Schema(description = "Payee bank name", example = "THE HONGKONG AND SHANGHAI BANKING CORPORATION", maxLength = 140)
    private String payeeBankName;
    @Schema(description = "Payee bank BIC/SWIFT code", example = "HSBCHKHH", maxLength = 11)
    private String payeeBicCode;
    @Schema(description = "Sender correspondent bank BIC", maxLength = 11)
    private String senderCorrBankBicCode;
    @Schema(description = "Receiver correspondent bank BIC", maxLength = 11)
    private String receiverCorrBankBicCode;
    @Schema(description = "Payee address line 1", maxLength = 70)
    private String payeeAddressLine1;
    @Schema(description = "Payee address line 2", maxLength = 70)
    private String payeeAddressLine2;
    @Schema(description = "Payee address line 3", maxLength = 70)
    private String payeeAddressLine3;
    @Schema(description = "Payee address line 4", maxLength = 70)
    private String payeeAddressLine4;
    @Schema(description = "Payee town name", maxLength = 70)
    private String payeeTownName;
    @Schema(description = "Payee country code, ISO 3166-1 alpha-2", example = "HK", minLength = 2, maxLength = 2)
    private String payeeCountryCode;

}
