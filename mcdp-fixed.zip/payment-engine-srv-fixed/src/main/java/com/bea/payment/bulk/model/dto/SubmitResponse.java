package com.bea.payment.bulk.model.dto;

import lombok.Getter;
import lombok.Setter;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.List;

@Schema(name = "SubmitResponse", description = "Payment submission acceptance result")
@Getter
@Setter
public class SubmitResponse {

    @Schema(description = "Server acceptance time", example = "2026-05-27T10:30:25+08:00", format = "date-time")
    private OffsetDateTime acceptedAt;

    @Schema(description = "Accepted transaction references generated for each persisted MAIN record")
    private List<SubmitTransactionResponse> transactions;

    public SubmitResponse() {}

    public SubmitResponse(OffsetDateTime acceptedAt, List<SubmitTransactionResponse> transactions) {
        this.acceptedAt = acceptedAt;
        this.transactions = transactions;
    }

}
