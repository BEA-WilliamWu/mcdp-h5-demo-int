package com.bea.payment.bulk.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Schema(name = "SubmitTransactionResponse", description = "Accepted transaction reference returned after submission")
@Getter
@Setter
public class SubmitTransactionResponse {

    @Schema(description = "Caller-provided transaction identifier", example = "BCO20260527103025000001")
    private String transactionId;

    @Schema(description = "IPE-generated UUIDv7 reference for this transaction", example = "018f6a12-6f7b-7a91-9c2d-8e3f4a5b6c7d")
    private String ipeReferenceId;

    @Schema(description = "Initial transaction status after acceptance and persistence", example = "PENDING")
    private String status;

    public SubmitTransactionResponse() {
    }

    public SubmitTransactionResponse(String transactionId, String ipeReferenceId, String status) {
        this.transactionId = transactionId;
        this.ipeReferenceId = ipeReferenceId;
        this.status = status;
    }
}
