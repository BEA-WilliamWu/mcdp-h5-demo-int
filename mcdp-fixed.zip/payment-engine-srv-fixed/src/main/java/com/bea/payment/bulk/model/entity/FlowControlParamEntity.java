package com.bea.payment.bulk.model.entity;

import lombok.Getter;
import lombok.Setter;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

/**
 * Flow Control Parameter Entity
 *
 * 对应表: IPE_FLOW_CONTROL_PARAM
 *
 * 含义：
 * - 某一条 Profile 下的具体流控参数
 */
@TableName("IPE_FLOW_CONTROL_PARAM")
@Getter
@Setter
public class FlowControlParamEntity {

    /**
     * 流控参数主键。
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long paramId;

    /**
     * 所属流控规则主键。
     */
    private Long profileId;

    /**
     * 参数名
     * 示例:
     * - TOTAL_TXN_PER_HOUR
     * - ONUS_TXN_PER_HOUR
     * - OFFUS_TXN_PER_HOUR
     */
    private String paramKey;

    /**
     * 参数值 (字符串存储，加载时转换)
     */
    private String paramValue;

    /**
     * 参数说明。
     */
    private String description;

    /**
     * 状态：
     * - ACTIVE
     * - INACTIVE
     */
    private String status;

    /**
     * 创建人。
     */
    @TableField(fill = FieldFill.INSERT)
    private String createdBy;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新人。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String lastUpdatedBy;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;

    /**
     * 逻辑删除标志：
     * - Y
     * - N
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 版本号 (用于并发控制 / 乐观锁)
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Long objectVersionNumber;

}
