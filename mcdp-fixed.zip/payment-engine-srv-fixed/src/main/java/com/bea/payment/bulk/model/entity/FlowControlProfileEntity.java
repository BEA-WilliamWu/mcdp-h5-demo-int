package com.bea.payment.bulk.model.entity;

import lombok.Getter;
import lombok.Setter;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

/**
 * Flow Control Profile Entity
 *
 * 对应表: IPE_FLOW_CONTROL_PROFILE
 *
 * 含义：
 * - 定义某一类交易在某时间段内的流控规则
 */
@TableName("IPE_FLOW_CONTROL_PROFILE")
@Getter
@Setter
public class FlowControlProfileEntity {

    /**
     * 流控规则主键。
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long profileId;

    /**
     * 流控规则名称。
     */
    private String profileName;

    /**
     * 交易类型：
     * - ON_US
     * - OFF_US
     */
    private String txType;

    /**
     * 生效星期
     * 示例: MON,TUE,WED,THU,FRI
     */
    private String applicableDays;

    /**
     * 开始时间 (HH:mm)
     */
    private String startTime;

    /**
     * 结束时间 (HH:mm)
     */
    private String endTime;

    /**
     * 优先级 (数值越小优先)
     */
    private Integer priority;

    /**
     * 状态：
     * - ACTIVE
     * - INACTIVE
     */
    private String status;

    /**
     * 创建人。
     */
    @TableField(fill = FieldFill.INSERT)
    private String createdBy;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新人。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String lastUpdatedBy;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;

    /**
     * 逻辑删除标志：
     * - Y
     * - N
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 版本号 (用于并发控制 / 乐观锁)
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Long objectVersionNumber;

}
