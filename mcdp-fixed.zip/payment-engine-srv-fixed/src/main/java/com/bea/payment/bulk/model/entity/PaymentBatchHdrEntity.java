package com.bea.payment.bulk.model.entity;

import lombok.Getter;
import lombok.Setter;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.math.BigDecimal;
import java.util.Date;

@TableName("IPE_PAYMENT_BATCH_HDR")
@Getter
@Setter
public class PaymentBatchHdrEntity {

    /**
     * 批次号，外部批量/outward 请求传入；单笔接口内部生成。
     */
    @TableId
    private String batchId;

    /**
     * 渠道代码：BCO、HTH。
     */
    private String channel;

    /**
     * 渠道侧参考号，用于和上游渠道请求关联。
     */
    private String channelReference;

    /**
     * 批次交易类型：FPS、CHATS、INTERNAL、TT。
     */
    private String transactionType;

    /**
     * 转账时间类型：NOW 表示即时，LATER 表示预约。
     */
    private String timeOfTransfer;

    /**
     * 计划执行日期；NOW 时落当前时间，LATER 时落请求执行日。
     */
    private Date executionDate;

    /**
     * 批次明细总笔数。
     */
    private Integer totalCount;

    /**
     * 批次借记总金额。
     */
    private BigDecimal totalAmount;

    /**
     * 批次服务费总金额。
     */
    private BigDecimal serviceChargeAmount;

    /**
     * 客户备注。
     */
    private String customerRemarks;

    /**
     * 批次状态：PENDING、DISPATCHING、DISPATCHED、COMPLETED、ALL_FAILED、PARTIAL_SUCCESS、UNKNOWN、MANUAL_REVIEW。
     */
    private String batchStatus;

    /**
     * 请求链路追踪 ID。
     */
    private String traceId;

    /**
     * API 来源：SINGLE_CREDIT_TRANSFER、MULTIPLE_CREDIT_TRANSFER、OUTWARD_CREDIT_TRANSFER。
     */
    private String apiSource;

    /**
     * MQ 投递断点，记录本批次最后成功发送的明细 orderId，Scanner 用于断点恢复。
     */
    private Integer mqSendPointer;

    /**
     * 逻辑删除标志：Y 表示已删除，N 表示未删除。
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;

}
