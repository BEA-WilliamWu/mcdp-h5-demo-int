package com.bea.payment.bulk.model.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@TableName("IPE_PAYMENT_CALLBACK_ATTEMPT")
@Getter
@Setter
public class PaymentCallbackAttemptEntity {

    /**
     * 回调尝试记录主键。
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long callbackAttemptId;

    /**
     * 关联回调任务主键。
     */
    private Long callbackTaskId;

    /**
     * 关联交易号。
     */
    private String transactionId;

    /**
     * 第几次回调尝试，从 1 开始。
     */
    private Integer attemptNo;

    /**
     * 本次尝试使用的回调地址。
     */
    private String callbackUrl;

    /**
     * 本次回调请求载荷，保存前按配置脱敏。
     */
    private String requestPayload;

    /**
     * 本次回调 HTTP 状态码。
     */
    private Integer httpStatus;

    /**
     * 本次回调响应体。
     */
    private String responseBody;

    /**
     * 预期业务状态，通常为终态支付结果。
     */
    private String expectedStatus;

    /**
     * 回调响应或处理结果中的实际状态。
     */
    private String actualStatus;

    /**
     * 本次 HTTP 回调尝试状态：SUCCESS、FAILED。
     */
    private String attemptStatus;

    /**
     * 本次尝试错误码。
     */
    private String errorCode;

    /**
     * 本次尝试错误信息。
     */
    private String errorMessage;

    /**
     * 本次尝试开始时间。
     */
    private Date startedAt;

    /**
     * 本次尝试结束时间。
     */
    private Date finishedAt;

    /**
     * 逻辑删除标志：Y 表示已删除，N 表示未删除。
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;
}
