package com.bea.payment.bulk.model.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@TableName("IPE_PAYMENT_CALLBACK_TASK")
@Getter
@Setter
public class PaymentCallbackTaskEntity {

    /**
     * 回调任务主键。
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long callbackTaskId;

    /**
     * 关联交易号。
     */
    private String transactionId;

    /**
     * 关联批次号。
     */
    private String batchId;

    /**
     * 渠道代码，当前回调主要用于 HTH online outward 超时后的异步闭环。
     */
    private String channel;

    /**
     * 交易类型：FPS、CHATS、INTERNAL、TT。
     */
    private String transactionType;

    /**
     * 上游请求传入的回调地址。
     */
    private String callbackUrl;

    /**
     * 回调任务状态：PENDING、IN_PROGRESS、RETRY、CALLBACK_SUCCEEDED、CALLBACK_FAILED。
     */
    private String callbackStatus;

    /**
     * 已执行回调尝试次数。
     */
    private Integer attemptCount;

    /**
     * 最大回调尝试次数。
     */
    private Integer maxAttempts;

    /**
     * 下次允许重试时间。
     */
    private Date nextRetryTime;

    /**
     * 最近一次尝试开始时间。
     */
    private Date lastAttemptTime;

    /**
     * 回调任务完成时间。
     */
    private Date completedTime;

    /**
     * 最近一次查询到的交易结果状态。
     */
    private String lastResultStatus;

    /**
     * 最近一次回调 HTTP 状态码。
     */
    private Integer lastHttpStatus;

    /**
     * 最近一次回调错误码。
     */
    private String lastErrorCode;

    /**
     * 最近一次回调错误信息。
     */
    private String lastErrorMessage;

    /**
     * 最近一次回调响应体。
     */
    private String lastResponseBody;

    /**
     * 最近一次回调请求载荷，保存前按配置脱敏。
     */
    private String lastPayload;

    /**
     * Worker 认领令牌，用于防止过期执行结果覆盖较新的任务状态。
     */
    private String claimToken;

    /**
     * 逻辑删除标志：Y 表示已删除，N 表示未删除。
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;
}
