package com.bea.payment.bulk.model.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

@TableName("IPE_PAYMENT_TXN_EVENT")
@Getter
@Setter
@Accessors(chain = true)
public class PaymentTxnEventEntity {
    @TableId(type = IdType.ASSIGN_ID)
    private Long eventId;
    private Long txnId;
    private String transactionId;
    private String batchId;
    private Integer orderId;
    private String downstreamSystem;
    private String eventType;
    private String eventStage;
    private String messageId;
    private String downstreamReference;
    private String resultStatus;
    private String resultCode;
    private String errorCode;
    private String errorMessage;
    private String requestSummary;
    private String responseSummary;
    private Date startTime;
    private Date endTime;
    private Long durationMs;
    private String traceId;
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;

    // ==================== Full request / response text (not JSON) ====================

    /**
     * 完整请求报文（非 JSON 格式，CLOB）。
     */
    private String requestPayloadText;

    /**
     * 完整响应报文（非 JSON 格式，CLOB）。
     */
    private String responsePayloadText;

    /**
     * 请求报文类型，如 XML、JSON 等。
     */
    private String requestPayloadType;

    /**
     * 响应报文类型，如 XML、JSON 等。
     */
    private String responsePayloadType;

    // ==================== Payer address detail ====================

    /**
     * 付款人地址第 1 行。
     */
    private String payerAddressLine1;

    /**
     * 付款人地址第 2 行。
     */
    private String payerAddressLine2;

    /**
     * 付款人地址第 3 行。
     */
    private String payerAddressLine3;

    /**
     * 付款人地址第 4 行。
     */
    private String payerAddressLine4;

    /**
     * 付款人城市或镇名。
     */
    private String payerTownName;

    // ==================== Payee address detail ====================

    /**
     * 收款人地址第 1 行。
     */
    private String payeeAddressLine1;

    /**
     * 收款人地址第 2 行。
     */
    private String payeeAddressLine2;

    /**
     * 收款人地址第 3 行。
     */
    private String payeeAddressLine3;

    /**
     * 收款人地址第 4 行。
     */
    private String payeeAddressLine4;

    /**
     * 收款人城市或镇名。
     */
    private String payeeTownName;

    // ==================== Correspondent bank / routing detail ====================

    /**
     * 发报方代理行 BIC。
     */
    private String senderCorrBankBicCode;

    /**
     * 收报方代理行 BIC。
     */
    private String receiverCorrBankBicCode;

    // ==================== EPH request / mapping detail ====================

    /**
     * EPH 支付来源，映射 I005 PaymentSrc / I006 PPmntSrc。
     */
    private String ephPaymentSource;

    /**
     * EPH I005 查询类型。
     */
    private String ephEnquiryType;

    /**
     * EPH 成本中心代码。
     */
    private String ephCostCenterCode;

    /**
     * EPH 费用代码。
     */
    private String ephFeeCode;

    /**
     * EPH 交易类型，映射 I006 TxTp。
     */
    private String ephTxType;

    /**
     * 付款附言或交易用途说明。
     */
    private String paymentDetail1 = "";
    private String paymentDetail2 = "";
    private String paymentDetail3 = "";
    private String paymentDetail4 = "";

    private String depositAccountName1 = "";
    private String depositAccountName2 = "";
    private String depositAccountName3 = "";
    private String depositAccountName4 = "";
    /**
     * EPH 收款人识别类型，用于 proxy 或账号识别。
     */
    private String ephPayeeIdentificationType;

    /**
     * EPH 账户校验选项。
     */
    private String ephAccountVerificationOption;

    /**
     * EPH 类别用途代码。
     */
    private String ephCategoryPurpose;

    /**
     * EPH 借记方清算系统成员 ID。
     */
    private String ephDebtorMemberId;

    /**
     * EPH/ALNOVA 限额检查标志。
     */
    private String ephAlnovaLmtChkInd;

    /**
     * EPH 借记支付方式。
     */
    private String ephDebitMop;

    /**
     * EPH 端到端 ID。
     */
    private String ephEndToEndId;

    /**
     * EPH I005 选定银行代码。
     */
    private String ephSelectedBankCode;

    /**
     * EPH I005 选定银行名称。
     */
    private String ephSelectedBankName;

    /**
     * EPH 贷记支付方式。
     */
    private String ephCreditMop;

    /**
     * EPH 付款人客户 ID。
     */
    private String ephPayerCustomerId;

    /**
     * EPH 付款人客户 ID 类型。
     */
    private String ephPayerCustomerIdType;

    /**
     * EPH 付款人客户 ID 类别。
     */
    private String ephPayerCustomerIdCategory;

    /**
     * EPH 收款人客户 ID。
     */
    private String ephPayeeCustomerId;

    /**
     * EPH 收款人客户 ID 类型。
     */
    private String ephPayeeCustomerIdType;

    /**
     * EPH 收款人客户 ID 类别。
     */
    private String ephPayeeCustomerIdCategory;

    // ==================== Exchange / treasury detail ====================

    /**
     * 换汇货币对。
     */
    private String exchangeCurrencyPair;

    /**
     * 合约汇率。
     */
    private String exchangeContractRate;

    /**
     * 特殊汇率。
     */
    private String exchangeSpecialRate;

    /**
     * 特殊汇率标志。
     */
    private String exchangeSpecialRateFlag;

    /**
     * Treasury 参考号。
     */
    private String treasuryReference;

    // ==================== BG3 detail ====================

    /**
     * 是否需要 EPH 状态补偿查询：Y、N。
     */
    private String ephNeedsStatusQuery;

    /**
     * EPH 首次可补偿查询时间，通常为 timeout 或非终态发生时间后 30 分钟。
     */
    private Date ephQueryEligibleTime;

    /**
     * EPH 已补偿查询次数。
     */
    private Integer ephQueryCount;

    /**
     * EPH 最近一次补偿查询时间。
     */
    private Date ephLastQueryTime;

    /**
     * BG3 e5002EventValue 事件值列表的 JSON 快照（CLOB）。
     */
    private String bg3EventValuesJson;

    /**
     * BG3 借记方存折币种 n520iFccPsbdeb。
     */
    private String bg3FccPsbdeb;

    /**
     * BG3 借记方支票号码 n520iNumCheckR。
     */
    private String bg3NumCheckR;

    /**
     * BG3 贷记方存折币种 n520iFccPsbcre。
     */
    private String bg3FccPsbcre;


    // ==================== HDR header detail ====================

    /**
     * Host term no / Request Header
     */
    private String hdrHostTermNo;

    /**
     * Host Session Id
     */
    private String hdrHostSessId;

    /**
     * Channel Source Indicator
     */
    private String hdrChSrcInd;

    /**
     * Message ID
     */
    private String hdrMessageId;

    /**
     * Tx. option code
     */
    private String hdrOpt;

    /**
     * External Bank code
     */
    private String hdrBankCode;

    /**
     * Internal Bank Code
     */
    private String hdrIntBankCode;

    /**
     * Media Code
     */
    private String hdrMediaCode;

    /**
     * CIB Customer ID
     */
    private String hdrCibCustId;

    /**
     * CIB internal a/c #
     */
    private String hdrCibIntAcNo;

    /**
     * Time-out flag
     */
    private String hdrRtTimeoutFlg;

    /**
     * Transaction Posting Date
     */
    private String hdrTxPostDate;

    /**
     * Transaction Match Key Area
     */
    private String hdrTxMatchKey;

    /**
     * Tx. Sub option code
     */
    private String hdrSubOpt;

    /**
     * Company code
     */
    private Integer hdrCompCode;

    /**
     * Corporate a/c access level
     */
    private String hdrCibAccessLvl;

    /**
     * Public Key Indicator
     */
    private String hdrPublicKeyInd;

    /**
     * Input user ID
     */
    private String hdrInputUserId;

    /**
     * Input date
     */
    private String hdrInputDate;

    /**
     * Input time
     */
    private String hdrInputTime;

    /**
     * Approval user ID
     */
    private String hdrAprvlUserId;

    /**
     * Approval date
     */
    private String hdrAprvlDate;

    /**
     * Approval time
     */
    private String hdrAprvlTime;

    /**
     * Internal bank/branch/Department code
     */
    private String hdrIntCcbbbdd;

    /**
     * Transaction Number
     */
    private String hdrTxnNumber;

    /**
     * Dial-up Backup Indicator
     */
    private String hdrDialupBkupInd;

    /**
     * Suspicious IP Indicator
     */
    private String hdrSusIpFlg;

    /**
     * CIB A/C product code
     */
    private String hdrCibAcProdCode;

    /**
     * Risk Indicator
     */
    private String hdrRiskInd;

    /**
     * Special Rate flag
     */
    private String hdrSpecRateFlg;

    /**
     * Transaction Type
     */
    private String hdrTxnType;

    /**
     * One Man Bank flag
     */
    private String hdrOmbFlag;

    // ==================== REL account detail ====================

    /**
     * Related a/c company code
     */
    private Integer relCompCode;

    /**
     * Related a/c sequence
     */
    private String relAcSeq;

    /**
     * Related a/c product code
     */
    private Integer relAcProdCode;

    /**
     * Related a/c cur. Code
     */
    private String relAcCcy;

    /**
     * Related a/c status
     */
    private Integer relAcStatus;

    /**
     * Formatted related a/c
     */
    private String relAcNoFmt;

    // ==================== Host / channel / fee / limit detail ====================

    /**
     * TRD other bank a/c #
     */
    private String chatAcNo;

    /**
     * Designated CHATS a/c type code
     */
    private String chatAcTpCode;

    /**
     * Print advise indicator
     */
    private String prntAdvInd;

    /**
     * Service charge exchange rate
     */
    private BigDecimal srvcExchRate;

    /**
     * Re-send flag
     */
    private String resendFlag;

    /**
     * Transaction status, used by BM only
     */
    private String transStatus;

    /**
     * Service charge discount rate
     */
    private BigDecimal chrgDiscRate;

    /**
     * Sweep type
     */
    private String sweepType;

    /**
     * Sweep trigger amount
     */
    private BigDecimal sweepTrigAmt;

    /**
     * Sweep amount
     */
    private BigDecimal sweepAmt;

    /**
     * Priority
     */
    private String priority;

    /**
     * Sweep transaction indicator (for CDC only)
     */
    private String lmInd;

    /**
     * LM instruction number (for CDC only)
     */
    private String lmInstrNum;

    /**
     * OVR CHARGE IND
     */
    private String ourChargeBearerInd;

    /**
     * OVR CHARGE CCY
     */
    private String ourChargeBearerCcy;

    /**
     * OVR CHARGE AMT
     */
    private String ourChargeBearerAmt;

    /**
     * Counter code
     */
    private String macCode;

    /**
     * Agent ID
     */
    private String agentId;

    /**
     * DES Key
     */
    private String desKey;

    // ==================== Downstream mapping detail ====================

    /**
     * 支付指令 ID，公共下游字段。
     */
    private String instructionId;

    /**
     * 清算方式，公共下游字段。
     */
    private String settlementMethod;

    /**
     * 清算系统，公共下游字段。
     */
    private String clearingSystem;

    /**
     * 费用承担方，公共下游字段。
     */
    private String chargeBearer;

    /**
     * ISO 用途代码，公共下游字段。
     */
    private String purposeCode;

    /**
     * 自定义用途说明，公共下游字段。
     */
    private String purposeProprietary;

    /**
     * Office ID，公共下游字段。
     */
    private String officeId;

    /**
     * 发票号，公共下游字段。
     */
    private String invoiceNumber;

    /**
     * 客户类型，公共下游字段。
     */
    private String customerType;

    /**
     * VIP 标志，公共下游字段。
     */
    private String vipInd;

    /**
     * 贷记方内部账号，公共下游字段。
     */
    private String creditInternalAccount;

    /**
     * 借记方内部账号，公共下游字段。
     */
    private String debitInternalAccount;

    /**
     * 产品类型，公共下游字段。
     */
    private String productType;

    /**
     * PIN count
     */
    private Integer pinCnt;

    /**
     * PIN block
     */
    private String pinBlock;

    /**
     * 清算成员 ID，EPH I005 账号模式 MmbId。
     */
    private String payeeMemberId;
}
