package com.bea.payment.bulk.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@TableName("IPE_PAYMENT_TXN_MAIN")
@Getter
@Setter
public class PaymentTxnMainEntity {

    /**
     * 交易主表技术主键。
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long txnId;

    /**
     * 上游传入的业务交易号，全局唯一。
     */
    private String transactionId;

    /**
     * IPE 生成的内部交易参考号，RAW(16) 存储 UUIDv7 字节。
     */
    private byte[] ipeReferenceId;

    /**
     * 所属批次号。
     */
    private String batchId;

    /**
     * 批次内明细顺序号，从 1 开始；Scanner 按此顺序投递并推进批次指针。
     */
    private Integer orderId;

    /**
     * 渠道代码：BCO、HTH。
     */
    private String channel;

    /**
     * 渠道侧参考号，用于和上游渠道请求关联。
     */
    private String channelReference;

    /**
     * 请求链路追踪 ID。
     */
    private String traceId;

    /**
     * SWIFT UETR，全局唯一端到端参考号。
     */
    private String uetr;

    /**
     * 交易类型：FPS、CHATS、INTERNAL、TT；当前下游路由中 FPS 走 EPH，INTERNAL 走 BG3。
     */
    private String transactionType;

    /**
     * 转账时间类型：NOW 表示即时，LATER 表示预约。
     */
    private String timeOfTransfer;

    /**
     * 计划执行日期；NOW 时落当前时间，LATER 时落请求执行日。
     */
    private Date executionDate;

    /**
     * 借记金额，即上游 API 提交的付款金额。
     */
    private BigDecimal debitAmount;

    /**
     * 借记金额币种。
     */
    private String debitAmountCcy;

    /**
     * 清算币种，未传时通常按借记币种处理。
     */
    private String settlementCurrency;

    /**
     * 港币等值金额，用于统计或限额口径。
     */
    private BigDecimal hkdEquivalentAmount;

    /**
     * 汇率。
     */
    private BigDecimal fxRate;

    /**
     * 服务费金额。
     */
    private BigDecimal serviceChargeAmount;

    /**
     * 服务费币种。
     */
    private String chargeCurrency;


    /**
     * 交易主状态：PENDING、QUEUED、PROCESSING、COMPLETED、FAILED、MANUAL_REVIEW。
     */
    private String paymentStatus;

    /**
     * 主状态原因或处理阶段说明，如 API_ACCEPTED、MQ_SENT、DOWNSTREAM_SUCCESS、EPH_QUERY_PENDING。
     */
    private String statusReason;

    /**
     * 最近一次错误来源：BG3、EPH_I005、EPH_I006、EPH_HTTP、EPH_QUERY、WORKER、OPS。
     */
    private String errorSource;

    /**
     * 人工核对原因代码或简短说明。
     */
    private String manualReviewReason;

    /**
     * 标记为人工核对的时间。
     */
    private Date manualReviewTime;

    /**
     * 人工核对通知详情，仅用于内存中传递下游原始失败信息，不映射数据库字段。
     */
    @TableField(exist = false)
    private String manualReviewDetailMessage;

    /**
     * 本次下游执行开始时间。
     */
    private Date executionStartTime;

    /**
     * 本次下游执行结束时间。
     */
    private Date executionEndTime;

    /**
     * 最近一次投递到 MQ 或下游处理链路的时间。
     */
    private Date lastDispatchTime;

    /**
     * 下游执行尝试次数。
     */
    private Integer executionAttemptCount;

    /**
     * 最近一次调用的下游系统：BG3、EPH。
     */
    private String lastDownstreamSystem;

    /**
     * 最近一次错误码，可能来自下游或内部处理。
     */
    private String lastErrorCode;

    /**
     * 付款人类型：INDIVIDUAL、CORPORATE。
     */
    private String payerType;

    /**
     * 付款人账号。
     */
    private String payerAccountNo;

    /**
     * 付款人内部账号。
     */
    private String payerInternalAccountNo;

    /**
     * 付款人银行 BIC。
     */
    private String payerBicCode;

    /**
     * 付款人账户类型：SSA、CUR。
     */
    private String payerAccountType;

    /**
     * 付款人账户币种。
     */
    private String payerAccountCurrency;

    /**
     * 付款人名称。
     */
    private String payerName;

    /**
     * 付款人国家/地区代码。
     */
    private String payerCountryCode;

    /**
     * 收款人类型：ACCOUNT、PROXY；未传时按 ACCOUNT 处理。
     */
    private String payeeType;

    /**
     * 收款人名称。
     */
    private String payeeName;

    /**
     * 收款人账号；payeeType 为 ACCOUNT 或未传时必填。
     */
    private String payeeAccountNo;

    /**
     * 收款人账户币种。
     */
    private String payeeAccountCurrency;

    /**
     * 收款人代理标识，FPS proxy 场景使用。
     */
    private String payeeProxyId;

    /**
     * 收款人手机号，FPS proxy 场景可作为识别字段。
     */
    private String payeeMobileNo;

    /**
     * 收款人电邮地址，FPS proxy 场景可作为识别字段。
     */
    private String payeeEmailAddress;

    /**
     * 收款银行代码。
     */
    private String payeeBankCode;

    /**
     * 收款银行名称。
     */
    private String payeeBankName;

    /**
     * 收款银行 BIC。
     */
    private String payeeBicCode;

    /**
     * 收款人国家/地区代码。
     */
    private String payeeCountryCode;

    /**
     * Reference No
     */
    private String referenceNo;


    //todo:PinListArea是个list，还没纳入到table

    /**
     * 逻辑删除标志：Y 表示已删除，N 表示未删除。
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;

}
