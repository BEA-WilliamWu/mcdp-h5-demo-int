package com.bea.payment.bulk.model.entity;

import lombok.Getter;
import lombok.Setter;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

@TableName("IPE_UPSTREAM_API_AUDIT")
@Getter
@Setter
public class UpstreamApiAuditEntity {

    /**
     * API 审计记录主键。
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long apiAuditId;

    /**
     * API 名称：SINGLE_CREDIT_TRANSFER、MULTIPLE_CREDIT_TRANSFER、OUTWARD_CREDIT_TRANSFER。
     */
    private String apiName;

    /**
     * 请求路径。
     */
    private String apiPath;

    /**
     * HTTP 方法。
     */
    private String httpMethod;

    /**
     * 渠道代码：BCO、HTH。
     */
    private String channel;

    /**
     * 请求 ID，当前按 traceId 写入。
     */
    private String requestId;

    /**
     * 业务类型预留字段，由调用方按需设置。
     */
    private String businessType;

    /**
     * 关联批次号。
     */
    private String batchId;

    /**
     * 关联交易号，单笔接口审计时写入。
     */
    private String transactionId;

    /**
     * 统一响应结果码。
     */
    private String resultCode;

    /**
     * 接口处理耗时，单位毫秒。
     */
    private Long processDurationMs;

    /**
     * 请求链路追踪 ID。
     */
    private String traceId;

    /**
     * 请求进入时间。
     */
    private Date requestTime;

    /**
     * 响应返回时间。
     */
    private Date responseTime;

    /**
     * 脱敏后的原始请求体 JSON。
     */
    private String requestBodyRaw;

    /**
     * 脱敏后的原始响应体 JSON 或异常摘要。
     */
    private String responseBodyRaw;

    /**
     * 逻辑删除标志：Y 表示已删除，N 表示未删除。
     */
    @TableField(fill = FieldFill.INSERT)
    private String isDeleted;

    /**
     * 创建时间。
     */
    @TableField(fill = FieldFill.INSERT)
    private Date creationDate;

    /**
     * 最后更新时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date lastUpdateDate;

}
