package com.bea.payment.bulk.notification;

import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.function.Supplier;

/**
 * Best-effort manual-review email notification service.
 */
@Service
public class ManualReviewEmailService {

    private static final Logger log = LoggerFactory.getLogger(ManualReviewEmailService.class);

    private final Supplier<JavaMailSender> mailSenderSupplier;
    private final PaymentNotificationEmailProperties properties;
    private final ManualReviewEmailTemplateRenderer renderer;

    @Autowired
    public ManualReviewEmailService(ObjectProvider<JavaMailSender> mailSenderProvider,
            PaymentNotificationEmailProperties properties,
            ManualReviewEmailTemplateRenderer renderer) {
        this(mailSenderProvider::getIfAvailable, properties, renderer);
    }

    public ManualReviewEmailService(JavaMailSender mailSender,
            PaymentNotificationEmailProperties properties,
            ManualReviewEmailTemplateRenderer renderer) {
        this(() -> mailSender, properties, renderer);
    }

    private ManualReviewEmailService(Supplier<JavaMailSender> mailSenderSupplier,
            PaymentNotificationEmailProperties properties,
            ManualReviewEmailTemplateRenderer renderer) {
        this.mailSenderSupplier = Objects.requireNonNull(mailSenderSupplier, "mailSenderSupplier must not be null");
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
        this.renderer = Objects.requireNonNull(renderer, "renderer must not be null");
    }

    public void notifyManualReview(PaymentTxnMainEntity txn, PaymentTxnEventEntity event, String downstreamSystem,
                                   String reasonCode, String detailMessage) {
        if (txn == null) {
            log.warn("[EMAIL-ALERT] Manual-review email skipped because transaction context is null, downstream={}",
                    downstreamSystem);
            return;
        }
        if (!properties.isEnabled()) {
            log.debug("[EMAIL-ALERT] Manual-review email disabled, transactionId={}, downstream={}",
                    txn.getTransactionId(), downstreamSystem);
            return;
        }

        try {
            JavaMailSender mailSender = mailSenderSupplier.get();
            if (mailSender == null) {
                log.warn("[EMAIL-ALERT] JavaMailSender is unavailable, transactionId={}, batchId={}, downstream={}, traceId={}",
                        txn.getTransactionId(), txn.getBatchId(), downstreamSystem, txn.getTraceId());
                return;
            }
            if (StringUtils.isBlank(properties.getFrom()) || StringUtils.isBlank(properties.getTo())) {
                log.warn("[EMAIL-ALERT] Email from/to is not configured, transactionId={}, batchId={}, downstream={}, traceId={}",
                        txn.getTransactionId(), txn.getBatchId(), downstreamSystem, txn.getTraceId());
                return;
            }

            ManualReviewEmailTemplateRenderer.RenderedEmail rendered =
                    renderer.render(txn, event, downstreamSystem, reasonCode, detailMessage);
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(properties.getFrom());
            message.setTo(splitAddresses(properties.getTo()));
            if (StringUtils.isNotBlank(properties.getCc())) {
                message.setCc(splitAddresses(properties.getCc()));
            }
            message.setSubject(rendered.subject());
            message.setText(rendered.body());

            mailSender.send(message);
            log.warn("[EMAIL-ALERT] Manual-review email sent, transactionId={}, batchId={}, downstream={}, traceId={}",
                    txn.getTransactionId(), txn.getBatchId(), downstreamSystem, txn.getTraceId());
        } catch (RuntimeException e) {
            log.error("[EMAIL-ALERT] Manual-review email failed, transactionId={}, batchId={}, downstream={}, traceId={}, message={}",
                    txn.getTransactionId(), txn.getBatchId(), downstreamSystem, txn.getTraceId(), e.getMessage(), e);
        }
    }

    private static String[] splitAddresses(String addresses) {
        return java.util.Arrays.stream(StringUtils.split(addresses, ","))
                .map(String::trim)
                .filter(StringUtils::isNotBlank)
                .toArray(String[]::new);
    }
}
