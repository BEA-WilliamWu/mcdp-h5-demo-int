package com.bea.payment.bulk.notification;

import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * Renders manual-review notification email content.
 */
@Component
public class ManualReviewEmailTemplateRenderer {

    private static final String DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";

    private final PaymentNotificationEmailProperties properties;

    public ManualReviewEmailTemplateRenderer(PaymentNotificationEmailProperties properties) {
        this.properties = Objects.requireNonNull(properties, "properties must not be null");
    }

    public RenderedEmail render(PaymentTxnMainEntity txn,PaymentTxnEventEntity event, String downstreamSystem,
            String reasonCode, String detailMessage) {
        Objects.requireNonNull(txn, "txn must not be null");
        String resolvedDownstream = value(downstreamSystem);
        String subject = renderSubject(resolvedDownstream);
        String body = """
                Dear CSOD Team,

                During the processing of Payments, IPE detected a transaction that encountered an exception during transfer in the core system
                and requires manual intervention. Below are the details of the affected transaction for your attention and immediate action:

                **Transaction Details:**
                - **Transaction ID:** %s
                - **Payer Account:** %s
                - **Payee Account:** %s
                - **Amount:** %s
                - **Execution Time:** %s
                - **Exception Information:** %s

                Please process this transaction as soon as possible to minimize any impact on the business. If you require additional information
                or have any questions, feel free to reach out.

                Thank you for your prompt attention to this matter.

                Best regards,
                IPE System
                %s
                """
                .formatted(
                        value(txn.getTransactionId()),
                        value(txn.getPayerAccountNo()),
                        payeeAccountDisplay(txn,event),
                        amountDisplay(txn),
                        executionTimeDisplay(txn),
                        exceptionInformation(txn, resolvedDownstream, reasonCode, detailMessage),
                        formatDate(new Date()));
        return new RenderedEmail(subject, body);
    }

    private String renderSubject(String downstreamSystem) {
        String template = "EPH".equalsIgnoreCase(downstreamSystem)
                ? properties.getEphSubject()
                : properties.getBg3Subject();
        if (template == null || template.isBlank()) {
            template = "Payment Transaction Exceptions";
        }
        return template
                .replace("${environment}", value(properties.getEnvironment()))
                .replace("${downstreamSystem}", downstreamSystem);
    }

    private static String formatDate(Date date) {
        return date == null ? "" : new SimpleDateFormat(DATE_PATTERN).format(date);
    }

    private static String formatAmount(BigDecimal amount) {
        return amount == null ? "" : amount.toPlainString();
    }

    private static String value(String value) {
        return value == null ? "" : value;
    }

    private static String amountDisplay(PaymentTxnMainEntity txn) {
        String amount = formatAmount(txn.getDebitAmount());
        String currency = value(txn.getDebitAmountCcy());
        if (amount.isBlank()) {
            return currency;
        }
        if (currency.isBlank()) {
            return amount;
        }
        return amount + " " + currency;
    }

    private static String payeeAccountDisplay(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        String accountNo = firstText(txn.getPayeeAccountNo());
        if (!accountNo.isBlank()) {
            return accountNo;
        }
        String identificationType = value(event.getEphPayeeIdentificationType()).trim().toUpperCase();
        if (identificationType.contains("EMAL") || identificationType.contains("EMAIL")) {
            return firstText(txn.getPayeeEmailAddress(), txn.getPayeeMobileNo(), txn.getPayeeProxyId());
        }
        if (identificationType.contains("MOB")
                || identificationType.contains("MSISDN")
                || identificationType.contains("PHONE")
                || identificationType.contains("TEL")) {
            return firstText(txn.getPayeeMobileNo(), txn.getPayeeEmailAddress(), txn.getPayeeProxyId());
        }
        if (identificationType.contains("SVID")
                || identificationType.contains("PROXY")
                || identificationType.contains("FPS")) {
            return firstText(txn.getPayeeProxyId(), txn.getPayeeEmailAddress(), txn.getPayeeMobileNo());
        }
        return firstText(
                txn.getPayeeEmailAddress(),
                txn.getPayeeMobileNo(),
                txn.getPayeeProxyId());
    }

    private static String executionTimeDisplay(PaymentTxnMainEntity txn) {
        return firstText(
                formatDate(txn.getExecutionStartTime()),
                formatDate(txn.getExecutionEndTime()),
                formatDate(txn.getExecutionDate()));
    }

    private static String exceptionInformation(PaymentTxnMainEntity txn, String downstreamSystem,
            String reasonCode, String detailMessage) {
        return firstText(
                detailMessage,
                reasonCode,
                txn.getLastErrorCode(),
                txn.getManualReviewReason(),
                downstreamSystem.isBlank() ? null : "call " + downstreamSystem.toLowerCase() + " failed");
    }

    private static String firstText(String... values) {
        if (values == null) {
            return "";
        }
        for (String candidate : values) {
            if (candidate != null && !candidate.isBlank()) {
                return candidate;
            }
        }
        return "";
    }

    public record RenderedEmail(String subject, String body) {
    }
}
