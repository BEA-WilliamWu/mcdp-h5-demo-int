package com.bea.payment.bulk.notification;

import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * Creates a JavaMailSender from the payment-engine notification namespace.
 */
@Configuration
public class PaymentNotificationEmailConfiguration {

    @Bean
    @ConditionalOnMissingBean(JavaMailSender.class)
    @ConditionalOnProperty(prefix = "pe.notification.email", name = "enabled", havingValue = "true")
    @ConditionalOnExpression("'${pe.notification.email.host:}' != ''")
    public JavaMailSender paymentNotificationJavaMailSender(PaymentNotificationEmailProperties properties) {
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        sender.setHost(properties.getHost());
        sender.setPort(properties.getPort());
        sender.setDefaultEncoding("UTF-8");
        return sender;
    }
}
