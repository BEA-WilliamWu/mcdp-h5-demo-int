package com.bea.payment.bulk.notification;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Manual-review email notification settings.
 */
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "pe.notification.email")
public class PaymentNotificationEmailProperties {

    private boolean enabled = false;

    private String host;

    private int port = 25;

    private String from;

    private String to;

    private String cc;

    private String environment = "LOCAL";

    private String bg3Subject = "Payment Transaction Exceptions";

    private String ephSubject = "Payment Transaction Exceptions";
}
