package com.bea.payment.bulk.service;

import com.bea.payment.bulk.mapper.BatchIdSequenceMapper;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class BatchIdGenerator {

    private static final DateTimeFormatter TIMESTAMP_FMT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final BatchIdSequenceMapper sequenceMapper;

    public BatchIdGenerator(BatchIdSequenceMapper sequenceMapper) {
        this.sequenceMapper = sequenceMapper;
    }

    /**
     * 生成 23 位 batchId: CHANNEL(3) + yyyyMMddHHmmss(14) + 序列号(6)
     */
    public String generate(String channel) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FMT);
        long seq = sequenceMapper.nextVal();
        return channel + timestamp + String.format("%06d", seq % 1_000_000L);
    }

}
