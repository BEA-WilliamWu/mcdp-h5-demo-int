package com.bea.payment.bulk.service;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.internal.flow.util.FlowControlParamMergeUtils;
import com.bea.payment.bulk.mapper.FlowControlParamMapper;
import com.bea.payment.bulk.mapper.FlowControlProfileMapper;
import com.bea.payment.bulk.model.dto.FlowControlProfileCreateRequest;
import com.bea.payment.bulk.model.dto.FlowControlProfileQueryRequest;
import com.bea.payment.bulk.model.dto.FlowControlProfileResponse;
import com.bea.payment.bulk.model.dto.FlowControlProfileUpdateRequest;
import com.bea.payment.bulk.model.entity.FlowControlParamEntity;
import com.bea.payment.bulk.model.entity.FlowControlProfileEntity;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.StandardResultCode;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Flow Control Profile 管理 Service
 */
@Service
public class FlowControlProfileService {

    private final FlowControlProfileMapper profileMapper;
    private final FlowControlParamMapper paramMapper;

    public FlowControlProfileService(
            FlowControlProfileMapper profileMapper,
            FlowControlParamMapper paramMapper
    ) {
        this.profileMapper = profileMapper;
        this.paramMapper = paramMapper;
    }

    /**
     * 查询 Profile (含参数)
     */
    public List<FlowControlProfileResponse> queryProfiles(FlowControlProfileQueryRequest request) {

        LambdaQueryWrapper<FlowControlProfileEntity> wrapper =
                new LambdaQueryWrapper<>();

        if (request.getTxType() != null) {
            wrapper.eq(FlowControlProfileEntity::getTxType, request.getTxType());
        }

        if (request.getStatus() != null) {
            wrapper.eq(FlowControlProfileEntity::getStatus, request.getStatus());
        }

        if (request.getIncludeDeleted() == null
                || !request.getIncludeDeleted()) {
            wrapper.eq(FlowControlProfileEntity::getIsDeleted, "N");
        }

        List<FlowControlProfileEntity> profiles =
                profileMapper.selectList(wrapper);

        if (profiles.isEmpty()) {
            return Collections.emptyList();
        }

        List<Long> profileIds = profiles.stream()
                .map(FlowControlProfileEntity::getProfileId)
                .collect(Collectors.toList());

        LambdaQueryWrapper<FlowControlParamEntity> paramWrapper =
                new LambdaQueryWrapper<>();

        paramWrapper.in(FlowControlParamEntity::getProfileId, profileIds)
                .eq(FlowControlParamEntity::getIsDeleted, "N")
                .eq(FlowControlParamEntity::getStatus, "ACTIVE");

        List<FlowControlParamEntity> params =
                paramMapper.selectList(paramWrapper);

        /*
         * 统一参数合并策略：
         * - 同一 PROFILE_ID + PARAM_KEY
         * - 取 OBJECT_VERSION_NUMBER 最大的一条
         *
         * 注意：
         * - Loader / Service / Engine 必须使用同一策略
         */
        Map<Long, Map<String, String>> paramMap =
                FlowControlParamMergeUtils.mergeByProfile(params);

        List<FlowControlProfileResponse> result = new ArrayList<>();

        for (FlowControlProfileEntity p : profiles) {

            FlowControlProfileResponse resp =
                    new FlowControlProfileResponse();

            resp.setProfileId(p.getProfileId());
            resp.setProfileName(p.getProfileName());
            resp.setTxType(p.getTxType());
            resp.setApplicableDays(p.getApplicableDays());
            resp.setStartTime(p.getStartTime());
            resp.setEndTime(p.getEndTime());
            resp.setPriority(p.getPriority());
            resp.setStatus(p.getStatus());
            resp.setObjectVersionNumber(p.getObjectVersionNumber());

            resp.setParams(
                    paramMap.getOrDefault(
                            p.getProfileId(),
                            Collections.emptyMap()
                    )
            );

            result.add(resp);
        }

        return result;
    }

    /**
     * 新增 Profile
     */
    @Transactional
    public void createProfile(FlowControlProfileCreateRequest request) {

        FlowControlProfileEntity entity = new FlowControlProfileEntity();
        entity.setProfileName(request.getProfileName());
        entity.setTxType(request.getTxType());
        entity.setApplicableDays(request.getApplicableDays());
        entity.setStartTime(request.getStartTime());
        entity.setEndTime(request.getEndTime());
        entity.setPriority(request.getPriority());
        entity.setStatus("ACTIVE");
        entity.setIsDeleted("N");
        entity.setObjectVersionNumber(1L);

        profileMapper.insert(entity);

        if (request.getParams() != null) {
            request.getParams().forEach((k, v) -> {
                FlowControlParamEntity param = new FlowControlParamEntity();
                param.setProfileId(entity.getProfileId());
                param.setParamKey(k);
                param.setParamValue(v);
                param.setStatus("ACTIVE");
                param.setIsDeleted("N");
                paramMapper.insert(param);
            });
        }
    }

    /**
     * 修改 Profile
     */
    @Transactional
    public void updateProfile(FlowControlProfileUpdateRequest request) {
        if (request.getProfileId() == null || request.getObjectVersionNumber() == null) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "profileId and objectVersionNumber are required");
        }

        FlowControlProfileEntity existing = profileMapper.selectOne(
                new LambdaQueryWrapper<FlowControlProfileEntity>()
                        .eq(FlowControlProfileEntity::getProfileId, request.getProfileId())
                        .eq(FlowControlProfileEntity::getIsDeleted, "N"));
        if (existing == null) {
            throw new BusinessException(
                    StandardResultCode.BUSINESS_REJECTED,
                    "Profile not found"
            );
        }

        FlowControlProfileEntity update = new FlowControlProfileEntity();
        update.setProfileName(request.getProfileName());
        update.setPriority(request.getPriority());
        update.setStatus(request.getStatus());
        update.setObjectVersionNumber(request.getObjectVersionNumber() + 1);
        int updated = profileMapper.update(update,
                new LambdaUpdateWrapper<FlowControlProfileEntity>()
                        .eq(FlowControlProfileEntity::getProfileId, request.getProfileId())
                        .eq(FlowControlProfileEntity::getIsDeleted, "N")
                        .eq(FlowControlProfileEntity::getObjectVersionNumber,
                                request.getObjectVersionNumber()));
        if (updated != 1) {
            throw new BusinessException(
                    StandardResultCode.BUSINESS_REJECTED,
                    "Profile version mismatch"
            );
        }

        if (request.getParams() != null) {
            List<FlowControlParamEntity> currentParams = paramMapper.selectList(
                    new LambdaQueryWrapper<FlowControlParamEntity>()
                            .eq(FlowControlParamEntity::getProfileId, request.getProfileId())
                            .eq(FlowControlParamEntity::getIsDeleted, "N"));
            Map<String, Long> maxVersions = currentParams.stream().collect(Collectors.toMap(
                    FlowControlParamEntity::getParamKey,
                    param -> Optional.ofNullable(param.getObjectVersionNumber()).orElse(0L),
                    Math::max));
            request.getParams().forEach((k, v) -> {
                FlowControlParamEntity param =
                        new FlowControlParamEntity();
                param.setProfileId(request.getProfileId());
                param.setParamKey(k);
                param.setParamValue(v);
                param.setStatus("ACTIVE");
                param.setIsDeleted("N");
                param.setObjectVersionNumber(maxVersions.getOrDefault(k, 0L) + 1);
                paramMapper.insert(param);
            });
        }
    }
}
