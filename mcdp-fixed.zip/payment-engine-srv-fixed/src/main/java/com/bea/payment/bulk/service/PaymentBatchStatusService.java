package com.bea.payment.bulk.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.BatchStatusEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.mapper.PaymentBatchHdrMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.entity.PaymentBatchHdrEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * 根据 MAIN 交易终态刷新 HDR 批次终态。
 */
@Service
public class PaymentBatchStatusService {

    private static final String NOT_DELETED = "N";
    private static final List<String> TERMINAL_BATCH_STATUSES = List.of(
            BatchStatusEnum.COMPLETED.getCode(),
            BatchStatusEnum.ALL_FAILED.getCode(),
            BatchStatusEnum.PARTIAL_SUCCESS.getCode(),
            BatchStatusEnum.MANUAL_REVIEW.getCode());

    private final PaymentBatchHdrMapper batchHdrMapper;
    private final PaymentTxnMainMapper txnMainMapper;

    public PaymentBatchStatusService(PaymentBatchHdrMapper batchHdrMapper,
            PaymentTxnMainMapper txnMainMapper) {
        this.batchHdrMapper = Objects.requireNonNull(batchHdrMapper, "batchHdrMapper must not be null");
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
    }

    public boolean refreshIfBatchTerminal(String batchId) {
        BatchStatusSummary summary = summarize(batchId);

        if (!summary.terminal()) {
            return false;
        }

        PaymentBatchHdrEntity update = new PaymentBatchHdrEntity();
        update.setBatchStatus(summary.batchStatus());
        int updated = batchHdrMapper.update(update, new LambdaUpdateWrapper<PaymentBatchHdrEntity>()
                .eq(PaymentBatchHdrEntity::getBatchId, batchId)
                .eq(PaymentBatchHdrEntity::getIsDeleted, NOT_DELETED)
                .notIn(PaymentBatchHdrEntity::getBatchStatus, TERMINAL_BATCH_STATUSES));
        return updated == 1;
    }

    public BatchStatusSummary summarize(String batchId) {
        if (batchId == null || batchId.isBlank()) {
            return BatchStatusSummary.empty();
        }

        List<PaymentTxnMainEntity> transactions = txnMainMapper.selectList(baseQuery(batchId));
        if (transactions.isEmpty()) {
            return BatchStatusSummary.empty();
        }
        String currentBatchStatus = currentBatchStatus(batchId);

        long total = transactions.size();
        long successCount = transactions.stream().filter(this::isSuccess).count();
        long failedCount = transactions.stream().filter(this::isFailed).count();
        long manualReviewCount = transactions.stream().filter(this::isManualReview).count();
        long terminalCount = successCount + failedCount + manualReviewCount;
        long nonTerminalCount = total - terminalCount;

        if (manualReviewCount > 0) {
            return new BatchStatusSummary(BatchStatusEnum.MANUAL_REVIEW.getCode(),
                    nonTerminalCount == 0, total, nonTerminalCount, failedCount);
        }
        if (nonTerminalCount > 0) {
            return new BatchStatusSummary(firstText(currentBatchStatus, BatchStatusEnum.DISPATCHING.getCode()),
                    false, total, nonTerminalCount, failedCount);
        }
        if (successCount == total) {
            return new BatchStatusSummary(BatchStatusEnum.COMPLETED.getCode(),
                    true, total, 0L, failedCount);
        }
        if (failedCount == total) {
            return new BatchStatusSummary(BatchStatusEnum.ALL_FAILED.getCode(),
                    true, total, 0L, failedCount);
        }
        if (successCount > 0 && failedCount > 0) {
            return new BatchStatusSummary(BatchStatusEnum.PARTIAL_SUCCESS.getCode(),
                    true, total, 0L, failedCount);
        }
        return new BatchStatusSummary(BatchStatusEnum.UNKNOWN.getCode(), false, total, nonTerminalCount, failedCount);
    }

    private LambdaQueryWrapper<PaymentTxnMainEntity> baseQuery(String batchId) {
        return new LambdaQueryWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getBatchId, batchId)
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED);
    }

    private String currentBatchStatus(String batchId) {
        PaymentBatchHdrEntity hdr = batchHdrMapper.selectOne(new LambdaQueryWrapper<PaymentBatchHdrEntity>()
                .eq(PaymentBatchHdrEntity::getBatchId, batchId)
                .eq(PaymentBatchHdrEntity::getIsDeleted, NOT_DELETED)
                .last("FETCH FIRST 1 ROWS ONLY"));
        return hdr == null ? null : hdr.getBatchStatus();
    }

    private String firstText(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private boolean isSuccess(PaymentTxnMainEntity txn) {
        return PaymentStatusEnum.COMPLETED.getCode().equals(txn.getPaymentStatus());
    }

    private boolean isFailed(PaymentTxnMainEntity txn) {
        return PaymentStatusEnum.FAILED.getCode().equals(txn.getPaymentStatus());
    }

    private boolean isManualReview(PaymentTxnMainEntity txn) {
        return PaymentStatusEnum.MANUAL_REVIEW.getCode().equals(txn.getPaymentStatus());
    }

    public record BatchStatusSummary(String batchStatus, boolean terminal, long totalCount,
            long nonTerminalCount, long failedCount) {

        private static BatchStatusSummary empty() {
            return new BatchStatusSummary(null, false, 0L, 0L, 0L);
        }
    }
}
