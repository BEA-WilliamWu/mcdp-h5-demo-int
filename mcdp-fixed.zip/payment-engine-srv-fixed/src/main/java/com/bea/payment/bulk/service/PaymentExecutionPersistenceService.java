package com.bea.payment.bulk.service;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

/**
 * Persists the result of one downstream execution as a single database unit.
 * The downstream call itself must happen before entering this service.
 */
@Service
public class PaymentExecutionPersistenceService {

    private static final String NOT_DELETED = "N";

    private final PaymentTxnMainMapper txnMainMapper;
    private final PaymentTxnEventService eventService;
    private final PaymentBatchStatusService batchStatusService;

    public PaymentExecutionPersistenceService(PaymentTxnMainMapper txnMainMapper,
            PaymentTxnEventService eventService,
            PaymentBatchStatusService batchStatusService) {
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.eventService = Objects.requireNonNull(eventService, "eventService must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService,
                "batchStatusService must not be null");
    }

    @Transactional
    public void save(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        Objects.requireNonNull(txn, "txn must not be null");
        Objects.requireNonNull(event, "event must not be null");
        if (txnMainMapper.update(txn, new LambdaUpdateWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getTxnId, txn.getTxnId())
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnMainEntity::getPaymentStatus,
                        PaymentStatusEnum.PROCESSING.getCode())) != 1) {
            throw new IllegalStateException("Payment transaction was not updated: " + txn.getTransactionId());
        }
        eventService.record(txn, event);
        batchStatusService.refreshIfBatchTerminal(txn.getBatchId());
    }
}
