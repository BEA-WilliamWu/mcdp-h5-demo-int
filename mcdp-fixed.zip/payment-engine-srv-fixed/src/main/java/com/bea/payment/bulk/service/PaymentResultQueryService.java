package com.bea.payment.bulk.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bea.payment.bulk.constants.DownstreamSystemEnum;
import com.bea.payment.bulk.constants.PaymentStatusEnum;
import com.bea.payment.bulk.constants.PaymentTxnEventTypeEnum;
import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.PaymentResultQueryRequest;
import com.bea.payment.bulk.model.dto.PaymentResultQueryResponse;
import com.bea.payment.bulk.model.dto.PaymentTxnMainConvertDTO;
import com.bea.payment.bulk.model.dto.PaymentTxnMainEventDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.StandardResultCode;
import com.bea.payment.common.util.UuidV7Utils;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Formal upstream payment result enquiry service.
 *
 * <p>This service is read-only. It does not trigger callback, EPH query
 * compensation, Scanner, Worker, MQ, BG3, or EPH execution.</p>
 */
@Service
public class PaymentResultQueryService {

    private static final String NOT_DELETED = "N";
    private static final String YES = "Y";

    private static final String STATUS_PROCESSING = "PROCESSING";
    private static final String STATUS_SUCCESS = "SUCCESS";
    private static final String STATUS_FAILED = "FAILED";
    private static final String STATUS_MANUAL_REVIEW = "MANUAL_REVIEW";

    private final PaymentTxnMainMapper txnMainMapper;
    private final PaymentBatchStatusService batchStatusService;
    private final PaymentTxnEventService eventService;
    private final PaymentTxnEventMapper eventMapper;

    public PaymentResultQueryService(PaymentTxnMainMapper txnMainMapper,
                                     PaymentBatchStatusService batchStatusService,
                                     PaymentTxnEventService eventService, PaymentTxnEventMapper eventMapper) {
        this.txnMainMapper = Objects.requireNonNull(txnMainMapper, "txnMainMapper must not be null");
        this.batchStatusService = Objects.requireNonNull(batchStatusService,
                "batchStatusService must not be null");
        this.eventService = Objects.requireNonNull(eventService, "eventService must not be null");
        this.eventMapper = eventMapper;
    }

    public List<PaymentResultQueryResponse> query(PaymentResultQueryRequest request) {
        String transactionId = trimToNull(request == null ? null : request.getTransactionId());
        if (transactionId != null) {
            return List.of(queryByTransactionId(transactionId));
        }

        String batchId = trimToNull(request == null ? null : request.getBatchId());
        if (batchId == null) {
            throw new BusinessException(StandardResultCode.INVALID_REQUEST,
                    "transactionId or batchId is required");
        }

        return queryByBatchId(batchId);
    }

    public PaymentResultQueryResponse queryByTransactionId(String transactionId) {
        PaymentTxnMainConvertDTO paymentTxnMainConvertDTO = loadTransaction(transactionId);
        return toResponse(paymentTxnMainConvertDTO);
    }

    public List<PaymentResultQueryResponse> queryByBatchId(String batchId) {
        List<PaymentTxnMainEventDTO> transactions = txnMainMapper.selectPaymentResultQueryList(batchId, 1);

        Map<String, String> downstreamStatuses = eventService.findEphDownstreamStatuses(batchId);
        Map<String, PaymentTxnEventService.EventSummary> eventSummaries =
                eventService.latestEventSummaries(batchId);
        PaymentBatchStatusService.BatchStatusSummary batchSummary = batchStatusService.summarize(batchId);

        return transactions.stream()
                .map(transaction -> toResponse(
                        transaction,
                        downstreamStatuses.get(transaction.getTransactionId()),
                        batchSummary,
                        eventSummaries.get(transaction.getTransactionId())
                ))
                .toList();
    }

    private PaymentResultQueryResponse toResponse(PaymentTxnMainEventDTO resultQueryRes,
            String downstreamStatus,
            PaymentBatchStatusService.BatchStatusSummary batchSummary,
            PaymentTxnEventService.EventSummary eventSummary) {
        PaymentResultQueryResponse response = new PaymentResultQueryResponse();
        response.setTransactionId(resultQueryRes.getTransactionId());
        response.setIpeReferenceId(UuidV7Utils.toString(resultQueryRes.getIpeReferenceId()));
        response.setBatchId(resultQueryRes.getBatchId());
        response.setBatchStatus(batchSummary.batchStatus());
        response.setBatchTerminal(batchSummary.terminal());
        response.setChannel(resultQueryRes.getChannel());
        response.setPayeeBankCode(resultQueryRes.getPayeeBankCode());
        response.setCustomerType(resultQueryRes.getCustomerType());
        response.setChannelReference(resultQueryRes.getChannelReference());
        response.setTransactionType(resultQueryRes.getTransactionType());
        response.setStatus(resolveExternalStatus(resultQueryRes));
        response.setTerminal(isTransactionTerminal(resultQueryRes));
        response.setStatusReason(resultQueryRes.getStatusReason());
        response.setManualReviewRequired(PaymentStatusEnum.MANUAL_REVIEW.getCode().equals(resultQueryRes.getPaymentStatus()));
        response.setManualReviewReason(resultQueryRes.getManualReviewReason());
        response.setAmount(resultQueryRes.getDebitAmount());
        response.setCurrency(resultQueryRes.getDebitAmountCcy());
        response.setDownstreamSystem(firstText(resultQueryRes.getLastDownstreamSystem(), expectedDownstreamSystem(resultQueryRes.getTransactionType(),resultQueryRes.getEphNeedsStatusQuery())));
        response.setDownstreamReference(resolveDownstreamReference(eventSummary));
        response.setDownstreamStatus(downstreamStatus);
        response.setErrorCode(resolveErrorCode(resultQueryRes, eventSummary, response.getStatus()));
        response.setErrorSource(resultQueryRes.getErrorSource());
        response.setErrorMessage(resolveErrorMessage(eventSummary));
        response.setLastUpdatedAt(firstDate(resultQueryRes.getLastUpdateDate(), resultQueryRes.getCreationDate()));
        return response;
    }

    private PaymentTxnMainConvertDTO loadTransaction(String transactionId) {
        PaymentTxnMainEntity txn = txnMainMapper.selectOne(new LambdaQueryWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getTransactionId, transactionId)
                .eq(PaymentTxnMainEntity::getIsDeleted, NOT_DELETED)
                .last("FETCH FIRST 1 ROWS ONLY"));
        PaymentTxnEventEntity event = eventMapper.selectOne(new LambdaQueryWrapper<PaymentTxnEventEntity>()
                .eq(PaymentTxnEventEntity::getTransactionId, transactionId)
                .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED)
                .eq(PaymentTxnEventEntity::getOrderId, 1)
                .eq(PaymentTxnEventEntity::getEventType,
                        PaymentTxnEventTypeEnum.PAYMENT_ACCEPTED.name())
                .last("FETCH FIRST 1 ROWS ONLY"));
        if (txn == null) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "Payment transaction[main] not found: " + transactionId);
        }
        if (event == null) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "Payment transaction[event] not found: " + transactionId);
        }
        PaymentTxnMainConvertDTO paymentTxnMainConvertDTO = new PaymentTxnMainConvertDTO();
        paymentTxnMainConvertDTO.setPaymentTxnMainEntity(txn);
        paymentTxnMainConvertDTO.setPaymentTxnEventEntity(event);
        return paymentTxnMainConvertDTO;
    }
    //
    private PaymentResultQueryResponse toResponse(PaymentTxnMainConvertDTO paymentTxnMainConvertDTO) {
        PaymentTxnMainEntity txn = paymentTxnMainConvertDTO.getPaymentTxnMainEntity();
        PaymentTxnEventEntity event = paymentTxnMainConvertDTO.getPaymentTxnEventEntity();
        PaymentResultQueryResponse response = new PaymentResultQueryResponse();
        PaymentBatchStatusService.BatchStatusSummary batchSummary = batchStatusService.summarize(txn.getBatchId());
        PaymentTxnEventService.EventSummary eventSummary =
                eventService.latestEventSummary(txn.getTransactionId()).orElse(null);
        response.setTransactionId(txn.getTransactionId());
        response.setIpeReferenceId(UuidV7Utils.toString(txn.getIpeReferenceId()));
        response.setBatchId(txn.getBatchId());
        response.setBatchStatus(batchSummary.batchStatus());
        response.setBatchTerminal(batchSummary.terminal());
        response.setChannel(txn.getChannel());
        response.setPayeeBankCode(txn.getPayeeBankCode());
        response.setCustomerType(event.getCustomerType());
        response.setChannelReference(txn.getChannelReference());
        response.setTransactionType(txn.getTransactionType());
        response.setStatus(resolveExternalStatus(txn));
        response.setTerminal(isTransactionTerminal(txn));
        response.setStatusReason(txn.getStatusReason());
        response.setManualReviewRequired(PaymentStatusEnum.MANUAL_REVIEW.getCode().equals(txn.getPaymentStatus()));
        response.setManualReviewReason(txn.getManualReviewReason());
        response.setAmount(txn.getDebitAmount());
        response.setCurrency(txn.getDebitAmountCcy());
        response.setDownstreamSystem(firstText(txn.getLastDownstreamSystem(), expectedDownstreamSystem(txn.getTransactionType(),event.getEphNeedsStatusQuery())));
        response.setDownstreamReference(resolveDownstreamReference(eventSummary));
        response.setDownstreamStatus(resolveDownstreamStatus(txn.getTransactionId()));
        response.setErrorCode(resolveErrorCode(txn, eventSummary, response.getStatus()));
        response.setErrorSource(txn.getErrorSource());
        response.setErrorMessage(resolveErrorMessage(eventSummary));
        response.setLastUpdatedAt(firstDate(txn.getLastUpdateDate(), txn.getCreationDate()));
        return response;
    }

    private String resolveExternalStatus(PaymentTxnMainEntity txn) {
        if (PaymentStatusEnum.COMPLETED.getCode().equals(txn.getPaymentStatus())) {
            return STATUS_SUCCESS;
        }
        if (PaymentStatusEnum.FAILED.getCode().equals(txn.getPaymentStatus())) {
            return STATUS_FAILED;
        }
        if (PaymentStatusEnum.MANUAL_REVIEW.getCode().equals(txn.getPaymentStatus())) {
            return STATUS_MANUAL_REVIEW;
        }
        return STATUS_PROCESSING;
    }

    private String resolveErrorCode(PaymentTxnMainEntity txn, PaymentTxnEventService.EventSummary eventSummary,
            String externalStatus) {
        String downstreamResultCode = isErrorResultStatus(externalStatus)
                ? eventSummary == null ? null : eventSummary.resultCode()
                : null;
        return firstText(
                eventSummary == null ? null : eventSummary.errorCode(),
                downstreamResultCode,
                txn.getLastErrorCode()
        );
    }

    private boolean isErrorResultStatus(String externalStatus) {
        return STATUS_FAILED.equals(externalStatus) || STATUS_MANUAL_REVIEW.equals(externalStatus);
    }

    private boolean isTransactionTerminal(PaymentTxnMainEntity txn) {
        return PaymentStatusEnum.COMPLETED.getCode().equals(txn.getPaymentStatus())
                || PaymentStatusEnum.FAILED.getCode().equals(txn.getPaymentStatus())
                || PaymentStatusEnum.MANUAL_REVIEW.getCode().equals(txn.getPaymentStatus());
    }

    private String resolveErrorMessage(PaymentTxnEventService.EventSummary eventSummary) {
        return eventSummary == null ? null : eventSummary.errorMessage();
    }

    private String resolveDownstreamReference(PaymentTxnEventService.EventSummary eventSummary) {
        return eventSummary == null ? null : eventSummary.downstreamReference();
    }

    private String expectedDownstreamSystem(String transactionType, String ephNeedsStatusQuery) {
        if (TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(nullToEmpty(transactionType))) {
            return DownstreamSystemEnum.EPH.getCode();
        }
        if (TransactionTypeEnum.INTERNAL.getCode().equalsIgnoreCase(nullToEmpty(transactionType))) {
            return DownstreamSystemEnum.BG3.getCode();
        }
        if (TransactionTypeEnum.CHATS.getCode().equalsIgnoreCase(nullToEmpty(transactionType))) {
            return DownstreamSystemEnum.CHATS.getCode();
        }
        if (YES.equalsIgnoreCase(nullToEmpty(ephNeedsStatusQuery))) {
            return DownstreamSystemEnum.EPH.getCode();
        }
        return null;
    }

    private String resolveDownstreamStatus(String transactionId) {
        return eventService.findEphDownstreamStatus(transactionId)
                .orElse(null);
    }

    private Date firstDate(Date... values) {
        if (values == null) {
            return null;
        }
        for (Date value : values) {
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    private static String firstText(String... values) {
        if (values == null) {
            return null;
        }
        for (String value : values) {
            if (notBlank(value)) {
                return value;
            }
        }
        return null;
    }

    private static boolean notBlank(String value) {
        return value != null && !value.isBlank();
    }

    private static String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
