package com.bea.payment.bulk.service;

import com.bea.payment.bulk.constants.*;
import com.bea.payment.bulk.internal.chats.ChatsHttpClient;
import com.bea.payment.bulk.internal.chats.ChatsHttpException;
import com.bea.payment.bulk.internal.chats.config.ChatsProperties;
import com.bea.payment.bulk.internal.chats.model.ChatsHttpErrorType;
import com.bea.payment.bulk.internal.chats.model.ChatsPerCheckTransferRequest;
import com.bea.payment.bulk.internal.eph.config.EphProperties;
import com.bea.payment.bulk.mapper.PaymentBatchHdrMapper;
import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.*;
import com.bea.payment.bulk.model.entity.PaymentBatchHdrEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.validator.BatchCreditTransferValidator;
import com.bea.payment.bulk.validator.SingleCreditTransferValidator;
import com.bea.payment.common.context.RequestContextHolder;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.exception.SystemException;
import com.bea.payment.common.response.ApiResponse;
import com.bea.payment.common.response.StandardResultCode;
import com.bea.payment.common.util.UuidV7Utils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;


import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


import static com.bea.payment.common.util.DateTimeUtils.toIntegerDate;


@Service
public class PaymentSubmitService {


    private static final Logger log = LoggerFactory.getLogger(PaymentSubmitService.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();


    /**
     * 单笔转账请求校验器。
     */
    private final SingleCreditTransferValidator singleValidator;


    /**
     * 批量转账请求校验器。
     */
    private final BatchCreditTransferValidator batchValidator;


    /**
     * 批次号生成器，用于单笔接口自动生成内部批次号。
     */
    private final BatchIdGenerator batchIdGenerator;


    /**
     * 批次头表 Mapper。
     */
    private final PaymentBatchHdrMapper batchHdrMapper;




    private final PaymentTxnEventMapper paymentTxnEventMapper;
    /**
     * 交易主表 Mapper。
     */
    private final PaymentTxnMainMapper txnMainMapper;


    private final ObjectMapper objectMapper;
    private final ChatsProperties chatsProperties;
    private final ObjectProvider<ChatsHttpClient> chatsHttpClientProvider;
    private final TransactionTemplate transactionTemplate;


    /**
     * EPH 下游配置，包括 IPE 负责维护的固定控制字段。
     */
    private final EphProperties ephProperties;


    public PaymentSubmitService(
            SingleCreditTransferValidator singleValidator,
            BatchCreditTransferValidator batchValidator,
            BatchIdGenerator batchIdGenerator,
            PaymentBatchHdrMapper batchHdrMapper,
            PaymentTxnMainMapper txnMainMapper,
            EphProperties ephProperties, PaymentTxnEventMapper paymentTxnEventMapper,
            ObjectMapper objectMapper,
            ChatsProperties chatsProperties, ObjectProvider<ChatsHttpClient> chatsHttpClientProvider,
            TransactionTemplate transactionTemplate) {
        this.singleValidator = singleValidator;
        this.batchValidator = batchValidator;
        this.batchIdGenerator = batchIdGenerator;
        this.batchHdrMapper = batchHdrMapper;
        this.txnMainMapper = txnMainMapper;
        this.paymentTxnEventMapper = paymentTxnEventMapper;
        this.objectMapper = objectMapper;
        this.ephProperties = ephProperties;
        this.chatsProperties = chatsProperties;
        this.chatsHttpClientProvider = Objects.requireNonNull(chatsHttpClientProvider,
                "chatsHttpClientProvider must not be null");
        this.transactionTemplate = transactionTemplate;
    }


    @Transactional
    public SubmitResponse submitSingle(SingleCreditTransferRequest req) {
        String transactionId = req.getTransactionId();
        log.info("[PAYMENT-SUBMIT] Starting single credit transfer submission: transactionId={}, channel={}, txType={}",
                transactionId, req.getChannel(), req.getTransactionType());
        singleValidator.validate(req);
        checkTransactionIdUnique(transactionId);


        // 单笔接口没有外部 batchId，这里生成内部批次号。
        String batchId = batchIdGenerator.generate(req.getChannel());
        log.debug("[PAYMENT-SUBMIT] Generated batchId: {} for transactionId={}", batchId, transactionId);
        PaymentBatchHdrEntity hdr = buildSingleHdr(req, batchId);
        batchHdrMapper.insert(hdr);
        log.debug("[PAYMENT-SUBMIT] Batch header inserted: batchId={}", batchId);


        // 构造并落库单笔交易，orderId 固定为 1。
        PaymentTxnMainConvertDTO paymentTxnMainConvert = buildTxnFromSingle(req, batchId);
        PaymentTxnMainEntity txn = paymentTxnMainConvert.getPaymentTxnMainEntity();
        PaymentTxnEventEntity event = paymentTxnMainConvert.getPaymentTxnEventEntity();
        txnMainMapper.insert(txn);
        initializeIntakeEvent(txn, event);
        paymentTxnEventMapper.insert(event);
        log.debug("[PAYMENT-SUBMIT] Transaction inserted: transactionId={}, batchId={}, orderId={}",
                transactionId, batchId, txn.getOrderId());


        SubmitResponse response = acceptedResponse(List.of(paymentTxnMainConvert));
        log.info("[PAYMENT-SUBMIT] Single credit transfer submitted successfully: transactionId={}, batchId={}",
                transactionId, batchId);
        return response;
    }


    @Transactional
    public SubmitResponse submitMultiple(BatchCreditTransferRequest req) {
        String batchId = req.getBatchId();
        int txnCount = req.getTransactions() != null ? req.getTransactions().size() : 0;
        log.info("[PAYMENT-SUBMIT] Starting multiple credit transfer submission: batchId={}, channel={}, txnCount={}, totalAmount={}",
                batchId, req.getChannel(), txnCount, req.getTotalAmount());


        // 校验批量请求基础字段和交易明细。
        batchValidator.validate(req);
        checkBatchIdUnique(batchId);
        for (TransactionDetailRequest txn : req.getTransactions()) {
            checkTransactionIdUnique(txn.getTransactionId());
        }


        // 批量接口落库批次头，apiSource 标记为 MULTIPLE_CREDIT_TRANSFER。
        PaymentBatchHdrEntity hdr = buildBatchHdr(req, ApiNameEnum.MULTIPLE_CREDIT_TRANSFER.getCode());
        batchHdrMapper.insert(hdr);
        log.debug("[PAYMENT-SUBMIT] Batch header inserted: batchId={}, apiSource=MULTIPLE_CREDIT_TRANSFER", batchId);
        List<PaymentTxnMainConvertDTO> paymentTxnMainConvertDTOList = buildBatchTxns(req, batchId);
        for (PaymentTxnMainConvertDTO paymentTxnMainConvert : paymentTxnMainConvertDTOList) {
            PaymentTxnMainEntity txn = paymentTxnMainConvert.getPaymentTxnMainEntity();
            PaymentTxnEventEntity event = paymentTxnMainConvert.getPaymentTxnEventEntity();
            txnMainMapper.insert(paymentTxnMainConvert.getPaymentTxnMainEntity());
            initializeIntakeEvent(txn, event);
            paymentTxnEventMapper.insert(event);
        }
        log.debug("[PAYMENT-SUBMIT] {} transactions inserted for batchId={}", paymentTxnMainConvertDTOList.size(), batchId);


        SubmitResponse response = acceptedResponse(paymentTxnMainConvertDTOList);
        log.info("[PAYMENT-SUBMIT] Multiple credit transfer submitted successfully: batchId={}, txnCount={}",
                batchId, paymentTxnMainConvertDTOList.size());
        return response;
    }


    public SubmitResponse submitOutward(BatchCreditTransferRequest request) {
        String batchId = request.getBatchId();
        int txnCount = request.getTransactions() != null ? request.getTransactions().size() : 0;
        log.info("[PAYMENT-SUBMIT] Starting outward credit transfer submission: batchId={}, channel={}, txnCount={}, totalAmount={}",
                batchId, request.getChannel(), txnCount, request.getTotalAmount());


        // 校验 outward 请求基础字段和交易明细。
        batchValidator.validate(request);

        Map<String, String> chatsMatchKeys = new HashMap<>();
        if (TransactionTypeEnum.CHATS.getCode().equals(request.getTransactionType())) {
            ChatsHttpClient httpClient = chatsHttpClientProvider.getIfAvailable();
            if (httpClient == null) {
                throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                        "CHATS downstream is not configured");
            }
            for (TransactionDetailRequest txn : request.getTransactions()) {
                String requestJson = buildPerCheckRequest(request, txn);
                ApiResponse<String> apiResponse = httpClient.postJson(chatsProperties.getPerCheckUrl(), requestJson);
                if(!(HttpStatus.OK.value() + "").equals(apiResponse.getCode())){
                    throw new ChatsHttpException(ChatsHttpErrorType.HTTP_STATUS,
                            Integer.parseInt(apiResponse.getCode()), null,
                            "CHATS returned HTTP error: " + apiResponse.getCode()+ ", transactionId is : " + txn.getTransactionId());
                }
                chatsMatchKeys.put(txn.getTransactionId(),
                        validateChatsPrecheck(apiResponse.getData(), txn.getTransactionId()));
            }
        }

        return transactionTemplate.execute(status -> persistOutward(request, chatsMatchKeys));
    }

    /**
     * CHATS pre-check 属于外部调用，必须在数据库事务之外完成；只有持久化阶段进入短事务。
     */
    private SubmitResponse persistOutward(BatchCreditTransferRequest request,
            Map<String, String> chatsMatchKeys) {
        String batchId = request.getBatchId();
        checkBatchIdUnique(batchId);

        for (TransactionDetailRequest txn : request.getTransactions()) {
            checkTransactionIdUnique(txn.getTransactionId());
        }


        // Outward 接口落库批次头，apiSource 标记为 OUTWARD_CREDIT_TRANSFER。
        PaymentBatchHdrEntity hdr = buildBatchHdr(request, ApiNameEnum.OUTWARD_CREDIT_TRANSFER.getCode());
        batchHdrMapper.insert(hdr);
        log.debug("[PAYMENT-SUBMIT] Batch header inserted: batchId={}, apiSource=OUTWARD_CREDIT_TRANSFER", batchId);
        List<PaymentTxnMainConvertDTO> paymentTxnMainConvertDTOS = buildBatchTxns(request, batchId);
        for (PaymentTxnMainConvertDTO paymentTxnMainConvert : paymentTxnMainConvertDTOS) {
            PaymentTxnMainEntity txn = paymentTxnMainConvert.getPaymentTxnMainEntity();
            PaymentTxnEventEntity event = paymentTxnMainConvert.getPaymentTxnEventEntity();
            txnMainMapper.insert(paymentTxnMainConvert.getPaymentTxnMainEntity());
            initializeIntakeEvent(txn, event);
            event.setHdrTxMatchKey(chatsMatchKeys.get(txn.getTransactionId()));
            paymentTxnEventMapper.insert(event);
        }
        log.debug("[PAYMENT-SUBMIT] {} transactions inserted for batchId={}", paymentTxnMainConvertDTOS.size(), batchId);


        SubmitResponse response = acceptedResponse(paymentTxnMainConvertDTOS);
        log.info("[PAYMENT-SUBMIT] Outward credit transfer submitted successfully: batchId={}, txnCount={}",
                batchId, paymentTxnMainConvertDTOS.size());
        return response;
    }

    private String validateChatsPrecheck(String responseJson, String transactionId) {
        try {
            JsonNode root = objectMapper.readTree(responseJson);
            String responseCode = textValue(root, "ebzwk00oHdrRespCode");
            if (!"00".equals(responseCode)) {
                throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                        "CHATS pre-check rejected transactionId=" + transactionId
                                + ", responseCode=" + (responseCode == null ? "UNKNOWN" : responseCode));
            }
            String matchKey = textValue(root, "ebzwk00oHdrTxMatchKey");
            if (matchKey == null || matchKey.isBlank()) {
                throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                        "CHATS pre-check response missing transaction match key for transactionId="
                                + transactionId);
            }
            return matchKey;
        } catch (JsonProcessingException | IllegalArgumentException e) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "CHATS pre-check returned an invalid response for transactionId=" + transactionId);
        }
    }

    private static String textValue(JsonNode root, String fieldName) {
        JsonNode value = root == null ? null : root.findValue(fieldName);
        return value == null || value.isNull() ? null : value.asText();
    }


    /**
     * Build CHATS pre-check transfer request JSON from batch credit transfer request.
     *
     * <p>Transforms BatchCreditTransferRequest + TransactionDetailRequest to ChatsInternalTransferRequest.</p>
     *
     * @param request the batch credit transfer request
     * @return JSON string of CHATS internal transfer request
     */
    private String buildPerCheckRequest(BatchCreditTransferRequest request, TransactionDetailRequest txn) {
        RequestRemittanceCreditTransferRequest chats = txn.getRequestRemittanceCreditTransferRequest();


        try {
            ChatsPerCheckTransferRequest chatsRequest = ChatsPerCheckTransferRequest.builder()
                    .dfhcommarea(
                            ChatsPerCheckTransferRequest.Dfhcommarea.builder()
                                    .ebzwk00wArea(
                                            ChatsPerCheckTransferRequest.Ebzwk00wArea.builder()
                                                    .ebzwk00iArea(
                                                            ChatsPerCheckTransferRequest.Ebzwk00iArea.builder()
                                                                    .ebzwk00iHeader(buildHeader(chats))
                                                                    .ebzwk00iHtcc1(buildHtcc1(request, txn, chats))
                                                                    .build()
                                                    )
                                                    .build()
                                    )
                                    .build()
                    )
                    .build();
            return objectMapper.writeValueAsString(chatsRequest);
        } catch (JsonProcessingException e) {
            log.error("Failed to build CHATS pre-check request for batchId={}", request.getBatchId(), e);
            throw new RuntimeException("Failed to build CHATS pre-check request: " + e.getMessage(), e);
        }
    }




    /**
     * Build the ebzwk00iHeader from RequestRemittanceCreditTransferRequest fields.
     */
    private ChatsPerCheckTransferRequest.Ebzwk00iHeader buildHeader(RequestRemittanceCreditTransferRequest chats) {
        return ChatsPerCheckTransferRequest.Ebzwk00iHeader.builder()
//                .ebzwk00iHdrHostTermNo(chats.getHdrHostTermNo())
                .ebzwk00iHdrHostStrArea(
                        ChatsPerCheckTransferRequest.Ebzwk00iHdrHostStrArea.builder()
//                                .ebzwk00iHdrHostSessId(chats.getHdrHostSessId())
                                .ebzwk00iHdrChSrcInd(chats.getHdrChSrcInd())
                                .build()
                )
                .ebzwk00iHdrMessageId(ChatsFieldsStatic.HDR_MESSAGE_ID_HTCC1)
                .ebzwk00iHdrOpt(chats.getHdrOpt())
                .ebzwk00iHdrBankCode(ChatsFieldsStatic.HDR_BANK_CODE)
                .ebzwk00iHdrIntBankCode(ChatsFieldsStatic.HDR_INT_BANK_CODE)
                .ebzwk00iHdrMediaCode(ChatsFieldsStatic.HDR_MEDIA_CODE)
                .ebzwk00iHdrCibCustId(
                        ChatsPerCheckTransferRequest.Ebzwk00iHdrCibCustId.builder()
                                .ebzwk00iHdrCibExtAcno(chats.getHdrCibCustId())
                                .build()
                )
                .ebzwk00iHdrCibIntAcNo(chats.getHdrCibIntAcNo())
                .ebzwk00iHdrRtTimeoutFlg(ChatsFieldsStatic.HDR_RT_TIMEOUT_FLG)
//                .ebzwk00iHdrTxPostDate(chats.getHdrTxPostDate())
//                .ebzwk00iHdrTxMatchKey(chats.getHdrTxMatchKey())
                .ebzwk00iHdrSubOpt(chats.getHdrSubOpt())
                .ebzwk00iHdrCompCode(ChatsFieldsStatic.HDR_COMP_CODE)
//                .ebzwk00iHdrCibAccessLvl(chats.getHdrCibAccessLvl())
//                .ebzwk00iHdrPublicKeyInd(chats.getHdrPublicKeyInd())
                .ebzwk00iHdrInputUserId(ChatsFieldsStatic.HDR_INPUT_USER_ID)
//                .ebzwk00iHdrInputDate(chats.getHdrInputDate())
//                .ebzwk00iHdrInputTime(chats.getHdrInputTime())
//                .ebzwk00iHdrAprvlUserId(chats.getHdrAprvlUserId())
//                .ebzwk00iHdrAprvlDate(chats.getHdrAprvlDate())
//                .ebzwk00iHdrAprvlTime(chats.getHdrAprvlTime())
//                .ebzwk00iHdrIntCcbbbdd(chats.getHdrIntCcbbbdd())
                .ebzwk00iHdrTxnNumber(ChatsFieldsStatic.HDR_TXN_NUMBER)
//                .ebzwk00iHdrDialupBkupInd(chats.getHdrDialupBkupInd())
//                .ebzwk00iHdrSusIpFlg(chats.getHdrSusIpFlg())
//                .ebzwk00iHdrCibAcProdCode(formatHdrCibAcProdCode(chats.getHdrCibAcProdCode()))
//                .ebzwk00iHdrRiskInd(chats.getHdrRiskInd())
//                .ebzwk00iHdrSpecRateFlg(chats.getHdrSpecRateFlg())
//                .ebzwk00iHdrTxnType(chats.getHdrTxnType())
//                .ebzwk00iHdrOmbFlag(chats.getHdrOmbFlag())
                .build();
    }






    /**
     * Build the ebzwk00iHtcc1 transfer detail block from request fields.
     */
    private ChatsPerCheckTransferRequest.Ebzwk00iHtcc1 buildHtcc1(BatchCreditTransferRequest request,
                                                                  TransactionDetailRequest txn,
                                                                  RequestRemittanceCreditTransferRequest chats) {
        return ChatsPerCheckTransferRequest.Ebzwk00iHtcc1.builder()
                .ebzwk00iHtcc1RelCompCode(chats.getRelCompCode())
                .ebzwk00iHtcc1RelAcSeq(ChatsFieldsStatic.REL_AC_SEQ)
                .ebzwk00iHtcc1RelAcPrdCode(formatRelAcPrdCode(chats.getRelAcProdCode()))
                .ebzwk00iHtcc1RelAcCcy(chats.getRelAcCcy())
                .ebzwk00iHtcc1RelAcStatus(ChatsFieldsStatic.REL_AC_STATUS)
                .ebzwk00iHtcc1RelAcNo(txn.getPayerAccountNo())
                .ebzwk00iHtcc1RelAcNoFmt(chats.getRelAcNoFmt())
                .ebzwk00iHtcc1DbAmtCcy(txn.getDebitAmountCcy())
                .ebzwk00iHtcc1DbAmt(txn.getDebitAmount())
                .ebzwk00iHtcc1ChatAcNo(chats.getChatAcNo())
                .ebzwk00iHtcc1ChatAcTpCode(chats.getChatAcTpCode())
                .ebzwk00iHtcc1ChatAcName1(getPart(txn.getPayeeName(),0))
                .ebzwk00iHtcc1ChatAcName2(getPart(txn.getPayeeName(),1))
                .ebzwk00iHtcc1ChatAcName3(getPart(txn.getPayeeName(),2))
                .ebzwk00iHtcc1ChatAcName4(getPart(txn.getPayeeName(),3))
                .ebzwk00iHtcc1PaymentDtl1(null != txn.getPaymentDetails() && txn.getPaymentDetails().size() > 0 ? txn.getPaymentDetails().get(0) : "")
                .ebzwk00iHtcc1PaymentDtl2(null != txn.getPaymentDetails() && txn.getPaymentDetails().size() > 1 ? txn.getPaymentDetails().get(1) : "")
                .ebzwk00iHtcc1PaymentDtl3(null != txn.getPaymentDetails() && txn.getPaymentDetails().size() > 2 ? txn.getPaymentDetails().get(2) : "")
                .ebzwk00iHtcc1PaymentDtl4(null != txn.getPaymentDetails() && txn.getPaymentDetails().size() > 3 ? txn.getPaymentDetails().get(3) : "")
                .ebzwk00iHtcc1PrntAdvInd(chats.getPrntAdvInd())
                .ebzwk00iHtcc1ServiceCcy(txn.getChargeCurrency())
                .ebzwk00iHtcc1ServiceAmt(txn.getServiceChargeAmount())
                .ebzwk00iHtcc1ExeDate(toIntegerDate(request.getExecutionDate()))
                .ebzwk00iHtcc1ResendFlag(ChatsFieldsStatic.RESEND_FLAG)
//                .ebzwk00iHtcc1TransStatus(chats.getTransStatus())
                .ebzwk00iHtcc1ChrgDiscRate(ChatsFieldsStatic.CHRG_DISC_RATE)
                .ebzwk00iHtcc1PinCnt(chats.getPinCnt())
                .ebzwk00iHtcc1PinListArea(buildPinListArea(chats))
                .ebzwk00iHtcc1MacArea(buildMacArea(chats))
//                .ebzwk00iHtcc1SweepType(chats.getSweepType())
//                .ebzwk00iHtcc1SweepTrigAmt(chats.getSweepTrigAmt() != null ? chats.getSweepTrigAmt() : null)
//                .ebzwk00iHtcc1SweepAmt(chats.getSweepAmt() != null ? chats.getSweepAmt() : null)
//                .ebzwk00iHtcc1Priority(chats.getPriority())
                .ebzwk00iHtcc1LmInd(chats.getLmInd())
                .ebzwk00iHtcc1DepAcName1(chats.getDepositAccountName1())
                .ebzwk00iHtcc1DepAcName2(chats.getDepositAccountName2())
                .ebzwk00iHtcc1DepAcName3(chats.getDepositAccountName3())
                .ebzwk00iHtcc1DepAcName4(chats.getDepositAccountName4())
//                .ebzwk00iHtcc1LmInstrNum(chats.getLmInstrNum())
                .ebzwk00iHtcc1OvrChrgInd(chats.getOurChargeBearerInd())
                .build();
    }




    /**
     * Build CHATS PIN list area from RequestRemittanceCreditTransferRequest.
     */
    private ChatsPerCheckTransferRequest.Ebzwk00iHtcc1PinListArea buildPinListArea(RequestRemittanceCreditTransferRequest chats) {
        if (chats.getPinListArea() == null || chats.getPinListArea().isEmpty()) {
            return null;
        }
        List<ChatsPerCheckTransferRequest.Ebzwk00iHtcc1PinList> pinLists = chats.getPinListArea().stream()
                .map(pin -> ChatsPerCheckTransferRequest.Ebzwk00iHtcc1PinList.builder()
//                        .ebzwk00iHtcc1PkeyInd(pin.getPkeyInd())
                        .ebzwk00iHtcc1AgentId(pin.getAgentId())
//                        .ebzwk00iHtcc1DesKey(pin.getDesKey())
//                        .ebzwk00iHtcc1PinBlock(pin.getPinBlock())
                        .build())
                .toList();
        return ChatsPerCheckTransferRequest.Ebzwk00iHtcc1PinListArea.builder()
                .ebzwk00iHtcc1PinList(pinLists)
                .build();
    }


    /**
     * Build CHATS MAC area from RequestRemittanceCreditTransferRequest.
     */
    private ChatsPerCheckTransferRequest.Ebzwk00iHtcc1MacArea buildMacArea(RequestRemittanceCreditTransferRequest chats) {
        if (chats.getMacArea() == null) {
            return null;
        }
        RequestRemittanceCreditTransferRequest.MacArea mac = chats.getMacArea();
        return ChatsPerCheckTransferRequest.Ebzwk00iHtcc1MacArea.builder()
                .ebzwk00iHtcc1MacPkeyInd(mac.getAgentId())
                .ebzwk00iHtcc1MacCode(mac.getMacCode())
                .ebzwk00iHtcc1MacDesKey(mac.getDesKey())
                .ebzwk00iHtcc1MacPinBlock(mac.getPinBlock())
                .build();
    }


    /**
     * Format related account product code (Integer -> String).
     */
    private static String formatRelAcPrdCode(Integer relAcProdCode) {
        if (relAcProdCode == null) {
            return null;
        }
        return String.valueOf(relAcProdCode);
    }


    private void initializeIntakeEvent(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        event.setTxnId(txn.getTxnId());
        event.setTransactionId(txn.getTransactionId());
        event.setBatchId(txn.getBatchId());
        event.setOrderId(1);
        event.setDownstreamSystem(DownstreamSystemEnum.PAYMENT_ENGINE.getCode());
        event.setEventType(PaymentTxnEventTypeEnum.PAYMENT_ACCEPTED.name());
        event.setEventStage("REQUEST");
        event.setResultStatus(PaymentStatusEnum.PENDING.getCode());
    }


    // --- 唯一性校验 ---


    /**
     * 校验 batchId 是否已存在。
     *
     * <p>重复提交直接抛业务异常，避免同一批次被重复落库。</p>
     */
    private void checkBatchIdUnique(String batchId) {
        Long count = batchHdrMapper.selectCount(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<PaymentBatchHdrEntity>()
                        .eq(PaymentBatchHdrEntity::getBatchId, batchId));
        if (count > 0) {
            log.warn("[PAYMENT-SUBMIT] Duplicate batchId detected: batchId={}", batchId);
            throw new BusinessException(StandardResultCode.DUPLICATE_REQUEST,
                    "batchId already exists: " + batchId);
        }
        log.debug("[PAYMENT-SUBMIT] BatchId uniqueness check passed: batchId={}", batchId);
    }


    /**
     * 校验 transactionId 是否已存在。
     *
     * <p>交易号作为幂等键，重复时拒绝提交。</p>
     */
    private void checkTransactionIdUnique(String transactionId) {
        Long count = txnMainMapper.selectCount(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<PaymentTxnMainEntity>()
                        .eq(PaymentTxnMainEntity::getTransactionId, transactionId));
        if (count > 0) {
            log.warn("[PAYMENT-SUBMIT] Duplicate transactionId detected: transactionId={}", transactionId);
            throw new BusinessException(StandardResultCode.DUPLICATE_REQUEST,
                    "transactionId already exists: " + transactionId);
        }
        log.debug("[PAYMENT-SUBMIT] TransactionId uniqueness check passed: transactionId={}", transactionId);
    }


    // --- 批次头构造 ---


    /**
     * 构造单笔接口对应的批次头。
     *
     * <p>单笔接口仍按批次模型落库，totalCount 固定为 1。</p>
     */
    private PaymentBatchHdrEntity buildSingleHdr(SingleCreditTransferRequest req, String batchId) {
        PaymentBatchHdrEntity hdr = new PaymentBatchHdrEntity();
        hdr.setBatchId(batchId);
        hdr.setChannel(req.getChannel());
        hdr.setChannelReference(req.getChannelReference());
        hdr.setTransactionType(req.getTransactionType());
        hdr.setTimeOfTransfer(req.getTimeOfTransfer());
        hdr.setExecutionDate(parseExecutionDate(req.getExecutionDate(), req.getTimeOfTransfer()));
        hdr.setTotalCount(1);
        hdr.setTotalAmount(req.getDebitAmount());
        hdr.setServiceChargeAmount(req.getServiceChargeAmount());
        hdr.setBatchStatus(BatchStatusEnum.PENDING.getCode());
        hdr.setTraceId(getTraceId());
        hdr.setApiSource(ApiNameEnum.SINGLE_CREDIT_TRANSFER.getCode());
        hdr.setMqSendPointer(0);
        return hdr;
    }


    /**
     * 构造批量或 outward 接口的批次头。
     *
     * <p>通过 apiSource 区分 MULTIPLE_CREDIT_TRANSFER 和 OUTWARD_CREDIT_TRANSFER。</p>
     */
    private PaymentBatchHdrEntity buildBatchHdr(BatchCreditTransferRequest req, String apiSource) {
        PaymentBatchHdrEntity hdr = new PaymentBatchHdrEntity();
        hdr.setBatchId(req.getBatchId());
        hdr.setChannel(req.getChannel());
        hdr.setChannelReference(req.getChannelReference());
        hdr.setTransactionType(req.getTransactionType());
        hdr.setTimeOfTransfer(req.getTimeOfTransfer());
        hdr.setExecutionDate(parseExecutionDate(req.getExecutionDate(), req.getTimeOfTransfer()));
        hdr.setTotalCount(req.getTotalCount());
        hdr.setTotalAmount(req.getTotalAmount());
        hdr.setServiceChargeAmount(req.getServiceChargeAmount());
        hdr.setCustomerRemarks(req.getCustomerRemarks());
        hdr.setBatchStatus(BatchStatusEnum.PENDING.getCode());
        hdr.setTraceId(getTraceId());
        hdr.setApiSource(apiSource);
        hdr.setMqSendPointer(0);
        return hdr;
    }


    // --- 交易主表构造 ---


    /**
     * 从单笔请求构造交易主表实体。
     *
     * <p>orderId 固定为 1，批次号使用单笔接口内部生成的 batchId。</p>
     */
    private PaymentTxnMainConvertDTO buildTxnFromSingle(SingleCreditTransferRequest req, String batchId) {
        PaymentTxnMainConvertDTO paymentTxnMainConvert = new PaymentTxnMainConvertDTO();
        PaymentTxnMainEntity txn = new PaymentTxnMainEntity();
        PaymentTxnEventEntity event = new PaymentTxnEventEntity();
        paymentTxnMainConvert.setPaymentTxnMainEntity(txn);
        paymentTxnMainConvert.setPaymentTxnEventEntity(event);


        txn.setTransactionId(req.getTransactionId());
        event.setTransactionId(req.getTransactionId());
        txn.setIpeReferenceId(UuidV7Utils.generateBytes());
        txn.setBatchId(batchId);
        event.setBatchId(batchId);
        txn.setOrderId(1);
        txn.setChannel(req.getChannel());
        txn.setChannelReference(req.getChannelReference());
        txn.setTraceId(getTraceId());
        txn.setTransactionType(req.getTransactionType());
        txn.setTimeOfTransfer(req.getTimeOfTransfer());
        txn.setExecutionDate(parseExecutionDate(req.getExecutionDate(), req.getTimeOfTransfer()));
        txn.setDebitAmount(req.getDebitAmount());
        txn.setDebitAmountCcy(req.getDebitAmountCcy());
        txn.setSettlementCurrency(
                req.getSettlementCurrency() != null ? req.getSettlementCurrency() : req.getDebitAmountCcy());
        txn.setHkdEquivalentAmount(req.getHkdEquivalentAmount());
        txn.setServiceChargeAmount(req.getServiceChargeAmount());
        txn.setChargeCurrency(req.getChargeCurrency());
        event.setPaymentDetail1(getPart(req.getPaymentDetails(), 0));
        event.setPaymentDetail2(getPart(req.getPaymentDetails(), 1));
        event.setPaymentDetail3(getPart(req.getPaymentDetails(), 2));
        event.setPaymentDetail4(getPart(req.getPaymentDetails(), 3));
        setExchangeFields(event, req.getExchangeCurrencyPair(), req.getExchangeContractRate(),
                req.getExchangeSpecialRate(), req.getExchangeSpecialRateFlag(), req.getTreasuryReference());
        txn.setPaymentStatus(PaymentStatusEnum.PENDING.getCode());
        applyInitialStateModel(txn);
        setPayerFields(txn,event, req.getPayerType(), req.getPayerAccountNo(), req.getPayerInternalAccountNo(),
                req.getPayerBicCode(), req.getPayerAccountType(), req.getPayerAccountCurrency(),
                req.getPayerName(), req.getPayerAddressLine1(), req.getPayerAddressLine2(),
                req.getPayerAddressLine3(), req.getPayerAddressLine4(), req.getPayerTownName(),
                req.getPayerCountryCode());
        setPayeeFields(txn, event, req.getPayeeType(), req.getPayeeName(), req.getPayeeAccountNo(),
                req.getPayeeAccountCurrency(),
                req.getPayeeProxyId(), req.getPayeeMobileNo(), req.getPayeeEmailAddress(),
                req.getPayeeBankCode(), req.getMemberId(), req.getPayeeBankName(), req.getPayeeBicCode(),
                req.getSenderCorrBankBicCode(), req.getReceiverCorrBankBicCode(),
                req.getPayeeAddressLine1(), req.getPayeeAddressLine2(), req.getPayeeAddressLine3(),
                req.getPayeeAddressLine4(), req.getPayeeTownName(), req.getPayeeCountryCode());
        setEphFieldsForSingleCreditTransferRequest(paymentTxnMainConvert, req);
        setBg3Fields(event, req.getBg3());
        return paymentTxnMainConvert;
    }


    /**
     * 从批量请求构造交易主表实体列表。
     *
     * <p>orderId 按请求明细顺序从 1 开始递增。</p>
     */
    private List<PaymentTxnMainConvertDTO> buildBatchTxns(BatchCreditTransferRequest req, String batchId) {
        List<PaymentTxnMainConvertDTO> result = new ArrayList<>();
        List<TransactionDetailRequest> details = req.getTransactions();


        for (int i = 0; i < details.size(); i++) {
            TransactionDetailRequest detailRequest = details.get(i);
            PaymentTxnMainEntity txn = new PaymentTxnMainEntity();
            PaymentTxnEventEntity event = new PaymentTxnEventEntity();
            txn.setTransactionId(detailRequest.getTransactionId());
            txn.setIpeReferenceId(UuidV7Utils.generateBytes());
            txn.setBatchId(batchId);
            txn.setOrderId(i + 1);
            txn.setChannel(req.getChannel());
            txn.setChannelReference(req.getChannelReference());
            txn.setTraceId(getTraceId());
            txn.setTransactionType(req.getTransactionType());
            txn.setTimeOfTransfer(req.getTimeOfTransfer());
            txn.setExecutionDate(parseExecutionDate(req.getExecutionDate(), req.getTimeOfTransfer()));
            txn.setDebitAmount(detailRequest.getDebitAmount());
            txn.setDebitAmountCcy(detailRequest.getDebitAmountCcy());
            txn.setSettlementCurrency(
                    detailRequest.getSettlementCurrency() != null ? detailRequest.getSettlementCurrency() : detailRequest.getDebitAmountCcy());
            txn.setHkdEquivalentAmount(detailRequest.getHkdEquivalentAmount());
            txn.setServiceChargeAmount(detailRequest.getServiceChargeAmount());
            txn.setChargeCurrency(detailRequest.getChargeCurrency());
            List<String> paymentDetailsList = detailRequest.getPaymentDetails();
            event.setPaymentDetail1(null != paymentDetailsList && paymentDetailsList.size() > 0 ? paymentDetailsList.get(0) : "");
            event.setPaymentDetail2(null != paymentDetailsList && paymentDetailsList.size() > 1 ? paymentDetailsList.get(1) : "");
            event.setPaymentDetail3(null != paymentDetailsList && paymentDetailsList.size() > 2 ? paymentDetailsList.get(2) : "");
            event.setPaymentDetail4(null != paymentDetailsList && paymentDetailsList.size() > 3 ? paymentDetailsList.get(3) : "");


            event.setDepositAccountName1(detailRequest.getRequestRemittanceCreditTransferRequest() != null
                    ? detailRequest.getRequestRemittanceCreditTransferRequest().getDepositAccountName1() : null);
            event.setDepositAccountName2(detailRequest.getRequestRemittanceCreditTransferRequest() != null
                    ? detailRequest.getRequestRemittanceCreditTransferRequest().getDepositAccountName2() : null);
            event.setDepositAccountName3(detailRequest.getRequestRemittanceCreditTransferRequest() != null
                    ? detailRequest.getRequestRemittanceCreditTransferRequest().getDepositAccountName3() : null);
            event.setDepositAccountName4(detailRequest.getRequestRemittanceCreditTransferRequest() != null
                    ? detailRequest.getRequestRemittanceCreditTransferRequest().getDepositAccountName4() : null);


            setExchangeFields(event, detailRequest.getExchangeCurrencyPair(), detailRequest.getExchangeContractRate(),
                    detailRequest.getExchangeSpecialRate(), detailRequest.getExchangeSpecialRateFlag(), detailRequest.getTreasuryReference());
            txn.setPaymentStatus(PaymentStatusEnum.PENDING.getCode());
            applyInitialStateModel(txn);
            setPayerFields(txn,event, detailRequest.getPayerType(), detailRequest.getPayerAccountNo(), detailRequest.getPayerInternalAccountNo(),
                    detailRequest.getPayerBicCode(), detailRequest.getPayerAccountType(), detailRequest.getPayerAccountCurrency(),
                    detailRequest.getPayerName(), detailRequest.getPayerAddressLine1(), detailRequest.getPayerAddressLine2(),
                    detailRequest.getPayerAddressLine3(), detailRequest.getPayerAddressLine4(), detailRequest.getPayerTownName(),
                    detailRequest.getPayerCountryCode());
            setPayeeFields(txn, event,detailRequest.getPayeeType(), detailRequest.getPayeeName(), detailRequest.getPayeeAccountNo(),
                    detailRequest.getPayeeAccountCurrency(),
                    detailRequest.getPayeeProxyId(), detailRequest.getPayeeMobileNo(), detailRequest.getPayeeEmailAddress(),
                    detailRequest.getPayeeBankCode(), detailRequest.getMemberId(), detailRequest.getPayeeBankName(), detailRequest.getPayeeBicCode(),
                    detailRequest.getSenderCorrBankBicCode(), detailRequest.getReceiverCorrBankBicCode(),
                    detailRequest.getPayeeAddressLine1(), detailRequest.getPayeeAddressLine2(), detailRequest.getPayeeAddressLine3(),
                    detailRequest.getPayeeAddressLine4(), detailRequest.getPayeeTownName(), detailRequest.getPayeeCountryCode());
            setEphFieldsForTransactionDetailRequest(txn,event, detailRequest);
            setBg3Fields(event, detailRequest.getBg3());
            setChatsFields(event,detailRequest.getRequestRemittanceCreditTransferRequest());
            PaymentTxnMainConvertDTO paymentTxnMainConvertDTO = new PaymentTxnMainConvertDTO();
            paymentTxnMainConvertDTO.setPaymentTxnMainEntity(txn);
            paymentTxnMainConvertDTO.setPaymentTxnEventEntity(event);
            result.add(paymentTxnMainConvertDTO);
        }
        return result;
    }


    private PaymentTxnEventEntity setChatsFields(PaymentTxnEventEntity paymentTxnEventEntity, RequestRemittanceCreditTransferRequest chats) {
        if (chats == null) {
            return null;
        }
//        txn.setHdrHostTermNo(chats.getHdrHostTermNo());
//        txn.setHdrHostSessId(chats.getHdrHostSessId());
        paymentTxnEventEntity.setHdrChSrcInd(chats.getHdrChSrcInd());
        paymentTxnEventEntity.setHdrMessageId(chats.getHdrMessageId());
        paymentTxnEventEntity.setHdrOpt(chats.getHdrOpt());
        paymentTxnEventEntity.setHdrBankCode(chats.getHdrBankCode());
        paymentTxnEventEntity.setHdrIntBankCode(chats.getHdrIntBankCode());
        paymentTxnEventEntity.setHdrMediaCode(chats.getHdrMediaCode());
        paymentTxnEventEntity.setHdrCibCustId(chats.getHdrCibCustId());
        paymentTxnEventEntity.setHdrCibIntAcNo(chats.getHdrCibIntAcNo());
        paymentTxnEventEntity.setHdrRtTimeoutFlg(chats.getHdrRtTimeoutFlg());
//        txn.setHdrTxPostDate(chats.getHdrTxPostDate());
//        txn.setHdrTxMatchKey(chats.getHdrTxMatchKey());
        paymentTxnEventEntity.setHdrSubOpt(chats.getHdrSubOpt());
        paymentTxnEventEntity.setHdrCompCode(chats.getHdrCompCode());
//        txn.setHdrCibAccessLvl(chats.getHdrCibAccessLvl());
//        txn.setHdrPublicKeyInd(chats.getHdrPublicKeyInd());
        paymentTxnEventEntity.setHdrInputUserId(chats.getHdrInputUserId());
//        txn.setHdrInputDate(chats.getHdrInputDate());
//        txn.setHdrInputTime(chats.getHdrInputTime());
//        txn.setHdrAprvlUserId(chats.getHdrAprvlUserId());
//        txn.setHdrAprvlDate(chats.getHdrAprvlDate());
//        txn.setHdrAprvlTime(chats.getHdrAprvlTime());
//        txn.setHdrIntCcbbbdd(chats.getHdrIntCcbbbdd());
        paymentTxnEventEntity.setHdrTxnNumber(chats.getHdrTxnNumber());
//        txn.setHdrDialupBkupInd(chats.getHdrDialupBkupInd());
//        txn.setHdrSusIpFlg(chats.getHdrSusIpFlg());
//        txn.setHdrCibAcProdCode(chats.getHdrCibAcProdCode());
//        txn.setHdrRiskInd(chats.getHdrRiskInd());
//        txn.setHdrSpecRateFlg(chats.getHdrSpecRateFlg());
//        txn.setHdrTxnType(chats.getHdrTxnType());
//        txn.setHdrOmbFlag(chats.getHdrOmbFlag());
        paymentTxnEventEntity.setRelCompCode(chats.getRelCompCode());
        paymentTxnEventEntity.setRelAcSeq(chats.getRelAcSeq());
        paymentTxnEventEntity.setRelAcProdCode(chats.getRelAcProdCode());
        paymentTxnEventEntity.setRelAcCcy(chats.getRelAcCcy());
        paymentTxnEventEntity.setRelAcStatus(chats.getRelAcStatus());
        paymentTxnEventEntity.setChatAcNo(chats.getChatAcNo());
        paymentTxnEventEntity.setChatAcTpCode(chats.getChatAcTpCode());
        paymentTxnEventEntity.setPrntAdvInd(chats.getPrntAdvInd());
        paymentTxnEventEntity.setSrvcExchRate(chats.getSrvcExchRate());
        paymentTxnEventEntity.setResendFlag(chats.getResendFlag());
//        txn.setTransStatus(chats.getTransStatus());
        paymentTxnEventEntity.setChrgDiscRate(chats.getChrgDiscRate());
//        txn.setSweepType(chats.getSweepType());
//        txn.setSweepTrigAmt(chats.getSweepTrigAmt());
//        txn.setSweepAmt(chats.getSweepAmt());
//        txn.setPriority(chats.getPriority());
        paymentTxnEventEntity.setLmInd(chats.getLmInd());
//        txn.setLmInstrNum(chats.getLmInstrNum());
        paymentTxnEventEntity.setOurChargeBearerInd(chats.getOurChargeBearerInd());
        paymentTxnEventEntity.setOurChargeBearerCcy(chats.getOurChargeBearerCcy());
        paymentTxnEventEntity.setOurChargeBearerAmt(chats.getOurChargeBearerAmt());
        paymentTxnEventEntity.setPinCnt(chats.getPinCnt());
        return paymentTxnEventEntity;
    }


    private void applyInitialStateModel(PaymentTxnMainEntity txn) {
        txn.setStatusReason(StatusReasonEnum.API_ACCEPTED.getCode());
    }


    private SubmitResponse acceptedResponse(List<PaymentTxnMainConvertDTO> paymentTxnMainConvertDTO) {
        return new SubmitResponse(OffsetDateTime.now(),
                paymentTxnMainConvertDTO.stream()
                        .map(this::toSubmitTransactionResponse)
                        .toList());
    }


    private SubmitTransactionResponse toSubmitTransactionResponse(PaymentTxnMainConvertDTO paymentTxnMainConvertDTO) {
        return new SubmitTransactionResponse(
                paymentTxnMainConvertDTO.getPaymentTxnMainEntity().getTransactionId(),
                UuidV7Utils.toString(paymentTxnMainConvertDTO.getPaymentTxnMainEntity().getIpeReferenceId()),
                paymentTxnMainConvertDTO.getPaymentTxnMainEntity().getPaymentStatus());
    }




    private static String getPart(String str, int partIndex) {
        if (str == null || str.isEmpty()) {
            return "";
        }
        int start = partIndex * 35;
        if (start >= str.length()) {
            return "";
        }
        int end = Math.min(start + 35, str.length());
        return str.substring(start, end);
    }




    /**
     * 设置付款人字段。
     *
     * <p>包括付款账号、内部账号、BIC、账号类型、账号币种、名称和地址。</p>
     */
    private void setPayerFields(PaymentTxnMainEntity txn, PaymentTxnEventEntity event,
                                String payerType, String payerAccountNo, String payerInternalAccountNo,
                                String payerBicCode, String payerAccountType, String payerAccountCurrency,
                                String payerName, String addr1, String addr2, String addr3, String addr4,
                                String townName, String countryCode) {
        txn.setPayerType(payerType);
        txn.setPayerAccountNo(payerAccountNo);
        txn.setPayerInternalAccountNo(payerInternalAccountNo);
        txn.setPayerBicCode(payerBicCode);
        txn.setPayerAccountType(payerAccountType);
        txn.setPayerAccountCurrency(payerAccountCurrency);
        txn.setPayerName(payerName);
        event.setPayerAddressLine1(addr1);
        event.setPayerAddressLine2(addr2);
        event.setPayerAddressLine3(addr3);
        event.setPayerAddressLine4(addr4);
        event.setPayerTownName(townName);
        txn.setPayerCountryCode(countryCode);
    }


    /**
     * 设置收款人字段。
     *
     * <p>包括收款账号、代理标识、联系方式、银行信息、SWIFT 相关行和地址。</p>
     */
    private void setPayeeFields(PaymentTxnMainEntity txn,PaymentTxnEventEntity event,
            String payeeType, String payeeName, String payeeAccountNo, String payeeAccountCurrency,
            String payeeProxyId, String payeeMobileNo, String payeeEmailAddress,
            String payeeBankCode, String memberId, String payeeBankName, String payeeBicCode,
            String senderCorrBankBicCode, String receiverCorrBankBicCode,
            String addr1, String addr2, String addr3, String addr4,
            String townName, String countryCode) {
        txn.setPayeeType(payeeType);
        txn.setPayeeName(payeeName);
        txn.setPayeeAccountNo(payeeAccountNo);
        txn.setPayeeAccountCurrency(payeeAccountCurrency);
        txn.setPayeeProxyId(payeeProxyId);
        txn.setPayeeMobileNo(payeeMobileNo);
        txn.setPayeeEmailAddress(payeeEmailAddress);
        txn.setPayeeBankCode(payeeBankCode);
        event.setPayeeMemberId(memberId);
        txn.setPayeeBankName(payeeBankName);
        txn.setPayeeBicCode(payeeBicCode);
        event.setSenderCorrBankBicCode(senderCorrBankBicCode);
        event.setReceiverCorrBankBicCode(receiverCorrBankBicCode);
        event.setPayeeAddressLine1(addr1);
        event.setPayeeAddressLine2(addr2);
        event.setPayeeAddressLine3(addr3);
        event.setPayeeAddressLine4(addr4);
        event.setPayeeTownName(townName);
        txn.setPayeeCountryCode(countryCode);
    }


    private void setExchangeFields(PaymentTxnEventEntity event,
            String exchangeCurrencyPair, String exchangeContractRate, String exchangeSpecialRate,
            String exchangeSpecialRateFlag, String treasuryReference) {
        event.setExchangeCurrencyPair(exchangeCurrencyPair);
        event.setExchangeContractRate(exchangeContractRate);
        event.setExchangeSpecialRate(exchangeSpecialRate);
        event.setExchangeSpecialRateFlag(exchangeSpecialRateFlag);
        event.setTreasuryReference(treasuryReference);
    }


    // --- 下游扩展字段映射 ---


    private void setBg3Fields(PaymentTxnEventEntity event, Bg3InstructionRequest bg3) {
        if (bg3 == null) {
            return;
        }
        if (bg3.getEventValues() == null) {
            return;
        }
        try {
            event.setBg3EventValuesJson(OBJECT_MAPPER.writeValueAsString(bg3.getEventValues()));
        } catch (JsonProcessingException e) {
            throw new SystemException("Failed to serialize BG3 event values", e);
        }
    }


    /**
     * 设置 EPH/FPS 扩展字段。
     *
     * <p>这里仅做请求字段到交易主表字段的映射，不做下游协议校验。</p>
     */
    private void setEphFieldsForSingleCreditTransferRequest(PaymentTxnMainConvertDTO paymentTxnMainConvertDTO, SingleCreditTransferRequest req) {
        if (req == null) {
            return;
        }
        PaymentTxnEventEntity event = paymentTxnMainConvertDTO.getPaymentTxnEventEntity();
        PaymentTxnMainEntity txn = paymentTxnMainConvertDTO.getPaymentTxnMainEntity();
        EphProperties.Control control = ephProperties.getControl();
        event.setEphPaymentSource(req.getPaymentSource());
        event.setEphEnquiryType(req.getEnquiryType());
        event.setEphCostCenterCode(req.getCostCenterCode());
        event.setEphFeeCode(req.getFeeCode());
        event.setEphTxType(control.getTransactionType());
        event.setEphPayeeIdentificationType(req.getPayeeIdentificationType());
        event.setEphAccountVerificationOption(control.getAccountVerificationOption());
//        txn.setEphCategoryPurpose(req.getCategoryPurpose());
        event.setSettlementMethod(control.getSettlementMethod());
        event.setClearingSystem(firstNonBlank(req.getClearingSystem(), control.getClearingSystem()));
        event.setEphDebtorMemberId(control.getDebtorMemberId());
        event.setChargeBearer(control.getChargeBearer());
        event.setEphAlnovaLmtChkInd(req.getAlnovaLimitCheckInd());
        event.setEphDebitMop(control.getDebitMop());
        event.setEphEndToEndId(txn.getTransactionId());
        event.setInstructionId(req.getInstructionId());
//        txn.setEphPayerCustomerId(req.getPayerCustomerId());
//        txn.setEphPayerCustomerIdType(req.getPayerCustomerIdType());
//        txn.setEphPayerCustomerIdCategory(req.getPayerCustomerIdCategory());
//        txn.setEphPayeeCustomerId(req.getPayeeCustomerId());
//        txn.setEphPayeeCustomerIdType(req.getPayeeCustomerIdType());
//        txn.setEphPayeeCustomerIdCategory(req.getPayeeCustomerIdCategory());
        event.setPurposeCode(req.getPurposeCode());
        event.setPurposeProprietary(req.getPurposeProprietary());
        event.setOfficeId(req.getOfficeId());
        event.setInvoiceNumber(req.getInvoiceNumber());
        event.setCustomerType(control.getCustomerType());
        event.setVipInd(req.getVipIndicator());
        event.setCreditInternalAccount(req.getCreditInternalAccount());
        event.setDebitInternalAccount(req.getDebitInternalAccount());
        event.setProductType(req.getProductType());
    }


    /**
     * 设置 EPH/FPS 扩展字段。
     *
     * <p>这里仅做请求字段到交易主表字段的映射，不做下游协议校验。</p>
     */
    private void setEphFieldsForTransactionDetailRequest(PaymentTxnMainEntity txn,PaymentTxnEventEntity event, TransactionDetailRequest req) {
        if (req == null) {
            return;
        }
        EphProperties.Control control = ephProperties.getControl();
        event.setEphPaymentSource(req.getPaymentSource());
        event.setEphEnquiryType(req.getEnquiryType());
        event.setEphCostCenterCode(req.getCostCenterCode());
        event.setEphFeeCode(req.getFeeCode());
        event.setEphTxType(control.getTransactionType());
        event.setEphPayeeIdentificationType(req.getPayeeIdentificationType());
        event.setEphAccountVerificationOption(control.getAccountVerificationOption());
//        txn.setEphCategoryPurpose(req.getCategoryPurpose());
        event.setSettlementMethod(control.getSettlementMethod());
        event.setClearingSystem(firstNonBlank(req.getClearingSystem(), control.getClearingSystem()));
        event.setEphDebtorMemberId(control.getDebtorMemberId());
        event.setChargeBearer(control.getChargeBearer());
        event.setEphAlnovaLmtChkInd(req.getAlnovaLimitCheckInd());
        event.setEphDebitMop(control.getDebitMop());
        event.setEphEndToEndId(txn.getTransactionId());
        event.setInstructionId(req.getInstructionId());
//        txn.setEphPayerCustomerId(req.getPayerCustomerId());
//        txn.setEphPayerCustomerIdType(req.getPayerCustomerIdType());
//        txn.setEphPayerCustomerIdCategory(req.getPayerCustomerIdCategory());
//        txn.setEphPayeeCustomerId(req.getPayeeCustomerId());
//        txn.setEphPayeeCustomerIdType(req.getPayeeCustomerIdType());
//        txn.setEphPayeeCustomerIdCategory(req.getPayeeCustomerIdCategory());
        event.setPurposeCode(req.getPurposeCode());
        event.setPurposeProprietary(req.getPurposeProprietary());
        event.setOfficeId(req.getOfficeId());
        event.setInvoiceNumber(req.getInvoiceNumber());
        event.setCustomerType(control.getCustomerType());
        event.setVipInd(req.getVipIndicator());
        event.setCreditInternalAccount(req.getCreditInternalAccount());
        event.setDebitInternalAccount(req.getDebitInternalAccount());
        event.setProductType(req.getProductType());
    }


    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }


    private static String firstNonBlank(String primary, String fallback) {
        String value = blankToNull(primary);
        return value != null ? value : blankToNull(fallback);
    }


    /**
     * 解析执行日期。
     *
     * <p>优先使用 executionDate；timeOfTransfer 为 NOW 时使用当前时间；其他情况返回 null。</p>
     */
    private Date parseExecutionDate(String executionDate, String timeOfTransfer) {
        if (executionDate != null && !executionDate.isBlank()) {
            LocalDate date = LocalDate.parse(executionDate);
            return Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        }
        if ("NOW".equalsIgnoreCase(timeOfTransfer)) {
            return new Date();
        }
        return null;
    }


    /**
     * 从请求上下文获取 traceId。
     *
     * <p>异步或测试场景没有上下文时返回 null。</p>
     */
    private String getTraceId() {
        var ctx = RequestContextHolder.get();
        return ctx != null ? ctx.getTraceContext().getTraceId() : null;
    }
}
