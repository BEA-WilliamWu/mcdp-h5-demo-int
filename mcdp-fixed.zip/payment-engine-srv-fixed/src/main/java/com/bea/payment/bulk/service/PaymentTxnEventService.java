package com.bea.payment.bulk.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import org.springframework.stereotype.Service;
import com.bea.payment.bulk.constants.DownstreamSystemEnum;
import com.bea.payment.bulk.constants.PaymentTxnEventTypeEnum;

import java.util.*;

@Service
public class PaymentTxnEventService {

    private static final String NOT_DELETED = "N";
    private final PaymentTxnEventMapper eventMapper;

    public PaymentTxnEventService(PaymentTxnEventMapper eventMapper) {
        this.eventMapper = Objects.requireNonNull(eventMapper, "eventMapper must not be null");
    }

    public void record(PaymentTxnMainEntity txn, PaymentTxnEventEntity event) {
        Objects.requireNonNull(txn, "txn must not be null");
        Objects.requireNonNull(event, "event must not be null");
        event.setTxnId(txn.getTxnId());
        event.setTransactionId(txn.getTransactionId());
        event.setBatchId(txn.getBatchId());
        event.setTraceId(txn.getTraceId());
        if (event.getEndTime() == null) {
            event.setEndTime(new Date());
        }
        if (event.getStartTime() != null && event.getDurationMs() == null) {
            event.setDurationMs(event.getEndTime().getTime() - event.getStartTime().getTime());
        }
        event.setEventId(null);
        event.setIsDeleted(null);
        event.setCreationDate(null);
        event.setLastUpdateDate(null);
        eventMapper.insert(event);
    }

    public Optional<EventSummary> latestEventSummary(String transactionId) {
        if (transactionId == null || transactionId.isBlank()) {
            return Optional.empty();
        }
        String normalizedTransactionId = transactionId.trim();
        PaymentTxnEventEntity event = eventMapper.selectOne(
                new LambdaQueryWrapper<PaymentTxnEventEntity>()
                        .eq(PaymentTxnEventEntity::getTransactionId, normalizedTransactionId)
                        .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED)
                        .orderByDesc(PaymentTxnEventEntity::getCreationDate)
                        .orderByDesc(PaymentTxnEventEntity::getEventId)
                        .last("FETCH FIRST 1 ROWS ONLY"));
        if (event == null) {
            return Optional.empty();
        }
        return Optional.of(new EventSummary(
                event.getDownstreamReference(),
                event.getResultCode(),
                event.getErrorCode(),
                event.getErrorMessage(),
                event.getEventType(),
                event.getResultStatus()));
    }

    /** Loads the latest audit event for every transaction in a batch in one query. */
    public Map<String, EventSummary> latestEventSummaries(String batchId) {
        if (batchId == null || batchId.isBlank()) {
            return Map.of();
        }
        List<PaymentTxnEventEntity> events = eventMapper.selectList(
                new LambdaQueryWrapper<PaymentTxnEventEntity>()
                        .eq(PaymentTxnEventEntity::getBatchId, batchId.trim())
                        .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED)
                        .orderByDesc(PaymentTxnEventEntity::getCreationDate)
                        .orderByDesc(PaymentTxnEventEntity::getEventId));
        Map<String, EventSummary> summaries = new HashMap<>();
        for (PaymentTxnEventEntity event : events) {
            if (event.getTransactionId() == null || event.getTransactionId().isBlank()) {
                continue;
            }
            summaries.putIfAbsent(event.getTransactionId(), new EventSummary(
                    event.getDownstreamReference(),
                    event.getResultCode(),
                    event.getErrorCode(),
                    event.getErrorMessage(),
                    event.getEventType(),
                    event.getResultStatus()));
        }
        return summaries;
    }

    public record EventSummary(String downstreamReference, String resultCode, String errorCode,
            String errorMessage, String eventType, String resultStatus) {
    }

    /**
     * 获取 EPH 原始交易状态。
     *
     * <p>优先读取 I006 正常响应；I006 无响应时，读取 I037 正常查询响应。
     * ERROR、I005、HTTP 异常等事件不属于有效下游交易状态。</p>
     */
    public Optional<String> findEphDownstreamStatus(String transactionId) {
        if (transactionId == null || transactionId.isBlank()) {
            return Optional.empty();
        }

        Optional<String> i006Status = findResultStatus(
                transactionId.trim(),
                PaymentTxnEventTypeEnum.EPH_I006.name(),
                "i006"
        );
        if (i006Status.isPresent()) {
            return i006Status;
        }

        return findResultStatus(
                transactionId.trim(),
                PaymentTxnEventTypeEnum.EPH_I037.name(),
                "RESPONSE"
        );
    }

    private Optional<String> findResultStatus(
            String transactionId,
            String eventType,
            String eventStage) {

        PaymentTxnEventEntity event = eventMapper.selectOne(
                new LambdaQueryWrapper<PaymentTxnEventEntity>()
                        .eq(PaymentTxnEventEntity::getTransactionId, transactionId)
                        .eq(PaymentTxnEventEntity::getDownstreamSystem,
                                DownstreamSystemEnum.EPH.getCode())
                        .eq(PaymentTxnEventEntity::getEventType, eventType)
                        .eq(PaymentTxnEventEntity::getEventStage, eventStage)
                        .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED)
                        .isNotNull(PaymentTxnEventEntity::getResultStatus)
                        .orderByDesc(PaymentTxnEventEntity::getCreationDate)
                        .orderByDesc(PaymentTxnEventEntity::getEventId)
                        .last("FETCH FIRST 1 ROWS ONLY")
        );

        if (event == null
                || event.getResultStatus() == null
                || event.getResultStatus().isBlank()) {
            return Optional.empty();
        }

        return Optional.of(event.getResultStatus());
    }

    /**
     * 按批次获取 EPH 原始交易状态。
     *
     * <p>每笔交易优先返回最新有效 I006 状态；
     * I006 不存在时，返回最新有效 I037 RESPONSE 状态。</p>
     */
    public Map<String, String> findEphDownstreamStatuses(String batchId) {
        if (batchId == null || batchId.isBlank()) {
            return Map.of();
        }

        List<PaymentTxnEventEntity> events = eventMapper.selectList(
                new LambdaQueryWrapper<PaymentTxnEventEntity>()
                        .eq(PaymentTxnEventEntity::getBatchId, batchId.trim())
                        .eq(
                                PaymentTxnEventEntity::getDownstreamSystem,
                                DownstreamSystemEnum.EPH.getCode()
                        )
                        .eq(PaymentTxnEventEntity::getIsDeleted, NOT_DELETED)
                        .isNotNull(PaymentTxnEventEntity::getResultStatus)
                        .and(wrapper -> wrapper
                                .and(i006 -> i006
                                        .eq(
                                                PaymentTxnEventEntity::getEventType,
                                                PaymentTxnEventTypeEnum.EPH_I006.name()
                                        )
                                        .eq(
                                                PaymentTxnEventEntity::getEventStage,
                                                "i006"
                                        )
                                )
                                .or(i037 -> i037
                                        .eq(
                                                PaymentTxnEventEntity::getEventType,
                                                PaymentTxnEventTypeEnum.EPH_I037.name()
                                        )
                                        .eq(
                                                PaymentTxnEventEntity::getEventStage,
                                                "RESPONSE"
                                        )
                                )
                        )
                        .orderByDesc(PaymentTxnEventEntity::getCreationDate)
                        .orderByDesc(PaymentTxnEventEntity::getEventId)
        );

        Map<String, String> latestI006Statuses = new HashMap<>();
        Map<String, String> latestI037Statuses = new HashMap<>();

        for (PaymentTxnEventEntity event : events) {
            String transactionId = event.getTransactionId();
            String resultStatus = event.getResultStatus();

            if (transactionId == null || transactionId.isBlank()
                    || resultStatus == null || resultStatus.isBlank()) {
                continue;
            }

            if (PaymentTxnEventTypeEnum.EPH_I006.name()
                    .equals(event.getEventType())) {
                latestI006Statuses.putIfAbsent(transactionId, resultStatus);
                continue;
            }

            if (PaymentTxnEventTypeEnum.EPH_I037.name()
                    .equals(event.getEventType())) {
                latestI037Statuses.putIfAbsent(transactionId, resultStatus);
            }
        }

        Map<String, String> result = new HashMap<>(latestI037Statuses);

        // I006优先级高于I037。
        result.putAll(latestI006Statuses);

        return result;
    }
}
