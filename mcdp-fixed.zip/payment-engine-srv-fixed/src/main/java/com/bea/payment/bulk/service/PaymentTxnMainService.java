package com.bea.payment.bulk.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bea.payment.bulk.mapper.PaymentTxnEventMapper;
import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
import com.bea.payment.bulk.model.dto.PaymentTxnMainConvertDTO;
import com.bea.payment.bulk.model.entity.PaymentTxnEventEntity;
import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
import com.bea.payment.bulk.constants.PaymentTxnEventTypeEnum;
import com.bea.payment.common.exception.BusinessException;
import com.bea.payment.common.response.StandardResultCode;
import org.springframework.stereotype.Service;

@Service
public class PaymentTxnMainService {


    private final PaymentTxnMainMapper txnMainMapper;
    private final PaymentTxnEventMapper eventMapper;

    public PaymentTxnMainService(PaymentTxnMainMapper txnMainMapper, PaymentTxnEventMapper eventMapper) {
        this.txnMainMapper = txnMainMapper;
        this.eventMapper = eventMapper;
    }

    /**
     * Load an undeleted transaction from MAIN table.
     */
    public PaymentTxnMainConvertDTO loadTxn(String transactionId) {
        if (transactionId == null || transactionId.isBlank()) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED, "transactionId is required");
        }

        PaymentTxnMainEntity txn = txnMainMapper.selectOne(new LambdaQueryWrapper<PaymentTxnMainEntity>()
                .eq(PaymentTxnMainEntity::getTransactionId, transactionId)
                .eq(PaymentTxnMainEntity::getIsDeleted, "N"));

        if (txn == null) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "Payment transaction not found: " + transactionId);
        }

        PaymentTxnEventEntity event = eventMapper.selectOne(new LambdaQueryWrapper<PaymentTxnEventEntity>()
                .eq(PaymentTxnEventEntity::getTransactionId, transactionId)
                .eq(PaymentTxnEventEntity::getOrderId, 1)
                .eq(PaymentTxnEventEntity::getEventType, PaymentTxnEventTypeEnum.PAYMENT_ACCEPTED.name())
                .eq(PaymentTxnEventEntity::getIsDeleted, "N"));

        if (event == null) {
            throw new BusinessException(StandardResultCode.BUSINESS_REJECTED,
                    "Payment transaction event not found: " + transactionId);
        }

        return new PaymentTxnMainConvertDTO(txn,event);
    }

}
