package com.bea.payment.bulk.service;

import com.bea.payment.bulk.mapper.UpstreamApiAuditMapper;
import com.bea.payment.bulk.model.entity.UpstreamApiAuditEntity;
import org.springframework.stereotype.Service;

@Service
public class UpstreamApiAuditService {

    private final UpstreamApiAuditMapper auditMapper;

    public UpstreamApiAuditService(UpstreamApiAuditMapper auditMapper) {
        this.auditMapper = auditMapper;
    }

    public void save(UpstreamApiAuditEntity audit) {
        auditMapper.insert(audit);
    }
}
