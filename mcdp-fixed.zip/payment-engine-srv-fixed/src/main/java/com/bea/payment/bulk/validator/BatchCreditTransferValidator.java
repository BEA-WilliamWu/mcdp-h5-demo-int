package com.bea.payment.bulk.validator;

import com.bea.payment.bulk.config.ChannelWhitelistConfig;
import com.bea.payment.bulk.constants.*;
import com.bea.payment.bulk.model.dto.BatchCreditTransferRequest;
import com.bea.payment.bulk.model.dto.TransactionDetailRequest;
import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.bea.payment.common.util.FieldValidateUtils.assertMaxLength;
import static com.bea.payment.common.util.FieldValidateUtils.requireNonBlank;

@Component
public class BatchCreditTransferValidator {

    private static final int MAX_TRANSACTIONS_PER_BATCH = 1000;

    private final ChannelWhitelistConfig channelWhitelistConfig;

    public BatchCreditTransferValidator(ChannelWhitelistConfig channelWhitelistConfig) {
        this.channelWhitelistConfig = channelWhitelistConfig;
    }

    public void validate(BatchCreditTransferRequest req) {
        // --- HDR level ---

        // channel
        requireNonBlank(req.getChannel(), "channel",
                StandardResultCode.INVALID_CHANNEL);
        if (!channelWhitelistConfig.isValid(req.getChannel())) {
            throw new ValidationException(StandardResultCode.INVALID_CHANNEL,
                    "Invalid channel: " + req.getChannel()
                            + ", allowed: " + channelWhitelistConfig.getWhitelist());
        }

        // batchId
        requireNonBlank(req.getBatchId(), "batchId",
                StandardResultCode.INVALID_ID_FORMAT);
        TransactionDetailValidator.validateIdFormat(req.getBatchId(), "batchId");

        // batchId first 3 chars must equal channel
        String batchChannel = req.getBatchId().substring(0, 3);
        if (!batchChannel.equalsIgnoreCase(req.getChannel())) {
            throw new ValidationException(StandardResultCode.INVALID_ID_FORMAT,
                    "batchId prefix '" + batchChannel + "' does not match channel '" + req.getChannel() + "'");
        }

        // transactionType
        TransactionDetailValidator.validateTransactionType(req.getTransactionType());

        // timeOfTransfer
        TimeOfTransferEnum timeOfTransfer = TimeOfTransferEnum.from(req.getTimeOfTransfer());

        // executionDate
        if (timeOfTransfer == TimeOfTransferEnum.LATER) {
            requireNonBlank(req.getExecutionDate(), "executionDate",
                    StandardResultCode.INVALID_EXECUTION_DATE);
        }
        if (req.getExecutionDate() != null && !req.getExecutionDate().isBlank()) {
            try {
                java.time.LocalDate executionDate = java.time.LocalDate.parse(req.getExecutionDate());
                if (timeOfTransfer == TimeOfTransferEnum.LATER
                        && executionDate.isBefore(java.time.LocalDate.now())) {
                    throw new ValidationException(StandardResultCode.INVALID_EXECUTION_DATE,
                            "executionDate must not be in the past for LATER payments");
                }
            } catch (ValidationException e) {
                throw e;
            } catch (java.time.format.DateTimeParseException e) {
                throw new ValidationException(StandardResultCode.INVALID_EXECUTION_DATE,
                        "executionDate must be a valid date (yyyy-MM-dd)");
            }
        }

        // totalCount
        if (req.getTotalCount() == null || req.getTotalCount() <= 0) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    "totalCount must be > 0");
        }

        // totalAmount
        TransactionDetailValidator.requirePositive(req.getTotalAmount(), "totalAmount");

        // serviceChargeAmount
        if (req.getServiceChargeAmount() != null
                && req.getServiceChargeAmount().compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException(StandardResultCode.INVALID_AMOUNT,
                    "serviceChargeAmount must be >= 0");
        }

        // customerRemarks
        assertMaxLength(req.getCustomerRemarks(), 256, "customerRemarks");

        // channelReference
        assertMaxLength(req.getChannelReference(), 64, "channelReference");

//        validateCallbackUrl(req.getCallbackUrl());

        // --- Transactions ---

        List<TransactionDetailRequest> txns = req.getTransactions();
        if (txns == null || txns.isEmpty()) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    "transactions must not be empty");
        }
        if (txns.size() > MAX_TRANSACTIONS_PER_BATCH) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    "transactions must contain at most " + MAX_TRANSACTIONS_PER_BATCH + " items");
        }

        // rule 37: no duplicate transactionId within batch
        Set<String> txnIds = new HashSet<>();

        for (int i = 0; i < txns.size(); i++) {
            TransactionDetailRequest txn = txns.get(i);
            TransactionDetailValidator.validate(txn, i, req.getTransactionType());
            // payeeName required for FPS/CHATS
            TransactionDetailValidator.requirePayeeNameForTransactionType(req.getTransactionType(), txn.getPayeeName());
            TransactionDetailValidator.requirePositive(
                    txn.getHkdEquivalentAmount(), "transactions[" + i + "].hkdEquivalentAmount");
            String txnIdChannel = txn.getTransactionId().substring(0, 3);
            if (!txnIdChannel.equalsIgnoreCase(req.getChannel())) {
                throw new ValidationException(StandardResultCode.INVALID_ID_FORMAT,
                        "transactions[" + i + "].transactionId prefix '"
                                + txnIdChannel + "' does not match channel '" + req.getChannel() + "'");
            }

            if (!txnIds.add(txn.getTransactionId())) {
                throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                        "Duplicate transactionId in batch: " + txn.getTransactionId());
            }
        }

        // rule 39: totalCount matches
        if (!req.getTotalCount().equals(txns.size())) {
            throw new ValidationException(StandardResultCode.BATCH_TOTAL_MISMATCH,
                    "totalCount (" + req.getTotalCount() + ") does not match transactions size (" + txns.size() + ")");
        }

        // rule 38: totalAmount matches
        BigDecimal sumAmount = txns.stream()
                .map(TransactionDetailRequest::getHkdEquivalentAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (req.getTotalAmount().compareTo(sumAmount) != 0) {
            throw new ValidationException(StandardResultCode.BATCH_TOTAL_MISMATCH,
                    "totalAmount (" + req.getTotalAmount()
                            + ") does not match sum of hkdEquivalentAmount (" + sumAmount + ")");
        }
    }

    private void validateCallbackUrl(String callbackUrl) {
        if (callbackUrl == null || callbackUrl.isBlank()) {
            return;
        }
        assertMaxLength(callbackUrl, 512, "callbackUrl");
        try {
            URI uri = URI.create(callbackUrl);
            String scheme = uri.getScheme();
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
                throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                        "callbackUrl must use http or https");
            }
            if (uri.getHost() == null || uri.getHost().isBlank()) {
                throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                        "callbackUrl must include host");
            }
        } catch (IllegalArgumentException e) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    "callbackUrl must be a valid URI");
        }
    }
}
