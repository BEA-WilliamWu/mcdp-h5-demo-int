package com.bea.payment.bulk.validator;

import com.bea.payment.bulk.config.ChannelWhitelistConfig;
import com.bea.payment.bulk.constants.*;
import com.bea.payment.bulk.model.dto.SingleCreditTransferRequest;
import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;
import org.springframework.stereotype.Component;

import static com.bea.payment.bulk.validator.TransactionDetailValidator.validateCurrency;
import static com.bea.payment.common.util.FieldValidateUtils.*;

@Component
public class SingleCreditTransferValidator {

    private final ChannelWhitelistConfig channelWhitelistConfig;

    public SingleCreditTransferValidator(ChannelWhitelistConfig channelWhitelistConfig) {
        this.channelWhitelistConfig = channelWhitelistConfig;
    }

    public void validate(SingleCreditTransferRequest req) {
        // channel
        requireNonBlank(req.getChannel(), "channel",
                StandardResultCode.INVALID_CHANNEL);
        if (!channelWhitelistConfig.isValid(req.getChannel())) {
            throw new ValidationException(StandardResultCode.INVALID_CHANNEL,
                    "Invalid channel: " + req.getChannel()
                            + ", allowed: " + channelWhitelistConfig.getWhitelist());
        }

        // transactionId
        requireNonBlank(req.getTransactionId(), "transactionId",
                StandardResultCode.INVALID_ID_FORMAT);
        TransactionDetailValidator.validateIdFormat(req.getTransactionId(), "transactionId");
        String txnIdChannel = req.getTransactionId().substring(0, 3);
        if (!txnIdChannel.equalsIgnoreCase(req.getChannel())) {
            throw new ValidationException(StandardResultCode.INVALID_ID_FORMAT,
                    "transactionId prefix '" + txnIdChannel + "' does not match channel '" + req.getChannel() + "'");
        }

        // transactionType
        TransactionDetailValidator.validateTransactionType(req.getTransactionType());

        // payeeName required for FPS/CHATS
        TransactionDetailValidator.requirePayeeNameForTransactionType(req.getTransactionType(), req.getPayeeName());

        // timeOfTransfer
        TimeOfTransferEnum timeOfTransfer = TimeOfTransferEnum.from(req.getTimeOfTransfer());

        // executionDate
        if (timeOfTransfer == TimeOfTransferEnum.LATER) {
            requireNonBlank(req.getExecutionDate(), "executionDate",
                    StandardResultCode.INVALID_EXECUTION_DATE);
        }
        if (req.getExecutionDate() != null && !req.getExecutionDate().isBlank()) {
            try {
                java.time.LocalDate executionDate = java.time.LocalDate.parse(req.getExecutionDate());
                if (timeOfTransfer == TimeOfTransferEnum.LATER
                        && executionDate.isBefore(java.time.LocalDate.now())) {
                    throw new ValidationException(StandardResultCode.INVALID_EXECUTION_DATE,
                            "executionDate must not be in the past for LATER payments");
                }
            } catch (ValidationException e) {
                throw e;
            } catch (java.time.format.DateTimeParseException e) {
                throw new ValidationException(StandardResultCode.INVALID_EXECUTION_DATE,
                        "executionDate must be a valid date (yyyy-MM-dd)");
            }
        }

        // channelReference
        assertMaxLength(req.getChannelReference(), 64, "channelReference");

        // amount
        TransactionDetailValidator.requirePositive(req.getDebitAmount(), "debitAmount");
        TransactionDetailValidator.validateOptionalPositive(req.getHkdEquivalentAmount(), "hkdEquivalentAmount");
        TransactionDetailValidator.validateExchangeFields(req.getExchangeCurrencyPair(), req.getExchangeContractRate(),
                req.getExchangeSpecialRate(), req.getExchangeSpecialRateFlag(), req.getTreasuryReference(), "");
        TransactionDetailValidator.validateBg3Instruction(req.getBg3(), "bg3");

        // currencies
        validateCurrency(req.getDebitAmountCcy(), "debitAmountCcy");

        if (req.getSettlementCurrency() != null && !req.getSettlementCurrency().isBlank()) {
            validateCurrency(req.getSettlementCurrency(), "settlementCurrency");
        }

        if (req.getServiceChargeAmount() != null
                && req.getServiceChargeAmount().compareTo(java.math.BigDecimal.ZERO) > 0) {
            validateCurrency(req.getChargeCurrency(), "chargeCurrency");
        }

        // payer
        validatePayer(req);

        // payee
        validatePayee(req);

        validateEphInstruction(req.getTransactionType(), req, "",
                req.getPayerInternalAccountNo(), req.getPayerAccountNo(), req.getPayeeType(),
                req.getPayeeAccountNo(), req.getMemberId(), req.getPayeeProxyId(), req.getPayeeName(),
                req.getChargeCurrency());
    }


    static void validateEphInstruction(String transactionType, SingleCreditTransferRequest req, String fieldPrefix,
                                       String payerInternalAccountNo, String payerAccountNo, String payeeType,
                                       String payeeAccountNo, String memberId, String payeeProxyId, String payeeName,
                                       String chargeCurrency) {
        boolean isFps = TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(transactionType);
        if (!isFps) {
//            if (req != null) {
//                throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
//                        fieldPrefix + " must be omitted when transactionType is not FPS");
//            }
            return;
        }

        if (req == null) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldPrefix + " is required when transactionType is FPS");
        }
        requireAndMax(req.getPaymentSource(), fieldPrefix + "paymentSource", 16);
        requireAndMax(req.getEnquiryType(), fieldPrefix + "enquiryType", 8);
        requireAndMax(req.getCostCenterCode(), fieldPrefix + "costCenterCode", 20);
        requireAndMax(req.getFeeCode(), fieldPrefix + "feeCode", 20);
        requireAndMax(req.getPayeeIdentificationType(), fieldPrefix + "payeeIdentificationType", 16);
//        requireAndMax(req.getCategoryPurpose(), fieldPrefix + ".categoryPurpose", 35);
        requireAndMax(req.getAlnovaLimitCheckInd(), fieldPrefix + "alnovaLimitCheckInd", 8);
//        requireAndMax(req.getEndToEndId(), fieldPrefix + ".endToEndId", 64);
        validateOptionalEphI006Fields(req, fieldPrefix);

        requireAndMax(payerInternalAccountNo, "payerInternalAccountNo", 20);
        requireAndMax(payerAccountNo, "payerAccountNo", 20);
        requireAndMax(payeeName, "payeeName", 140);
        validateCurrency(chargeCurrency, "chargeCurrency");

        PayeeTypeEnum parsedPayeeType = parsePayeeTypeOrDefaultAccount(payeeType);
        if (parsedPayeeType == PayeeTypeEnum.ACCOUNT) {
            requireNonBlank(payeeAccountNo, "payeeAccountNo", StandardResultCode.INVALID_PAYEE);
            requireAndMax(memberId, "memberId", 16);
        }
//        if (parsedPayeeType == PayeeTypeEnum.PROXY) {
//            requireNonBlank(payeeProxyId, "payeeProxyId", StandardResultCode.INVALID_PAYEE);
//        }
    }


    private void validatePayer(SingleCreditTransferRequest req) {
        requireNonBlank(req.getPayerAccountNo(), "payerAccountNo",
                StandardResultCode.INVALID_PAYER);
        assertMaxLength(req.getPayerAccountNo(), 34, "payerAccountNo");

        requireNonBlank(req.getPayerName(), "payerName",
                StandardResultCode.INVALID_PAYER);
        assertMaxLength(req.getPayerName(), 140, "payerName");

        PayerTypeEnum.from(req.getPayerType());

        if (req.getPayerBicCode() != null && !req.getPayerBicCode().isBlank()) {
            assertMaxLength(req.getPayerBicCode(), 11, "payerBicCode");
        }

        if (req.getPayerAccountCurrency() != null && !req.getPayerAccountCurrency().isBlank()) {
            validateCurrency(req.getPayerAccountCurrency(), "payerAccountCurrency");
        }

        TransactionDetailValidator.validateCountryCode(req.getPayerCountryCode(), "payerCountryCode");

        assertMaxLength(req.getPayerAddressLine1(), 70, "payerAddressLine1");
        assertMaxLength(req.getPayerAddressLine2(), 70, "payerAddressLine2");
        assertMaxLength(req.getPayerAddressLine3(), 70, "payerAddressLine3");
        assertMaxLength(req.getPayerAddressLine4(), 70, "payerAddressLine4");
        assertMaxLength(req.getPayerTownName(), 70, "payerTownName");
    }

    private void validatePayee(SingleCreditTransferRequest req) {
        PayeeTypeEnum payeeType = parsePayeeTypeOrDefaultAccount(req.getPayeeType());

        assertMaxLength(req.getPayeeName(), 140, "payeeName");

        if (payeeType == PayeeTypeEnum.ACCOUNT) {
            requireNonBlank(req.getPayeeAccountNo(), "payeeAccountNo",
                    StandardResultCode.INVALID_PAYEE);
            assertMaxLength(req.getPayeeAccountNo(), 34, "payeeAccountNo");
        }

        if (payeeType == PayeeTypeEnum.PROXY) {
            boolean hasProxyId = req.getPayeeProxyId() != null && !req.getPayeeProxyId().isBlank();
            boolean hasMobile = req.getPayeeMobileNo() != null && !req.getPayeeMobileNo().isBlank();
            boolean hasEmail = req.getPayeeEmailAddress() != null && !req.getPayeeEmailAddress().isBlank();
            if (!(hasProxyId || hasMobile || hasEmail)) {
                throw new ValidationException(StandardResultCode.INVALID_PAYEE,
                        "payeeProxyId, payeeMobileNo, payeeEmailAddress must contain at least one value");
            }
            assertMaxLength(req.getPayeeProxyId(), 64, "payeeProxyId");
        }

        if (req.getPayeeAccountCurrency() != null && !req.getPayeeAccountCurrency().isBlank()) {
            validateCurrency(req.getPayeeAccountCurrency(), "payeeAccountCurrency");
        }

        assertMaxLength(req.getPayeeBankCode(), 16, "payeeBankCode");
        assertMaxLength(req.getMemberId(), 16, "memberId");
        assertMaxLength(req.getPayeeBankName(), 140, "payeeBankName");
        assertMaxLength(req.getPayeeMobileNo(), 32, "payeeMobileNo");

        if (req.getPayeeEmailAddress() != null && !req.getPayeeEmailAddress().isBlank()) {
            assertMaxLength(req.getPayeeEmailAddress(), 128, "payeeEmailAddress");
            if (!req.getPayeeEmailAddress().contains("@")) {
                throw new ValidationException(StandardResultCode.INVALID_PAYEE,
                        "payeeEmailAddress must contain @");
            }
        }

        if (req.getPayeeBicCode() != null && !req.getPayeeBicCode().isBlank()) {
            assertMaxLength(req.getPayeeBicCode(), 11, "payeeBicCode");
        }

        TransactionDetailValidator.validateCountryCode(req.getPayeeCountryCode(), "payeeCountryCode");

        assertMaxLength(req.getPayeeAddressLine1(), 70, "payeeAddressLine1");
        assertMaxLength(req.getPayeeAddressLine2(), 70, "payeeAddressLine2");
        assertMaxLength(req.getPayeeAddressLine3(), 70, "payeeAddressLine3");
        assertMaxLength(req.getPayeeAddressLine4(), 70, "payeeAddressLine4");
        assertMaxLength(req.getPayeeTownName(), 70, "payeeTownName");

        assertMaxLength(req.getSenderCorrBankBicCode(), 11, "senderCorrBankBicCode");
        assertMaxLength(req.getReceiverCorrBankBicCode(), 11, "receiverCorrBankBicCode");

        assertMaxLength(req.getPaymentDetails(), 140, "paymentDetails");
    }
}
