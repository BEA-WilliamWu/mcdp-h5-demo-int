package com.bea.payment.bulk.validator;

import com.bea.payment.bulk.constants.*;
import com.bea.payment.bulk.model.dto.Bg3InstructionRequest;
import com.bea.payment.bulk.model.dto.TransactionDetailRequest;
import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.regex.Pattern;

import static com.bea.payment.common.util.FieldValidateUtils.*;

public final class TransactionDetailValidator {

    // Transaction id: 3 alphanumeric chars followed by 20 digits
    private static final Pattern ID_PATTERN = Pattern.compile("^[A-Za-z0-9]{3}\\d{20}$");
    private static final Pattern BIC_PATTERN = Pattern.compile("^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$");
    private static final Pattern COUNTRY_PATTERN = Pattern.compile("^[A-Z]{2}$");
    private static final int BG3_EVENT_VALUE_MAX_SIZE = 10;

    private TransactionDetailValidator() {}

    public static void validate(TransactionDetailRequest txn, int index) {
        validate(txn, index, null);
    }

    public static void validate(TransactionDetailRequest txn, int index, String transactionType) {
        String prefix = "transactions[" + index + "].";

        // transactionId
        requireNonBlank(txn.getTransactionId(), prefix + "transactionId",
                StandardResultCode.INVALID_ID_FORMAT);
        validateIdFormat(txn.getTransactionId(), prefix + "transactionId");

        // debitAmount
        requirePositive(txn.getDebitAmount(), prefix + "debitAmount");
        validateOptionalPositive(txn.getHkdEquivalentAmount(), prefix + "hkdEquivalentAmount");

        // debitAmountCcy
        validateCurrency(txn.getDebitAmountCcy(), prefix + "debitAmountCcy");

        // settlementCurrency (optional, defaults to debitAmountCcy)
        if (txn.getSettlementCurrency() != null && !txn.getSettlementCurrency().isBlank()) {
            validateCurrency(txn.getSettlementCurrency(), prefix + "settlementCurrency");
        }

        // serviceChargeAmount
        if (txn.getServiceChargeAmount() != null && txn.getServiceChargeAmount().compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException(StandardResultCode.INVALID_AMOUNT,
                    prefix + "serviceChargeAmount must be >= 0");
        }

        // chargeCurrency (required if serviceChargeAmount present)
        if (txn.getServiceChargeAmount() != null
                && txn.getServiceChargeAmount().compareTo(BigDecimal.ZERO) > 0) {
            validateCurrency(txn.getChargeCurrency(), prefix + "chargeCurrency");
        }

        // paymentDetails
        if(null != txn.getPaymentDetails()){
            for (int i = 0; i < txn.getPaymentDetails().size(); i++) {
                assertMaxLength(txn.getPaymentDetails().get(i), 35, prefix + "paymentDetails" + (i + 1));
            }
        }
        validateExchangeFields(txn.getExchangeCurrencyPair(), txn.getExchangeContractRate(),
                txn.getExchangeSpecialRate(), txn.getExchangeSpecialRateFlag(), txn.getTreasuryReference(), prefix);
        validateBg3Instruction(txn.getBg3(), prefix + "bg3");

        // payer
        validatePayer(txn, prefix);

        // payee
        validatePayee(txn, prefix);

        validateEphInstruction(transactionType, txn, prefix,
                txn.getPayerInternalAccountNo(), txn.getPayerAccountNo(), txn.getPayeeType(),
                txn.getPayeeAccountNo(), txn.getMemberId(), txn.getPayeeProxyId(), txn.getPayeeName(),
                txn.getChargeCurrency());
    }

    private static void validatePayer(TransactionDetailRequest txn, String prefix) {
        requireNonBlank(txn.getPayerAccountNo(), prefix + "payerAccountNo",
                StandardResultCode.INVALID_PAYER);
        assertMaxLength(txn.getPayerAccountNo(), 34, prefix + "payerAccountNo");

        requireNonBlank(txn.getPayerName(), prefix + "payerName",
                StandardResultCode.INVALID_PAYER);
        assertMaxLength(txn.getPayerName(), 140, prefix + "payerName");

        // payerType
        PayerTypeEnum.from(txn.getPayerType());

        // payerAccountType
//        AccountTypeEnum.valueOf(txn.getPayerAccountType());

        // payerBicCode
        if (txn.getPayerBicCode() != null && !txn.getPayerBicCode().isBlank()) {
            if (!BIC_PATTERN.matcher(txn.getPayerBicCode()).matches()) {
                throw new ValidationException(StandardResultCode.INVALID_PAYER,
                        prefix + "payerBicCode must be 8 or 11 alphanumeric characters");
            }
        }

        // payerAccountCurrency
        if (txn.getPayerAccountCurrency() != null && !txn.getPayerAccountCurrency().isBlank()) {
            validateCurrency(txn.getPayerAccountCurrency(), prefix + "payerAccountCurrency");
        }

        // payerCountryCode
        if (txn.getPayerCountryCode() != null && !txn.getPayerCountryCode().isBlank()) {
            validateCountryCode(txn.getPayerCountryCode(), prefix + "payerCountryCode");
        }

        // address lines
        assertMaxLength(txn.getPayerAddressLine1(), 70, prefix + "payerAddressLine1");
        assertMaxLength(txn.getPayerAddressLine2(), 70, prefix + "payerAddressLine2");
        assertMaxLength(txn.getPayerAddressLine3(), 70, prefix + "payerAddressLine3");
        assertMaxLength(txn.getPayerAddressLine4(), 70, prefix + "payerAddressLine4");
        assertMaxLength(txn.getPayerTownName(), 70, prefix + "payerTownName");
    }

    private static void validatePayee(TransactionDetailRequest txn, String prefix) {
        PayeeTypeEnum payeeType = parsePayeeTypeOrDefaultAccount(txn.getPayeeType());

        assertMaxLength(txn.getPayeeName(), 140, prefix + "payeeName");

        if (payeeType == PayeeTypeEnum.ACCOUNT) {
            requireNonBlank(txn.getPayeeAccountNo(), prefix + "payeeAccountNo",
                    StandardResultCode.INVALID_PAYEE);
            assertMaxLength(txn.getPayeeAccountNo(), 34, prefix + "payeeAccountNo");
        }
        // For PROXY payee, at least one of proxyId/mobile/email is required.
        if (payeeType == PayeeTypeEnum.PROXY) {
            String payeeProxyId = txn.getPayeeProxyId();
            String payeeMobileNo = txn.getPayeeMobileNo();
            String payeeEmailAddress = txn.getPayeeEmailAddress();

            boolean hasProxyId = payeeProxyId != null && !payeeProxyId.isBlank();
            boolean hasMobileNo = payeeMobileNo != null && !payeeMobileNo.isBlank();
            boolean hasEmailAddress = payeeEmailAddress != null && !payeeEmailAddress.isBlank();

            if (!(hasProxyId || hasMobileNo || hasEmailAddress)) {
                throw new ValidationException(StandardResultCode.INVALID_PAYEE,
                        prefix + "payeeProxyId, payeeMobileNo, payeeEmailAddress must be one of them");
            }
            if (hasProxyId) {
                assertMaxLength(payeeProxyId, 64, prefix + "payeeProxyId");
            }
        }

        // optional fields
        assertMaxLength(txn.getPayeeBankCode(), 16, prefix + "payeeBankCode");
        assertMaxLength(txn.getMemberId(), 16, prefix + "memberId");

        if (txn.getPayeeAccountCurrency() != null && !txn.getPayeeAccountCurrency().isBlank()) {
            validateCurrency(txn.getPayeeAccountCurrency(), prefix + "payeeAccountCurrency");
        }

        if (txn.getPayeeBicCode() != null && !txn.getPayeeBicCode().isBlank()) {
            if (!BIC_PATTERN.matcher(txn.getPayeeBicCode()).matches()) {
                throw new ValidationException(StandardResultCode.INVALID_PAYEE,
                        prefix + "payeeBicCode must be 8 or 11 alphanumeric characters");
            }
        }

        if (txn.getPayeeCountryCode() != null && !txn.getPayeeCountryCode().isBlank()) {
            validateCountryCode(txn.getPayeeCountryCode(), prefix + "payeeCountryCode");
        }

        assertMaxLength(txn.getPayeeMobileNo(), 32, prefix + "payeeMobileNo");
        assertMaxLength(txn.getPayeeBankName(), 140, prefix + "payeeBankName");

        if (txn.getPayeeEmailAddress() != null && !txn.getPayeeEmailAddress().isBlank()) {
            assertMaxLength(txn.getPayeeEmailAddress(), 128, prefix + "payeeEmailAddress");
            if (!txn.getPayeeEmailAddress().contains("@")) {
                throw new ValidationException(StandardResultCode.INVALID_PAYEE,
                        prefix + "payeeEmailAddress must contain @");
            }
        }

        // address lines
        assertMaxLength(txn.getPayeeAddressLine1(), 70, prefix + "payeeAddressLine1");
        assertMaxLength(txn.getPayeeAddressLine2(), 70, prefix + "payeeAddressLine2");
        assertMaxLength(txn.getPayeeAddressLine3(), 70, prefix + "payeeAddressLine3");
        assertMaxLength(txn.getPayeeAddressLine4(), 70, prefix + "payeeAddressLine4");
        assertMaxLength(txn.getPayeeTownName(), 70, prefix + "payeeTownName");

        // corr bank BICs
        assertMaxLength(txn.getSenderCorrBankBicCode(), 11, prefix + "senderCorrBankBicCode");
        assertMaxLength(txn.getReceiverCorrBankBicCode(), 11, prefix + "receiverCorrBankBicCode");
    }

    // --- helpers ---

    static void validateExchangeFields(String exchangeCurrencyPair, String exchangeContractRate,
            String exchangeSpecialRate, String exchangeSpecialRateFlag, String treasuryReference, String prefix) {
        assertMaxLength(exchangeCurrencyPair, 7, prefix + "exchangeCurrencyPair");
        assertMaxLength(exchangeContractRate, 11, prefix + "exchangeContractRate");
        assertMaxLength(exchangeSpecialRate, 11, prefix + "exchangeSpecialRate");
        assertMaxLength(exchangeSpecialRateFlag, 1, prefix + "exchangeSpecialRateFlag");
        assertMaxLength(treasuryReference, 7, prefix + "treasuryReference");
    }

    static void validateBg3Instruction(Bg3InstructionRequest bg3, String fieldPrefix) {
        if (bg3 == null) {
            return;
        }
        if (bg3.getEventValues() != null && bg3.getEventValues().size() > BG3_EVENT_VALUE_MAX_SIZE) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldPrefix + ".eventValues must contain at most " + BG3_EVENT_VALUE_MAX_SIZE + " items");
        }
    }

    static void validateEphInstruction(String transactionType, TransactionDetailRequest req, String fieldPrefix,
            String payerInternalAccountNo, String payerAccountNo, String payeeType,
            String payeeAccountNo, String memberId, String payeeProxyId, String payeeName,
            String chargeCurrency) {
        boolean isFps = TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(transactionType);
        if (!isFps) {
            return;
        }

        if (req == null) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldPrefix + " is required when transactionType is FPS");
        }
        requireAndMax(req.getPaymentSource(), fieldPrefix + "paymentSource", 16);
        requireAndMax(req.getEnquiryType(), fieldPrefix + "enquiryType", 8);
        requireAndMax(req.getCostCenterCode(), fieldPrefix + "costCenterCode", 20);
        requireAndMax(req.getFeeCode(), fieldPrefix + "feeCode", 20);
        requireAndMax(req.getPayeeIdentificationType(), fieldPrefix + "payeeIdentificationType", 16);
//        requireAndMax(req.getCategoryPurpose(), fieldPrefix + ".categoryPurpose", 35);
        requireAndMax(req.getAlnovaLimitCheckInd(), fieldPrefix + "alnovaLimitCheckInd", 8);
//        requireAndMax(req.getEndToEndId(), fieldPrefix + ".endToEndId", 64);
        validateOptionalEphI006Fields(req, fieldPrefix);

        requireAndMax(payerInternalAccountNo, "payerInternalAccountNo", 20);
        requireAndMax(payerAccountNo, "payerAccountNo", 20);
        requireAndMax(payeeName, "payeeName", 140);
        validateCurrency(chargeCurrency, "chargeCurrency");

        PayeeTypeEnum parsedPayeeType = parsePayeeTypeOrDefaultAccount(payeeType);
        if (parsedPayeeType == PayeeTypeEnum.ACCOUNT) {
            requireNonBlank(payeeAccountNo, "payeeAccountNo", StandardResultCode.INVALID_PAYEE);
            requireAndMax(memberId, "memberId", 16);
        }
//        if (parsedPayeeType == PayeeTypeEnum.PROXY) {
//            requireNonBlank(payeeProxyId, "payeeProxyId", StandardResultCode.INVALID_PAYEE);
//        }
    }



    private static void validateCustomerIdGroup(String id, String type, String category,
            String idField, String typeField, String categoryField) {
        boolean anyPresent = hasText(id) || hasText(type) || hasText(category);
        if (!anyPresent) {
            return;
        }
        requireAndMax(id, idField, 35);
        requireAndMax(type, typeField, 8);
        requireAndMax(category, categoryField, 16);
        if (!"ORG".equalsIgnoreCase(category) && !"PRIVATE".equalsIgnoreCase(category)) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    categoryField + " must be ORG or PRIVATE");
        }
    }


    static void validateIdFormat(String id, String fieldName) {
        if (id.length() != 23) {
            throw new ValidationException(StandardResultCode.INVALID_ID_FORMAT,
                    fieldName + " must be 23 characters");
        }
        if (!ID_PATTERN.matcher(id).matches()) {
            throw new ValidationException(StandardResultCode.INVALID_ID_FORMAT,
                    fieldName + " format invalid: Must match 3-letter Channel + yyyyMMddHHmmss + 6-digits sequence");
        }
        // validate timestamp portion is a valid date
        String timestamp = id.substring(3, 17);
        try {
            java.time.LocalDateTime.parse(timestamp, java.time.format.DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        } catch (java.time.format.DateTimeParseException e) {
            throw new ValidationException(StandardResultCode.INVALID_ID_FORMAT,
                    fieldName + " contains invalid timestamp: " + timestamp);
        }
    }

    static void validateCurrency(String currency, String fieldName) {
        requireNonBlank(currency, fieldName, StandardResultCode.INVALID_CURRENCY);
        if (currency.length() != 3) {
            throw new ValidationException(StandardResultCode.INVALID_CURRENCY,
                    fieldName + " must be 3 characters");
        }
        try {
            Currency.getInstance(currency.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ValidationException(StandardResultCode.INVALID_CURRENCY,
                    fieldName + " is not a valid ISO 4217 currency: " + currency);
        }
    }

    static void validateTimeOfTransfer(String timeOfTransfer) {
        TimeOfTransferEnum.from(timeOfTransfer);
    }

    static void validateTransactionType(String transactionType) {
        TransactionTypeEnum.from(transactionType);
    }

    /**
     * 校验 FPS/CHATS 交易类型下 payeeName 为必填。
     *
     * <p>若 transactionType 为 FPS 或 CHATS，则 payeeName 不能为 null、空或仅空格。</p>
     */
    static void requirePayeeNameForTransactionType(String transactionType, String payeeName) {
        boolean isFpsOrChats = TransactionTypeEnum.FPS.getCode().equalsIgnoreCase(transactionType)
                || TransactionTypeEnum.CHATS.getCode().equalsIgnoreCase(transactionType);
        if (isFpsOrChats) {
            if (payeeName == null || payeeName.trim().isEmpty()) {
                throw new ValidationException(StandardResultCode.INVALID_PAYEE,
                        "payeeName is required when transactionType is FPS or CHATS");
            }
        }
    }

    static void validateCountryCode(String code, String fieldName) {
        if (code != null && !code.isBlank() && !COUNTRY_PATTERN.matcher(code).matches()) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldName + " must be 2 uppercase letters");
        }
    }


    static void requirePositive(BigDecimal value, String fieldName) {
        if (value == null || value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException(StandardResultCode.INVALID_AMOUNT,
                    fieldName + " must be > 0");
        }
    }

    static void validateOptionalPositive(BigDecimal value, String fieldName) {
        if (value != null && value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException(StandardResultCode.INVALID_AMOUNT,
                    fieldName + " must be > 0");
        }
    }

}
