package com.bea.payment.common.advice;


import com.bea.payment.common.exception.BaseException;
import com.bea.payment.common.response.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理
 *
 * 所有异常在此转换为 ApiResponse
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(BaseException.class)
    public ApiResponse<Void> handleBaseException(BaseException ex) {
        return ApiResponse.failure(
                ex.getResultCode(),
                ex.getMessage()
        );
    }

    @ExceptionHandler(Exception.class)
    public ApiResponse<Void> handleUnexpectedException(Exception ex) {
        logger.error("Unexpected system error: {}", ex.getMessage());
        return ApiResponse.failure(
                com.bea.payment.common.response.StandardResultCode.SYSTEM_ERROR,
                "Unexpected system error"
        );
    }
}