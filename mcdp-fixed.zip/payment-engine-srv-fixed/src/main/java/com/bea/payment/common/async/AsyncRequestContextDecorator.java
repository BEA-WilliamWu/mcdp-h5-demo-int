package com.bea.payment.common.async;


import com.bea.payment.common.constants.HeaderConstants;
import com.bea.payment.common.context.RequestContext;
import com.bea.payment.common.context.RequestContextHolder;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

/**
 * 异步任务上下文装饰器
 * * 职责：
 * - 捕获提交任务线程的 RequestContext
 * - 在异步线程中恢复 RequestContext 和 MDC
 */
public class AsyncRequestContextDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable runnable) {
        RequestContext parentContext = RequestContextHolder.copy();

        return () -> {
            try {
                if (parentContext != null) {
                    RequestContextHolder.set(parentContext);
                    MDC.put(HeaderConstants.TRACE_ID, parentContext.getTraceContext().getTraceId());
                }
                runnable.run();
            } finally {
                RequestContextHolder.clear();
                MDC.remove(HeaderConstants.TRACE_ID);
            }
        };
    }
}