package com.bea.payment.common.config;


import com.bea.payment.common.async.AsyncRequestContextDecorator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * 统一异步线程池配置
 */
@Configuration
public class AsyncExecutorConfig {

    @Bean("paymentTaskExecutor")
    public ThreadPoolTaskExecutor paymentTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(50);
        executor.setQueueCapacity(200);
        executor.setThreadNamePrefix("payment-async-");
        executor.setTaskDecorator(new AsyncRequestContextDecorator());
        executor.initialize();
        return executor;
    }
}