package com.bea.payment.common.config;


import com.bea.payment.bulk.internal.flow.cache.FlowControlConfigCache;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.redisson.api.RedissonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 流控配置组件装配。
 *
 * 职责：
 * - 声明 Redis-backed `FlowControlConfigCache` 为 Spring 单例 Bean
 *
 * 设计说明：
 * - Cache 是运行期基础设施组件，Redis 是运行期配置快照事实来源；
 * - 由定时 Loader 负责从 DB 同步到 Redis
 * - 业务侧只读访问 Redis 快照
 */
@Configuration
public class FlowControlConfigConfiguration {

    /**
     * 创建 Redis-backed 配置快照组件。
     *
     * <p>这里集中注入 `RedissonClient` 和 `ObjectMapper`，让 `FlowControlConfigCache`
     * 保持为基础设施组件，不直接绑定到业务 Service 的生命周期或创建逻辑。</p>
     */
    @Bean
    public FlowControlConfigCache flowControlConfigCache(
            RedissonClient redisson,
            ObjectMapper objectMapper
    ) {
        return new FlowControlConfigCache(redisson, objectMapper);
    }
}
