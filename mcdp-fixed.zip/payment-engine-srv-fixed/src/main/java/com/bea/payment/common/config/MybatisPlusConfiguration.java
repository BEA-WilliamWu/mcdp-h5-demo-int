package com.bea.payment.common.config;

import com.baomidou.mybatisplus.autoconfigure.ConfigurationCustomizer;
import org.apache.ibatis.type.JdbcType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MybatisPlusConfiguration {

    @Bean
    public ConfigurationCustomizer oracleNullJdbcTypeCustomizer() {
        return configuration -> configuration.setJdbcTypeForNull(JdbcType.NULL);
    }
}
