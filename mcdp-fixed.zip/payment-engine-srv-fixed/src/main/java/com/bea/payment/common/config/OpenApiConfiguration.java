package com.bea.payment.common.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "Payment Engine API",
                version = "v1",
                description = """
                        Banking payment-engine submission APIs for single and batch credit transfers.

                        The APIs use an asynchronous acceptance model: a successful response means the request has been validated and persisted; final execution is processed downstream.

                        All business responses use HTTP 200. Consumers must inspect `code` and retain `traceId` / `X-RequestId` for enquiry and audit.
                        """
        ),
        tags = @Tag(
                name = "Payment Submission",
                description = "Payment acceptance APIs for upstream channels"
        )
)
public class OpenApiConfiguration {
}
