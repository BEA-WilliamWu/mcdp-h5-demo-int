package com.bea.payment.common.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Scheduling Configuration
 *
 * 职责：
 * - 启用 Spring 定时任务能力
 */
@Configuration
@EnableScheduling
public class SchedulingConfiguration {
}