package com.bea.payment.common.config;

import com.bea.payment.common.filter.TraceIdFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

/**
 * Web Filter 顺序配置
 *
 * 顺序定义：
 * HIGHEST--TraceId
 * +10--安全/认证
 * +20--审计
 * ...--其他
 * LOWEST--Metrics/AccessLog
 *
 */
@Configuration
public class WebFilterConfig {

    @Bean
    public FilterRegistrationBean<TraceIdFilter> requestIdFilter() {
        FilterRegistrationBean<TraceIdFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(new TraceIdFilter());
        bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        bean.addUrlPatterns("/*");
        return bean;
    }

    // 以后可以继续加：
    // // SecurityFilter
    // // AuditFilter
}