package com.bea.payment.common.constants;

/**
 * HTTP Header 常量定义
 * * 统一管理请求上下文相关 Header
 */
public final class HeaderConstants {

    private HeaderConstants() {
    }

    public static final String TRACE_ID = "X-RequestId";
}