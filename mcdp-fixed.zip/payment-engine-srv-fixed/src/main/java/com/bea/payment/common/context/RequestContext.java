package com.bea.payment.common.context;


import lombok.Getter;
/**
 * 请求上下文
 *
 * 设计为可扩展结构，避免后续反复重构。
 * 未来可以放：user / tenant / channel.
 */
@Getter
public class RequestContext {

    private final TraceContext traceContext;

    public RequestContext(TraceContext traceContext) { this.traceContext = traceContext; }

    /**
     * 创建上下文副本
     */
    public RequestContext copy() {
        return new RequestContext(this.traceContext);
    }
}