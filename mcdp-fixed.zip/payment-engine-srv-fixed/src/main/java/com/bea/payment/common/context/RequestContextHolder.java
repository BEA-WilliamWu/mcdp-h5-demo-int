package com.bea.payment.common.context;

/**
 * 请求上下文持有器
 *
 * 基于 ThreadLocal，用于：
 * - Controller
 * - Service
 * - Internal Component
 */
public final class RequestContextHolder {

    private static final ThreadLocal<RequestContext> CONTEXT = new ThreadLocal<>();

    private RequestContextHolder() {
    }

    public static void set(RequestContext context) {
        CONTEXT.set(context);
    }

    public static RequestContext get() {
        return CONTEXT.get();
    }

    public static void clear() {
        CONTEXT.remove();
    }


    /**
     * 复制当前线程的上下文
     *
     * 用于异步任务传递
     */
    public static RequestContext copy() {
        RequestContext context = CONTEXT.get();
        if (context == null) {
            return null;
        }
        return context.copy();
    }
}