package com.bea.payment.common.context;


import lombok.Getter;
/**
 * Trace 上下文信息
 *
 * 仅用于日志追踪，不携带业务信息
 */
@Getter
public class TraceContext {

    private final String traceId;

    public TraceContext(String traceId) { this.traceId = traceId; }

}