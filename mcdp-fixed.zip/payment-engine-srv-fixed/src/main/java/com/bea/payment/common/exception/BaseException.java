package com.bea.payment.common.exception;

import lombok.Getter;

import com.bea.payment.common.response.StandardResultCode;

/**
 * 所有业务相关异常的基类
 *
 * 特点：
 * - 持有 StandardResultCode
 * - 不与具体业务场景绑定
 */
@Getter
public abstract class BaseException extends RuntimeException {

    private final StandardResultCode resultCode;

    protected BaseException(StandardResultCode resultCode, String message) {
        super(message);
        this.resultCode = resultCode;
    }

}