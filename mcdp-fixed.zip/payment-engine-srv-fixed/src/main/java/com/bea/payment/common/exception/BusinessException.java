package com.bea.payment.common.exception;

import com.bea.payment.common.response.StandardResultCode;

/**
 * 业务异常
 *
 * 用于表达：
 * - 业务规则不满足
 *
 * 该异常不代表系统错误
 */
public class BusinessException extends BaseException {

    /**
     * 推荐使用：只传 resultCode，message 自动取默认值
     */
    public BusinessException(StandardResultCode resultCode) {
        super(resultCode, resultCode.getDefaultMessage());
    }

    /**
     * 保留：允许覆盖 message（特殊场景用）
     */
    public BusinessException(StandardResultCode resultCode, String message) {
        super(resultCode, message);
    }
}