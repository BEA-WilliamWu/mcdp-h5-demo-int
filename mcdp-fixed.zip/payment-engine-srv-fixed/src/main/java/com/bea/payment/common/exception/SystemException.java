package com.bea.payment.common.exception;

import com.bea.payment.common.response.StandardResultCode;

/**
 * 系统异常
 *
 * 使用场景：
 * - 不可恢复的系统错误
 * - 下游异常无法识别
 */
public class SystemException extends BaseException {

    public SystemException(String message, Throwable cause) {
        super(StandardResultCode.SYSTEM_ERROR, message);
        initCause(cause);
    }
}