package com.bea.payment.common.exception;

import com.bea.payment.common.response.StandardResultCode;

/**
 * 参数 / 校验类异常
 *
 * 使用场景：
 * - Controller 参数校验失败
 * - Service 层业务前置校验失败
 *
 * 注意：
 * - 不绑定具体错误码
 * - 调用方自行选择合适的 StandardResultCode
 */
public class ValidationException extends BaseException {

    public ValidationException(StandardResultCode resultCode, String message) {
        super(resultCode, message);
    }

    /**
     * 常用构造方法：通用校验失败
     */
    public static ValidationException validationFailed(String message) {
        return new ValidationException(
                StandardResultCode.VALIDATION_FAILED,
                message
        );
    }
}