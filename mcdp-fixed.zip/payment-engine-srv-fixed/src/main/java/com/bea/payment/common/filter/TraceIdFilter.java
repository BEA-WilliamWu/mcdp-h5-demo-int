package com.bea.payment.common.filter;


import com.bea.payment.common.constants.HeaderConstants;
import com.bea.payment.common.context.RequestContext;
import com.bea.payment.common.context.RequestContextHolder;
import com.bea.payment.common.context.TraceContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * TraceId 过滤器
 *
 * 职责：
 * - 提取或生成 TraceId
 * - 初始化 RequestContext
 * - 写入 MDC
 * - 请求结束后清理上下文
 */
@Component
public class TraceIdFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain
    ) throws ServletException, IOException {

        String traceId = resolveTraceId(request);

        try {
            // 初始化上下文
            TraceContext traceContext = new TraceContext(traceId);
            RequestContext requestContext = new RequestContext(traceContext);

            RequestContextHolder.set(requestContext);
            MDC.put(HeaderConstants.TRACE_ID, traceId);

            // 回传给调用方
            response.setHeader(HeaderConstants.TRACE_ID, traceId);

            filterChain.doFilter(request, response);
        } finally {
            // 清理，防止线程复用污染
            RequestContextHolder.clear();
            MDC.remove(HeaderConstants.TRACE_ID);
        }
    }

    private String resolveTraceId(HttpServletRequest request) {
        String traceId = request.getHeader(HeaderConstants.TRACE_ID);
        return (traceId == null || traceId.isBlank())
                ? UUID.randomUUID().toString()
                : traceId;
    }
}