package com.bea.payment.common.logging;

import com.bea.payment.common.context.RequestContextHolder;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;

/**
 * API Access Log 切面
 *
 * 用于记录：
 * - API 调用耗时
 * - 慢接口识别
 */
@Aspect
@Component
public class ApiAccessLogAspect {

    private static final Logger log = LoggerFactory.getLogger("API_ACCESS_LOG");

    private final ApiLogConfig config;

    public ApiAccessLogAspect(ApiLogConfig config) { this.config = config; }

    @Around("@within(restController)")
    public Object logAccess(
            ProceedingJoinPoint joinPoint,
            RestController restController
    ) throws Throwable {

        if (!config.isEnabled()) {
            return joinPoint.proceed();
        }

        long startTime = System.currentTimeMillis();

        Object result;
        try {
            result = joinPoint.proceed();
            return result;
        } finally {
            long costMs = System.currentTimeMillis() - startTime;
            writeAccessLog(joinPoint, costMs);
        }
    }

    private void writeAccessLog(ProceedingJoinPoint joinPoint, long costMs) {
        HttpServletRequest request = currentRequest();
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();

        String requestId = currentRequestId();
        String httpMethod = request.getMethod();
        String uri = request.getRequestURI();
        String handler = method.getDeclaringClass().getSimpleName()
                + "#"
                + method.getName();

        // 慢接口统计，预留入口
        if (costMs >= config.getSlowThresholdMs()) {
            log.warn(
                    "API_SLOW requestId={}, method={}, uri={}, handler={}, costMs={}",
                    requestId,
                    httpMethod,
                    uri,
                    handler,
                    costMs
            );
        } else {
            log.info(
                    "API_ACCESS requestId={}, method={}, uri={}, handler={}, costMs={}",
                    requestId,
                    httpMethod,
                    uri,
                    handler,
                    costMs
            );
        }
    }

    private HttpServletRequest currentRequest() {
        ServletRequestAttributes attr =
                (ServletRequestAttributes)
                        org.springframework.web.context.request.RequestContextHolder.getRequestAttributes();
        return attr.getRequest();
    }

    private String currentRequestId() {
        if (RequestContextHolder.get() == null) {
            return null;
        }
        return RequestContextHolder.get()
                .getTraceContext()
                .getTraceId();
    }
}