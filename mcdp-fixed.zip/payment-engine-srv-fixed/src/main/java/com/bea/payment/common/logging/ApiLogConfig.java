package com.bea.payment.common.logging;


import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * API 日志配置
 *
 * 支持通过配置控制是否打印请求 / 响应
 */
@Configuration
@ConfigurationProperties(prefix = "pe.api.log")
@Getter
@Setter
public class ApiLogConfig {

    /**
     * 是否启用 API 日志
     */
    private boolean enabled = true;

    /**
     * 是否打印低敏 Header allowlist。
     */
    private boolean logHeaders = false;

    /**
     * 是否打印响应体
     */
    private boolean logResponse = true;

    /**
     * Access Log 慢接口阈值 (毫秒)
     */
    private long slowThresholdMs = 1000;

}
