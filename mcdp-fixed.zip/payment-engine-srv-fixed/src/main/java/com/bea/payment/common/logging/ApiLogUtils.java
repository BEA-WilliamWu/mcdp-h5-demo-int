package com.bea.payment.common.logging;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * API 日志辅助工具
 *
 * 职责：
 * - 使用 Spring Web 层一致的 ObjectMapper
 * - 对对象进行安全序列化
 * - 避免日志影响主流程
 */
@Component
public class ApiLogUtils {

    private static final Logger log = LoggerFactory.getLogger(ApiLogUtils.class);

    /**
     * 注意：
     * 这里必须使用 Spring 注入的 ObjectMapper，
     * 以保证：
     * - Java Time 类型可序列化
     * - 配置与 HttpMessageConverter 一致
     */
    private final ObjectMapper objectMapper;
    private final SensitiveDataMasker sensitiveDataMasker;

    public ApiLogUtils(ObjectMapper objectMapper, SensitiveDataMasker sensitiveDataMasker) {
        this.objectMapper = objectMapper;
        this.sensitiveDataMasker = sensitiveDataMasker;
    }

    public String toJsonSafely(Object object) {
        return toJsonSafely(object, false);
    }

    public String toMaskedJsonSafely(Object object) {
        return toJsonSafely(object, true);
    }

    public String maskText(String value) {
        return sensitiveDataMasker.maskText(value);
    }

    private String toJsonSafely(Object object, boolean maskSensitiveData) {
        if (object == null) {
            return "null";
        }
        try {
            Object value = maskSensitiveData ? sensitiveDataMasker.mask(object) : object;
            return objectMapper.writeValueAsString(value);
        } catch (Exception ex) {
            log.warn(
                    "Failed to serialize object for api log, type={}",
                    object.getClass().getName()
            );
            return "\"<serialization_failed>\"";
        }
    }
}
