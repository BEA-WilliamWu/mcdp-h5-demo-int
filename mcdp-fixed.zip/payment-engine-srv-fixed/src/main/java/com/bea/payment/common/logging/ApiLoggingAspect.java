package com.bea.payment.common.logging;

import com.bea.payment.common.context.RequestContextHolder;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * API 请求 / 响应日志切面
 *
 * 拦截所有 @RestController 方法
 *
 * 职责：
 * - 打印请求参数
 * - 打印响应参数
 * - 关联 RequestId
 * - 记录接口耗时
 */
@Aspect
@Component
public class ApiLoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(ApiLoggingAspect.class);
    private static final Set<String> HEADER_ALLOWLIST = Set.of(
            "x-requestid",
            "x-request-id",
            "content-type",
            "user-agent");

    private final ApiLogConfig config;

    private final ApiLogUtils apiLogUtils;

    // 构造器注入
    public ApiLoggingAspect(ApiLogConfig config, ApiLogUtils apiLogUtils) {
        this.config = config;
        this.apiLogUtils = apiLogUtils;
    }

    @Around("@within(restController)")
    public Object logApi(
            ProceedingJoinPoint joinPoint,
            RestController restController
    ) throws Throwable {

        if (!config.isEnabled()) {
            return joinPoint.proceed();
        }

        // 开始计时
        long startTime = System.currentTimeMillis();

        HttpServletRequest request = currentRequest();
        String requestId = currentRequestId();

        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();

        Map<String, Object> logMap = new HashMap<>();
        logMap.put("requestId", requestId);
        logMap.put("method", request.getMethod());
        logMap.put("uri", request.getRequestURI());
        logMap.put("controllerMethod", method.getDeclaringClass().getSimpleName() + "#" + method.getName());
        logMap.put("queryParams", request.getParameterMap());
        logMap.put("body", joinPoint.getArgs());

        if (config.isLogHeaders()) {
            logMap.put("headers", extractHeaders(request));
        }

        log.info("API_REQUEST {}", apiLogUtils.toMaskedJsonSafely(logMap));

        Object result = null;
        try {
            result = joinPoint.proceed();
            return result;
        } catch (Exception ex) {
            log.error(
                    "API_EXCEPTION requestId={}, error={}",
                    requestId,
                    ex.getMessage(),
                    ex
            );
            throw ex;
        } finally {
            // 计算耗时
            long costMs = System.currentTimeMillis() - startTime;

            if (config.isLogResponse()) {
                log.info(
                        "API_RESPONSE requestId={}, costMs={}, body={}",
                        requestId,
                        costMs,
                        apiLogUtils.toMaskedJsonSafely(result)
                );
            }
        }
    }

    private HttpServletRequest currentRequest() {
        ServletRequestAttributes attr =
                (ServletRequestAttributes)
                        org.springframework.web.context.request.RequestContextHolder.getRequestAttributes();
        return attr.getRequest();
    }

    private String currentRequestId() {
        if (RequestContextHolder.get() == null) {
            return null;
        }
        return RequestContextHolder.get()
                .getTraceContext()
                .getTraceId();
    }

    private Map<String, String> extractHeaders(HttpServletRequest request) {
        Map<String, String> headers = new HashMap<>();
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            if (HEADER_ALLOWLIST.contains(name.toLowerCase())) {
                headers.put(name, apiLogUtils.maskText(request.getHeader(name)));
            }
        }
        return headers;
    }
}
