package com.bea.payment.common.logging;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Masks sensitive values before they are written to logs or audit rows.
 */
@Component
public class SensitiveDataMasker {

    private static final String MASKED = "***MASKED***";
    private static final Set<String> SENSITIVE_FIELD_TOKENS = Set.of(
            "account", "accountno", "internalaccount", "payeraccount", "payeeaccount",
            "mobile", "phone", "email", "idcard", "identity", "passport",
            "secret", "token", "authorization", "password", "credential", "certificate",
            "clientsecret", "clientid", "proxyid", "address", "name");
    private static final Pattern LONG_DIGITS = Pattern.compile("\\b\\d{7,}\\b");
    private static final Pattern EMAIL = Pattern.compile(
            "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b");

    private final ObjectMapper objectMapper;

    public SensitiveDataMasker(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public Object mask(Object value) {
        if (value == null) {
            return null;
        }
        JsonNode node = objectMapper.convertValue(value, JsonNode.class);
        return maskNode(null, node);
    }

    public String maskText(String value) {
        if (value == null || value.isBlank()) {
            return value;
        }
        String masked = EMAIL.matcher(value).replaceAll(MASKED);
        return LONG_DIGITS.matcher(masked).replaceAll(match -> maskLongDigits(match.group()));
    }

    private JsonNode maskNode(String fieldName, JsonNode node) {
        if (node == null || node.isNull()) {
            return node;
        }
        if (isSensitiveField(fieldName)) {
            return TextNode.valueOf(MASKED);
        }
        if (node.isObject()) {
            ObjectNode objectNode = (ObjectNode) node;
            Iterator<Map.Entry<String, JsonNode>> fields = objectNode.properties().iterator();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> field = fields.next();
                objectNode.set(field.getKey(), maskNode(field.getKey(), field.getValue()));
            }
            return objectNode;
        }
        if (node.isArray()) {
            ArrayNode arrayNode = (ArrayNode) node;
            ArrayNode maskedArray = objectMapper.createArrayNode();
            for (int i = 0; i < arrayNode.size(); i++) {
                maskedArray.add(maskNode(fieldName, arrayNode.get(i)));
            }
            return maskedArray;
        }
        if (node.isTextual()) {
            return TextNode.valueOf(maskText(node.asText()));
        }
        return node;
    }

    private boolean isSensitiveField(String fieldName) {
        if (fieldName == null || fieldName.isBlank()) {
            return false;
        }
        String normalized = fieldName.toLowerCase(Locale.ROOT)
                .replace("_", "")
                .replace("-", "");
        for (String token : SENSITIVE_FIELD_TOKENS) {
            if (normalized.contains(token)) {
                return true;
            }
        }
        return false;
    }

    private String maskLongDigits(String value) {
        if (value.length() <= 6) {
            return MASKED;
        }
        return value.substring(0, 2) + "****" + value.substring(value.length() - 4);
    }
}
