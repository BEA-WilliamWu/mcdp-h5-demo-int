package com.bea.payment.common.mybatis;


import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 审计字段自动填充处理器
 */
@Component
public class AuditMetaObjectHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {

        Date now = new Date();
        String user = getCurrentUser();

        this.strictInsertFill(metaObject, "createdBy", String.class, user);
        this.strictInsertFill(metaObject, "creationDate", Date.class, now);

        this.strictInsertFill(metaObject, "lastUpdatedBy", String.class, user);
        this.strictInsertFill(metaObject, "lastUpdateDate", Date.class, now);

        this.strictInsertFill(metaObject, "isDeleted", String.class, "N");
        this.strictInsertFill(metaObject, "objectVersionNumber", Long.class, 1L);
    }

    @Override
    public void updateFill(MetaObject metaObject) {

        Date now = new Date();

        this.strictUpdateFill(metaObject, "lastUpdatedBy", String.class, getCurrentUser());
        this.strictUpdateFill(metaObject, "lastUpdateDate", Date.class, now);
    }

    private String getCurrentUser() {
        // 后续可以接入登录上下文
        return "SYSTEM";
    }
}
