package com.bea.payment.common.response;

import lombok.Getter;

import com.bea.payment.common.context.RequestContextHolder;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;

/**
 * API 统一响应结构
 *
 * 设计原则：
 * - HTTP Status 恒定为 200
 * - 业务语义全部通过 code + message 表达
 * - traceId 用于日志关联
 */
@Schema(name = "ApiResponse", description = "Standard API response envelope; inspect code even when HTTP status is 200")
@Getter
public class ApiResponse<T> {

    @Schema(description = "Business result code; 00 indicates acceptance", example = "00")
    private String code;

    @Schema(description = "Result message", example = "Success")
    private String message;

    @Schema(description = "Business response payload; null on failure")
    private T data;

    @Schema(description = "Request correlation identifier matching response header X-RequestId", example = "31dfd480-3fb3-4eb3-bd26-9a7c92761645")
    private String traceId;

    @Schema(description = "Response timestamp", example = "2026-05-27T10:30:25.118+08:00", format = "date-time")
    private OffsetDateTime timestamp;

    public static <T> ApiResponse<T> success(T data) {
        ApiResponse<T> response = new ApiResponse<>();
        response.code = StandardResultCode.SUCCESS.getCode();
        response.message = StandardResultCode.SUCCESS.getDefaultMessage();
        response.data = data;
        response.timestamp = OffsetDateTime.now();
        response.traceId = currentTraceId();
        return response;
    }

    public static <T> ApiResponse<T> normalResponse(String code,T data) {
        ApiResponse<T> response = new ApiResponse<>();
        response.data = data;
        response.code = code;
        response.timestamp = OffsetDateTime.now();
        response.traceId = currentTraceId();
        return response;
    }

    public static ApiResponse<Void> success() {
        ApiResponse<Void> response = new ApiResponse<>();
        response.code = StandardResultCode.SUCCESS.getCode();
        response.message = StandardResultCode.SUCCESS.getDefaultMessage();
        response.data = null;
        response.timestamp = OffsetDateTime.now();
        response.traceId = currentTraceId();
        return response;
    }

    public static ApiResponse<Void> failure(StandardResultCode resultCode, String message) {
        ApiResponse<Void> response = new ApiResponse<>();
        response.code = resultCode.getCode();
        response.message = message != null
                ? message
                : resultCode.getDefaultMessage();
        response.timestamp = OffsetDateTime.now();
        response.traceId = currentTraceId();
        return response;
    }

    /**
     * 在构建响应时自动补 TraceId
     */
    private static String currentTraceId() {
        if (RequestContextHolder.get() == null) {
            return null;
        }
        return RequestContextHolder.get()
                .getTraceContext()
                .getTraceId();
    }

}
