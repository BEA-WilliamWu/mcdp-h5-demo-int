package com.bea.payment.common.response;


import lombok.Getter;
/**
 * 标准响应码定义
 *
 * 设计原则：
 * - 所有对外返回 code 必须来自本枚举
 * - 异常与响应均引用该枚举
 *
 * 编码规则：
 * - 00        : 成功
 * - 400xxx   : 参数 / 校验类错误
 * - 420xxx   : 业务拒绝 (非系统异常)
 * - 500xxx   : 系统异常
 */
@Getter
public enum StandardResultCode {

    // ===== 成功 =====
    SUCCESS("00", "Success"),

    // ===== 参数 / 校验类错误 (400xxx) =====
    INVALID_REQUEST("400001", "Invalid request"),
    VALIDATION_FAILED("400002", "Validation failed"),

    // 细化的校验失败 (用于 Validator)
    INVALID_CHANNEL("400003", "Invalid channel"),
    INVALID_ID_FORMAT("400004", "Invalid id format"),
    INVALID_AMOUNT("400005", "Invalid amount"),
    INVALID_PAYEE("400006", "Invalid payee information"),
    INVALID_PAYER("400007", "Invalid payer information"),
    INVALID_CURRENCY("400008", "Invalid currency"),
    INVALID_TRANSACTION_TYPE("400009", "Invalid transaction type"),
    INVALID_TIME_OF_TRANSFER("400010", "Invalid time of transfer"),
    INVALID_EXECUTION_DATE("400011", "Invalid execution date"),
    INVALID_ACCOUNT_TYPE("400012", "Invalid account type"),
    INVALID_PAYER_TYPE("400013", "Invalid payer type"),
    INVALID_PAYEE_TYPE("400014", "Invalid payee type"),

    // ===== 业务拒绝 (420xxx) =====
    FLOW_CONTROL_REJECTED("420001", "Flow control rejected"),
    BUSINESS_REJECTED("420002", "Business rule rejected"),

    // 幂等冲突
    DUPLICATE_REQUEST("420003", "Duplicate request"),

    // 批次一致性
    BATCH_TOTAL_MISMATCH("420004", "Batch total mismatch"),

    // ===== 系统异常 (500xxx) =====
    SYSTEM_ERROR("500000", "System error");

    private final String code;
    private final String defaultMessage;

    StandardResultCode(String code, String defaultMessage) {
        this.code = code;
        this.defaultMessage = defaultMessage;
    }

}