package com.bea.payment.common.util;


import lombok.extern.slf4j.Slf4j;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.EnumSet;
import java.util.Set;

/**
 * DateTimeUtils
 *
 * 日期 / 时间相关的工具方法集合。
 *
 * 设计原则：
 * - 只做确定性转换
 * - 明确非法输入
 * - 不返回 null (除非明确说明)
 * - 不依赖业务模型
 */
@Slf4j
public final class DateTimeUtils {

    private DateTimeUtils() {
        // utility class
    }

    /**
     * 将数据库中存储的星期值转换为 DayOfWeek。
     *
     * 支持的输入值 (大写)：
     * MON, TUE, WED, THU, FRI, SAT, SUN
     * MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
     *
     * @param value 星期值
     * @return 对应的 DayOfWeek
     * @throws IllegalArgumentException 当输入非法时
     */
    public static DayOfWeek parseDayOfWeek(String value) {

        if (value == null) {
            throw new IllegalArgumentException("DayOfWeek value must not be null");
        }

        String v = value.trim().toUpperCase(java.util.Locale.ROOT);
        if (v.isEmpty()) {
            throw new IllegalArgumentException("DayOfWeek value must not be empty");
        }

        switch (v) {
            case "MON":
            case "MONDAY":
                return DayOfWeek.MONDAY;
            case "TUE":
            case "TUESDAY":
                return DayOfWeek.TUESDAY;
            case "WED":
            case "WEDNESDAY":
                return DayOfWeek.WEDNESDAY;
            case "THU":
            case "THURSDAY":
                return DayOfWeek.THURSDAY;
            case "FRI":
            case "FRIDAY":
                return DayOfWeek.FRIDAY;
            case "SAT":
            case "SATURDAY":
                return DayOfWeek.SATURDAY;
            case "SUN":
            case "SUNDAY":
                return DayOfWeek.SUNDAY;
            default:
                throw new IllegalArgumentException(
                        "Unsupported DayOfWeek value: " + value
                );
        }
    }

    /**
     * 将数据库中存储的 APPLICABLE_DAYS 字符串解析为 DayOfWeek 集合。
     *
     * 示例：
     * MON,TUE,WED,THU,FRI
     *
     * @param days APPLICABLE_DAYS 字段值
     * @return DayOfWeek 集合
     * @throws IllegalArgumentException 当输入非法时
     */
    public static Set<DayOfWeek> parseApplicableDays(String days) {

        if (days == null) {
            throw new IllegalArgumentException("Applicable days must not be null");
        }

        String value = days.trim();
        if (value.isEmpty()) {
            throw new IllegalArgumentException("Applicable days must not be empty");
        }

        String[] parts = value.split(",");
        Set<DayOfWeek> result = EnumSet.noneOf(DayOfWeek.class);

        for (String part : parts) {
            result.add(parseDayOfWeek(part));
        }

        if (result.isEmpty()) {
            throw new IllegalArgumentException(
                    "No valid DayOfWeek parsed from value: " + days
            );
        }

        return result;
    }

    public static Integer toIntegerDate(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) {
            log.warn("dateStr is null or blank");
            return null;
        }

        try {
            LocalDate date = LocalDate.parse(dateStr,
                    DateTimeFormatter.ofPattern("uuuu-MM-dd")
                            .withResolverStyle(ResolverStyle.STRICT)
            );
            return Integer.valueOf(date.format(DateTimeFormatter.BASIC_ISO_DATE));
        } catch (DateTimeParseException e) {
            log.warn("Invalid date format, dateStr={}", dateStr);
            return null;
        }
    }

}
