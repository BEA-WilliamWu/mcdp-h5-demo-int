package com.bea.payment.common.util;

import com.bea.payment.bulk.constants.PayeeTypeEnum;
import com.bea.payment.bulk.model.dto.SingleCreditTransferRequest;
import com.bea.payment.bulk.model.dto.TransactionDetailRequest;
import com.bea.payment.common.exception.ValidationException;
import com.bea.payment.common.response.StandardResultCode;

public class FieldValidateUtils {

    public static void requireAndMax(String value, String fieldName, int max) {
        requireNonBlank(value, fieldName, StandardResultCode.VALIDATION_FAILED);
        assertMaxLength(value, max, fieldName);
    }

    public static void assertMaxLength(String value, int max, String fieldName) {
        if (value != null && value.length() > max) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldName + " max length is " + max);
        }
    }

    public static void requireNonBlank(String value, String fieldName, StandardResultCode code) {
        if (value == null || value.isBlank()) {
//            throw new ValidationException(code, fieldName + " is required");
        }
    }


    public static void validateOptionalEphI006Fields(TransactionDetailRequest req, String fieldPrefix) {
        optionalMax(req.getInstructionId(), fieldPrefix + ".instructionId", 64);
//        validateCustomerIdGroup(req.getPayerCustomerId(), req.getPayerCustomerIdType(),
//                req.getPayerCustomerIdCategory(), fieldPrefix + ".payerCustomerId",
//                fieldPrefix + ".payerCustomerIdType", fieldPrefix + ".payerCustomerIdCategory");
//        validateCustomerIdGroup(req.getPayeeCustomerId(), req.getPayeeCustomerIdType(),
//                req.getPayeeCustomerIdCategory(), fieldPrefix + ".payeeCustomerId",
//                fieldPrefix + ".payeeCustomerIdType", fieldPrefix + ".payeeCustomerIdCategory");
        validatePurpose(req, fieldPrefix);
        optionalMax(req.getClearingSystem(), fieldPrefix + ".clearingSystem", 16);
        optionalMax(req.getOfficeId(), fieldPrefix + ".officeId", 3);
        optionalMax(req.getInvoiceNumber(), fieldPrefix + ".invoiceNumber", 35);
        optionalMax(req.getVipIndicator(), fieldPrefix + ".vipIndicator", 1);
        optionalMax(req.getCreditInternalAccount(), fieldPrefix + ".creditInternalAccount", 35);
        optionalMax(req.getDebitInternalAccount(), fieldPrefix + ".debitInternalAccount", 35);
        optionalMax(req.getProductType(), fieldPrefix + ".productType", 4);
    }
    public static void validateOptionalEphI006Fields(SingleCreditTransferRequest req, String fieldPrefix) {
        optionalMax(req.getInstructionId(), fieldPrefix + ".instructionId", 64);
//        validateCustomerIdGroup(req.getPayerCustomerId(), req.getPayerCustomerIdType(),
//                req.getPayerCustomerIdCategory(), fieldPrefix + ".payerCustomerId",
//                fieldPrefix + ".payerCustomerIdType", fieldPrefix + ".payerCustomerIdCategory");
//        validateCustomerIdGroup(req.getPayeeCustomerId(), req.getPayeeCustomerIdType(),
//                req.getPayeeCustomerIdCategory(), fieldPrefix + ".payeeCustomerId",
//                fieldPrefix + ".payeeCustomerIdType", fieldPrefix + ".payeeCustomerIdCategory");
        validatePurpose(req, fieldPrefix);
        optionalMax(req.getClearingSystem(), fieldPrefix + ".clearingSystem", 16);
        optionalMax(req.getOfficeId(), fieldPrefix + ".officeId", 3);
        optionalMax(req.getInvoiceNumber(), fieldPrefix + ".invoiceNumber", 35);
        optionalMax(req.getVipIndicator(), fieldPrefix + ".vipIndicator", 1);
        optionalMax(req.getCreditInternalAccount(), fieldPrefix + ".creditInternalAccount", 35);
        optionalMax(req.getDebitInternalAccount(), fieldPrefix + ".debitInternalAccount", 35);
        optionalMax(req.getProductType(), fieldPrefix + ".productType", 4);
    }

    public static void optionalMax(String value, String fieldName, int max) {
        if (hasText(value)) {
            assertMaxLength(value, max, fieldName);
        }
    }

    public static void validatePurpose(TransactionDetailRequest req, String fieldPrefix) {
        boolean hasCode = hasText(req.getPurposeCode());
        boolean hasProprietary = hasText(req.getPurposeProprietary());
        if (hasCode && hasProprietary) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldPrefix + ".purposeCode and " + fieldPrefix + ".purposeProprietary are mutually exclusive");
        }
        optionalMax(req.getPurposeCode(), fieldPrefix + ".purposeCode", 8);
        optionalMax(req.getPurposeProprietary(), fieldPrefix + ".purposeProprietary", 35);
    }

    public static void validatePurpose(SingleCreditTransferRequest req, String fieldPrefix) {
        boolean hasCode = hasText(req.getPurposeCode());
        boolean hasProprietary = hasText(req.getPurposeProprietary());
        if (hasCode && hasProprietary) {
            throw new ValidationException(StandardResultCode.VALIDATION_FAILED,
                    fieldPrefix + ".purposeCode and " + fieldPrefix + ".purposeProprietary are mutually exclusive");
        }
        optionalMax(req.getPurposeCode(), fieldPrefix + ".purposeCode", 8);
        optionalMax(req.getPurposeProprietary(), fieldPrefix + ".purposeProprietary", 35);
    }

    public static PayeeTypeEnum parsePayeeTypeOrDefaultAccount(String value) {
        if (value == null || value.isBlank()) {
            return PayeeTypeEnum.ACCOUNT;
        }
        return PayeeTypeEnum.from(value);
    }

    public static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

}
