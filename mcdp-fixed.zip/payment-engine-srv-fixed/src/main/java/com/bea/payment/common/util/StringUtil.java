package com.bea.payment.common.util;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StringUtil {

    public static String getPart(String source, int index) {
        if (source == null || source.isEmpty()) {
            return "";
        }

        if (index < 1 || index > 4) {
            throw new IllegalArgumentException("INDEX MUST BE BETWEEN 1 AND 4");
        }

        int start = (index - 1) * 35;

        // 该分段不存在
        if (start >= source.length()) {
            return "";
        }

        int end = Math.min(start + 35, source.length());

        return source.substring(start, end);
    }

    public static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

}
