package com.bea.payment.common.util;

import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.UUID;

public final class UuidV7Utils {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final long TIMESTAMP_MASK = 0x0000_FFFF_FFFF_FFFFL;
    private static final long VERSION_7 = 0x0000_0000_0000_7000L;
    private static final long VARIANT_10 = 0x8000_0000_0000_0000L;
    private static final long RAND_B_MASK = 0x3FFF_FFFF_FFFF_FFFFL;

    private UuidV7Utils() {
    }

    public static UUID generate() {
        long unixMillis = System.currentTimeMillis() & TIMESTAMP_MASK;
        long randA = RANDOM.nextInt(1 << 12);
        long randB = RANDOM.nextLong() & RAND_B_MASK;
        long mostSignificantBits = (unixMillis << 16) | VERSION_7 | randA;
        long leastSignificantBits = VARIANT_10 | randB;
        return new UUID(mostSignificantBits, leastSignificantBits);
    }

    public static byte[] generateBytes() {
        return toBytes(generate());
    }

    public static byte[] toBytes(UUID uuid) {
        ByteBuffer buffer = ByteBuffer.allocate(16);
        buffer.putLong(uuid.getMostSignificantBits());
        buffer.putLong(uuid.getLeastSignificantBits());
        return buffer.array();
    }

    public static UUID fromBytes(byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        if (bytes.length != 16) {
            throw new IllegalArgumentException("UUID binary value must contain exactly 16 bytes");
        }
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        return new UUID(buffer.getLong(), buffer.getLong());
    }

    public static String toString(byte[] bytes) {
        UUID uuid = fromBytes(bytes);
        return uuid == null ? null : uuid.toString();
    }
}
