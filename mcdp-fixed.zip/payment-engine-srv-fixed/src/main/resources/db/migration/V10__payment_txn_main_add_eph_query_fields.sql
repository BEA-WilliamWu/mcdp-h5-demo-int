-- V10: EPH status query compensation fields
-- Purpose: Support scheduled query of EPH transaction status after I006 timeout/non-terminal response.
-- maxQueryAttempts defaults to 1 as a conservative engineering safeguard, configurable via
-- bulk.eph.query.max-query-attempts. This default does NOT represent a confirmed EPH contract; see OQ-EPH-009.

ALTER TABLE IPE_PAYMENT_TXN_MAIN ADD (
    EPH_NEEDS_STATUS_QUERY      VARCHAR2(1)  DEFAULT 'N',
    EPH_QUERY_ELIGIBLE_TIME     DATE,
    EPH_QUERY_COUNT             NUMBER(10,0) DEFAULT 0,
    EPH_LAST_QUERY_TIME         DATE,
    EPH_QUERY_RESPONSE_STATUS   VARCHAR2(16),
    EPH_QUERY_RESPONSE_MESSAGE  VARCHAR2(300),
    EPH_QUERY_ERROR_CODE        VARCHAR2(64)
);

COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_NEEDS_STATUS_QUERY IS '是否需要补偿查询EPH交易最终状态: Y/N';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_QUERY_ELIGIBLE_TIME IS '首次可查询时间, timeout/非终态发生时间 + 1小时';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_QUERY_COUNT IS '已查询次数, 上限由bulk.eph.query.max-query-attempts控制, 默认1为保守策略, 非EPH已确认契约';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_LAST_QUERY_TIME IS '最近一次查询时间';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_QUERY_RESPONSE_STATUS IS 'EPH查询接口返回的交易状态, 如 ACSC/RJCT/ACSP/ACCP/PDNG';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_QUERY_RESPONSE_MESSAGE IS 'EPH查询接口返回的附加信息或错误描述';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.EPH_QUERY_ERROR_CODE IS '查询接口调用本身的错误码, 非EPH业务错误';

-- Composite index for scheduler candidate scan: needs_query='Y' + eligible_time reached + count < maxQueryAttempts
CREATE INDEX IDX_EPH_STATUS_QUERY ON IPE_PAYMENT_TXN_MAIN(EPH_NEEDS_STATUS_QUERY, EPH_QUERY_ELIGIBLE_TIME, EPH_QUERY_COUNT);
