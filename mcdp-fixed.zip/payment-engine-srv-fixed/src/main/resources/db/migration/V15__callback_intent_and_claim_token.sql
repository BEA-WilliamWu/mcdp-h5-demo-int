-- V15: move callback work creation behind terminal MAIN status and protect task claims.

ALTER TABLE IPE_PAYMENT_TXN_MAIN ADD (
    CALLBACK_REQUIRED      CHAR(1) DEFAULT 'N' NOT NULL,
    CALLBACK_URL           VARCHAR2(512),
    CALLBACK_TASK_CREATED  CHAR(1) DEFAULT 'N' NOT NULL,
    CALLBACK_TASK_ID       NUMBER(19,0),
    CALLBACK_INTENT_TIME   DATE
);

ALTER TABLE IPE_PAYMENT_CALLBACK_TASK ADD (
    CLAIM_TOKEN            VARCHAR2(64)
);

CREATE INDEX IDX_IPE_TXN_MAIN_CALLBACK_SCAN
ON IPE_PAYMENT_TXN_MAIN (
    CALLBACK_REQUIRED,
    CALLBACK_TASK_CREATED,
    RESULT_STATUS,
    MANUAL_REVIEW_FLAG,
    PAYMENT_STATUS,
    IS_DELETED
);

COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.CALLBACK_REQUIRED IS 'Whether this transaction needs callback after terminal MAIN status: Y/N';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.CALLBACK_URL IS 'Callback URL captured from H2H online request after synchronous wait times out';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.CALLBACK_TASK_CREATED IS 'Callback task creation state: N=not created, P=creating, Y=created';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.CALLBACK_TASK_ID IS 'Created callback task id for traceability';
COMMENT ON COLUMN IPE_PAYMENT_TXN_MAIN.CALLBACK_INTENT_TIME IS 'Time when callback intent was recorded';
COMMENT ON COLUMN IPE_PAYMENT_CALLBACK_TASK.CLAIM_TOKEN IS 'Worker claim token used to prevent stale callback execution from overwriting newer results';
COMMENT ON COLUMN IPE_PAYMENT_CALLBACK_ATTEMPT.ATTEMPT_STATUS IS 'Callback HTTP attempt status: SUCCESS/FAILED';
