-- V17: Add database guard for duplicate callback attempts.
-- Purpose: one callback task can have only one evidence row for each attempt number.

ALTER TABLE IPE_PAYMENT_CALLBACK_ATTEMPT
    ADD CONSTRAINT UK_IPE_CB_ATT_TASK_NO UNIQUE (CALLBACK_TASK_ID, ATTEMPT_NO);
