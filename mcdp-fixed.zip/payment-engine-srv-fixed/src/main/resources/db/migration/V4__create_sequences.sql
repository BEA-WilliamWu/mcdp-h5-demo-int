-- Batch ID Sequence
-- 用于 single-credit-transfer 接口生成 23 位 batchId
-- 格式: CHANNEL(3) + yyyyMMddHHmmss(14) + 序列号(6)

CREATE SEQUENCE SEQ_IPE_BATCH_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;
