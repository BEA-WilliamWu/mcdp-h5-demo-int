//package com.bea.payment.bulk.flow;
//
//import com.baomidou.mybatisplus.core.conditions.Wrapper;
//import com.bea.payment.bulk.constants.BatchStatusEnum;
//import com.bea.payment.bulk.constants.PaymentStatusEnum;
//import com.bea.payment.bulk.constants.TransactionTypeEnum;
//import com.bea.payment.bulk.internal.eph.config.EphProperties;
//import com.bea.payment.bulk.internal.flow.mq.MqProducerService;
//import com.bea.payment.bulk.internal.flow.mq.MqProperties;
//import com.bea.payment.bulk.internal.flow.mq.MqRoutingService;
//import com.bea.payment.bulk.mapper.PaymentBatchHdrMapper;
//import com.bea.payment.bulk.mapper.PaymentTxnMainMapper;
//import com.bea.payment.bulk.model.dto.PaymentResultQueryRequest;
//import com.bea.payment.bulk.model.dto.PaymentResultQueryResponse;
//import com.bea.payment.bulk.model.dto.SingleCreditTransferRequest;
//import com.bea.payment.bulk.model.dto.SubmitResponse;
//import com.bea.payment.bulk.model.entity.PaymentBatchHdrEntity;
//import com.bea.payment.bulk.model.entity.PaymentTxnMainEntity;
//import com.bea.payment.bulk.service.BatchIdGenerator;
//import com.bea.payment.bulk.service.PaymentBatchStatusService;
//import com.bea.payment.bulk.service.PaymentResultQueryService;
//import com.bea.payment.bulk.service.PaymentSubmitService;
//import com.bea.payment.bulk.service.PaymentTxnEventService;
//import com.bea.payment.bulk.service.UpstreamApiAuditService;
//import com.bea.payment.bulk.validator.BatchCreditTransferValidator;
//import com.bea.payment.bulk.validator.SingleCreditTransferValidator;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.ArgumentCaptor;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.jms.core.JmsTemplate;
//
//import java.math.BigDecimal;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//class MainBusinessFlowTest {
//
//    private static final String BATCH_ID = "BCO20260616090000000001";
//    private static final String TXN_ID = "BCO20260616090000000002";
//
//    @Mock
//    private SingleCreditTransferValidator singleValidator;
//    @Mock
//    private BatchCreditTransferValidator batchValidator;
//    @Mock
//    private BatchIdGenerator batchIdGenerator;
//    @Mock
//    private PaymentBatchHdrMapper batchHdrMapper;
//    @Mock
//    private PaymentTxnMainMapper txnMainMapper;
//    @Mock
//    private UpstreamApiAuditService auditService;
//    @Mock
//    private MqRoutingService routingService;
//    @Mock
//    private MqProducerService producer;
//    @Mock
//    private JmsTemplate jmsTemplate;
//    @Mock
//    private ObjectMapper objectMapper;
//    @Mock
//    private MqProperties mqProperties;
//
////    @Test
////    void submitSinglePersistsBatchAndTransactionForLaterScannerFlow() {
////        when(batchIdGenerator.generate("BCO")).thenReturn(BATCH_ID);
////        when(txnMainMapper.selectCount(any(Wrapper.class))).thenReturn(0L);
////
////        PaymentSubmitService service = new PaymentSubmitService(
////                singleValidator,
////                batchValidator,
////                batchIdGenerator,
////                batchHdrMapper,
////                txnMainMapper,
////                auditService,
////                ephProperties(),
////                producer,
////                jmsTemplate,
////                objectMapper,
////                routingService,
////                mqProperties);
////
////        SingleCreditTransferRequest request = singleRequest();
////
////        SubmitResponse response = service.submitSingle(request);
////
////        assertNotNull(response.getAcceptedAt());
////        assertEquals(1, response.getTransactions().size());
////        assertEquals(TXN_ID, response.getTransactions().get(0).getTransactionId());
////        assertEquals(PaymentStatusEnum.PENDING.getCode(), response.getTransactions().get(0).getStatus());
////        assertNotNull(response.getTransactions().get(0).getIpeReferenceId());
////
////        ArgumentCaptor<PaymentBatchHdrEntity> batchCaptor =
////                ArgumentCaptor.forClass(PaymentBatchHdrEntity.class);
////        ArgumentCaptor<PaymentTxnMainEntity> txnCaptor =
////                ArgumentCaptor.forClass(PaymentTxnMainEntity.class);
////        verify(batchHdrMapper).insert(batchCaptor.capture());
////        verify(txnMainMapper).insert(txnCaptor.capture());
////
////        PaymentBatchHdrEntity batch = batchCaptor.getValue();
////        assertEquals(BATCH_ID, batch.getBatchId());
////        assertEquals(BatchStatusEnum.PENDING.getCode(), batch.getBatchStatus());
////        assertEquals(0, batch.getMqSendPointer());
////
////        PaymentTxnMainEntity txn = txnCaptor.getValue();
////        assertEquals(TXN_ID, txn.getTransactionId());
////        assertEquals(BATCH_ID, txn.getBatchId());
////        assertEquals(1, txn.getOrderId());
////        assertEquals(PaymentStatusEnum.PENDING.getCode(), txn.getPaymentStatus());
////        assertEquals(new BigDecimal("88.88"), txn.getHkdEquivalentAmount());
////        assertNull(txn.getUetr());
////    }
//
////    @Test
////    void submitSingleFpsPersistsApiPaymentSourceAndFixedEphFieldsFromIpeConfiguration() {
////        when(batchIdGenerator.generate("BCO")).thenReturn(BATCH_ID);
////        when(txnMainMapper.selectCount(any(Wrapper.class))).thenReturn(0L);
////
////        PaymentSubmitService service = new PaymentSubmitService(
////                singleValidator,
////                batchValidator,
////                batchIdGenerator,
////                batchHdrMapper,
////                txnMainMapper,
////                auditService,
////                ephProperties(),
////                producer,
////                jmsTemplate,
////                objectMapper,
////                routingService,
////                mqProperties);
////
////        SingleCreditTransferRequest request = singleRequest();
////        request.setTransactionType(TransactionTypeEnum.FPS.getCode());
////        request.setPayerInternalAccountNo("000123456789");
////        request.setChargeCurrency("HKD");
////        request.setMemberId("004");
////        request.setFps(fpsWithApiPaymentSource());
////
////        service.submitSingle(request);
////
////        ArgumentCaptor<PaymentTxnMainEntity> txnCaptor =
////                ArgumentCaptor.forClass(PaymentTxnMainEntity.class);
////        verify(txnMainMapper).insert(txnCaptor.capture());
////
////        PaymentTxnMainEntity txn = txnCaptor.getValue();
////        assertEquals("CCB", txn.getEphPaymentSource());
////        assertEquals("TOB", txn.getEphTxType());
////        assertEquals("PERFORM_PYE_VRF", txn.getEphAccountVerificationOption());
////        assertEquals("CLRG", txn.getSettlementMethod());
////        assertEquals("FPS", txn.getClearingSystem());
////        assertEquals("015", txn.getEphDebtorMemberId());
////        assertEquals("SLEV", txn.getChargeBearer());
////        assertEquals("BOOK", txn.getEphDebitMop());
////        assertEquals("CORP", txn.getCustomerType());
////        assertEquals("004", txn.getPayeeMemberId());
////    }
//
//    @Test
//    void queryApiReadsTransactionAndBatchAsProcessingBusinessResult() {
//        PaymentTxnMainMapper queryTxnMapper = mock(PaymentTxnMainMapper.class);
//        PaymentBatchStatusService batchStatusService = mock(PaymentBatchStatusService.class);
//        PaymentTxnEventService eventService = mock(PaymentTxnEventService.class);
//        PaymentTxnMainEntity txn = txn(BATCH_ID, TXN_ID, 1, PaymentStatusEnum.PROCESSING.getCode());
//
//        when(queryTxnMapper.selectOne(any(Wrapper.class))).thenReturn(txn);
//        when(batchStatusService.summarize(BATCH_ID))
//                .thenReturn(new PaymentBatchStatusService.BatchStatusSummary(
//                        BatchStatusEnum.DISPATCHED.getCode(), false, 1L, 1L, 0L));
//        when(eventService.latestEventSummary(TXN_ID))
//                .thenReturn(Optional.of(new PaymentTxnEventService.EventSummary(
//                        "BG3-SEQ1", null, "BG3_REJECTED", "Rejected by BG3",
//                        "BG3_TRANSFER", "FAILED")));
//
//        PaymentResultQueryRequest request = new PaymentResultQueryRequest();
//        request.setTransactionId(TXN_ID);
//
//        List<PaymentResultQueryResponse> responses =
//                new PaymentResultQueryService(queryTxnMapper, batchStatusService, eventService).query(request);
//
//        assertEquals(1, responses.size());
//        PaymentResultQueryResponse response = responses.get(0);
//        assertEquals(TXN_ID, response.getTransactionId());
//        assertEquals(BATCH_ID, response.getBatchId());
//        assertEquals(BatchStatusEnum.DISPATCHED.getCode(), response.getBatchStatus());
//        assertFalse(response.getBatchTerminal());
//        assertEquals("PROCESSING", response.getStatus());
//        assertFalse(response.getTerminal());
//        assertEquals("BG3", response.getDownstreamSystem());
//        assertEquals("BG3-SEQ1", response.getDownstreamReference());
//        assertEquals("BG3_REJECTED", response.getErrorCode());
//        assertEquals("Rejected by BG3", response.getErrorMessage());
//    }
//
//    @Test
//    void queryApiReadsBatchTransactionsAsList() {
//        PaymentTxnMainMapper queryTxnMapper = mock(PaymentTxnMainMapper.class);
//        PaymentBatchStatusService batchStatusService = mock(PaymentBatchStatusService.class);
//        PaymentTxnEventService eventService = mock(PaymentTxnEventService.class);
//        PaymentTxnMainEntity first = txn(BATCH_ID, TXN_ID, 1, PaymentStatusEnum.COMPLETED.getCode());
//        PaymentTxnMainEntity second = txn(BATCH_ID, "BCO20260616090000000003", 2,
//                PaymentStatusEnum.PROCESSING.getCode());
//
//        when(queryTxnMapper.selectList(any(Wrapper.class))).thenReturn(List.of(first, second));
//        when(batchStatusService.summarize(BATCH_ID))
//                .thenReturn(new PaymentBatchStatusService.BatchStatusSummary(
//                        BatchStatusEnum.PARTIAL_SUCCESS.getCode(), false, 2L, 1L, 0L));
//        when(eventService.latestEventSummary(anyString())).thenReturn(Optional.empty());
//
//        PaymentResultQueryRequest request = new PaymentResultQueryRequest();
//        request.setBatchId(BATCH_ID);
//
//        List<PaymentResultQueryResponse> responses =
//                new PaymentResultQueryService(queryTxnMapper, batchStatusService, eventService).query(request);
//
//        assertEquals(2, responses.size());
//        assertEquals(TXN_ID, responses.get(0).getTransactionId());
//        assertEquals("BCO20260616090000000003", responses.get(1).getTransactionId());
//        assertEquals(BatchStatusEnum.PARTIAL_SUCCESS.getCode(), responses.get(0).getBatchStatus());
//        assertEquals("SUCCESS", responses.get(0).getStatus());
//        assertEquals("PROCESSING", responses.get(1).getStatus());
//    }
//
//    private static SingleCreditTransferRequest singleRequest() {
//        SingleCreditTransferRequest request = new SingleCreditTransferRequest();
//        request.setChannel("BCO");
//        request.setTransactionId(TXN_ID);
//        request.setChannelReference("REF-1");
//        request.setTransactionType(TransactionTypeEnum.INTERNAL.getCode());
//        request.setTimeOfTransfer("NOW");
//        request.setDebitAmount(new BigDecimal("100.00"));
//        request.setDebitAmountCcy("HKD");
//        request.setHkdEquivalentAmount(new BigDecimal("88.88"));
//        request.setSettlementCurrency("HKD");
//        request.setPayerType("CORPORATE");
//        request.setPayerAccountNo("1234567890");
//        request.setPayerAccountType("6805");
//        request.setPayerAccountCurrency("HKD");
//        request.setPayerName("ABC COMPANY LIMITED");
//        request.setPayeeType("ACCOUNT");
//        request.setPayeeName("BENEFICIARY LIMITED");
//        request.setPayeeAccountNo("9876543210");
//        request.setPayeeAccountCurrency("HKD");
//        return request;
//    }
//
////    private static FpsEphInstructionRequest fpsWithApiPaymentSource() {
////        FpsEphInstructionRequest fps = new FpsEphInstructionRequest();
////        fps.setPaymentSource("CCB");
////        fps.setEnquiryType("ALL");
////        fps.setCostCenterCode("CYB");
////        fps.setFeeCode("SHA");
////        fps.setPayeeIdentificationType("BBAN");
////        fps.setAlnovaLimitCheckInd("Y");
////        fps.setInstructionId("INS20260616090000000002");
////        fps.setClearingSystem("FPS");
////        fps.setPurposeCode("CXBSNS");
////        fps.setVipIndicator("N");
////        fps.setDebitInternalAccount("123456789012345");
////        fps.setProductType("8805");
////        return fps;
////    }
//
//    private static EphProperties ephProperties() {
//        EphProperties properties = new EphProperties();
//        properties.getControl().setTransactionType("TOB");
//        properties.getControl().setAccountVerificationOption("PERFORM_PYE_VRF");
//        properties.getControl().setSettlementMethod("CLRG");
//        properties.getControl().setDebtorMemberId("015");
//        properties.getControl().setChargeBearer("SLEV");
//        properties.getControl().setDebitMop("BOOK");
//        properties.getControl().setCustomerType("CORP");
//        return properties;
//    }
//
//    private static PaymentTxnMainEntity txn(String batchId, String transactionId, Integer orderId, String status) {
//        PaymentTxnMainEntity txn = new PaymentTxnMainEntity();
//        txn.setBatchId(batchId);
//        txn.setTransactionId(transactionId);
//        txn.setOrderId(orderId);
//        txn.setChannel("BCO");
//        txn.setTransactionType(TransactionTypeEnum.INTERNAL.getCode());
//        txn.setPaymentStatus(status);
//        txn.setPayerAccountNo("1234567890");
//        txn.setDebitAmount(new BigDecimal("100.00"));
//        txn.setDebitAmountCcy("HKD");
//        txn.setSettlementCurrency("HKD");
//        txn.setIsDeleted("N");
//        return txn;
//    }
//
//}
