package com.bea.payment.bulk.validator;

import com.bea.payment.bulk.constants.TransactionTypeEnum;
import com.bea.payment.common.exception.ValidationException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TransactionDetailValidatorTest {

    @Test
    void fpsAndChatsRequirePayeeName() {
        assertThrows(ValidationException.class,
                () -> TransactionDetailValidator.requirePayeeNameForTransactionType("FPS", "  "));
        assertThrows(ValidationException.class,
                () -> TransactionDetailValidator.requirePayeeNameForTransactionType("CHATS", null));
        assertDoesNotThrow(
                () -> TransactionDetailValidator.requirePayeeNameForTransactionType("INTERNAL", null));
    }

    @Test
    void unsupportedTelegraphicTransferIsRejectedAtValidationBoundary() {
        assertThrows(ValidationException.class, () -> TransactionTypeEnum.from("TT"));
    }
}
