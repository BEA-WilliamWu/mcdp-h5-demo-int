@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js is not available in PATH.
  exit /b 1
)

if not exist "node_modules\vite\bin\vite.js" (
  echo [ERROR] Missing local Vite dependency: node_modules\vite\bin\vite.js
  echo.
  echo Run this once on a Windows machine that can access npm registry:
  echo   npm.cmd ci
  echo.
  echo If this BEA machine cannot install dependencies, copy a Windows-generated node_modules folder.
  echo Do not copy node_modules generated on macOS.
  exit /b 1
)

node node_modules\vite\bin\vite.js build
